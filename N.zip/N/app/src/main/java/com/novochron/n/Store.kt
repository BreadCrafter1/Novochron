package com.novochron.n

import android.content.Context

/**
 * Everything N remembers between launches.
 *
 * The shared repo is hardcoded below — every install of this particular build talks to the
 * same repo, so there's nothing to configure except a display name.
 *
 * The GitHub token is NOT hardcoded here. It's injected at build time into BuildConfig from
 * either local.properties (git-ignored — see local.properties.example) for local builds, or
 * an N_GH_TOKEN GitHub Actions secret for CI builds. See app/build.gradle.kts.
 *
 * ⚠️ It still ends up baked into the built APK as a string constant — anyone with the APK can
 * pull it back out with a decompiler or even `strings`, same as before. What this setup fixes
 * is the token being committed to git/GitHub, where secret scanning would auto-revoke it (or
 * where anyone with repo access could read it out of history) regardless of whether the repo
 * is public or private. Use a token scoped to only this one repo, and if it's ever exposed
 * more widely than intended, rotate it on GitHub (Settings → Developer settings → Personal
 * access tokens).
 */
class Store(ctx: Context) {
    private val prefs = ctx.applicationContext.getSharedPreferences("n_prefs", Context.MODE_PRIVATE)

    val repo: String = "BreadCrafter1/chatter"
    val token: String = BuildConfig.GITHUB_TOKEN

    var branch: String
        get() = prefs.getString("branch", "main") ?: "main"
        set(v) { prefs.edit().putString("branch", v.trim().ifBlank { "main" }).apply() }

    var name: String
        get() = prefs.getString("name", "") ?: ""
        set(v) { prefs.edit().putString("name", v.trim()).apply() }
}
