package com.atlas.assistant

import android.content.Context
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Runs Silero VAD (see SileroVad.kt) over a live mic tap so Novochron can tell the instant the user
 * actually stops talking, instead of waiting on the speech recognizer's own fixed silence timer
 * (see Listener's EXTRA_SPEECH_INPUT_..._MILLIS extras, which stay in place as the fallback below).
 *
 * This opens its own short-lived [AudioRecord] alongside whatever the active SpeechRecognizer is doing.
 * Two things read the mic at once. On a device that doesn't actually support concurrent capture,
 * Android doesn't fail the second [AudioRecord] open with an error — it just silently routes real audio
 * to only one of the two clients and feeds the other zeroes, with no exception to catch, and there is no
 * public API to check in advance whether a device can do this. Left unchecked, that can starve the
 * SpeechRecognizer of audio while this tap keeps working fine, so the recognizer never hears anything and
 * the UI sits on "Listening…" forever. Two mitigations: this tap uses [MediaRecorder.AudioSource.MIC]
 * rather than [MediaRecorder.AudioSource.VOICE_RECOGNITION] specifically so it isn't requesting the same
 * capture use case as the recognizer (much less likely to collide), and the feature defaults off in
 * [Store.instantResponseEnabled] so nobody hits this by default; it's opt-in for people who want snappier
 * turn-taking and whose phone handles it fine. [start] still fails closed the same way any optional
 * hardware-dependent feature in this app does: if the mic tap can't be opened, or the bundled model won't
 * load, [start] just returns false and Novochron keeps using the classic silence timer, exactly as if this
 * feature didn't exist.
 *
 * Fires [onSpeechEnd] once per utterance: after real speech was heard, then [SILENCE_HANGOVER_MS] of
 * genuine silence (per the model, not just low volume) follows. Keeps running and re-arms itself for
 * the next utterance automatically.
 */
class VadEndpointer(private val ctx: Context) {

    private var vad: SileroVad? = null
    private var record: AudioRecord? = null
    private var thread: Thread? = null
    private val running = AtomicBoolean(false)

    /** Starts the mic tap. Returns false immediately (fails closed) if anything about this device can't support it. */
    fun start(onSpeechEnd: () -> Unit): Boolean {
        if (running.get()) return true
        val model = vad ?: SileroVad.load(ctx)?.also { vad = it } ?: return false
        model.reset()

        val minBuf = try {
            AudioRecord.getMinBufferSize(SileroVad.SAMPLE_RATE_HZ, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        } catch (e: Exception) {
            -1
        }
        if (minBuf <= 0) return false

        val bufBytes = (minBuf.coerceAtLeast(SileroVad.FRAME_SAMPLES * 2 * 4))
        val rec = try {
            AudioRecord(
                MediaRecorder.AudioSource.MIC,
                SileroVad.SAMPLE_RATE_HZ,
                AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT,
                bufBytes
            )
        } catch (e: SecurityException) {
            null
        } catch (e: Exception) {
            null
        }
        if (rec == null || rec.state != AudioRecord.STATE_INITIALIZED) {
            rec?.release()
            return false
        }

        try {
            rec.startRecording()
        } catch (e: Exception) {
            rec.release()
            return false
        }
        if (rec.recordingState != AudioRecord.RECORDSTATE_RECORDING) {
            rec.release()
            return false
        }

        record = rec
        running.set(true)
        thread = Thread({ loop(rec, model, onSpeechEnd) }, "vad-endpointer").apply {
            isDaemon = true
            start()
        }
        return true
    }

    fun stop() {
        running.set(false)
        thread?.let { try { it.join(300) } catch (e: InterruptedException) { } }
        thread = null
        try { record?.stop() } catch (e: Exception) { }
        try { record?.release() } catch (e: Exception) { }
        record = null
    }

    private fun loop(rec: AudioRecord, model: SileroVad, onSpeechEnd: () -> Unit) {
        val chunk = ShortArray(SileroVad.FRAME_SAMPLES)
        var speechActive = false
        var silenceMsSinceSpeech = 0
        val frameMs = (SileroVad.FRAME_SAMPLES * 1000L / SileroVad.SAMPLE_RATE_HZ).toInt()

        while (running.get()) {
            val n = try {
                rec.read(chunk, 0, chunk.size)
            } catch (e: Exception) {
                break
            }
            if (n < 0) break // AudioRecord error code (e.g. ERROR_DEAD_OBJECT) - stop rather than spin
            if (n != chunk.size) continue // partial/short read - skip this frame rather than feed it garbage

            val prob = try {
                model.speechProbability(chunk)
            } catch (e: Exception) {
                break
            }
            DebugTelemetry.recordVadFrame(prob)

            if (prob >= SPEECH_THRESHOLD) {
                speechActive = true
                silenceMsSinceSpeech = 0
            } else if (speechActive) {
                if (prob <= SILENCE_THRESHOLD) {
                    silenceMsSinceSpeech += frameMs
                    if (silenceMsSinceSpeech >= SILENCE_HANGOVER_MS) {
                        speechActive = false
                        silenceMsSinceSpeech = 0
                        DebugTelemetry.recordVadEndpoint()
                        onSpeechEnd()
                    }
                }
                // between the two thresholds: ambiguous frame, neither resets nor advances the hangover clock
            }
        }
    }

    companion object {
        // Hysteresis band so one borderline frame doesn't flip the state back and forth.
        private const val SPEECH_THRESHOLD = 0.5f
        private const val SILENCE_THRESHOLD = 0.35f
        // A short natural breath mid-sentence is shorter than this, so it doesn't cut people off — but
        // Novochron no longer sits there waiting once they're actually done, unlike the old fixed timer.
        private const val SILENCE_HANGOVER_MS = 260
    }
}
