package com.atlas.assistant

import ai.onnxruntime.OnnxTensor
import ai.onnxruntime.OrtEnvironment
import ai.onnxruntime.OrtSession
import android.content.Context
import java.nio.FloatBuffer
import java.nio.LongBuffer

/**
 * Thin wrapper around Silero VAD (assets/models/silero_vad.onnx, MIT-licensed, bundled with the app —
 * see build.gradle.kts), the small neural network that decides frame-by-frame whether a chunk of audio
 * is speech or silence. Unlike the fixed-length silence timer the old EXTRA_SPEECH_INPUT_..._MILLIS
 * approach used, this actually listens to what's in the audio, so it reacts the instant real silence
 * starts instead of guessing from a stopwatch. See VadEndpointer for how the probabilities this returns
 * are turned into a single "the user just stopped talking" event.
 *
 * The model is stateful (it carries a small recurrent state between chunks, [state]/[stateShape] below),
 * so one instance must keep seeing every chunk of one continuous audio stream in order — call [reset]
 * whenever the stream restarts (e.g. a fresh recognizer session).
 */
class SileroVad private constructor(private val session: OrtSession, private val env: OrtEnvironment) {

    // [2, batch=1, 128]: the model's own recurrent state, fed back in on every call and replaced with
    // whatever the model returns. Starts at zero, same as a fresh LSTM.
    private var state = FloatArray(2 * 1 * 128)

    fun reset() {
        state = FloatArray(2 * 1 * 128)
    }

    /**
     * Runs one chunk through the model. [samples] must be exactly [FRAME_SAMPLES] 16-bit PCM samples
     * at [SAMPLE_RATE_HZ]. Returns the probability (0..1) that this chunk contains speech.
     */
    @Synchronized
    fun speechProbability(samples: ShortArray): Float {
        require(samples.size == FRAME_SAMPLES) { "Silero VAD expects exactly $FRAME_SAMPLES samples per chunk" }
        val input = FloatArray(samples.size) { samples[it] / 32768f }
        OnnxTensor.createTensor(env, FloatBuffer.wrap(input), longArrayOf(1, input.size.toLong())).use { inputTensor ->
            OnnxTensor.createTensor(env, FloatBuffer.wrap(state), longArrayOf(2, 1, 128)).use { stateTensor ->
                OnnxTensor.createTensor(env, LongBuffer.wrap(longArrayOf(SAMPLE_RATE_HZ.toLong())), longArrayOf()).use { srTensor ->
                    val inputs = mapOf("input" to inputTensor, "state" to stateTensor, "sr" to srTensor)
                    session.run(inputs).use { result ->
                        @Suppress("UNCHECKED_CAST")
                        val prob = ((result.get(0).value) as Array<FloatArray>)[0][0]
                        @Suppress("UNCHECKED_CAST")
                        val newState = result.get(1).value as Array<Array<FloatArray>>
                        var i = 0
                        for (a in newState) for (row in a) for (x in row) state[i++] = x
                        return prob
                    }
                }
            }
        }
    }

    fun close() {
        try { session.close() } catch (e: Exception) { }
    }

    companion object {
        const val SAMPLE_RATE_HZ = 16_000
        /** 32 ms per chunk at 16 kHz — the window size this model was trained on. */
        const val FRAME_SAMPLES = 512

        /** Loads the bundled model. Returns null (fails closed) if onnxruntime or the asset can't be read. */
        fun load(ctx: Context): SileroVad? = try {
            val bytes = ctx.assets.open("models/silero_vad.onnx").use { it.readBytes() }
            val env = OrtEnvironment.getEnvironment()
            val session = env.createSession(bytes, OrtSession.SessionOptions())
            SileroVad(session, env)
        } catch (e: Exception) {
            null
        }
    }
}
