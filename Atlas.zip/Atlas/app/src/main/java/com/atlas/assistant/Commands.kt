package com.atlas.assistant

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.net.Uri
import android.os.Build
import android.provider.AlarmClock
import android.provider.ContactsContract
import android.telephony.SmsManager
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlin.math.roundToInt

/**
 * Rule-based phone control. Works fully offline and instantly.
 * handle() returns the spoken reply, or null if the text is not a command.
 */
class Commands(private val ctx: Context, private val store: Store) {

    var onStopListening: (() -> Unit)? = null
    var onOpenArtifact: ((Long) -> Unit)? = null
    var onOpenLibrary: (() -> Unit)? = null
    /** "Turn off, computer" (or a few equivalents) — closes Novochron entirely, not just the voice. */
    var onExitApp: (() -> Unit)? = null
    private var pending: (() -> String)? = null
    private val maps = Maps.get(ctx)
    private val controls = Controls(ctx)

    private val yes = Regex("^(yes|yeah|yep|yup|confirm|send it|do it|go ahead|sure)\\b")
    private val no = Regex("^(no|nope|cancel|don't|never mind|nevermind)\\b")

    // Strips conversational wrapping ("hey Novochron, can you please...") so natural phrasing still hits the
    // instant, offline command matches below instead of waiting on a round trip to the online model.
    private val FILLER_PREFIX = Regex(
        "^(?:hey\\s+|hi\\s+|okay\\s+|ok\\s+|so\\s+|novochron[,]?\\s+|please\\s+|" +
            "can\\s+you\\s+|could\\s+you\\s+|would\\s+you\\s+|will\\s+you\\s+|go\\s+ahead\\s+and\\s+)+",
        RegexOption.IGNORE_CASE
    )

    fun handle(raw: String): String? {
        val trimmed = raw.trim().trimEnd('.', '!', '?', ',').trim()
        if (trimmed.isEmpty()) return null
        val text = FILLER_PREFIX.replace(trimmed, "").ifBlank { trimmed }
        val t = text.lowercase(Locale.US)

        // confirmation for a risky action (sending a text)
        val action = pending
        if (action != null) {
            pending = null
            if (yes.containsMatchIn(t)) return action()
            if (no.containsMatchIn(t)) return "Cancelled."
        }

        // full shutdown - closes Novochron entirely, not just the voice. Checked before the plain
        // "voice off" rule below since both start with "turn off".
        if (EXIT.containsMatchIn(t)) {
            onExitApp?.invoke()
            return "Shutting down."
        }

        // voice off
        if (Regex("^(stop listening|go to sleep|voice off|turn off (the )?(voice|mic|microphone|listening)|that'?s all( for now)?|goodbye)\\b").containsMatchIn(t)) {
            onStopListening?.invoke()
            return "Understood. Going quiet."
        }

        // offline maps: learn a place, or ask how far it is. Checked before the general "remember ..."
        // memory rule below, since "remember this place as home" would otherwise be saved as a plain fact.
        Regex("^(?:remember|save|learn|mark)\\s+(?:this place|this location|this spot|here)\\s+as\\s+(.+)$", RegexOption.IGNORE_CASE)
            .find(text)?.let { return learnPlace(it.groupValues[1].trim()) }
        Regex("^this (?:place|spot|location) is\\s+(.+)$", RegexOption.IGNORE_CASE).find(text)?.let {
            return learnPlace(it.groupValues[1].trim())
        }
        Regex("^(?:how (?:far|many (?:kilometres|kilometers|km|miles))(?: away)?(?: is| to)|distance to|how much (?:further|farther|more) to)\\s+(.+)$", RegexOption.IGNORE_CASE)
            .find(text)?.let { return distanceTo(it.groupValues[1].trim()) }
        if (Regex("^(?:what places (?:do you know|have you learned)|list (?:my |the )?places|what (?:do you|have you) (?:remember|learned) about (?:my )?places)").containsMatchIn(t)) {
            return listPlaces()
        }
        Regex("^forget (?:the )?(?:place|location)\\s+(.+)$", RegexOption.IGNORE_CASE).find(text)?.let {
            return if (maps.forgetPlace(it.groupValues[1].trim())) "Done. That place is forgotten."
            else "I don't have that place saved."
        }

        // memory
        Regex("^(?:please )?(?:remember|memorize|make a note|note)(?: that)?\\s+(.+)$", RegexOption.IGNORE_CASE).find(text)?.let {
            store.addMemory(it.groupValues[1])
            return "Got it. I'll remember that."
        }
        if (Regex("^forget (everything|all)").containsMatchIn(t)) {
            store.clearMemories()
            return "Memory wiped."
        }
        Regex("^forget (?:about |that )?(.+)$").find(t)?.let {
            val n = store.forget(it.groupValues[1])
            return if (n > 0) "Done. Forgotten." else "I don't have anything saved about that."
        }
        if (Regex("^(what do you (remember|know)( about me)?|what('s| is) in your memory|list (my )?memories|what have i told you)").containsMatchIn(t)) {
            val m = store.memories().takeLast(6)
            return if (m.isEmpty()) "I haven't saved anything yet." else "Here's what I have. " + m.joinToString(". ") { it.text }
        }

        // time and date
        if (Regex("what('s| is)? the time|what time is it|tell me the time|current time").containsMatchIn(t))
            return "It's " + SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date())
        if (Regex("what('s| is)? (the |today'?s )?date|what day is it|what is today").containsMatchIn(t))
            return "Today is " + SimpleDateFormat("EEEE, MMMM d", Locale.getDefault()).format(Date())

        // flashlight
        if (Regex("^(turn|switch)\\b.*\\b(flashlight|torch)\\b|^(flashlight|torch)\\b.*\\b(on|off)\\b").containsMatchIn(t))
            return torch(!Regex("\\boff\\b").containsMatchIn(t))

        // phone settings: Wi-Fi, Bluetooth, mobile data, location, airplane mode, Do Not Disturb, volume,
        // brightness and so on (see Controls.kt for what Android lets Novochron flip and what it only opens)
        controls.handle(t)?.let { return it }

        // timer
        if (Regex("^(set|start|create|make)\\b.*\\btimer\\b|^timer\\b").containsMatchIn(t)) {
            val secs = durationSeconds(t) ?: return "For how long? Say something like, set a timer for 10 minutes."
            return startTimer(secs)
        }

        // alarm
        if (Regex("^(set|create|make|add)\\b.*\\balarm\\b|^wake me\\b|^alarm\\b").containsMatchIn(t)) {
            if (Regex("\\bin\\s+\\d|\\bin (an|half an) hour").containsMatchIn(t)) {
                durationSeconds(t)?.let { return startTimer(it) }
            }
            val time = parseClock(t) ?: return "What time? Say something like, set an alarm for 7:30 AM."
            return setAlarm(time.first, time.second)
        }

        // reopen what Novochron built, or show the library
        if (REOPEN.containsMatchIn(t)) {
            val a = store.latestArtifact() ?: return "I haven't built anything yet."
            onOpenArtifact?.invoke(a.id)
            return "Opening ${a.title}."
        }
        if (LIBRARY.containsMatchIn(t)) {
            onOpenLibrary?.invoke()
            return "Here's your library."
        }

        // call
        Regex("^(?:call|phone|dial)(?: up)?\\s+(.+)$").find(t)?.let { return call(it.groupValues[1].trim()) }

        // message
        val msgRe = Regex("^(?:send\\s+)?(?:an?\\s+)?(?:text|message|sms)\\s+(?:to\\s+)?(.+?)\\s+(?:saying|that says|and say|say|with the message)\\s+(.+)$", RegexOption.IGNORE_CASE)
        val shortRe = Regex("^(?:text|message|sms)\\s+(\\S+)\\s+(.+)$", RegexOption.IGNORE_CASE)
        (msgRe.find(text) ?: shortRe.find(text))?.let {
            return message(it.groupValues[1].trim(), it.groupValues[2].trim())
        }

        // open app
        Regex("^(open|launch|start|run)\\s+(?:up\\s+)?(.+)$").find(t)?.let {
            val verb = it.groupValues[1]
            val name = it.groupValues[2].trim()
            val r = openApp(name)
            if (r != null) return r
            if (verb == "open" || verb == "launch") return "I couldn't find an app called $name."
        }

        return null
    }

    // ---------- helpers ----------
    private fun has(perm: String) = ctx.checkSelfPermission(perm) == PackageManager.PERMISSION_GRANTED

    private fun launch(i: Intent): Boolean = try {
        ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); true
    } catch (e: Exception) { false }

    private fun durationSeconds(input: String): Int? {
        val t = input.replace("an hour", "1 hour")
        var total = 0
        var found = false
        Regex("(\\d+(?:\\.\\d+)?)\\s*(hours?|hrs?|minutes?|mins?|seconds?|secs?)").findAll(t).forEach { m ->
            val n = m.groupValues[1].toDouble()
            val unit = m.groupValues[2]
            found = true
            total += (n * when {
                unit.startsWith("h") -> 3600
                unit.startsWith("m") -> 60
                else -> 1
            }).toInt()
        }
        if (Regex("half an hour|half hour").containsMatchIn(t)) { total += 1800; found = true }
        return if (found && total > 0) total else null
    }

    private fun spoken(secs: Int): String {
        val h = secs / 3600
        val m = secs % 3600 / 60
        val s = secs % 60
        return listOfNotNull(
            if (h > 0) "$h hour${if (h > 1) "s" else ""}" else null,
            if (m > 0) "$m minute${if (m > 1) "s" else ""}" else null,
            if (s > 0) "$s second${if (s > 1) "s" else ""}" else null
        ).joinToString(" ")
    }

    private fun startTimer(secs: Int): String {
        val i = Intent(AlarmClock.ACTION_SET_TIMER)
            .putExtra(AlarmClock.EXTRA_LENGTH, secs)
            .putExtra(AlarmClock.EXTRA_MESSAGE, "Novochron")
            .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        return if (launch(i)) "Timer set for ${spoken(secs)}." else "I couldn't reach the clock app."
    }

    private fun parseClock(t: String): Pair<Int, Int>? {
        if (t.contains("midnight")) return 0 to 0
        if (t.contains("noon")) return 12 to 0
        val m = Regex("(\\d{1,2})(?:[:.\\s]?(\\d{2}))?\\s*(a\\.?m\\.?|p\\.?m\\.?)?").find(t) ?: return null
        var h = m.groupValues[1].toInt()
        val min = m.groupValues[2].ifEmpty { "0" }.toInt()
        if (h > 23 || min > 59) return null
        val mer = m.groupValues[3].firstOrNull()
        when (mer) {
            'a' -> if (h == 12) h = 0
            'p' -> if (h < 12) h += 12
            else -> if (h in 1..12) {
                // no am/pm said: pick whichever comes up soonest
                val now = Calendar.getInstance()
                val nowMin = now.get(Calendar.HOUR_OF_DAY) * 60 + now.get(Calendar.MINUTE)
                val c1 = (h % 12) * 60 + min
                val c2 = c1 + 720
                fun wait(c: Int) = ((c - nowMin) + 1440) % 1440
                h = if (wait(c1) <= wait(c2)) h % 12 else h % 12 + 12
            }
        }
        return h to min
    }

    private fun setAlarm(h: Int, m: Int): String {
        val i = Intent(AlarmClock.ACTION_SET_ALARM)
            .putExtra(AlarmClock.EXTRA_HOUR, h)
            .putExtra(AlarmClock.EXTRA_MINUTES, m)
            .putExtra(AlarmClock.EXTRA_MESSAGE, "Novochron")
            .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        val cal = Calendar.getInstance().apply { set(Calendar.HOUR_OF_DAY, h); set(Calendar.MINUTE, m) }
        val label = SimpleDateFormat("h:mm a", Locale.getDefault()).format(cal.time)
        return if (launch(i)) "Alarm set for $label." else "I couldn't reach the clock app."
    }

    // ---------- offline maps ----------

    private fun learnPlace(label: String): String {
        if (label.isBlank()) return "What should I call this place?"
        val hasPerm = ctx.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
            ctx.checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
        if (!hasPerm) return "I need location permission to learn places. Enable it in app settings."
        val loc = maps.currentLocation() ?: return "I don't have a location fix yet. Give me a moment with a clear view of the sky and try again."
        maps.savePlace(label, loc.latitude, loc.longitude)
        return "Got it. I'll remember this as $label."
    }

    private fun distanceTo(rawLabel: String): String {
        val label = rawLabel.trimEnd('?', '.', '!').trim()
        val place = maps.findPlace(label) ?: return "I don't have $label saved yet. Say, remember this place as $label, next time you're there."
        val hasPerm = ctx.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
            ctx.checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
        if (!hasPerm) return "I need location permission to work that out. Enable it in app settings."
        val here = maps.currentLocation() ?: return "I don't have a location fix yet. Give me a moment and try again."
        val km = Maps.haversineKm(here.latitude, here.longitude, place.lat, place.lon)
        val text = if (km < 1.0) "${(km * 1000).roundToInt()} metres" else "${roundKm(km)} kilometres"
        return "${place.label} is about $text away."
    }

    private fun roundKm(km: Double): String =
        if (km < 10) String.format(Locale.US, "%.1f", km) else km.roundToInt().toString()

    private fun listPlaces(): String {
        val p = maps.places()
        return if (p.isEmpty()) "I haven't learned any places yet. Say, remember this place as home, to teach me one."
        else "I know " + p.joinToString(", ") { it.label } + "."
    }

    private fun torch(on: Boolean): String = try {
        val cm = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
        val id = cm.cameraIdList.firstOrNull {
            cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
        }
        if (id == null) "This phone has no flashlight." else {
            cm.setTorchMode(id, on)
            if (on) "Flashlight on." else "Flashlight off."
        }
    } catch (e: Exception) { "I couldn't reach the flashlight." }

    private class Target(val label: String = "", val number: String = "", val error: String? = null)

    private fun resolve(name: String): Target {
        val digits = name.replace(Regex("[\\s\\-().]"), "")
        if (digits.matches(Regex("\\+?\\d{3,}"))) return Target(name, digits)
        if (!has(Manifest.permission.READ_CONTACTS))
            return Target(error = "I need contacts permission to find people. Enable it in app settings.")
        val c = findContact(name) ?: return Target(error = "I couldn't find $name in your contacts.")
        return Target(c.first, c.second)
    }

    private fun findContact(name: String): Pair<String, String>? {
        val rows = mutableListOf<Pair<String, String>>()
        val p = ContactsContract.CommonDataKinds.Phone.CONTENT_URI
        val cols = arrayOf(
            ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
            ContactsContract.CommonDataKinds.Phone.NUMBER
        )
        ctx.contentResolver.query(
            p, cols, "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?", arrayOf("%$name%"), null
        )?.use { c ->
            while (c.moveToNext()) rows.add((c.getString(0) ?: "") to (c.getString(1) ?: ""))
        }
        return rows.minByOrNull { if (it.first.equals(name, ignoreCase = true)) 0 else it.first.length }
    }

    private fun call(target: String): String {
        val r = resolve(target)
        if (r.error != null) return r.error
        val uri = Uri.parse("tel:" + Uri.encode(r.number))
        val action = if (has(Manifest.permission.CALL_PHONE)) Intent.ACTION_CALL else Intent.ACTION_DIAL
        return if (launch(Intent(action, uri))) "Calling ${r.label}." else "I couldn't place the call."
    }

    private fun message(name: String, body: String): String {
        val r = resolve(name)
        if (r.error != null) return r.error
        pending = { sendSms(r.number, r.label, body) }
        return "Send to ${r.label}: $body. Should I send it?"
    }

    @Suppress("DEPRECATION")
    private fun smsManager(): SmsManager =
        if (Build.VERSION.SDK_INT >= 31) ctx.getSystemService(SmsManager::class.java) else SmsManager.getDefault()

    private fun sendSms(number: String, label: String, body: String): String {
        if (!has(Manifest.permission.SEND_SMS)) {
            val i = Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:" + Uri.encode(number))).putExtra("sms_body", body)
            return if (launch(i)) "I can't send directly without permission, so I opened the message for you." else "I couldn't send that."
        }
        return try {
            val sms = smsManager()
            sms.sendMultipartTextMessage(number, null, sms.divideMessage(body), null, null)
            "Message sent to $label."
        } catch (e: Exception) { "The message failed to send." }
    }

    private fun openApp(query: String): String? {
        val pm = ctx.packageManager
        val q = query.lowercase(Locale.US).removePrefix("the ").removeSuffix(" app").replace(" ", "").trim()
        if (q.isEmpty()) return null
        val main = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        var best: Pair<String, String>? = null
        var bestScore = 0
        @Suppress("DEPRECATION")
        for (ri in pm.queryIntentActivities(main, 0)) {
            val label = ri.loadLabel(pm).toString()
            val l = label.lowercase(Locale.US).replace(" ", "")
            val score = when {
                l == q -> 4
                l.startsWith(q) -> 3
                l.contains(q) -> 2
                l.length >= 4 && q.contains(l) -> 1
                else -> 0
            }
            if (score > bestScore) { bestScore = score; best = label to ri.activityInfo.packageName }
        }
        val (label, pkg) = best ?: return null
        val intent = pm.getLaunchIntentForPackage(pkg) ?: return null
        return if (launch(intent)) "Opening $label." else "I couldn't open $label."
    }

    companion object {
        /** "Turn off, computer" / "computer, turn off" / a few plain-English equivalents. */
        val EXIT = Regex(
            "^(?:turn off,?\\s*computer\\b|computer,?\\s*turn off\\b|shut down,?\\s*computer\\b|" +
                "computer,?\\s*shut down\\b|exit (?:the )?app\\b|quit (?:the )?app\\b|close (?:the )?app\\b|" +
                "shut down novochron\\b|power off\\b)",
            RegexOption.IGNORE_CASE
        )
        val REOPEN = Regex(
            "^(?:open|show|reopen|bring up|pull up)\\s+(?:that|it|the (?:last|latest|previous|recent)(?: one| artifact| app| game| puzzle)?|" +
                "my (?:last|latest) (?:artifact|app|game|puzzle))(?:\\s+again)?$"
        )
        val LIBRARY = Regex("^(?:open|show)\\s+(?:my |the )?(?:library|artifacts|creations)$")
    }
}
