package com.atlas.assistant

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * "[chats]": lets separate conversations with Novochron be kept apart and switched between, instead of
 * everything living in one endless history. Each row is one saved chat (see Store's `chats` table /
 * ChatInfo); tapping one makes it the active chat everywhere else in the app (voice, typed, the message
 * log) and closes this screen. Renaming and deleting happen right here, inline, same as the artifact
 * library. All local — nothing here ever leaves the phone.
 */
@Composable
fun ChatsScreen(engine: Engine, onClose: () -> Unit) {
    var tick by remember { mutableStateOf(0) }
    val chats = remember(tick) { engine.store.listChats() }
    val currentId = engine.store.currentChatId
    var renaming by remember { mutableStateOf<ChatInfo?>(null) }
    var renameText by remember { mutableStateOf("") }
    var confirmDelete by remember { mutableStateOf<ChatInfo?>(null) }

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        Column(Modifier.fillMaxSize().padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                TermTextKey("[back]", onClick = onClose)
                Spacer(Modifier.weight(1f))
                Text("chats", color = Accent, fontFamily = TermFont, fontSize = 18.sp)
                Spacer(Modifier.weight(1f))
                TermTextKey("[+ new]", tone = Accent, onClick = {
                    engine.newChat()
                    onClose()
                })
            }
            Spacer(Modifier.height(8.dp))
            Text(
                "Separate, switchable conversations — start a new one to talk about something else without " +
                    "losing this thread. Only the open chat is used for voice and typed replies.",
                color = Dim, fontFamily = TermFont, fontSize = 12.sp
            )
            Spacer(Modifier.height(14.dp))

            if (chats.isEmpty()) {
                Text("No chats yet.", color = Dim, fontFamily = TermFont, fontSize = 13.sp)
            } else {
                LazyColumn(Modifier.fillMaxSize()) {
                    items(chats.size) { i ->
                        val c = chats[i]
                        val active = c.id == currentId
                        Column(
                            Modifier
                                .fillMaxWidth()
                                .clickable {
                                    if (!active) engine.switchChat(c.id)
                                    onClose()
                                }
                                .padding(vertical = 10.dp)
                        ) {
                            Row(
                                Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    (if (active) "> " else "  ") + c.title,
                                    color = if (active) Accent else Ink,
                                    fontFamily = TermFont,
                                    fontWeight = if (active) FontWeight.Bold else FontWeight.Normal,
                                    fontSize = 15.sp,
                                    maxLines = 1,
                                    modifier = Modifier.weight(1f)
                                )
                                TermTextKey("[rename]", hpad = 6, onClick = { renaming = c; renameText = c.title })
                                if (chats.size > 1) {
                                    TermTextKey("[del]", tone = Warn, hpad = 6, onClick = { confirmDelete = c })
                                }
                            }
                            Text(
                                "${c.messageCount} message${if (c.messageCount == 1) "" else "s"} · ${relTime(c.updatedTs)}",
                                color = Dim, fontFamily = TermFont, fontSize = 11.sp
                            )
                            Box(Modifier.fillMaxWidth().height(1.dp).background(Line).padding(top = 6.dp))
                        }
                    }
                }
            }
        }
    }

    renaming?.let { c ->
        AlertDialog(
            onDismissRequest = { renaming = null },
            containerColor = Color(0xFF0B0B0B),
            title = { Text("[ rename chat ]", color = Accent, fontFamily = TermFont, fontWeight = FontWeight.Bold) },
            text = {
                OutlinedTextField(
                    value = renameText,
                    onValueChange = { renameText = it },
                    singleLine = true,
                    colors = fieldColors(),
                    modifier = Modifier.fillMaxWidth()
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    engine.store.renameChat(c.id, renameText)
                    renaming = null
                    tick++
                }) { Text("Save", color = Accent, fontFamily = TermFont) }
            },
            dismissButton = {
                TextButton(onClick = { renaming = null }) { Text("Cancel", color = Ink, fontFamily = TermFont) }
            }
        )
    }

    confirmDelete?.let { c ->
        AlertDialog(
            onDismissRequest = { confirmDelete = null },
            containerColor = Color(0xFF0B0B0B),
            title = { Text("[ delete chat ]", color = Warn, fontFamily = TermFont, fontWeight = FontWeight.Bold) },
            text = {
                Text(
                    "Delete \"${c.title}\" and everything in it? This can't be undone.",
                    color = Ink, fontFamily = TermFont, fontSize = 13.sp
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    val wasCurrent = c.id == engine.store.currentChatId
                    engine.store.deleteChat(c.id)
                    confirmDelete = null
                    tick++
                    if (wasCurrent) engine.refresh()
                }) { Text("Delete", color = Warn, fontFamily = TermFont) }
            },
            dismissButton = {
                TextButton(onClick = { confirmDelete = null }) { Text("Cancel", color = Ink, fontFamily = TermFont) }
            }
        )
    }
}

private fun relTime(ts: Long): String {
    val diffMin = (System.currentTimeMillis() - ts) / 60_000L
    return when {
        diffMin < 1 -> "just now"
        diffMin < 60 -> "${diffMin}m ago"
        diffMin < 1440 -> "${diffMin / 60}h ago"
        else -> "${diffMin / 1440}d ago"
    }
}
