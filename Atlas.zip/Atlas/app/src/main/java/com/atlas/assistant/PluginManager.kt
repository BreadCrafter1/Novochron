package com.atlas.assistant

import android.content.Context
import android.webkit.WebView
import android.webkit.WebViewClient
import kotlinx.coroutines.suspendCancellableCoroutine
import org.json.JSONObject
import org.json.JSONTokener
import java.io.File
import java.util.Locale
import kotlin.coroutines.resume

/** One installed plugin: its trigger phrase, a short description, and the .js file backing it. */
data class PluginInfo(val command: String, val description: String, val file: File)

/** A recognised plugin call: which plugin, and whatever text followed the trigger phrase. */
data class MatchedPlugin(val info: PluginInfo, val arg: String)

/**
 * Developer/power-user plugin system: drop a small `.js` file into Atlas/Plugins/ and Novochron can
 * call it as a new voice/typed command — no rebuild, no Kotlin needed. A plugin is a plain JS file with
 * a two-line header comment and a `run(input)` function, for example:
 *
 *   // command: roll dice
 *   // description: rolls a six-sided die, or "roll dice 3" for three dice
 *   function run(input) {
 *     var n = parseInt(input) || 1;
 *     var total = 0;
 *     for (var i = 0; i < n; i++) total += 1 + Math.floor(Math.random() * 6);
 *     return "Rolled " + total + ".";
 *   }
 *
 * Saying (or typing) "roll dice" or "roll dice 3" runs it and speaks back whatever `run()` returns.
 * Execution happens in a headless, invisible WebView's JS engine — the same JS engine Chrome uses, so
 * plugins can use normal modern JavaScript (just no DOM/network access worth relying on; the page is
 * never shown and has no address bar to load anything real from). This must run on the main thread,
 * which is exactly where Engine's command turns already run (see Engine.runPlugin).
 */
object PluginManager {

    private fun dir(ctx: Context): File {
        val d = if (AtlasStorage.hasAccess() && AtlasStorage.ensureDirs()) AtlasStorage.pluginsDir()
        else File(ctx.filesDir, "Plugins")
        try { d.mkdirs() } catch (e: Exception) { }
        return d
    }

    private fun parseHeader(file: File): PluginInfo? = try {
        var command = ""
        var description = ""
        file.bufferedReader().useLines { lines ->
            for (raw in lines) {
                val l = raw.trim()
                when {
                    l.startsWith("// command:", ignoreCase = true) -> command = l.substringAfter(":").trim()
                    l.startsWith("// description:", ignoreCase = true) -> description = l.substringAfter(":").trim()
                    l.startsWith("//") || l.isBlank() -> { /* keep scanning header comments */ }
                    else -> return@useLines // first real code line: header block is done
                }
            }
        }
        if (command.isBlank()) null else PluginInfo(command, description, file)
    } catch (e: Exception) {
        null
    }

    /** Every valid plugin found in Atlas/Plugins/, alphabetical by command. */
    fun list(ctx: Context): List<PluginInfo> =
        (dir(ctx).listFiles { f -> f.isFile && f.extension.equals("js", ignoreCase = true) } ?: emptyArray())
            .mapNotNull { parseHeader(it) }
            .sortedBy { it.command.lowercase(Locale.US) }

    /**
     * If [text] starts with (or exactly is) some installed plugin's trigger phrase, returns that match
     * with whatever followed as [MatchedPlugin.arg]. The longest matching trigger wins, so a more
     * specific plugin ("open the pod bay doors") beats a shorter overlapping one ("open").
     */
    fun matchCommand(ctx: Context, text: String): MatchedPlugin? {
        val t = text.trim()
        val tLower = t.lowercase(Locale.US)
        var best: MatchedPlugin? = null
        for (p in list(ctx)) {
            val c = p.command.trim()
            if (c.isBlank()) continue
            val cLower = c.lowercase(Locale.US)
            val hit = tLower == cLower || tLower.startsWith("$cLower ")
            if (hit && (best == null || c.length > best!!.info.command.length)) {
                best = MatchedPlugin(p, t.drop(c.length).trim())
            }
        }
        return best
    }

    /**
     * Runs [matched]'s `run(input)` function in a headless WebView and returns its return value as a
     * spoken string (empty if it returned nothing). Must be called from the main thread. Caller is
     * expected to wrap this in a timeout (see Engine.runPlugin) — a misbehaving plugin script (infinite
     * loop) could otherwise hang the calling coroutine forever.
     */
    suspend fun run(ctx: Context, matched: MatchedPlugin): String = suspendCancellableCoroutine { cont ->
        val script = try { matched.info.file.readText() } catch (e: Exception) {
            cont.resume("Couldn't read that plugin file.")
            return@suspendCancellableCoroutine
        }
        val webView = WebView(ctx.applicationContext)
        webView.settings.javaScriptEnabled = true
        var done = false
        fun finish(result: String) {
            if (done) return
            done = true
            try { webView.destroy() } catch (e: Exception) { }
            if (cont.isActive) cont.resume(result)
        }
        webView.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView, url: String?) {
                val call = "(function(){try{var r=run(${JSONObject.quote(matched.arg)});" +
                    "return (r===undefined||r===null)?'':String(r);}catch(e){return 'Plugin error: '+e;}})()"
                webView.evaluateJavascript(call) { raw ->
                    // evaluateJavascript's callback value is JSON-encoded (e.g. a quoted string) - decode it back
                    val decoded = try { JSONTokener(raw).nextValue().toString() } catch (e: Exception) { raw ?: "" }
                    finish(decoded)
                }
            }
            override fun onReceivedError(view: WebView?, errorCode: Int, description: String?, failingUrl: String?) {
                finish("Plugin failed to load.")
            }
        }
        webView.loadDataWithBaseURL(
            null,
            "<html><head><script>$script</script></head><body></body></html>",
            "text/html", "UTF-8", null
        )
        cont.invokeOnCancellation { try { webView.destroy() } catch (e: Exception) { } }
    }
}
