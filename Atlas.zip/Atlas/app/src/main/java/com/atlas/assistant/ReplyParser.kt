package com.atlas.assistant

/**
 * Incrementally splits a streamed model reply into:
 *  - spoken sentences (any text outside tags), emitted as soon as each sentence is complete
 *  - [[name: arg]] tags (remember / do)
 *  - <artifact title="..."> ... </artifact> blocks, which are never spoken
 * Chunks can be cut anywhere, including in the middle of a tag.
 */
class ReplyParser(
    private val onSentence: (String) -> Unit,
    private val onTag: (name: String, arg: String) -> Unit,
    private val onArtifactStart: (title: String) -> Unit,
    private val onArtifact: (title: String, html: String, complete: Boolean) -> Unit
) {
    private val buf = StringBuilder()
    private var inArtifact = false
    private var title = "Untitled"

    /** True while an artifact's code is being received. */
    val building: Boolean get() = inArtifact
    val artifactTitle: String get() = title
    /** Characters of artifact code received so far. */
    val artifactChars: Int get() = if (inArtifact) buf.length else 0

    fun feed(chunk: String) {
        buf.append(chunk)
        drain(false)
    }

    /** Call once the stream has ended. */
    fun finish() {
        drain(true)
        if (inArtifact) {
            // The reply was cut off inside an artifact: keep whatever arrived.
            val html = cleanHtml(buf.toString())
            buf.setLength(0)
            inArtifact = false
            if (html.isNotBlank()) onArtifact(title, html, false)
        }
        buf.setLength(0)
    }

    private fun drain(final: Boolean) {
        while (true) {
            if (inArtifact) {
                val end = buf.indexOf(ARTIFACT_END)
                if (end < 0) return
                val html = buf.substring(0, end)
                buf.delete(0, end + ARTIFACT_END.length)
                inArtifact = false
                onArtifact(title, cleanHtml(html), true)
                continue
            }

            val a = buf.indexOf(ARTIFACT_START)
            val t = buf.indexOf("[[")
            val next = when {
                a < 0 -> t
                t < 0 -> a
                else -> minOf(a, t)
            }

            if (next < 0) {
                // Plain text only. Hold back a possible half-arrived marker such as "<arti" or "[".
                val hold = if (final) 0 else partialMarkerLength()
                val used = emit(buf.substring(0, buf.length - hold), final)
                buf.delete(0, used)
                return
            }

            // Everything before the marker is finished text.
            if (next > 0) {
                emit(buf.substring(0, next), true)
                buf.delete(0, next)
            }

            if (buf.startsWith(ARTIFACT_START)) {
                val close = buf.indexOf(">")
                if (close < 0) return
                title = parseTitle(buf.substring(0, close + 1))
                buf.delete(0, close + 1)
                inArtifact = true
                onArtifactStart(title)
            } else {
                val close = buf.indexOf("]]")
                if (close < 0) return
                val inner = buf.substring(2, close)
                buf.delete(0, close + 2)
                val colon = inner.indexOf(':')
                if (colon > 0) onTag(inner.substring(0, colon).trim().lowercase(), inner.substring(colon + 1).trim())
            }
        }
    }

    /** Length of a suffix of the buffer that could be the beginning of a marker. */
    private fun partialMarkerLength(): Int {
        var best = 0
        for (m in MARKERS) {
            val max = minOf(m.length - 1, buf.length)
            for (k in max downTo 1) {
                if (buf.endsWith(m.substring(0, k))) {
                    if (k > best) best = k
                    break
                }
            }
        }
        return best
    }

    /** Emits complete sentences from [text]; returns how many characters were consumed. */
    private fun emit(text: String, final: Boolean): Int {
        var start = 0
        var i = 0
        while (i < text.length) {
            val c = text[i]
            var end = -1
            if (c == '\n') {
                end = i
            } else if (c == '.' || c == '!' || c == '?' || c == '…') {
                var j = i + 1
                while (j < text.length && (text[j] == '"' || text[j] == '\'' || text[j] == ')' || text[j] == '”')) j++
                if (j < text.length && text[j].isWhitespace()) end = j
            }
            if (end >= 0) {
                speak(text.substring(start, end))
                start = end
                i = end + 1
            } else {
                i++
            }
        }
        // A very long run without punctuation: cut it at a space so speech can begin.
        while (text.length - start > MAX_RUN) {
            val cut = text.lastIndexOf(' ', start + MAX_RUN)
            if (cut <= start) break
            speak(text.substring(start, cut))
            start = cut
        }
        if (final) {
            speak(text.substring(start))
            return text.length
        }
        return start
    }

    private fun speak(s: String) {
        val t = s.trim()
        if (t.isNotEmpty()) onSentence(t)
    }

    companion object {
        private const val ARTIFACT_START = "<artifact"
        private const val ARTIFACT_END = "</artifact>"
        private val MARKERS = listOf(ARTIFACT_START, "[[")
        private const val MAX_RUN = 260
        private val TITLE = Regex("title\\s*=\\s*(?:\"([^\"]*)\"|'([^']*)')")

        fun parseTitle(tag: String): String {
            val m = TITLE.find(tag) ?: return "Untitled"
            val t = (m.groups[1]?.value ?: m.groups[2]?.value ?: "").trim()
            return t.ifEmpty { "Untitled" }
        }

        /** Removes ```html fences if the model added them inside the artifact. */
        fun cleanHtml(raw: String): String {
            var s = raw.trim()
            if (s.startsWith("```")) {
                val nl = s.indexOf('\n')
                s = if (nl >= 0) s.substring(nl + 1) else ""
            }
            if (s.endsWith("```")) s = s.removeSuffix("```")
            return s.trim()
        }
    }
}
