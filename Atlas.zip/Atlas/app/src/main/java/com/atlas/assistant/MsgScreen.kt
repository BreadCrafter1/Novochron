package com.atlas.assistant

import android.content.Intent
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.util.UUID

/** Everything for "msg" lives under this folder in whichever repo the two people both point at. */
private const val MSG_DIR = "Msg"
private const val MSG_MEDIA_DIR = "Msg/media"
private const val POLL_MS = 2000L
/** Contents API can't read back a file's base64 body once it's over ~1 MB, so that's the practical
 *  ceiling for a photo/video that this screen can actually display/play again. */
private const val MAX_MEDIA_BYTES = 1_000_000L

private enum class MsgType { TEXT, PHOTO, VIDEO }

private data class ChatMsg(
    val path: String,
    val sender: String,
    val ts: Long,
    val type: MsgType,
    val text: String = "",
    val mediaPath: String = ""
)

/**
 * "msg": a tiny chat that uses a GitHub repo as the mailbox instead of a server. Both people paste
 * the same "owner/repo" into the box at the top (each logged into their own GitHub account via the
 * same device-code login the terminal's `gh login` sets up - see GitHub.kt), pick a name, and from
 * then on sending a message is one commit to Msg/ in that repo; receiving is just polling the same
 * folder for commits the other person made. Photos and videos are committed as their own file under
 * Msg/media/ and referenced from the text message that announces them.
 */
@Composable
fun MsgScreen(engine: Engine, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val github = remember { GitHub(engine.store) }
    val scope = rememberCoroutineScope()

    var linked by remember { mutableStateOf(github.isLinked) }
    var repoText by remember { mutableStateOf(engine.store.msgRepo) }
    var nameText by remember { mutableStateOf(engine.store.msgUserName.ifBlank { "me" }) }
    var editingSetup by remember { mutableStateOf(engine.store.msgRepo.isBlank()) }
    var tokenText by remember { mutableStateOf("") }
    var tokenBusy by remember { mutableStateOf(false) }
    var tokenStatus by remember { mutableStateOf("") }

    var messages by remember { mutableStateOf(listOf<ChatMsg>()) }
    val knownPaths = remember { mutableSetOf<String>() }
    var input by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("") }
    val listState = rememberLazyListState()

    fun repoRef(): RepoRef? = RepoRef.parse(engine.store.msgRepo)

    suspend fun poll() {
        val repo = repoRef() ?: return
        val files = try {
            withContext(Dispatchers.IO) { github.listFiles(MSG_DIR, repo) }
        } catch (e: GitHubApiException) {
            if (e.code == 404) emptyList() else { status = "Couldn't check for messages: ${e.body.take(80)}"; return }
        } catch (e: Exception) {
            status = "Couldn't check for messages: ${e.message ?: "unknown error"}"
            return
        }
        val newOnes = files.filter { !it.isDir && it.path.endsWith(".json") && it.path !in knownPaths }
        if (newOnes.isEmpty()) return
        val parsed = mutableListOf<ChatMsg>()
        for (f in newOnes.sortedBy { it.path }) {
            knownPaths += f.path
            val body = try { withContext(Dispatchers.IO) { github.readFile(f.path, repo) } } catch (e: Exception) { null } ?: continue
            try {
                val o = JSONObject(body)
                parsed += ChatMsg(
                    path = f.path,
                    sender = o.optString("from", "them"),
                    ts = o.optLong("ts", 0L),
                    type = MsgType.valueOf(o.optString("type", "TEXT").uppercase()),
                    text = o.optString("text", ""),
                    mediaPath = o.optString("media", "")
                )
            } catch (e: Exception) { /* skip a malformed/unrelated file rather than crash the poll */ }
        }
        if (parsed.isNotEmpty()) {
            messages = (messages + parsed).sortedBy { it.ts }
            status = ""
        }
    }

    // First load, then keep polling for what the other person sends while this screen is open.
    LaunchedEffect(engine.store.msgRepo) {
        messages = emptyList()
        knownPaths.clear()
        if (repoRef() != null) {
            while (true) {
                poll()
                delay(POLL_MS)
            }
        }
    }

    fun sendText(text: String) {
        val repo = repoRef() ?: return
        val trimmed = text.trim()
        if (trimmed.isEmpty()) return
        input = ""
        scope.launch {
            busy = true
            status = "Sending…"
            try {
                val ts = System.currentTimeMillis()
                val path = "$MSG_DIR/$ts-${UUID.randomUUID().toString().take(6)}.json"
                val body = JSONObject().apply {
                    put("from", engine.store.msgUserName.ifBlank { "me" })
                    put("ts", ts)
                    put("type", "TEXT")
                    put("text", trimmed)
                }
                withContext(Dispatchers.IO) { github.commitFile(path, body.toString(), "msg: text") }
                knownPaths += path
                messages = messages + ChatMsg(path, engine.store.msgUserName.ifBlank { "me" }, ts, MsgType.TEXT, text = trimmed)
                status = ""
            } catch (e: GitHubApiException) {
                status = "Failed to send: ${e.body.take(80)}"
            } catch (e: Exception) {
                status = "Failed to send: ${e.message ?: "unknown error"}"
            }
            busy = false
        }
    }

    fun sendMedia(uri: Uri, type: MsgType) {
        val repo = repoRef() ?: return
        scope.launch {
            busy = true
            status = "Uploading ${if (type == MsgType.PHOTO) "photo" else "video"}…"
            try {
                val bytes = withContext(Dispatchers.IO) { readBytes(ctx, uri) }
                if (bytes == null) { status = "Couldn't read that file."; busy = false; return@launch }
                if (bytes.size.toLong() > MAX_MEDIA_BYTES) {
                    status = "That's ${humanMsgBytes(bytes.size.toLong())} - keep attachments under ${humanMsgBytes(MAX_MEDIA_BYTES)} so it can be viewed back in the app."
                    busy = false
                    return@launch
                }
                val ts = System.currentTimeMillis()
                val ext = if (type == MsgType.PHOTO) "jpg" else "mp4"
                val mediaPath = "$MSG_MEDIA_DIR/$ts.$ext"
                withContext(Dispatchers.IO) { github.commitBytes(mediaPath, bytes, "msg: ${type.name.lowercase()}") }
                val jsonPath = "$MSG_DIR/$ts-${UUID.randomUUID().toString().take(6)}.json"
                val body = JSONObject().apply {
                    put("from", engine.store.msgUserName.ifBlank { "me" })
                    put("ts", ts)
                    put("type", type.name)
                    put("media", mediaPath)
                }
                withContext(Dispatchers.IO) { github.commitFile(jsonPath, body.toString(), "msg: ${type.name.lowercase()}") }
                knownPaths += jsonPath
                messages = messages + ChatMsg(jsonPath, engine.store.msgUserName.ifBlank { "me" }, ts, type, mediaPath = mediaPath)
                status = ""
            } catch (e: GitHubApiException) {
                status = "Failed to send: ${e.body.take(80)}"
            } catch (e: Exception) {
                status = "Failed to send: ${e.message ?: "unknown error"}"
            }
            busy = false
        }
    }

    val photoLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) sendMedia(uri, MsgType.PHOTO)
    }
    val videoLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) sendMedia(uri, MsgType.VIDEO)
    }

    LaunchedEffect(messages.size) {
        if (messages.isNotEmpty()) listState.animateScrollToItem(messages.size - 1)
    }

    Column(
        Modifier
            .fillMaxSize()
            .background(Color.Black)
            .padding(horizontal = 12.dp, vertical = 10.dp)
    ) {
        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("[ msg ]", color = Accent, fontFamily = TermFont, fontWeight = FontWeight.Bold, fontSize = 18.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                if (!editingSetup && repoRef() != null) {
                    TextButton(onClick = { editingSetup = true }) { Text("[repo]", color = Accent, fontFamily = TermFont, fontSize = 13.sp) }
                }
                TextButton(onClick = onClose) { Text("[close]", color = Ink, fontFamily = TermFont, fontSize = 13.sp) }
            }
        }
        Spacer(Modifier.height(8.dp))

        if (!linked) {
            Text(
                "Not logged into GitHub yet - msg needs that to reach the shared repo. Paste a Personal " +
                    "Access Token below (create one at github.com/settings/tokens - a fine-grained token " +
                    "with Contents read/write on the repo, or a classic token with the \"repo\" scope), " +
                    "or open [term] and run \"gh login\" instead.",
                color = Dim, fontFamily = TermFont, fontSize = 13.sp
            )
            Spacer(Modifier.height(8.dp))
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                TextField(
                    value = tokenText,
                    onValueChange = { tokenText = it; tokenStatus = "" },
                    placeholder = { Text("ghp_… or github_pat_…", color = Dim, fontFamily = TermFont) },
                    singleLine = true,
                    enabled = !tokenBusy,
                    textStyle = androidx.compose.ui.text.TextStyle(color = Ink, fontFamily = TermFont, fontSize = 13.sp),
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                    keyboardActions = androidx.compose.foundation.text.KeyboardActions(onDone = {
                        if (tokenText.isNotBlank() && !tokenBusy) {
                            scope.launch {
                                tokenBusy = true
                                tokenStatus = "Verifying…"
                                github.loginWithToken(tokenText).onSuccess {
                                    tokenStatus = ""; tokenText = ""; linked = true
                                }.onFailure { tokenStatus = it.message ?: "Couldn't verify that token." }
                                tokenBusy = false
                            }
                        }
                    }),
                    colors = TextFieldDefaults.colors(
                        focusedContainerColor = Raised, unfocusedContainerColor = Raised,
                        focusedIndicatorColor = Accent, unfocusedIndicatorColor = Line,
                        cursorColor = Accent
                    ),
                    modifier = Modifier.weight(1f)
                )
                TextButton(
                    onClick = {
                        scope.launch {
                            tokenBusy = true
                            tokenStatus = "Verifying…"
                            github.loginWithToken(tokenText).onSuccess {
                                tokenStatus = ""; tokenText = ""; linked = true
                            }.onFailure { tokenStatus = it.message ?: "Couldn't verify that token." }
                            tokenBusy = false
                        }
                    },
                    enabled = !tokenBusy && tokenText.isNotBlank()
                ) { Text(if (tokenBusy) "[…]" else "[link]", color = Accent, fontFamily = TermFont, fontSize = 13.sp) }
            }
            if (tokenStatus.isNotEmpty()) {
                Spacer(Modifier.height(6.dp))
                Text(tokenStatus, color = Warn, fontFamily = TermFont, fontSize = 12.sp)
            }
            LaunchedEffect(Unit) {
                while (!linked) { delay(1000); linked = github.isLinked }
            }
            return@Column
        }

        if (editingSetup) {
            Text("Shared repo (owner/name) - both people paste the same one:", color = Dim, fontFamily = TermFont, fontSize = 12.sp)
            Spacer(Modifier.height(4.dp))
            TextField(
                value = repoText,
                onValueChange = { repoText = it },
                singleLine = true,
                textStyle = androidx.compose.ui.text.TextStyle(color = Ink, fontFamily = TermFont, fontSize = 14.sp),
                colors = TextFieldDefaults.colors(
                    focusedContainerColor = Raised, unfocusedContainerColor = Raised,
                    focusedIndicatorColor = Accent, unfocusedIndicatorColor = Line,
                    cursorColor = Accent
                ),
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(8.dp))
            Text("Your name (shown on your messages):", color = Dim, fontFamily = TermFont, fontSize = 12.sp)
            Spacer(Modifier.height(4.dp))
            TextField(
                value = nameText,
                onValueChange = { nameText = it },
                singleLine = true,
                textStyle = androidx.compose.ui.text.TextStyle(color = Ink, fontFamily = TermFont, fontSize = 14.sp),
                colors = TextFieldDefaults.colors(
                    focusedContainerColor = Raised, unfocusedContainerColor = Raised,
                    focusedIndicatorColor = Accent, unfocusedIndicatorColor = Line,
                    cursorColor = Accent
                ),
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                TextButton(onClick = {
                    val ok = RepoRef.parse(repoText) != null
                    if (!ok) { status = "That doesn't look like \"owner/repo\"."; return@TextButton }
                    engine.store.msgRepo = repoText
                    engine.store.msgUserName = nameText.ifBlank { "me" }
                    editingSetup = false
                    status = ""
                }) { Text("[save]", color = Accent, fontFamily = TermFont, fontSize = 14.sp) }
                if (repoRef() != null) {
                    TextButton(onClick = { editingSetup = false }) { Text("[cancel]", color = Ink, fontFamily = TermFont, fontSize = 14.sp) }
                }
            }
            if (status.isNotEmpty()) {
                Spacer(Modifier.height(8.dp))
                Text(status, color = Warn, fontFamily = TermFont, fontSize = 12.sp)
            }
            return@Column
        }

        Text(
            "${engine.store.msgRepo} @ ${engine.store.githubBranch} · as \"${engine.store.msgUserName.ifBlank { "me" }}\"",
            color = Dim, fontFamily = TermFont, fontSize = 11.sp
        )
        Spacer(Modifier.height(6.dp))

        Box(Modifier.weight(1f).fillMaxWidth()) {
            if (messages.isEmpty()) {
                Text(
                    if (status.isNotEmpty()) status else "No messages yet. Say hi below - it'll show up for the other person next time they check.",
                    color = Dim, fontFamily = TermFont, fontSize = 13.sp
                )
            } else {
                LazyColumn(state = listState, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(messages, key = { it.path }) { m ->
                        MsgBubble(m, mine = m.sender == engine.store.msgUserName.ifBlank { "me" }, github = github, repo = repoRef())
                    }
                }
            }
        }

        if (status.isNotEmpty() && messages.isNotEmpty()) {
            Text(status, color = Warn, fontFamily = TermFont, fontSize = 11.sp)
            Spacer(Modifier.height(4.dp))
        }

        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            TextButton(onClick = { photoLauncher.launch(arrayOf("image/*")) }, enabled = !busy) {
                Text("[photo]", color = Accent, fontFamily = TermFont, fontSize = 13.sp)
            }
            TextButton(onClick = { videoLauncher.launch(arrayOf("video/*")) }, enabled = !busy) {
                Text("[video]", color = Accent, fontFamily = TermFont, fontSize = 13.sp)
            }
            TextField(
                value = input,
                onValueChange = { input = it },
                placeholder = { Text("message…", color = Dim, fontFamily = TermFont) },
                textStyle = androidx.compose.ui.text.TextStyle(color = Ink, fontFamily = TermFont, fontSize = 14.sp),
                singleLine = true,
                enabled = !busy,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                keyboardActions = androidx.compose.foundation.text.KeyboardActions(onSend = { sendText(input) }),
                colors = TextFieldDefaults.colors(
                    focusedContainerColor = Raised, unfocusedContainerColor = Raised,
                    focusedIndicatorColor = Accent, unfocusedIndicatorColor = Line,
                    cursorColor = Accent
                ),
                modifier = Modifier.weight(1f)
            )
            TextButton(onClick = { sendText(input) }, enabled = !busy && input.isNotBlank()) {
                Text("[send]", color = Accent, fontFamily = TermFont, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            }
        }
    }
}

@Composable
private fun MsgBubble(m: ChatMsg, mine: Boolean, github: GitHub, repo: RepoRef?) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val bg = if (mine) Color(0xFF0E2A12) else Raised
    val align = if (mine) Alignment.End else Alignment.Start

    Column(Modifier.fillMaxWidth(), horizontalAlignment = align) {
        Text(
            "${m.sender} · ${timeLabel(m.ts)}",
            color = Dim, fontFamily = TermFont, fontSize = 10.sp
        )
        Box(
            Modifier
                .widthIn(max = 260.dp)
                .clip(RoundedCornerShape(6.dp))
                .background(bg)
                .padding(10.dp)
        ) {
            when (m.type) {
                MsgType.TEXT -> Text(m.text, color = Ink, fontFamily = TermFont, fontSize = 14.sp)
                MsgType.PHOTO -> MediaBubble(m, github, repo, isVideo = false)
                MsgType.VIDEO -> MediaBubble(m, github, repo, isVideo = true)
            }
        }
    }
    Spacer(Modifier.height(2.dp))
}

@Composable
private fun MediaBubble(m: ChatMsg, github: GitHub, repo: RepoRef?, isVideo: Boolean) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var bytes by remember(m.path) { mutableStateOf<ByteArray?>(null) }
    var error by remember(m.path) { mutableStateOf("") }
    var loading by remember(m.path) { mutableStateOf(false) }

    fun load() {
        val r = repo ?: return
        loading = true
        scope.launch {
            bytes = try {
                withContext(Dispatchers.IO) { github.readFileBytes(m.mediaPath, r) }
            } catch (e: Exception) { error = e.message ?: "couldn't load"; null }
            loading = false
        }
    }

    LaunchedEffect(m.path) { if (!isVideo) load() }

    if (!isVideo) {
        when {
            bytes != null -> {
                val bmp = remember(bytes) { BitmapFactory.decodeByteArray(bytes, 0, bytes!!.size) }
                if (bmp != null) {
                    Image(bmp.asImageBitmap(), contentDescription = "photo", modifier = Modifier.widthIn(max = 240.dp))
                } else {
                    Text("[photo couldn't be decoded]", color = Warn, fontFamily = TermFont, fontSize = 12.sp)
                }
            }
            loading -> Text("[loading photo…]", color = Dim, fontFamily = TermFont, fontSize = 12.sp)
            error.isNotEmpty() -> Text("[photo failed: $error]", color = Warn, fontFamily = TermFont, fontSize = 12.sp)
            else -> Text("[photo]", color = Dim, fontFamily = TermFont, fontSize = 12.sp)
        }
    } else {
        Column {
            Text("[ video ]", color = Ink, fontFamily = TermFont, fontSize = 13.sp)
            Spacer(Modifier.height(4.dp))
            TextButton(onClick = {
                if (bytes != null) openVideo(ctx, bytes!!) else {
                    loading = true
                    scope.launch {
                        val r = repo
                        bytes = if (r != null) try {
                            withContext(Dispatchers.IO) { github.readFileBytes(m.mediaPath, r) }
                        } catch (e: Exception) { error = e.message ?: "couldn't load"; null } else null
                        loading = false
                        bytes?.let { openVideo(ctx, it) }
                    }
                }
            }, enabled = !loading) {
                Text(if (loading) "[loading…]" else "[play]", color = Accent, fontFamily = TermFont, fontSize = 13.sp)
            }
            if (error.isNotEmpty()) Text("[video failed: $error]", color = Warn, fontFamily = TermFont, fontSize = 11.sp)
        }
    }
}

private fun openVideo(ctx: android.content.Context, bytes: ByteArray) {
    val dir = File(ctx.cacheDir, "msg").apply { mkdirs() }
    val file = File(dir, "clip-${System.currentTimeMillis()}.mp4")
    file.writeBytes(bytes)
    val uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.fileprovider", file)
    val intent = Intent(Intent.ACTION_VIEW).apply {
        setDataAndType(uri, "video/mp4")
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
    ctx.startActivity(intent)
}

private fun timeLabel(ts: Long): String {
    if (ts <= 0L) return ""
    val fmt = java.text.SimpleDateFormat("MMM d, HH:mm", java.util.Locale.getDefault())
    return fmt.format(java.util.Date(ts))
}

private fun humanMsgBytes(n: Long): String = when {
    n >= 1_000_000 -> "%.1f MB".format(n / 1_000_000.0)
    n >= 1_000 -> "%.0f KB".format(n / 1_000.0)
    else -> "$n B"
}

private fun readBytes(ctx: android.content.Context, uri: Uri): ByteArray? = try {
    ctx.contentResolver.openInputStream(uri)?.use { it.readBytes() }
} catch (e: Exception) { null }
