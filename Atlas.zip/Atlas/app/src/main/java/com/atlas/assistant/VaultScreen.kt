package com.atlas.assistant

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Locale

/** Files live under this folder inside whichever repo is chosen, so the vault never touches the rest of the repo. */
private const val VAULT_DIR = "Vault"

/** A file the vault will refuse to touch, either on upload (too big) or nowhere - GitHub's own ceiling. */
private const val MAX_VAULT_FILE_BYTES = 25L * 1024 * 1024
private const val GITHUB_HARD_LIMIT_BYTES = 100L * 1024 * 1024

/**
 * "Vault": upload photos or any other files into a folder (`Vault/`) inside whichever GitHub repo you
 * pick, list what's there, and delete files - all through the same logged-in GitHub account the
 * terminal's `gh login` sets up (see GitHub.kt). Picking a repo here changes the *active* repo, the
 * same `store.githubRepo`/`store.githubBranch` the terminal's `repo use` command sets - they're two
 * views onto one "repo Novochron is currently pointed at", by design (see Terminal.kt).
 *
 * Uploads and deletes are each one commit via the Contents API (see [GitHub.commitBytes] /
 * [GitHub.deleteFile]); there's no local caching, so this always reflects the real state of the repo.
 */
@Composable
fun VaultScreen(engine: Engine, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val github = remember { GitHub(engine.store) }
    val scope = rememberCoroutineScope()

    var linked by remember { mutableStateOf(github.isLinked) }
    var repos by remember { mutableStateOf<List<String>?>(null) } // null = not loaded yet
    var reposError by remember { mutableStateOf("") }
    var activeRepo by remember { mutableStateOf(github.activeRepo?.full ?: "") }
    var files by remember { mutableStateOf<List<RepoFile>>(emptyList()) }
    var filesLoading by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) } // true while an upload/delete is in flight
    var progress by remember { mutableStateOf("") }
    var log by remember { mutableStateOf(listOf<String>()) }
    var confirmDelete by remember { mutableStateOf<RepoFile?>(null) }

    suspend fun refreshFiles() {
        val repo = github.activeRepo ?: run { files = emptyList(); return }
        filesLoading = true
        files = try {
            withContext(Dispatchers.IO) { github.listFiles(VAULT_DIR, repo) }.filter { !it.isDir }
        } catch (e: GitHubApiException) {
            if (e.code == 404) emptyList() // Vault/ doesn't exist in this repo yet - that's fine, not an error
            else { log = log + "Couldn't list files: ${friendlyVaultError(e)}"; files }
        } catch (e: Exception) {
            log = log + "Couldn't list files: ${e.message ?: "unknown error"}"
            files
        }
        filesLoading = false
    }

    // Re-checked periodically so logging in / choosing a repo in the terminal shows up here without reopening
    LaunchedEffect(Unit) {
        while (true) {
            val nowLinked = github.isLinked
            if (nowLinked != linked) {
                linked = nowLinked
                if (nowLinked) repos = null // force a reload of the repo list on first becoming linked
            }
            val nowRepo = github.activeRepo?.full ?: ""
            if (nowRepo != activeRepo) {
                activeRepo = nowRepo
                refreshFiles()
            }
            kotlinx.coroutines.delay(2000)
        }
    }

    LaunchedEffect(linked) {
        if (linked && repos == null) {
            reposError = ""
            repos = try {
                withContext(Dispatchers.IO) { github.listRepos(30) }
            } catch (e: Exception) {
                reposError = "Couldn't load your repos: ${e.message ?: "unknown error"}"
                emptyList()
            }
            if (activeRepo.isNotEmpty()) refreshFiles()
        }
    }

    fun uploadUris(uris: List<Uri>) {
        if (uris.isEmpty()) return
        scope.launch {
            busy = true
            uris.forEachIndexed { i, uri ->
                val name = sanitizeFileName(queryDisplayName(ctx, uri))
                progress = "Uploading $name (${i + 1}/${uris.size})…"
                val bytes = withContext(Dispatchers.IO) { readBytes(ctx, uri) }
                when {
                    bytes == null -> log = log + "Couldn't read $name."
                    bytes.size.toLong() > MAX_VAULT_FILE_BYTES ->
                        log = log + "$name is ${humanVaultBytes(bytes.size.toLong())} - the vault's limit is ${humanVaultBytes(MAX_VAULT_FILE_BYTES)}."
                    else -> try {
                        withContext(Dispatchers.IO) {
                            github.commitBytes("$VAULT_DIR/$name", bytes, "Add $name via Atlas vault")
                        }
                        log = log + "Uploaded $name ✓"
                    } catch (e: GitHubApiException) {
                        log = log + "Failed to upload $name: ${friendlyVaultError(e)}"
                    } catch (e: Exception) {
                        log = log + "Failed to upload $name: ${e.message ?: "unknown error"}"
                    }
                }
            }
            progress = ""
            busy = false
            refreshFiles()
        }
    }

    fun deleteFile(f: RepoFile) {
        val shortName = f.path.removePrefix("$VAULT_DIR/")
        scope.launch {
            busy = true
            progress = "Deleting $shortName…"
            try {
                withContext(Dispatchers.IO) { github.deleteFile(f.path, "Remove $shortName via Atlas vault") }
                log = log + "Deleted $shortName ✓"
            } catch (e: GitHubApiException) {
                log = log + "Failed to delete $shortName: ${friendlyVaultError(e)}"
            } catch (e: Exception) {
                log = log + "Failed to delete $shortName: ${e.message ?: "unknown error"}"
            }
            progress = ""
            busy = false
            refreshFiles()
        }
    }

    val uploadLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        uploadUris(uris)
    }

    Column(
        Modifier
            .fillMaxSize()
            .background(Color.Black)
            .padding(horizontal = 12.dp, vertical = 10.dp)
    ) {
        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("[ vault ]", color = Accent, fontFamily = TermFont, fontWeight = FontWeight.Bold, fontSize = 18.sp)
            TextButton(onClick = onClose) { Text("[close]", color = Ink, fontFamily = TermFont, fontSize = 13.sp) }
        }
        Spacer(Modifier.height(8.dp))

        if (!linked) {
            VaultNotLinked {
                onClose()
                AssistantState.showTerminal.value = true
            }
            return@Column
        }

        // ---- repo picker ----
        Text("Repo", color = Dim, fontFamily = TermFont, fontSize = 12.sp)
        Spacer(Modifier.height(4.dp))
        when {
            repos == null -> Text("Loading your repos…", color = Dim, fontFamily = TermFont, fontSize = 13.sp)
            reposError.isNotEmpty() -> Text(reposError, color = Warn, fontFamily = TermFont, fontSize = 12.sp)
            repos!!.isEmpty() -> Text("No repos found on this account.", color = Dim, fontFamily = TermFont, fontSize = 13.sp)
            else -> Row(
                Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                repos!!.forEach { full ->
                    VaultChip(full.substringAfter('/'), selected = full == activeRepo) {
                        engine.store.githubRepo = full
                        activeRepo = full
                        scope.launch { refreshFiles() }
                    }
                }
            }
        }
        Spacer(Modifier.height(10.dp))

        if (activeRepo.isEmpty()) {
            Text("Pick a repo above to store files in.", color = Dim, fontFamily = TermFont, fontSize = 13.sp)
        } else {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                Text("$activeRepo · $VAULT_DIR/ @ ${engine.store.githubBranch}", color = Dim, fontFamily = TermFont, fontSize = 12.sp)
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    TextButton(onClick = { scope.launch { refreshFiles() } }, enabled = !busy) {
                        Text("[refresh]", color = Accent, fontFamily = TermFont, fontSize = 13.sp)
                    }
                    TextButton(
                        onClick = { uploadLauncher.launch(arrayOf("*/*")) },
                        enabled = !busy
                    ) { Text("[upload]", color = Accent, fontFamily = TermFont, fontSize = 13.sp) }
                    TextButton(
                        onClick = {
                            busy = true; progress = "Pushing memory & places…"
                            scope.launch {
                                progress = try { VaultSync.push(ctx, github) } catch (e: Exception) { "Sync push failed: ${e.message ?: "unknown error"}" }
                                busy = false
                            }
                        },
                        enabled = !busy
                    ) { Text("[sync push]", color = Accent, fontFamily = TermFont, fontSize = 13.sp) }
                    TextButton(
                        onClick = {
                            busy = true; progress = "Pulling memory & places…"
                            scope.launch {
                                progress = try { VaultSync.pull(ctx, github) } catch (e: Exception) { "Sync pull failed: ${e.message ?: "unknown error"}" }
                                busy = false
                            }
                        },
                        enabled = !busy
                    ) { Text("[sync pull]", color = Accent, fontFamily = TermFont, fontSize = 13.sp) }
                }
            }
            Spacer(Modifier.height(6.dp))

            Box(Modifier.weight(1f).fillMaxWidth()) {
                when {
                    filesLoading -> Text("Loading files…", color = Dim, fontFamily = TermFont, fontSize = 13.sp)
                    files.isEmpty() -> Text(
                        "Nothing in the vault yet. Tap [upload] to add a file or photo.",
                        color = Dim, fontFamily = TermFont, fontSize = 13.sp
                    )
                    else -> LazyColumn(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        items(files, key = { it.path }) { f ->
                            VaultFileRow(f, enabled = !busy, onDelete = { confirmDelete = f })
                        }
                    }
                }
            }
        }

        if (progress.isNotEmpty()) {
            Spacer(Modifier.height(6.dp))
            Text(progress, color = Accent, fontFamily = TermFont, fontSize = 12.sp)
        }

        if (log.isNotEmpty()) {
            Spacer(Modifier.height(6.dp))
            Column(
                Modifier
                    .fillMaxWidth()
                    .heightIn(max = 96.dp)
                    .background(CardBg, RoundedCornerShape(4.dp))
                    .padding(8.dp)
            ) {
                log.takeLast(6).forEach { line ->
                    Text(line, color = Color(0xFFCFCFCF), fontFamily = TermFont, fontSize = 11.sp)
                }
            }
        }
    }

    confirmDelete?.let { f ->
        val shortName = f.path.removePrefix("$VAULT_DIR/")
        AlertDialog(
            onDismissRequest = { confirmDelete = null },
            containerColor = Color(0xFF0B0B0B),
            title = { Text("[ delete file ]", color = Warn, fontFamily = TermFont, fontWeight = FontWeight.Bold) },
            text = {
                Text(
                    "Delete \"$shortName\" from $activeRepo? This commits a removal to the repo and can't be undone from here.",
                    color = Ink, fontFamily = TermFont, fontSize = 13.sp
                )
            },
            confirmButton = {
                TextButton(onClick = { confirmDelete = null; deleteFile(f) }) {
                    Text("Delete", color = Warn, fontFamily = TermFont)
                }
            },
            dismissButton = {
                TextButton(onClick = { confirmDelete = null }) { Text("Cancel", color = Ink, fontFamily = TermFont) }
            }
        )
    }
}

@Composable
private fun VaultNotLinked(onOpenTerminal: () -> Unit) {
    Column(
        Modifier
            .fillMaxWidth()
            .padding(top = 8.dp)
            .background(CardBg, RoundedCornerShape(8.dp))
            .border(1.dp, Line, RoundedCornerShape(8.dp))
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Text("Not logged into GitHub", color = Warn, fontFamily = TermFont, fontWeight = FontWeight.Bold, fontSize = 14.sp)
        Text(
            "The vault stores files in a GitHub repo using the same login the terminal's \"gh\" commands use. " +
                "Open the terminal and run \"gh login\", then come back here.",
            color = Ink, fontFamily = TermFont, fontSize = 13.sp
        )
        TextButton(onClick = onOpenTerminal) { Text("Open terminal", color = Accent, fontFamily = TermFont) }
    }
}

@Composable
private fun VaultChip(label: String, selected: Boolean, onClick: () -> Unit) {
    val shape = RoundedCornerShape(6.dp)
    Box(
        Modifier
            .clip(shape)
            .background(if (selected) Accent else Raised)
            .border(1.dp, if (selected) Accent else Line, shape)
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 7.dp)
    ) {
        Text(
            label,
            color = if (selected) Color.Black else Ink,
            fontFamily = TermFont,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
            fontSize = 13.sp,
            maxLines = 1
        )
    }
}

@Composable
private fun VaultFileRow(f: RepoFile, enabled: Boolean, onDelete: () -> Unit) {
    val name = f.path.removePrefix("$VAULT_DIR/")
    Row(
        Modifier.fillMaxWidth().padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(name, color = Ink, fontFamily = TermFont, fontSize = 13.sp, maxLines = 1)
            Text(humanVaultBytes(f.size), color = Dim, fontFamily = TermFont, fontSize = 11.sp)
        }
        TextButton(onClick = onDelete, enabled = enabled) {
            Text("[delete]", color = Warn, fontFamily = TermFont, fontSize = 13.sp)
        }
    }
}

private fun friendlyVaultError(e: GitHubApiException): String = when (e.code) {
    401, 403 -> "GitHub rejected the login. Try \"gh login\" again in the terminal."
    404 -> "Not found."
    409 -> "Someone else changed this file first. Refresh and try again."
    413 -> "That file is too big for GitHub's API (over ${humanVaultBytes(GITHUB_HARD_LIMIT_BYTES)})."
    422 -> "GitHub rejected the request (${e.body.take(120)})."
    429 -> "Rate limited by GitHub. Wait a moment and try again."
    else -> "GitHub error ${e.code}."
}

private fun humanVaultBytes(bytes: Long): String = when {
    bytes >= 1_048_576L -> String.format(Locale.US, "%.1f MB", bytes / 1_048_576.0)
    bytes >= 1024L -> "${bytes / 1024} KB"
    else -> "$bytes B"
}

/** Strips path separators etc. out of a picked file's display name so it can't escape the Vault/ folder. */
private fun sanitizeFileName(name: String): String =
    name.replace('/', '_').replace('\\', '_').trim().ifBlank { "file" }

private fun queryDisplayName(ctx: Context, uri: Uri): String = try {
    ctx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
        val idx = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
        if (c.moveToFirst() && idx >= 0) c.getString(idx) else null
    } ?: uri.lastPathSegment ?: "file"
} catch (e: Exception) {
    uri.lastPathSegment ?: "file"
}

private fun readBytes(ctx: Context, uri: Uri): ByteArray? = try {
    ctx.contentResolver.openInputStream(uri)?.use { it.readBytes() }
} catch (e: Exception) {
    null
}
