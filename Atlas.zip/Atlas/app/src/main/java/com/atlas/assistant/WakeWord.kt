package com.atlas.assistant

import java.util.Locale

/**
 * Matches a wake phrase (default "novochron", optionally "hey novochron" / "ok novochron" etc.) against a
 * finished chunk of recognized speech. Not a true low-power always-on keyword spotter like Google
 * Assistant's (that needs a dedicated on-device model running below the OS's normal speech stack) —
 * this reuses the same continuous SpeechRecognizer session Novochron already runs, and just gates what it
 * reacts to until the phrase is heard. See Engine's wake-word handling for how it's used.
 */
object WakeWord {
    private val GREETINGS = setOf("hey", "hi", "ok", "okay", "yo")

    /**
     * If [heard] contains [phrase] (a greeting like "hey"/"ok" may come first), returns whatever
     * comes after it, trimmed (possibly blank). Returns null if the phrase wasn't heard at all.
     */
    fun strip(heard: String, phrase: String): String? {
        val words = heard.trim().lowercase(Locale.US).split(Regex("\\s+")).filter { it.isNotBlank() }
        val target = phrase.trim().lowercase(Locale.US).split(Regex("\\s+"))
            .filter { it.isNotBlank() && it !in GREETINGS }
        if (words.isEmpty() || target.isEmpty()) return null

        val maxStart = (words.size - target.size).coerceAtLeast(0).coerceAtMost(3)
        for (start in 0..maxStart) {
            if (start + target.size > words.size) break
            val window = words.subList(start, start + target.size)
            if (matches(window, target)) {
                return words.subList(start + target.size, words.size).joinToString(" ")
            }
        }
        return null
    }

    private fun matches(window: List<String>, target: List<String>): Boolean {
        if (window == target) return true
        // a single made-up name is easy for the recognizer to mangle; allow a loose prefix match
        if (target.size == 1 && window.size == 1) {
            val t = target[0]; val w = window[0]
            val prefixLen = (t.length - 1).coerceAtLeast(3).coerceAtMost(t.length)
            return w.length >= prefixLen && w.startsWith(t.take(prefixLen))
        }
        return false
    }
}
