package com.atlas.assistant

import android.content.Context

/** Facts Novochron knows about itself. */
object About {
    const val CREATOR = "Daniel"
    const val OWNER = "Aishadina"
    private const val FALLBACK_VERSION = "2.1"

    @Suppress("DEPRECATION")
    fun version(ctx: Context): String = try {
        ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName ?: FALLBACK_VERSION
    } catch (e: Exception) {
        FALLBACK_VERSION
    }

    /** One-line summary used in prompts and settings. */
    fun summary(version: String) = "Novochron $version, built by $CREATOR for $OWNER"

    private val WHO_MADE = Regex(
        "who (made|built|created|designed|developed|programmed|coded|wrote) (you|this|novochron)|" +
            "who('s| is| was) (your|the) (creator|maker|developer|builder|author|programmer)|who do you belong to"
    )
    private val WHO_FOR = Regex(
        "who (were you|are you|was this|is this|is novochron|was novochron) (made|built|created|meant|intended|designed) for|" +
            "who (is|was) (this|novochron|the app) for|who (are|were) you for|who am i"
    )
    private val VERSION = Regex("what version|which version|version number|what release")
    private val IDENTITY = Regex("who are you|what are you|what('s| is) your name|your name|introduce yourself")

    /** Answers "who made you / who are you for / what version" without needing the internet. [t] is lowercase. */
    fun answer(t: String, version: String): String? = when {
        WHO_MADE.containsMatchIn(t) -> "$CREATOR built me."
        WHO_FOR.containsMatchIn(t) -> "I was built for $OWNER. If that's you, hello."
        VERSION.containsMatchIn(t) -> "I'm Novochron, version $version."
        IDENTITY.containsMatchIn(t) -> "I'm ${summary(version)}."
        else -> null
    }
}
