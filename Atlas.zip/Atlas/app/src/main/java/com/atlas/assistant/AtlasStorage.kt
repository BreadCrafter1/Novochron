package com.atlas.assistant

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.Settings
import java.io.File

/**
 * Gives Novochron its own visible folder on shared storage, at /storage/emulated/0/Atlas, instead of
 * hiding everything inside Android's private app sandbox. Chat history, memory and learned places
 * live there once access is granted, so the user can see, back up or copy the folder like any other
 * folder on the phone (file manager, USB, etc.).
 *
 * Layout:
 *   /storage/emulated/0/Atlas/atlas.db     - chat history, memory, artifacts (SQLite)
 *   /storage/emulated/0/Atlas/Maps/        - learned places (places.json) for offline distance answers
 *   /storage/emulated/0/Atlas/Models/      - optional offline LLM model (model.task)
 */
object AtlasStorage {

    fun root(): File = File(Environment.getExternalStorageDirectory(), "Atlas")
    fun mapsDir(): File = File(root(), "Maps")
    fun modelsDir(): File = File(root(), "Models")
    fun photosDir(): File = File(root(), "Photos")
    fun dbFile(): File = File(root(), "atlas.db")
    fun placesFile(): File = File(mapsDir(), "places.json")

    /** True once Novochron is allowed to read and write its own folder on shared storage. */
    fun hasAccess(): Boolean = when {
        Build.VERSION.SDK_INT >= 30 -> Environment.isExternalStorageManager()
        else -> true // WRITE_EXTERNAL_STORAGE is requested as a normal runtime permission below API 30
    }

    fun hasLegacyPermission(ctx: Context): Boolean =
        Build.VERSION.SDK_INT >= 30 ||
            ctx.checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED

    /** Creates the folder (and subfolders) if they don't exist yet. Safe to call repeatedly. */
    fun ensureDirs(): Boolean = try {
        root().mkdirs()
        mapsDir().mkdirs()
        modelsDir().mkdirs()
        photosDir().mkdirs()
        root().exists()
    } catch (e: Exception) {
        false
    }

    /** Opens system settings so the user can grant Novochron "All files access" (Android 11+). */
    fun requestAccessIntent(ctx: Context): Intent = try {
        Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:${ctx.packageName}"))
    } catch (e: Exception) {
        Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION)
    }
}
