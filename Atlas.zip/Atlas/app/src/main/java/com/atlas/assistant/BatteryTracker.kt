package com.atlas.assistant

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.PowerManager
import android.os.Process
import org.json.JSONObject
import java.io.File

/** One reading of the battery, tagged with which background features were running when it was taken. */
data class BatterySample(
    val ts: Long,
    val pct: Int,            // 0..100, or -1 if unknown
    val uah: Long,           // charge counter in µAh, or -1 if this phone doesn't report it
    val charging: Boolean,
    val screenOn: Boolean,
    val tags: String,        // "", "voice", "msg" or "voice,msg" - what was running from this sample until the next
    val cpuMs: Long          // this app's process CPU time so far
)

/** Totals for a set of tracked intervals. */
data class BatteryBucket(
    val ms: Long = 0L,
    val pct: Double = 0.0,
    val mah: Double = 0.0,
    val mahMs: Long = 0L,    // the part of [ms] that had a real mAh reading (not every phone has one)
    val cpuMs: Long = 0L
) {
    val hours: Double get() = ms / 3_600_000.0
    val pctPerHour: Double? get() = if (ms >= 60_000L) pct / hours else null
    val mahPerHour: Double? get() = if (mahMs >= 60_000L) mah / (mahMs / 3_600_000.0) else null
    fun plus(o: BatteryBucket) = BatteryBucket(ms + o.ms, pct + o.pct, mah + o.mah, mahMs + o.mahMs, cpuMs + o.cpuMs)
}

data class BatterySummary(
    val all: BatteryBucket,                       // every tracked, unplugged interval
    val screenOff: BatteryBucket,                 // the same, but only while the screen was off (closest to Atlas' own cost)
    val byFeature: Map<String, BatteryBucket>,    // screen-off buckets split by what was running
    val hourly: List<Double?>                     // last 24 hours, oldest first: drain in %/h while tracked (null = no data)
)

/** A live look at the battery right now. */
data class BatteryNow(
    val pct: Int, val charging: Boolean, val tempC: Double?, val volts: Double?,
    val currentMa: Int?, val powerSave: Boolean, val ignoringOptimizations: Boolean
)

/**
 * Battery bookkeeping for the [stats] screen. Android doesn't let an app read its own exact share of
 * battery use, so this does the next best honest thing: while a background feature is running (voice
 * listening, message alerts) it takes a battery reading every minute or so and logs it. The drain between
 * two readings - only counting stretches where the phone wasn't charging - is what the phone lost while
 * Novochron was working. Screen-off stretches are the cleanest read, because there's little else going on.
 *
 * Purely local: readings live in a small file in the app's private storage (battery_log.jsonl, pruned to
 * 14 days) and [clear] wipes it. Nothing is uploaded.
 */
object BatteryTracker {
    const val TAG_VOICE = "voice"
    const val TAG_MSG = "msg"

    private const val MIN_SAMPLE_GAP_MS = 60_000L            // don't log more often than this
    private const val MAX_PAIR_GAP_MS = 15 * 60_000L         // a longer hole means the service was killed; skip it
    private const val KEEP_MS = 14L * 24 * 3_600_000L

    private val lock = Any()
    private val active = linkedSetOf<String>()
    private var lastSampleTs = 0L

    private fun logFile(ctx: Context) = File(ctx.applicationContext.filesDir, "battery_log.jsonl")
    private fun tagString() = active.joinToString(",")

    /** Call when a background feature starts or stops. Closes the interval under the old tags, opens one under the new. */
    fun setActive(ctx: Context, tag: String, on: Boolean) { synchronized(lock) {
        val before = tagString()
        val changed = if (on) active.add(tag) else active.remove(tag)
        if (!changed) return@synchronized
        try {
            if (on && before.isEmpty()) prune(ctx)
            append(ctx, capture(ctx, before))
            append(ctx, capture(ctx, tagString()))
            lastSampleTs = System.currentTimeMillis()
        } catch (e: Exception) { /* bookkeeping must never take a service down */ }
    } }

    /** Cheap to call often - it only writes a reading if a minute has passed since the last one. */
    fun sample(ctx: Context) { synchronized(lock) {
        if (active.isEmpty()) return@synchronized
        val now = System.currentTimeMillis()
        if (now - lastSampleTs < MIN_SAMPLE_GAP_MS) return@synchronized
        try {
            append(ctx, capture(ctx, tagString()))
            lastSampleTs = now
        } catch (e: Exception) { }
    } }

    fun clear(ctx: Context) { synchronized(lock) {
        try { logFile(ctx).delete() } catch (e: Exception) { }
        lastSampleTs = 0L
    } }

    // ---------------- reading the phone ----------------

    private fun capture(ctx: Context, tags: String): BatterySample {
        val app = ctx.applicationContext
        val i = app.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = i?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = i?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        val pct = if (level >= 0 && scale > 0) level * 100 / scale else -1
        val plugged = i?.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) ?: 0
        val status = i?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        val charging = plugged != 0 || status == BatteryManager.BATTERY_STATUS_CHARGING || status == BatteryManager.BATTERY_STATUS_FULL
        val bm = app.getSystemService(BatteryManager::class.java)
        val uahRaw = try { bm.getLongProperty(BatteryManager.BATTERY_PROPERTY_CHARGE_COUNTER) } catch (e: Exception) { Long.MIN_VALUE }
        val uah = if (uahRaw == Long.MIN_VALUE || uahRaw <= 0L) -1L else uahRaw
        val screenOn = app.getSystemService(PowerManager::class.java).isInteractive
        return BatterySample(System.currentTimeMillis(), pct, uah, charging, screenOn, tags, Process.getElapsedCpuTime())
    }

    /** What the battery is doing right now (for the live line at the top of the stats screen). */
    fun now(ctx: Context): BatteryNow {
        val app = ctx.applicationContext
        val i = app.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = i?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = i?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        val plugged = i?.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) ?: 0
        val status = i?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        val temp = i?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, Int.MIN_VALUE) ?: Int.MIN_VALUE
        val mv = i?.getIntExtra(BatteryManager.EXTRA_VOLTAGE, 0) ?: 0
        val bm = app.getSystemService(BatteryManager::class.java)
        val cur = try { bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_NOW) } catch (e: Exception) { Int.MIN_VALUE }
        val pm = app.getSystemService(PowerManager::class.java)
        return BatteryNow(
            pct = if (level >= 0 && scale > 0) level * 100 / scale else -1,
            charging = plugged != 0 || status == BatteryManager.BATTERY_STATUS_CHARGING || status == BatteryManager.BATTERY_STATUS_FULL,
            tempC = if (temp == Int.MIN_VALUE) null else temp / 10.0,
            volts = if (mv > 0) mv / 1000.0 else null,
            // Phones disagree on the sign and even the unit of this reading, so only the size is shown.
            currentMa = if (cur == Int.MIN_VALUE || cur == 0) null else Math.abs(cur) / 1000,
            powerSave = pm.isPowerSaveMode,
            ignoringOptimizations = pm.isIgnoringBatteryOptimizations(app.packageName)
        )
    }

    // ---------------- the log file ----------------

    private fun append(ctx: Context, s: BatterySample) {
        val o = JSONObject().put("t", s.ts).put("p", s.pct).put("u", s.uah).put("c", s.charging)
            .put("s", s.screenOn).put("g", s.tags).put("k", s.cpuMs)
        logFile(ctx).appendText(o.toString() + "\n")
    }

    private fun load(ctx: Context, sinceMs: Long): List<BatterySample> {
        val f = logFile(ctx)
        if (!f.exists()) return emptyList()
        val cutoff = System.currentTimeMillis() - sinceMs
        val out = ArrayList<BatterySample>()
        try {
            f.forEachLine { line ->
                try {
                    val o = JSONObject(line)
                    val t = o.getLong("t")
                    if (t >= cutoff) out += BatterySample(
                        t, o.optInt("p", -1), o.optLong("u", -1L), o.optBoolean("c"), o.optBoolean("s"),
                        o.optString("g", ""), o.optLong("k", 0L)
                    )
                } catch (e: Exception) { /* skip a torn line */ }
            }
        } catch (e: Exception) { }
        return out.sortedBy { it.ts }
    }

    private fun prune(ctx: Context) {
        val f = logFile(ctx)
        if (!f.exists() || f.length() < 64 * 1024) return
        val keep = load(ctx, KEEP_MS)
        f.writeText(keep.joinToString("") { s ->
            JSONObject().put("t", s.ts).put("p", s.pct).put("u", s.uah).put("c", s.charging)
                .put("s", s.screenOn).put("g", s.tags).put("k", s.cpuMs).toString() + "\n"
        })
    }

    // ---------------- the numbers ----------------

    private class Pair2(val a: BatterySample, val b: BatterySample)

    /** Consecutive readings that describe a clean, unplugged stretch with something running. */
    private fun validPairs(samples: List<BatterySample>): List<Pair2> {
        val out = ArrayList<Pair2>()
        for (i in 0 until samples.size - 1) {
            val a = samples[i]; val b = samples[i + 1]
            val dt = b.ts - a.ts
            if (a.tags.isEmpty() || dt <= 0 || dt > MAX_PAIR_GAP_MS) continue
            if (a.charging || b.charging || a.pct < 0 || b.pct < 0) continue
            if (b.pct > a.pct) continue                      // level went up: a charge we missed
            out += Pair2(a, b)
        }
        return out
    }

    private fun bucketOf(p: Pair2): BatteryBucket {
        val dt = p.b.ts - p.a.ts
        val haveMah = p.a.uah > 0 && p.b.uah > 0 && p.b.uah <= p.a.uah
        return BatteryBucket(
            ms = dt,
            pct = (p.a.pct - p.b.pct).toDouble(),
            mah = if (haveMah) (p.a.uah - p.b.uah) / 1000.0 else 0.0,
            mahMs = if (haveMah) dt else 0L,
            cpuMs = if (p.b.cpuMs >= p.a.cpuMs) p.b.cpuMs - p.a.cpuMs else 0L
        )
    }

    fun summary(ctx: Context, sinceMs: Long): BatterySummary = synchronized(lock) {
        val samples = load(ctx, sinceMs)
        var all = BatteryBucket()
        var off = BatteryBucket()
        val feat = LinkedHashMap<String, BatteryBucket>()
        for (p in validPairs(samples)) {
            val b = bucketOf(p)
            all = all.plus(b)
            if (!p.a.screenOn && !p.b.screenOn) {
                off = off.plus(b)
                feat[p.a.tags] = (feat[p.a.tags] ?: BatteryBucket()).plus(b)
            }
        }

        // 24 hourly bars, always for the last day no matter which range is selected.
        val now = System.currentTimeMillis()
        val hourMs = 3_600_000L
        val perHour = Array(24) { BatteryBucket() }
        for (p in validPairs(load(ctx, 24 * hourMs))) {
            val idx = 23 - ((now - p.a.ts) / hourMs).toInt()
            if (idx in 0..23) perHour[idx] = perHour[idx].plus(bucketOf(p))
        }
        BatterySummary(all, off, feat, perHour.map { it.pctPerHour })
    }
}
