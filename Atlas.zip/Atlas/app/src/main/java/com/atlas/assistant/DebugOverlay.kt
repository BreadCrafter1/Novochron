package com.atlas.assistant

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

/**
 * Live counters for the developer/power-user debug overlay. Filled in from three places that already
 * exist: [VadEndpointer] (the last frame's speech probability and how many times it has cut a turn
 * short so far), [Brain] (each Gemini streaming call's time-to-first-response), and [LocalLlm] (the
 * offline model's load state). Everything here is in-memory only, reset on process restart.
 */
object DebugTelemetry {
    @Volatile var lastVadProb: Float? = null
    @Volatile var lastVadEndpointAtMs: Long = 0L
    @Volatile var vadEndpointCount: Int = 0

    @Volatile var lastApiLatencyMs: Long = -1L
    @Volatile var avgApiLatencyMs: Long = -1L
    private var apiSamples = 0

    fun recordVadFrame(prob: Float) {
        lastVadProb = prob
    }

    fun recordVadEndpoint() {
        lastVadEndpointAtMs = System.currentTimeMillis()
        vadEndpointCount++
    }

    @Synchronized
    fun recordApiLatency(ms: Long) {
        lastApiLatencyMs = ms
        apiSamples++
        avgApiLatencyMs = if (avgApiLatencyMs < 0) ms else ((avgApiLatencyMs * (apiSamples - 1)) + ms) / apiSamples
    }
}

/** Small translucent HUD, refreshed twice a second while shown. Toggled by the `[debug]` control-row key
 *  or by saying "show debug console" (see Commands.kt / Store.debugOverlayOn). */
@Composable
fun DebugOverlay(modifier: Modifier = Modifier) {
    val ctx = LocalContext.current
    var tick by remember { mutableStateOf(0) }
    androidx.compose.runtime.LaunchedEffect(Unit) {
        while (true) { delay(500); tick++ }
    }
    val modelState = remember(tick) {
        when {
            LocalLlm.findModel(ctx) == null -> "not installed"
            LocalLlm.lastLoadError != null -> "error: ${LocalLlm.lastLoadError}"
            LocalLlm.loadState == "loading" -> "loading…"
            LocalLlm.loadState == "loaded" -> "loaded"
            else -> "not loaded"
        }
    }
    Column(
        modifier
            .width(220.dp)
            .background(Color(0xCC0B0B0B), RoundedCornerShape(6.dp))
            .border(1.dp, Line, RoundedCornerShape(6.dp))
            .padding(10.dp)
    ) {
        Text("[ debug ]", color = Accent, fontFamily = TermFont, fontSize = 12.sp)
        DebugLine("vad speech prob", DebugTelemetry.lastVadProb?.let { "%.2f".format(it) } ?: "—")
        DebugLine("vad endpoints", "${DebugTelemetry.vadEndpointCount}")
        DebugLine("last API latency", if (DebugTelemetry.lastApiLatencyMs >= 0) "${DebugTelemetry.lastApiLatencyMs} ms" else "—")
        DebugLine("avg API latency", if (DebugTelemetry.avgApiLatencyMs >= 0) "${DebugTelemetry.avgApiLatencyMs} ms" else "—")
        DebugLine("offline model", modelState)
    }
}

@Composable
private fun DebugLine(label: String, value: String) {
    Text("$label: $value", color = Ink, fontFamily = TermFont, fontSize = 11.sp)
}
