package com.atlas.assistant

import android.Manifest
import android.app.Activity
import android.app.NotificationManager
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.location.LocationManager
import android.media.AudioManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.net.wifi.WifiManager
import android.nfc.NfcAdapter
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import androidx.core.location.LocationManagerCompat
import java.util.Locale
import kotlin.math.max
import kotlin.math.roundToInt

/**
 * Phone settings by voice: "turn off Wi-Fi", "turn on Bluetooth", "turn up the volume", "do not disturb on"...
 *
 * What Android allows a normal app to do (this is Android's rule, not Novochron's):
 *  - FLIPPED DIRECTLY by Novochron: volume, ringer (silent / vibrate / normal), brightness and auto-brightness,
 *    auto-rotate, Do Not Disturb. The last three need a one-time permission (Settings > Phone controls).
 *    Wi-Fi on Android 9 and older, and Bluetooth on Android 12 and older, are also flipped directly.
 *  - SHOWN FOR ONE TAP: Wi-Fi (Android 10+), mobile data, location, airplane mode, hotspot, NFC, battery saver
 *    and turning Bluetooth off on Android 13+. Novochron opens exactly the right switch or panel and says what to
 *    tap. Turning Bluetooth ON on Android 13+ shows Android's own "Allow" dialog.
 */
class Controls(private val ctx: Context) {

    private val audio = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager

    /** Returns the spoken reply, or null when [raw] is not a phone-settings command. */
    fun handle(raw: String): String? {
        val t = normalize(raw)
        if (!commandShaped(t)) return null
        val target = targetOf(t) ?: return null
        return try {
            when (target) {
                Target.VOLUME -> volume(t)
                Target.BRIGHTNESS -> brightness(t)
                Target.ROTATION -> rotation(t)
                Target.RINGER -> ringer(t)
                Target.DND -> dnd(t)
                Target.WIFI -> radio(t, "Wi-Fi", { wifiState() }, { setWifi(it) }, { openWifi() })
                Target.BLUETOOTH -> radio(t, "Bluetooth", { bluetoothState() }, { setBluetooth(it) }, { openBluetooth() })
                Target.LOCATION -> radio(t, "Location", { locationState() }, { panel("location", it, Settings.ACTION_LOCATION_SOURCE_SETTINGS) }, { openOnly("location", Settings.ACTION_LOCATION_SOURCE_SETTINGS) })
                Target.AIRPLANE -> radio(t, "Airplane mode", { airplaneState() }, { panel("airplane mode", it, Settings.ACTION_AIRPLANE_MODE_SETTINGS) }, { openOnly("airplane mode", Settings.ACTION_AIRPLANE_MODE_SETTINGS) })
                Target.NFC -> radio(t, "NFC", { nfcState() }, { setNfc(it) }, { openOnly("NFC", Settings.ACTION_NFC_SETTINGS) })
                Target.BATTERY_SAVER -> radio(t, "Battery saver", { batterySaverState() }, { panel("battery saver", it, Settings.ACTION_BATTERY_SAVER_SETTINGS) }, { openOnly("battery saver", Settings.ACTION_BATTERY_SAVER_SETTINGS) })
                Target.HOTSPOT -> radio(t, "Hotspot", { null }, { setHotspot(it) }, { openHotspot() }, "I can't read the hotspot switch from here.")
                Target.DATA -> radio(t, "Mobile data", { null }, { setData(it) }, { openData() }, dataStatusText())
            }
        } catch (e: SecurityException) {
            "Android wouldn't let me change that."
        }
    }

    // ------------------------------------------------------------------ volume (media) - changed directly

    private fun volume(t: String): String? {
        val top = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
        val cur = audio.getStreamVolume(AudioManager.STREAM_MUSIC)
        val step = max(1, (top * 0.15f).roundToInt())

        fun setTo(v: Int): Int {
            val n = v.coerceIn(0, top)
            audio.setStreamVolume(AudioManager.STREAM_MUSIC, n, AudioManager.FLAG_SHOW_UI)
            return percentOf(n, top)
        }

        return when {
            UNMUTE.containsMatchIn(t) -> {
                val back = if (prevVolume > 0) prevVolume else top / 2
                "Volume back to ${setTo(back)} percent."
            }
            MUTE.containsMatchIn(t) -> {
                if (cur > 0) prevVolume = cur
                setTo(0)
                "Muted."
            }
            NUMBER.containsMatchIn(t) -> {
                val pct = NUMBER.find(t)!!.groupValues[1].toInt().coerceIn(0, 100)
                "Volume at ${setTo((pct * top / 100f).roundToInt())} percent."
            }
            HALF.containsMatchIn(t) -> "Volume at ${setTo(top / 2)} percent."
            MAX_WORDS.containsMatchIn(t) -> "Volume at ${setTo(top)} percent."
            MIN_WORDS.containsMatchIn(t) -> "Volume at ${setTo(1)} percent."
            UP.containsMatchIn(t) -> "Volume up to ${setTo(cur + step)} percent."
            DOWN.containsMatchIn(t) -> "Volume down to ${setTo(cur - step)} percent."
            LEVEL_Q.containsMatchIn(t) -> "Volume is at ${percentOf(cur, top)} percent."
            else -> null
        }
    }

    // ------------------------------------------------------------------ ringer - changed directly

    private fun ringer(t: String): String? {
        if (STATUS.containsMatchIn(t)) {
            val label = when (audio.ringerMode) {
                AudioManager.RINGER_MODE_SILENT -> "silent"
                AudioManager.RINGER_MODE_VIBRATE -> "on vibrate"
                else -> "in normal ring mode"
            }
            return "Your phone is $label."
        }
        val off = OFF.containsMatchIn(t)
        val vibrate = VIBRATE.containsMatchIn(t)
        val silent = SILENT.containsMatchIn(t)
        val mode = when {
            UNMUTE.containsMatchIn(t) -> AudioManager.RINGER_MODE_NORMAL
            (vibrate || silent) && off -> AudioManager.RINGER_MODE_NORMAL // "turn off silent mode"
            vibrate -> AudioManager.RINGER_MODE_VIBRATE
            silent -> AudioManager.RINGER_MODE_SILENT
            off -> AudioManager.RINGER_MODE_SILENT                          // "turn off the ringer"
            else -> AudioManager.RINGER_MODE_NORMAL                         // "ringer on"
        }
        val label = when (mode) {
            AudioManager.RINGER_MODE_SILENT -> "silent"
            AudioManager.RINGER_MODE_VIBRATE -> "on vibrate"
            else -> "back to normal"
        }
        return try {
            audio.ringerMode = mode
            "Phone is $label."
        } catch (e: SecurityException) {
            needDndAccess()
        }
    }

    // ------------------------------------------------------------------ brightness - changed directly (needs WRITE_SETTINGS)

    private fun brightness(t: String): String? {
        val cr = ctx.contentResolver
        val cur = try { Settings.System.getInt(cr, Settings.System.SCREEN_BRIGHTNESS, 128) } catch (e: Exception) { 128 }
        val curPct = percentOf(cur, 255)

        if (AUTO_WORDS.containsMatchIn(t)) {
            val auto = try {
                Settings.System.getInt(cr, Settings.System.SCREEN_BRIGHTNESS_MODE) == Settings.System.SCREEN_BRIGHTNESS_MODE_AUTOMATIC
            } catch (e: Exception) { false }
            val act = actionOf(t) ?: return null
            if (act == Act.STATUS) return "Auto brightness is ${onOff(auto)}."
            if (!Settings.System.canWrite(ctx)) return needWriteSettings("change the brightness")
            val want = when (act) { Act.ON -> true; Act.OFF -> false; else -> !auto }
            Settings.System.putInt(
                cr, Settings.System.SCREEN_BRIGHTNESS_MODE,
                if (want) Settings.System.SCREEN_BRIGHTNESS_MODE_AUTOMATIC else Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL
            )
            return "Auto brightness ${onOff(want)}."
        }

        if (LEVEL_Q.containsMatchIn(t)) {
            return "Brightness is at $curPct percent."
        }
        val wanted: Int = when {
            NUMBER.containsMatchIn(t) -> NUMBER.find(t)!!.groupValues[1].toInt()
            HALF.containsMatchIn(t) -> 50
            MAX_WORDS.containsMatchIn(t) -> 100
            MIN_WORDS.containsMatchIn(t) -> 1
            UP.containsMatchIn(t) -> curPct + 20
            DOWN.containsMatchIn(t) -> curPct - 20
            else -> return null
        }
        if (!Settings.System.canWrite(ctx)) return needWriteSettings("change the brightness")
        val p = wanted.coerceIn(1, 100) // never fully black
        Settings.System.putInt(cr, Settings.System.SCREEN_BRIGHTNESS_MODE, Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL)
        Settings.System.putInt(cr, Settings.System.SCREEN_BRIGHTNESS, (p * 255 / 100).coerceIn(1, 255))
        return "Brightness at $p percent."
    }

    // ------------------------------------------------------------------ auto-rotate - changed directly (needs WRITE_SETTINGS)

    private fun rotation(t: String): String? {
        val cr = ctx.contentResolver
        val auto = try { Settings.System.getInt(cr, Settings.System.ACCELEROMETER_ROTATION, 1) == 1 } catch (e: Exception) { true }
        val act = actionOf(t) ?: return null
        if (act == Act.STATUS) return "Auto rotate is ${onOff(auto)}."
        if (!Settings.System.canWrite(ctx)) return needWriteSettings("change auto rotate")
        val lock = t.contains("lock")
        val wantRotate = when (act) {
            Act.ON -> !lock // "turn on rotation lock" means auto rotate off
            Act.OFF -> lock
            else -> !auto
        }
        Settings.System.putInt(cr, Settings.System.ACCELEROMETER_ROTATION, if (wantRotate) 1 else 0)
        return "Auto rotate ${onOff(wantRotate)}."
    }

    // ------------------------------------------------------------------ Do Not Disturb - changed directly (needs DND access)

    private fun dnd(t: String): String? {
        val nm = ctx.getSystemService(NotificationManager::class.java) ?: return null
        val act = actionOf(t) ?: return null
        val filter = nm.currentInterruptionFilter
        val on = filter == NotificationManager.INTERRUPTION_FILTER_PRIORITY ||
            filter == NotificationManager.INTERRUPTION_FILTER_ALARMS ||
            filter == NotificationManager.INTERRUPTION_FILTER_NONE
        if (act == Act.STATUS) return "Do Not Disturb is ${onOff(on)}."
        if (act == Act.OPEN) return openOnly("sound settings", Settings.ACTION_SOUND_SETTINGS)
        if (!nm.isNotificationPolicyAccessGranted) return needDndAccess()
        val want = when (act) { Act.ON -> true; Act.OFF -> false; else -> !on }
        if (act != Act.TOGGLE && want == on) return "Do Not Disturb is already ${onOff(on)}."
        val next = when {
            !want -> NotificationManager.INTERRUPTION_FILTER_ALL
            ALARMS_ONLY.containsMatchIn(t) -> NotificationManager.INTERRUPTION_FILTER_ALARMS
            TOTAL_SILENCE.containsMatchIn(t) -> NotificationManager.INTERRUPTION_FILTER_NONE
            else -> NotificationManager.INTERRUPTION_FILTER_PRIORITY
        }
        nm.setInterruptionFilter(next)
        return when (next) {
            NotificationManager.INTERRUPTION_FILTER_ALL -> "Do Not Disturb off."
            NotificationManager.INTERRUPTION_FILTER_ALARMS -> "Do Not Disturb on, alarms only."
            NotificationManager.INTERRUPTION_FILTER_NONE -> "Do Not Disturb on, total silence."
            else -> "Do Not Disturb on."
        }
    }

    // ------------------------------------------------------------------ switches Android will not let apps flip

    /** Shared flow for on / off / toggle / status / open on a switch. [state] is null when Android hides the current value; [change] flips or opens the switch, [show] just opens it. */
    private fun radio(
        t: String,
        name: String,
        state: () -> Boolean?,
        change: (Boolean) -> String,
        show: () -> String,
        statusUnknown: String = "I can't read that switch from here."
    ): String? {
        val act = actionOf(t) ?: return null
        val cur = state()
        if (act == Act.STATUS) return if (cur == null) statusUnknown else "$name is ${onOff(cur)}."
        if (act == Act.OPEN) return show()
        val want = when (act) { Act.ON -> true; Act.OFF -> false; else -> !(cur ?: false) }
        if (cur != null && cur == want) return "$name is already ${onOff(want)}."
        return change(want)
    }

    // Wi-Fi: flipped directly on Android 9 and older; Android 10+ only allows the on-screen Wi-Fi panel.
    private fun wifiManager(): WifiManager? = ctx.applicationContext.getSystemService(Context.WIFI_SERVICE) as? WifiManager

    private fun wifiState(): Boolean? = try { wifiManager()?.isWifiEnabled } catch (e: Exception) { null }

    @Suppress("DEPRECATION")
    private fun setWifi(on: Boolean): String {
        val wm = wifiManager()
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q && wm != null) {
            val ok = try { wm.setWifiEnabled(on) } catch (e: Exception) { false }
            if (ok) return "Wi-Fi ${onOff(on)}."
        }
        val opened = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            launchAny(Intent(Settings.Panel.ACTION_WIFI), Intent(Settings.ACTION_WIFI_SETTINGS))
        } else {
            launchAny(Intent(Settings.ACTION_WIFI_SETTINGS))
        }
        return if (opened) "Opening Wi-Fi. Tap the switch to turn it ${onOff(on)}." else "I couldn't open the Wi-Fi settings."
    }

    private fun openWifi(): String {
        val ok = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            launchAny(Intent(Settings.Panel.ACTION_WIFI), Intent(Settings.ACTION_WIFI_SETTINGS))
        } else {
            launchAny(Intent(Settings.ACTION_WIFI_SETTINGS))
        }
        return if (ok) "Opening Wi-Fi." else "I couldn't open the Wi-Fi settings."
    }

    // Bluetooth: flipped directly up to Android 12; Android 13+ shows an "Allow" dialog to turn it on, and the
    // settings page to turn it off.
    private fun bluetoothAdapter(): BluetoothAdapter? = ctx.getSystemService(BluetoothManager::class.java)?.adapter

    private fun bluetoothState(): Boolean? = try { bluetoothAdapter()?.isEnabled } catch (e: Exception) { null }

    private fun canUseBluetooth(): Boolean =
        Build.VERSION.SDK_INT < Build.VERSION_CODES.S || has(Manifest.permission.BLUETOOTH_CONNECT)

    @Suppress("DEPRECATION")
    private fun setBluetooth(on: Boolean): String {
        val adapter = bluetoothAdapter() ?: return "This phone has no Bluetooth."
        val allowed = canUseBluetooth()
        if (allowed && Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU) {
            val ok = try { if (on) adapter.enable() else adapter.disable() } catch (e: Exception) { false }
            if (ok) return "Bluetooth ${onOff(on)}."
        }
        if (on && allowed && launch(Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE))) {
            return "Asking Android to turn Bluetooth on. Tap Allow."
        }
        return if (launch(Intent(Settings.ACTION_BLUETOOTH_SETTINGS))) {
            "Opening Bluetooth. Tap the switch to turn it ${onOff(on)}."
        } else "I couldn't open the Bluetooth settings."
    }

    private fun openBluetooth(): String = openOnly("Bluetooth", Settings.ACTION_BLUETOOTH_SETTINGS)

    // Location: Android gives apps no way to flip the master switch.
    private fun locationState(): Boolean? = try {
        (ctx.getSystemService(Context.LOCATION_SERVICE) as? LocationManager)?.let { LocationManagerCompat.isLocationEnabled(it) }
    } catch (e: Exception) { null }

    private fun airplaneState(): Boolean? = try {
        Settings.Global.getInt(ctx.contentResolver, Settings.Global.AIRPLANE_MODE_ON, 0) == 1
    } catch (e: Exception) { null }

    private fun nfcState(): Boolean? = try { NfcAdapter.getDefaultAdapter(ctx)?.isEnabled } catch (e: Exception) { null }

    private fun setNfc(on: Boolean): String {
        val nfc = try { NfcAdapter.getDefaultAdapter(ctx) } catch (e: Exception) { null }
        if (nfc == null) return "This phone has no NFC."
        return panel("NFC", on, Settings.ACTION_NFC_SETTINGS)
    }

    private fun batterySaverState(): Boolean? = try { ctx.getSystemService(PowerManager::class.java)?.isPowerSaveMode } catch (e: Exception) { null }

    private fun hotspotIntents(): Array<Intent> = arrayOf(
        Intent().setClassName("com.android.settings", "com.android.settings.TetherSettings"),
        Intent(Settings.ACTION_WIRELESS_SETTINGS)
    )

    private fun setHotspot(on: Boolean): String =
        if (launchAny(*hotspotIntents())) "Opening hotspot settings. Tap the switch to turn it ${onOff(on)}."
        else "I couldn't open the hotspot settings."

    private fun openHotspot(): String =
        if (launchAny(*hotspotIntents())) "Opening hotspot settings." else "I couldn't open the hotspot settings."

    private fun dataIntents(): Array<Intent> =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            arrayOf(
                Intent(Settings.Panel.ACTION_INTERNET_CONNECTIVITY),
                Intent(Settings.ACTION_DATA_ROAMING_SETTINGS),
                Intent(Settings.ACTION_WIRELESS_SETTINGS)
            )
        } else {
            arrayOf(Intent(Settings.ACTION_DATA_ROAMING_SETTINGS), Intent(Settings.ACTION_WIRELESS_SETTINGS))
        }

    private fun setData(on: Boolean): String =
        if (launchAny(*dataIntents())) "Opening mobile data. Tap the switch to turn it ${onOff(on)}."
        else "I couldn't open the mobile data settings."

    private fun openData(): String =
        if (launchAny(*dataIntents())) "Opening mobile data." else "I couldn't open the mobile data settings."

    /** Android hides the mobile data switch, so say what the phone is actually connected through. */
    private fun dataStatusText(): String {
        val kind = try {
            val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            val caps = cm.getNetworkCapabilities(cm.activeNetwork ?: return "I can't read the mobile data switch, and you're not connected to anything right now.")
            when {
                caps?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true -> "Wi-Fi"
                caps?.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) == true -> "mobile data"
                else -> null
            }
        } catch (e: Exception) { null }
        return if (kind == null) "I can't read the mobile data switch from here."
        else "I can't read the mobile data switch, but you're connected through $kind right now."
    }

    // ------------------------------------------------------------------ helpers

    private fun panel(what: String, on: Boolean, action: String): String =
        if (launch(Intent(action))) "Opening $what. Tap the switch to turn it ${onOff(on)}." else "I couldn't open the $what settings."

    private fun openOnly(what: String, action: String): String =
        if (launch(Intent(action))) "Opening $what." else "I couldn't open the $what settings."

    private fun needWriteSettings(what: String): String {
        openWriteSettings(ctx)
        return "I need permission to change system settings before I can $what. Switch it on for Novochron, then ask again."
    }

    private fun needDndAccess(): String {
        openDndAccess(ctx)
        return "I need Do Not Disturb access first. Switch it on for Novochron, then ask again."
    }

    private fun has(perm: String) = ctx.checkSelfPermission(perm) == PackageManager.PERMISSION_GRANTED

    private fun launch(i: Intent): Boolean = start(ctx, i)

    private fun launchAny(vararg intents: Intent): Boolean = intents.any { launch(it) }

    private fun onOff(b: Boolean) = if (b) "on" else "off"

    private fun percentOf(v: Int, top: Int) = (v * 100f / top).roundToInt().coerceIn(0, 100)

    // ------------------------------------------------------------------ parsing (pure, easy to test)

    enum class Target { VOLUME, BRIGHTNESS, ROTATION, RINGER, DND, WIFI, BLUETOOTH, LOCATION, AIRPLANE, NFC, BATTERY_SAVER, HOTSPOT, DATA }
    enum class Act { ON, OFF, TOGGLE, STATUS, OPEN }

    companion object {
        /** Kept in memory only: the media volume before "mute", so "unmute" can bring it back. */
        @Volatile private var prevVolume = -1

        // what the user is talking about
        private val T_VOLUME = Regex("""\bvolume\b|\b(louder|quieter)\b""")
        private val T_MUTE = Regex("""\b(un)?mute\b""")
        private val T_MUTE_PHONE = Regex("""\b(un)?mute\b.*\b(phone|ringer|ringtone)\b""")
        private val T_BRIGHT = Regex("""\bbrightness\b|\bbrighter\b|\bbrighten\b|\bdimmer\b|^dim\b""")
        private val T_ROTATE = Regex("""\bauto[- ]?rotat\w*|\brotation\b""")
        private val T_DND = Regex("""\bdo not disturb\b|\bdon'?t disturb\b|\bdnd\b""")
        private val T_RINGER = Regex("""\b(silent|vibrate|vibration|ringer|ringtone)\b|\bsilence (my |the )?(phone|ringer|ringtone)\b|\bmute (my |the )?(phone|ringer|ringtone)\b""")
        private val T_AIRPLANE = Regex("""\b(air|aero)\s?plane\b|\bflight mode\b""")
        private val T_HOTSPOT = Regex("""\bhot ?spot\b|\btethering\b""")
        private val T_WIFI = Regex("""\bwifi\b""")
        private val T_BLUETOOTH = Regex("""\bbluetooth\b""")
        private val T_NFC = Regex("""\bnfc\b""")
        private val T_LOCATION = Regex("""\b(location|gps)\b""")
        private val T_BATTERY = Regex("""\bbattery (saver|saving)\b|\bpower saving\b|\blow power mode\b""")
        private val T_DATA = Regex("""\b(mobile|cellular) (data|internet|network)\b|\bcellular\b|\bdata connection\b|\b(4g|5g|lte)\b|\bdata\b(?! saver)""")

        // what the user wants done
        private val STATUS = Regex("""^(is|are|check)\b|\bstatus\b|\bstate of\b""")
        private val OFF = Regex("""\b(off|disable|deactivate|kill)\b""")
        private val ON = Regex("""\b(on|enable|activate)\b""")
        private val TOGGLE = Regex("""^toggle\b""")
        private val OPEN = Regex("""^(open|show|go to|take me to)\b.*\bsettings$|^(open|show)( the| my)? (wifi|bluetooth|location|nfc|airplane mode|hotspot|mobile data|cellular data)$""")
        private val LEVEL_Q = Regex("""^(what'?s|whats|what is|check)( the| my)?( current| phone| media| screen)? (volume|brightness)( level| setting)?( right now| now)?$""")

        // amounts, for volume and brightness
        private val NUMBER = Regex("""\b(\d{1,3})\b""")
        private val HALF = Regex("""\bhalf(way)?\b""")
        private val MAX_WORDS = Regex("""\b(max|maximum|full|highest|loudest|brightest)\b""")
        private val MIN_WORDS = Regex("""\b(min|minimum|lowest|quietest|dimmest)\b""")
        private val UP = Regex("""\b(up|raise|increase|louder|brighter|brighten|higher|more)\b""")
        private val DOWN = Regex("""\b(down|lower|decrease|reduce|quieter|softer|dimmer|dim|less)\b""")
        private val MUTE = Regex("""\bmute\b""")
        private val UNMUTE = Regex("""\bunmute\b""")
        private val AUTO_WORDS = Regex("""\b(auto|automatic|adaptive)\b""")
        private val VIBRATE = Regex("""\bvibrat\w*""")
        private val SILENT = Regex("""\bsilent\b|\bsilence\b|\bmute\b""")
        private val ALARMS_ONLY = Regex("""\balarms? only\b""")
        private val TOTAL_SILENCE = Regex("""\btotal silence\b""")

        // only sentences that are shaped like a command are considered, so a question such as
        // "how do I turn off Wi-Fi on a laptop" still goes to the chat brain
        private val START = Regex("""^(turn|switch|toggle|enable|disable|activate|deactivate|put|set|open|show|go to|take me to|is|are|check|mute|unmute|silence|increase|decrease|raise|lower|reduce|dim|brighten|make|max|maximum|maximize|min|minimum|minimize|lowest|highest|full|volume|brightness|what'?s|whats|what is)\b""")
        private val TAIL = Regex("""\b(on|off)$""")
        private val SINGLE = Regex("""^(louder|quieter|softer|brighter|dimmer)$""")

        fun normalize(raw: String): String = raw.lowercase(Locale.US)
            .replace('\u2019', '\'')
            .replace(Regex("""\bwi[\s-]?fi\b"""), "wifi")
            .replace(Regex("""\bblue[\s-]tooth\b"""), "bluetooth")
            .replace(Regex("""\s+"""), " ")
            .trim()

        fun commandShaped(t: String): Boolean {
            val words = t.split(' ').size
            return (words <= 10 && START.containsMatchIn(t)) ||
                (words <= 4 && TAIL.containsMatchIn(t)) ||
                SINGLE.matches(t)
        }

        /** Which setting the sentence is about (order matters: the specific ones before the general ones). */
        fun targetOf(t: String): Target? = when {
            T_DND.containsMatchIn(t) -> Target.DND
            T_AIRPLANE.containsMatchIn(t) -> Target.AIRPLANE
            T_HOTSPOT.containsMatchIn(t) -> Target.HOTSPOT
            T_BATTERY.containsMatchIn(t) -> Target.BATTERY_SAVER
            T_WIFI.containsMatchIn(t) -> Target.WIFI
            T_BLUETOOTH.containsMatchIn(t) -> Target.BLUETOOTH
            T_NFC.containsMatchIn(t) -> Target.NFC
            T_LOCATION.containsMatchIn(t) -> Target.LOCATION
            T_ROTATE.containsMatchIn(t) -> Target.ROTATION
            T_BRIGHT.containsMatchIn(t) -> Target.BRIGHTNESS
            T_MUTE_PHONE.containsMatchIn(t) || T_RINGER.containsMatchIn(t) -> Target.RINGER
            T_VOLUME.containsMatchIn(t) || T_MUTE.containsMatchIn(t) -> Target.VOLUME
            T_DATA.containsMatchIn(t) -> Target.DATA
            else -> null
        }

        /** What to do with a switch. Null means the sentence names a setting but does not ask for anything (so do nothing). */
        fun actionOf(t: String): Act? = when {
            STATUS.containsMatchIn(t) -> Act.STATUS
            OPEN.containsMatchIn(t) -> Act.OPEN
            OFF.containsMatchIn(t) -> Act.OFF
            ON.containsMatchIn(t) -> Act.ON
            TOGGLE.containsMatchIn(t) -> Act.TOGGLE
            else -> null
        }

        // ---- one-time permissions, also used by the Settings screen ----

        fun canWriteSettings(ctx: Context): Boolean = Settings.System.canWrite(ctx)

        fun hasDndAccess(ctx: Context): Boolean =
            ctx.getSystemService(NotificationManager::class.java)?.isNotificationPolicyAccessGranted == true

        fun openWriteSettings(ctx: Context) {
            start(ctx, Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:" + ctx.packageName)))
        }

        fun openDndAccess(ctx: Context) {
            start(ctx, Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
        }

        /** Starts a screen; works from the app screen and from the background service. */
        fun start(ctx: Context, i: Intent): Boolean = try {
            if (ctx !is Activity) i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            ctx.startActivity(i)
            true
        } catch (e: Exception) {
            false
        }
    }
}
