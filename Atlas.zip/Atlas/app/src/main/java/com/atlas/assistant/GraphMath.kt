package com.atlas.assistant

import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.acos
import kotlin.math.asin
import kotlin.math.atan
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.floor
import kotlin.math.ln
import kotlin.math.log10
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.round
import kotlin.math.sign
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.math.tan

/**
 * Tiny self-contained expression compiler for the `[graph]` screen (see GraphScreen.kt).
 * Deliberately separate from [MathEval]'s parser: that one only does bare arithmetic for the offline
 * calculator (no variables, no functions) and is private to that file. Graphing formulas need a
 * variable (`x`) and named functions (`sin`, `sqrt`, ...), so this is its own small recursive-descent
 * parser producing a reusable closure — `compile()` parses once per formula edit, not once per pixel
 * column, so panning/zooming stays smooth.
 */
object GraphMath {

    class GraphMathException(message: String) : Exception(message)

    private val CONSTANTS = mapOf("pi" to PI, "e" to Math.E, "tau" to (2 * PI))

    private val FUNCTIONS: Map<String, (Double) -> Double> = mapOf(
        "sin" to { x: Double -> sin(x) },
        "cos" to { x: Double -> cos(x) },
        "tan" to { x: Double -> tan(x) },
        "asin" to { x: Double -> asin(x) },
        "acos" to { x: Double -> acos(x) },
        "atan" to { x: Double -> atan(x) },
        "sqrt" to { x: Double -> sqrt(x) },
        "abs" to { x: Double -> abs(x) },
        "ln" to { x: Double -> ln(x) },
        "log" to { x: Double -> log10(x) },
        "exp" to { x: Double -> exp(x) },
        "floor" to { x: Double -> floor(x) },
        "round" to { x: Double -> round(x) },
        "sign" to { x: Double -> sign(x) }
    )

    /** Compiles `formula` (RHS only, e.g. "sin(x) + 1", "x^2 - 3") to `f(x)`. Throws on bad syntax. */
    fun compile(formula: String): (Double) -> Double {
        // Accept "y = ..." / "f(x) = ..." prefixes by dropping anything up to and including the first '='
        val rhs = formula.substringAfter('=', formula).ifBlank { throw GraphMathException("empty") }
        val tokens = Lexer(rhs).lex()
        val ast = Parser(tokens).parseExpr()
        return { x: Double -> ast.eval(x) }
    }

    private sealed class Node {
        abstract fun eval(x: Double): Double
    }
    private class Num(val v: Double) : Node() { override fun eval(x: Double) = v }
    private class Var(val name: String) : Node() {
        override fun eval(x: Double) = if (name == "x") x else CONSTANTS[name]
            ?: throw GraphMathException("unknown name '$name'")
    }
    private class Neg(val a: Node) : Node() { override fun eval(x: Double) = -a.eval(x) }
    private class Bin(val op: Char, val a: Node, val b: Node) : Node() {
        override fun eval(x: Double): Double {
            val l = a.eval(x); val r = b.eval(x)
            return when (op) {
                '+' -> l + r
                '-' -> l - r
                '*' -> l * r
                '/' -> l / r
                '^' -> l.pow(r)
                else -> throw GraphMathException("bad op")
            }
        }
    }
    private class Call(val name: String, val arg: Node) : Node() {
        override fun eval(x: Double): Double {
            val fn = FUNCTIONS[name] ?: throw GraphMathException("unknown function '$name'")
            return fn(arg.eval(x))
        }
    }

    private sealed class Tok {
        data class NumT(val v: Double) : Tok()
        data class Ident(val s: String) : Tok()
        data class Op(val c: Char) : Tok()
    }

    private class Lexer(private val s: String) {
        fun lex(): List<Tok> {
            val out = mutableListOf<Tok>()
            var i = 0
            while (i < s.length) {
                val c = s[i]
                when {
                    c.isWhitespace() -> i++
                    c.isDigit() || c == '.' -> {
                        val start = i
                        while (i < s.length && (s[i].isDigit() || s[i] == '.')) i++
                        out += Tok.NumT(s.substring(start, i).toDouble())
                    }
                    c.isLetter() -> {
                        val start = i
                        while (i < s.length && s[i].isLetterOrDigit()) i++
                        out += Tok.Ident(s.substring(start, i).lowercase())
                    }
                    c in "+-*/^()," -> { out += Tok.Op(c); i++ }
                    else -> throw GraphMathException("unexpected character '$c'")
                }
            }
            return out
        }
    }

    /** + - * / ^ with normal precedence, unary minus, parens, and single-argument function calls. */
    private class Parser(private val toks: List<Tok>) {
        private var i = 0
        private fun peek(): Tok? = toks.getOrNull(i)

        fun parseExpr(): Node {
            val n = expr()
            if (i != toks.size) throw GraphMathException("unexpected trailing input")
            return n
        }

        private fun expr(): Node {
            var v = term()
            while (true) {
                val t = peek()
                if (t is Tok.Op && (t.c == '+' || t.c == '-')) {
                    i++
                    v = Bin(t.c, v, term())
                } else break
            }
            return v
        }

        private fun term(): Node {
            var v = factor()
            while (true) {
                val t = peek()
                if (t is Tok.Op && (t.c == '*' || t.c == '/')) {
                    i++
                    v = Bin(t.c, v, factor())
                } else if (t is Tok.Ident || (t is Tok.Op && t.c == '(')) {
                    // implicit multiplication: "2x", "3sin(x)", "2(x+1)"
                    v = Bin('*', v, factor())
                } else break
            }
            return v
        }

        private fun factor(): Node {
            val base = unary()
            val t = peek()
            return if (t is Tok.Op && t.c == '^') { i++; Bin('^', base, factor()) } else base
        }

        private fun unary(): Node {
            val t = peek()
            if (t is Tok.Op && t.c == '-') { i++; return Neg(unary()) }
            if (t is Tok.Op && t.c == '+') { i++; return unary() }
            return primary()
        }

        private fun primary(): Node {
            val t = peek() ?: throw GraphMathException("unexpected end of formula")
            return when {
                t is Tok.NumT -> { i++; Num(t.v) }
                t is Tok.Op && t.c == '(' -> {
                    i++
                    val n = expr()
                    val close = peek()
                    if (close is Tok.Op && close.c == ')') i++ else throw GraphMathException("missing ')'")
                    n
                }
                t is Tok.Ident -> {
                    i++
                    val next = peek()
                    if (next is Tok.Op && next.c == '(') {
                        i++
                        val arg = expr()
                        val close = peek()
                        if (close is Tok.Op && close.c == ')') i++ else throw GraphMathException("missing ')'")
                        Call(t.s, arg)
                    } else {
                        Var(t.s)
                    }
                }
                else -> throw GraphMathException("unexpected token")
            }
        }
    }

    /** "Nice" gridline spacing (1/2/5 * power of ten) closest to `targetUnitsPerGridline`. */
    fun niceStep(targetUnitsPerGridline: Double): Double {
        val t = max(targetUnitsPerGridline, 1e-9)
        val mag = 10.0.pow(floor(log10(t)))
        val residual = t / mag
        val step = when {
            residual < 1.5 -> 1.0
            residual < 3.5 -> 2.0
            residual < 7.5 -> 5.0
            else -> 10.0
        }
        return step * mag
    }

    fun clamp(v: Double, lo: Double, hi: Double) = min(max(v, lo), hi)
}
