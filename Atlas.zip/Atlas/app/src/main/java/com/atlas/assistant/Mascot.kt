package com.atlas.assistant

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.graphics.graphicsLayer
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

/**
 * The character in the background of the conversation: a white line drawing, half body, holding up a
 * sketch of her own face. She IS the assistant: her drawn mouth flaps while Novochron speaks, she
 * thinks (spiral eyes) while a reply is being worked out, perks up while you talk or type, and does
 * silly things when nothing is going on (see MascotAnimator).
 *
 * It sits behind the text, drawn dim, so the log stays readable on top of it.
 */
@Composable
fun MascotBackdrop(mode: MascotMode, nudge: Int, modifier: Modifier = Modifier) {
    val art = remember { MascotPaths() }
    val anim = remember { MascotAnimator() }
    val frame = remember { mutableLongStateOf(0L) }

    SideEffect { anim.mode = mode }
    LaunchedEffect(nudge) { anim.poke() }
    LaunchedEffect(Unit) {
        var last = 0L
        while (true) {
            withFrameNanos { ns ->
                // ~30 fps is plenty for line art and keeps the battery happy
                if (ns - last >= 30_000_000L) {
                    last = ns
                    anim.update(ns / 1_000_000_000.0)
                    frame.longValue = ns
                }
            }
        }
    }

    Canvas(
        modifier
            .fillMaxSize()
            .clipToBounds()
            .graphicsLayer { if (frame.longValue >= 0L) alpha = anim.alpha }
    ) {
        if (frame.longValue < 0L) return@Canvas
        val s = min(size.width / ART_W, size.height / ART_H)
        val ox = (size.width - ART_W * s) / 2f
        val oy = size.height - ART_H * s // anchored to the bottom: the waist is the edge of the screen
        withTransform({
            translate(ox, oy)
            scale(s, s, Offset.Zero)
        }) {
            drawMascot(art, anim)
        }
    }
}

private const val ART_W = 600f
private const val ART_H = 760f
private const val PIV_X = 300f
private const val PIV_Y = 510f

// ------------------------------------------------------------------------------------------ paths

/** Tiny SVG path parser: absolute M, L, Q, C and Z is all the art uses. */
private fun parsePath(d: String): Path {
    val path = Path()
    val tok = d.trim().split(Regex("[\\s,]+")).filter { it.isNotEmpty() }
    var i = 0
    var cmd = ' '
    fun num(): Float = tok[i++].toFloat()
    while (i < tok.size) {
        val t = tok[i]
        if (t[0].isLetter()) {
            cmd = t[0]
            i++
            if (cmd == 'Z' || cmd == 'z') {
                path.close()
                continue
            }
        }
        when (cmd) {
            'M' -> { path.moveTo(num(), num()); cmd = 'L' }
            'L' -> path.lineTo(num(), num())
            'Q' -> path.quadraticBezierTo(num(), num(), num(), num())
            'C' -> path.cubicTo(num(), num(), num(), num(), num(), num())
            else -> return path
        }
    }
    return path
}

private fun Path.circle(cx: Float, cy: Float, r: Float) {
    val k = 0.5523f * r
    moveTo(cx - r, cy)
    cubicTo(cx - r, cy - k, cx - k, cy - r, cx, cy - r)
    cubicTo(cx + k, cy - r, cx + r, cy - k, cx + r, cy)
    cubicTo(cx + r, cy + k, cx + k, cy + r, cx, cy + r)
    cubicTo(cx - k, cy + r, cx - r, cy + k, cx - r, cy)
    close()
}

private fun circlePath(cx: Float, cy: Float, r: Float): Path = Path().also { it.circle(cx, cy, r) }

private class LockPath(val fill: Path, val flow: Path, val px: Float, val py: Float)
private class HandPath(val fist: Path, val thumb: Path, val creases: List<Path>)

/** All the static shapes, parsed once. */
private class MascotPaths {
    val hairMass = parsePath(MascotArt.HAIR_MASS)
    val locks = MascotArt.LOCKS.map { LockPath(parsePath(it.d), parsePath(it.flow), it.px, it.py) }
    val ahoge = parsePath(MascotArt.AHOGE)
    val ahogeLine = parsePath(MascotArt.AHOGE_LINE)

    val neck = parsePath(MascotArt.NECK)
    val torso = parsePath(MascotArt.TORSO)
    val collar = parsePath(MascotArt.COLLAR)
    val zipper = parsePath(MascotArt.ZIPPER)
    val zipTab = parsePath(MascotArt.ZIP_TAB)
    val bowKnot = parsePath(MascotArt.BOW_KNOT)
    val bowL = parsePath(MascotArt.BOW_L)
    val bowLLine = parsePath(MascotArt.BOW_L_LINE)
    val bowR = parsePath(MascotArt.BOW_R)
    val bowRLine = parsePath(MascotArt.BOW_R_LINE)
    val tailL = parsePath(MascotArt.TAIL_L)
    val tailR = parsePath(MascotArt.TAIL_R)

    val paper = parsePath(MascotArt.PAPER)
    val paperEdge = parsePath(MascotArt.PAPER_EDGE)
    val holes = MascotArt.HOLES.map { parsePath(it) }
    val bangs = parsePath(MascotArt.BANGS)
    val bangsTop = MascotArt.BANGS_TOP.map { parsePath(it) }
    val sideL = parsePath(MascotArt.SIDE_L)
    val sideR = parsePath(MascotArt.SIDE_R)
    val hookL = parsePath(MascotArt.HOOK_L)
    val hookR = parsePath(MascotArt.HOOK_R)
    val blush = MascotArt.BLUSH.map { parsePath(it) }

    val handL = HandPath(
        parsePath(MascotArt.HAND_L.fist), parsePath(MascotArt.HAND_L.thumb),
        MascotArt.HAND_L.creases.map { parsePath(it) }
    )
    val handR = HandPath(
        parsePath(MascotArt.HAND_R.fist), parsePath(MascotArt.HAND_R.thumb),
        MascotArt.HAND_R.creases.map { parsePath(it) }
    )

    // ---- expressions (origin-relative: they are translated onto the drawn face) ----
    val eyeGtL = parsePath("M -18,-18 L 16,0 L -18,18")
    val eyeGtR = parsePath("M 18,-18 L -16,0 L 18,18")
    val eyeArc = parsePath("M -17,8 Q 0,-16 17,8")
    val eyeDot = circlePath(0f, 0f, 9f)
    val eyeLine = parsePath("M -16,0 L 16,0")
    val eyeCross = parsePath("M -13,-13 L 13,13 M 13,-13 L -13,13")
    val eyeSpiral = Path().also { p ->
        val n = 44
        for (i in 0..n) {
            val a = i.toDouble() / n * 2 * PI * 2.5
            val r = 1.0 + 15.0 * i / n
            val x = (r * cos(a)).toFloat()
            val y = (r * sin(a)).toFloat()
            if (i == 0) p.moveTo(x, y) else p.lineTo(x, y)
        }
    }
    val mouthCat = parsePath("M -26,4 Q -13,24 0,4 Q 13,24 26,4")
    val mouthWavy = parsePath("M -28,10 Q -21,0 -14,10 Q -7,20 0,10 Q 7,0 14,10 Q 21,20 28,10")
    val mouthTri = Path()
    val mouthO = Path()

    // ---- little symbols that float around her: (shape, filled?) ----
    private fun sym(vararg parts: Pair<Path, Boolean>) = parts.toList()
    val symbols: Map<Sym, List<Pair<Path, Boolean>>> = mapOf(
        Sym.NOTE to sym(parsePath("M 6,0 L 6,-26 Q 8,-20 16,-17") to false, circlePath(0f, 0f, 6f) to true),
        Sym.HEART to sym(parsePath("M 0,10 C -22,-6 -12,-22 0,-10 C 12,-22 22,-6 0,10 Z") to false),
        Sym.QMARK to sym(parsePath("M -9,-14 C -9,-28 10,-28 10,-14 C 10,-6 0,-4 0,6") to false, circlePath(0f, 16f, 2.6f) to true),
        Sym.EXCL to sym(parsePath("M 0,-26 L 0,0") to false, circlePath(0f, 12f, 2.8f) to true),
        Sym.ZED to sym(parsePath("M -9,-9 L 9,-9 L -9,9 L 9,9") to false),
        Sym.DROP to sym(parsePath("M 0,-16 C 10,-2 10,8 0,8 C -10,8 -10,-2 0,-16 Z") to false),
        Sym.DOT to sym(circlePath(0f, 0f, 4.5f) to true)
    )
}

// ------------------------------------------------------------------------------------------ drawing

private val LineCap = StrokeCap.Round
private val LineJoin = StrokeJoin.Round

/** Outlined shape: black fill first (so lines behind it are hidden), then the white outline. */
private fun DrawScope.fl(p: Path, w: Float) {
    drawPath(p, Color.Black)
    drawPath(p, Color.White, style = Stroke(width = w, cap = LineCap, join = LineJoin))
}

private fun DrawScope.ln(p: Path, w: Float) {
    drawPath(p, Color.White, style = Stroke(width = w, cap = LineCap, join = LineJoin))
}

/** An outlined tube (a sleeve): a fat white line with a slightly thinner black one on top. */
private fun DrawScope.tube(p: Path) {
    drawPath(p, Color.White, style = Stroke(width = 78f, cap = LineCap, join = LineJoin))
    drawPath(p, Color.Black, style = Stroke(width = 72f, cap = LineCap, join = LineJoin))
}

private fun DrawScope.drawHand(h: HandPath) {
    fl(h.fist, 3f)
    fl(h.thumb, 3f)
    h.creases.forEach { ln(it, 2.4f) }
}

private fun eyeWidth(k: Eye): Float = when (k) {
    Eye.DOT -> 5f
    Eye.SPIRAL -> 3.4f
    else -> 6f
}

private fun eyeFor(a: MascotPaths, k: Eye, right: Boolean): Path = when (k) {
    Eye.GT -> if (right) a.eyeGtR else a.eyeGtL
    Eye.ARC -> a.eyeArc
    Eye.DOT -> a.eyeDot
    Eye.LINE -> a.eyeLine
    Eye.CROSS -> a.eyeCross
    Eye.SPIRAL -> a.eyeSpiral
}

private fun DrawScope.drawMascot(a: MascotPaths, anim: MascotAnimator) {
    val p = anim.pose
    val t = anim.clock

    withTransform({
        translate(0f, p.bodyDy.toFloat())
        rotate(p.bodyRot.toFloat(), Offset(300f, 800f))
    }) {
        // ---- hair, behind everything ----
        fl(a.hairMass, 3.2f)
        for (i in a.locks.indices) {
            val l = a.locks[i]
            val deg = p.hair * anim.lockAmp[i] * sin(t * anim.lockFreq[i] + anim.lockPhase[i]) - 0.5 * p.bodyRot
            withTransform({ rotate(deg.toFloat(), Offset(l.px, l.py)) }) {
                fl(l.fill, 3.2f)
                ln(l.flow, 2.2f)
            }
        }
        withTransform({ rotate(p.ahoge.toFloat(), Offset(302f, 112f)) }) {
            fl(a.ahoge, 3.2f)
            ln(a.ahogeLine, 2.2f)
        }

        // ---- jacket, collar and ribbon (breathes) ----
        withTransform({ translate(0f, p.torsoDy.toFloat()) }) {
            fl(a.neck, 3.2f)
            fl(a.torso, 3.2f)
            fl(a.collar, 3.2f)
            ln(a.zipper, 2.4f)
            fl(a.zipTab, 2.4f)
            val swayL = (3 * sin(t * 1.5 + 1) + 0.3 * p.bodyRot).toFloat()
            val swayR = (3 * sin(t * 1.3 + 2) + 0.3 * p.bodyRot).toFloat()
            withTransform({ rotate(swayL, Offset(296f, 552f)) }) { fl(a.tailL, 2.6f) }
            withTransform({ rotate(swayR, Offset(304f, 552f)) }) { fl(a.tailR, 2.6f) }
            fl(a.bowL, 2.6f)
            ln(a.bowLLine, 2f)
            fl(a.bowR, 2.6f)
            ln(a.bowRLine, 2f)
            fl(a.bowKnot, 2.6f)
        }

        // ---- sleeves: shoulder -> elbow are fixed, the wrist follows the paper ----
        val rad = p.pRot * PI / 180.0
        val cs = cos(rad)
        val sn = sin(rad)
        fun follow(x: Float, y: Float): Offset {
            val dx = (x - PIV_X) * p.pS
            val dy = (y - PIV_Y) * p.pS
            return Offset(
                (PIV_X + dx * cs - dy * sn + p.pDx).toFloat(),
                (PIV_Y + dx * sn + dy * cs + p.pDy).toFloat()
            )
        }
        val wl = follow(200f, 516f)
        val wr = follow(400f, 516f)
        val td = p.torsoDy.toFloat()
        val armL = Path().apply { moveTo(130f, 592f + td); lineTo(88f, 742f + td); lineTo(wl.x, wl.y) }
        val armR = Path().apply { moveTo(470f, 592f + td); lineTo(512f, 742f + td); lineTo(wr.x, wr.y) }
        tube(armL)
        tube(armR)

        // ---- the paper she holds up, with her hands ----
        withTransform({
            translate(p.pDx.toFloat(), p.pDy.toFloat())
            rotate(p.pRot.toFloat(), Offset(PIV_X, PIV_Y))
            scale(p.pS.toFloat(), p.pS.toFloat(), Offset(PIV_X, PIV_Y))
        }) {
            val flipX = abs(cos(PI * p.flip)).toFloat().coerceAtLeast(0.02f)
            withTransform({
                translate(300f, 0f)
                scale(flipX, 1f, Offset.Zero)
                translate(-300f, 0f)
            }) {
                fl(a.paper, 3.2f)
                ln(a.paperEdge, 2.2f)
                a.holes.forEach { ln(it, 3f) }
                ln(a.bangs, 3f)
                a.bangsTop.forEach { ln(it, 2.4f) }
                ln(a.sideL, 3f)
                ln(a.sideR, 3f)
                ln(a.hookL, 2.6f)
                ln(a.hookR, 2.6f)
                a.blush.forEach { ln(it, 2.6f) }

                // the drawn face: eyes and mouth
                val spin = ((t * 420.0) % 360.0).toFloat()
                val eyeW = eyeWidth(p.eyes)
                val spiral = p.eyes == Eye.SPIRAL
                withTransform({
                    translate(244f, 336f)
                    if (spiral) rotate(spin, Offset.Zero)
                }) { ln(eyeFor(a, p.eyes, false), eyeW) }
                withTransform({
                    translate(356f, 336f)
                    if (spiral) rotate(-spin, Offset.Zero)
                }) { ln(eyeFor(a, p.eyes, true), eyeW) }

                val m = p.mo.coerceIn(0.0, 1.0).toFloat()
                val mouth: Path = when (p.mouth) {
                    Mouth.TRI -> a.mouthTri.also {
                        val hw = 18f + 22f * m
                        val d = 6f + 56f * m
                        it.reset()
                        it.moveTo(-hw, 0f)
                        it.lineTo(hw, 0f)
                        it.lineTo(0f, d)
                        it.close()
                    }
                    Mouth.O -> a.mouthO.also {
                        val r = 7f + 9f * m
                        it.reset()
                        it.circle(0f, r + 2f, r)
                    }
                    Mouth.CAT -> a.mouthCat
                    Mouth.WAVY -> a.mouthWavy
                }
                withTransform({ translate(300f, 376f) }) { ln(mouth, 4f) }
            }
            drawHand(a.handL)
            drawHand(a.handR)
        }

        // ---- floating symbols: notes, hearts, zzz, ? ! ... ----
        for (i in 0 until p.fxN) {
            val f = p.fx[i]
            val al = f.a.coerceIn(0.0, 1.0).toFloat()
            if (al <= 0.01f) continue
            val sc = f.s.toFloat()
            withTransform({
                translate(f.x.toFloat(), f.y.toFloat())
                rotate(f.r.toFloat(), Offset.Zero)
                scale(sc, sc, Offset.Zero)
            }) {
                for ((shape, filled) in a.symbols.getValue(f.k)) {
                    if (filled) drawPath(shape, Color.White, alpha = al)
                    else drawPath(shape, Color.White, alpha = al, style = Stroke(width = 3f, cap = LineCap, join = LineJoin))
                }
            }
        }
    }
}
