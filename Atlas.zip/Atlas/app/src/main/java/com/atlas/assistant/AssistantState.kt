package com.atlas.assistant

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import kotlinx.coroutines.flow.MutableStateFlow

/** Observable state shared between the service, the engine and the UI. */
object AssistantState {
    val messages = MutableStateFlow<List<Msg>>(emptyList())
    val status = MutableStateFlow("Voice off")
    val voiceOn = MutableStateFlow(false)
    val heard = MutableStateFlow("")
    /** Manual online/offline toggle, mirrors Store.forceOffline so every screen sees the same live state. */
    val forceOffline = MutableStateFlow(false)
    /** Mirrors Store.wakeWordEnabled: while true, Novochron waits for the wake phrase before reacting. */
    val wakeWordOn = MutableStateFlow(false)
    /** True from Novochron's first spoken sentence until speech ends or is cut off (drives the on-screen character's mouth). */
    val speaking = MutableStateFlow(false)
    /** Mirrors Store.mascotOn: show the line-art character behind the conversation. */
    val mascotOn = MutableStateFlow(true)

    /** Id of the artifact currently open full screen (0 = none). */
    val openArtifact = MutableStateFlow(0L)
    val showLibrary = MutableStateFlow(false)
    /** True while the full-screen offline map (pinpoint + distance) is open. */
    val showMap = MutableStateFlow(false)
    /** True while the terminal (local sandbox shell + GitHub login/repo/build commands) is open. */
    val showTerminal = MutableStateFlow(false)
    /** True while the vault (upload/delete files in a GitHub repo, once logged in) is open. */
    val showVault = MutableStateFlow(false)

    // [graph]: Desmos-style plotting calculator (see GraphScreen.kt)
    val showGraph = MutableStateFlow(false)

    // [sim]: 3D solar system / Proxima Centauri orbit viewer (see SolarSystemScreen.kt)
    val showSolar = MutableStateFlow(false)
    /** Flips true when Novochron is closing itself (exit button or "turn off, computer"), so the
     *  Activity can remove itself from Recents right before the process is ended. */
    val exitRequested = MutableStateFlow(false)

    /** True while the full-screen camera (photo / live scan) is open. */
    val cameraOpen = MutableStateFlow(false)
    /** True while Novochron is watching the screen: every spoken/typed question gets the latest frame attached. */
    val screencastOn = MutableStateFlow(false)

    /** True while the app screen is in front (used to decide whether to pull it forward). */
    @Volatile var appVisible = false
}

object Net {
    fun isOnline(ctx: Context): Boolean {
        val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val n = cm.activeNetwork ?: return false
        val c = cm.getNetworkCapabilities(n) ?: return false
        return c.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
            c.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
    }
}
