package com.atlas.assistant

import android.app.SearchManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.media.browse.MediaBrowser
import android.media.session.MediaController
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.service.media.MediaBrowserService
import android.widget.Toast

/**
 * "Open SimpMusic and play Multo by Cup of Joe": asks another music app to play something specific.
 *
 * Android has no universal "play this song in that app" call, so this uses the two standard ways a music
 * app can offer it (the same ones Google Assistant and Android Auto use). Which one works depends on
 * what the target app declares, and route() checks that up front:
 *
 *  1. ACTIVITY: the app handles the MEDIA_PLAY_FROM_SEARCH intent (Spotify, YouTube Music and most big apps).
 *  2. BROWSER:  the app exposes a media browser service (this is what Android Auto talks to). Novochron
 *               connects to it and sends a "play from search" request to the app's media session.
 *  3. NONE:     the app offers neither, so Novochron can open it but cannot choose the song for you.
 *
 * Whether the app then actually finds and plays the right track is up to the app.
 */
class MusicPlayer(private val ctx: Context) {

    enum class Route { ACTIVITY, BROWSER, NONE }

    private val main = Handler(Looper.getMainLooper())

    fun route(pkg: String): Route = when {
        searchIntent(pkg, "x").resolveActivity(ctx.packageManager) != null -> Route.ACTIVITY
        browserService(pkg) != null -> Route.BROWSER
        else -> Route.NONE
    }

    /** Route.ACTIVITY: the app opens itself and starts the search. */
    fun viaActivity(pkg: String, query: String): Boolean = try {
        ctx.startActivity(searchIntent(pkg, query)); true
    } catch (e: Exception) { false }

    /**
     * Route.BROWSER: connect to the app's media browser service, grab its media session and ask it to play.
     * Asynchronous; if the app refuses the connection the person gets a short on-screen note.
     */
    fun viaBrowser(pkg: String, label: String, query: String) {
        val svc = browserService(pkg) ?: return
        main.post {
            var browser: MediaBrowser? = null
            var done = false
            fun finish(ok: Boolean) {
                if (done) return
                done = true
                if (!ok) Toast.makeText(ctx, "$label didn't accept the play request.", Toast.LENGTH_LONG).show()
                // give the app a moment to start playback before letting go of the connection
                main.postDelayed({ try { browser?.disconnect() } catch (_: Exception) {} }, if (ok) 5000L else 0L)
            }
            val callback = object : MediaBrowser.ConnectionCallback() {
                override fun onConnected() {
                    try {
                        val b = browser ?: return finish(false)
                        MediaController(ctx, b.sessionToken).transportControls.playFromSearch(query, extras())
                        finish(true)
                    } catch (e: Exception) { finish(false) }
                }
                override fun onConnectionFailed() = finish(false)
            }
            try {
                browser = MediaBrowser(ctx, svc, callback, null).also { it.connect() }
                main.postDelayed({ finish(false) }, 8000L)
            } catch (e: Exception) { finish(false) }
        }
    }

    // ---------- helpers ----------

    private fun extras() = Bundle().apply {
        // "unstructured" search: the query is free text, e.g. "Multo by Cup of Joe"
        putString(MediaStore.EXTRA_MEDIA_FOCUS, "vnd.android.cursor.item/*")
    }

    private fun searchIntent(pkg: String, query: String) =
        Intent(MediaStore.INTENT_ACTION_MEDIA_PLAY_FROM_SEARCH).apply {
            setPackage(pkg)
            putExtra(SearchManager.QUERY, query)
            putExtra(MediaStore.EXTRA_MEDIA_FOCUS, "vnd.android.cursor.item/*")
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }

    private fun browserService(pkg: String): ComponentName? {
        val i = Intent(MediaBrowserService.SERVICE_INTERFACE).setPackage(pkg)
        @Suppress("DEPRECATION")
        val info = ctx.packageManager.queryIntentServices(i, 0)
            .firstOrNull { it.serviceInfo.exported }?.serviceInfo ?: return null
        return ComponentName(info.packageName, info.name)
    }
}
