package com.atlas.assistant

import android.content.Context
import android.media.AudioManager
import android.util.Log
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import org.json.JSONObject
import org.webrtc.AudioTrack
import org.webrtc.Camera2Enumerator
import org.webrtc.CameraVideoCapturer
import org.webrtc.DataChannel
import org.webrtc.DefaultVideoDecoderFactory
import org.webrtc.DefaultVideoEncoderFactory
import org.webrtc.EglBase
import org.webrtc.IceCandidate
import org.webrtc.MediaConstraints
import org.webrtc.MediaStream
import org.webrtc.PeerConnection
import org.webrtc.PeerConnectionFactory
import org.webrtc.RendererCommon
import org.webrtc.RtpReceiver
import org.webrtc.RtpTransceiver
import org.webrtc.SdpObserver
import org.webrtc.SessionDescription
import org.webrtc.SurfaceTextureHelper
import org.webrtc.SurfaceViewRenderer
import org.webrtc.VideoTrack
import java.util.UUID
import kotlin.coroutines.resumeWithException

// ---------------------------------------------------------------------------------------------
// Calling for "msg", over the same "shared repo as mailbox" trick the chat itself uses: the caller
// commits an SDP offer, the callee commits back an SDP answer, and the actual audio/video then
// flows directly phone-to-phone once that handshake is done. Each SDP already has its ICE
// candidates baked into it (STUN tells each phone its public address so the other phone can reach
// it through the NAT), so this is "non-trickle" ICE — one file each way, no back-and-forth of
// separate candidate messages, which suits polling far better than classic trickle ICE would.
// This is the same design N (the tiny two-person branch app this was ported from) uses for its own
// [call]/[video call] buttons — just wired to Atlas's MsgClient/Store instead of N's.
//
// Known limits: STUN alone can't get through every kind of NAT (a small fraction of networks,
// mostly symmetric-NAT carrier or corporate ones, need a relay/TURN server as a fallback — add one
// to iceServers() below if that turns out to matter). The live WebRTC handshake itself still only
// works while "msg" is open on both ends; while it's closed, MsgWatchService's background watcher
// (see CallWatcher in MsgWatchService.kt) notices an incoming offer and posts a notification / has
// Novochron announce it out loud, and opening "msg" from that notification picks the ringing call
// straight up (see the "still-live offer" check in CallManager.poll() below) as long as it's within
// the ring timeout.
// ---------------------------------------------------------------------------------------------

private const val CALL_DIR = "Call"
private const val OFFER_FILE = "$CALL_DIR/offer.json"
private const val ANSWER_FILE = "$CALL_DIR/answer.json"
private const val HANGUP_FILE = "$CALL_DIR/hangup.json"
const val CALL_POLL_MS = 1000L
const val RING_TIMEOUT_MS = 45_000L       // give up ringing (either direction) after this long
private const val ICE_GATHER_TIMEOUT_MS = 8_000L  // cap on waiting for STUN candidates before sending anyway
private const val TAG = "Calling"

enum class CallPhase { RINGING_OUT, RINGING_IN, CONNECTING, CONNECTED, ENDED }

data class CallUiState(
    val callId: String,
    val peerName: String,
    val outgoing: Boolean,
    val video: Boolean,
    val phase: CallPhase,
    val note: String = "",
    val muted: Boolean = false,
    val speakerOn: Boolean = false,
    val elapsedSec: Int = 0,
)

/** The WebRTC PeerConnectionFactory + shared EglBase, created once per process and reused across calls. */
private object Rtc {
    @Volatile private var initialized = false
    lateinit var eglBase: EglBase; private set
    lateinit var factory: PeerConnectionFactory; private set

    @Synchronized
    fun ensure(ctx: Context) {
        if (initialized) return
        PeerConnectionFactory.initialize(
            PeerConnectionFactory.InitializationOptions.builder(ctx.applicationContext)
                .setEnableInternalTracer(false)
                .createInitializationOptions()
        )
        eglBase = EglBase.create()
        factory = PeerConnectionFactory.builder()
            .setVideoEncoderFactory(DefaultVideoEncoderFactory(eglBase.eglBaseContext, true, true))
            .setVideoDecoderFactory(DefaultVideoDecoderFactory(eglBase.eglBaseContext))
            .createPeerConnectionFactory()
        initialized = true
    }
}

private abstract class SimpleSdpObserver : SdpObserver {
    override fun onCreateSuccess(p0: SessionDescription?) {}
    override fun onSetSuccess() {}
    override fun onCreateFailure(p0: String?) {}
    override fun onSetFailure(p0: String?) {}
}

/** One call's WebRTC plumbing: mic (+ camera, for a video call) and the peer connection. */
private class CallEngine(
    private val context: Context,
    val video: Boolean,
    private val onRemoteVideo: (VideoTrack?) -> Unit,
    private val onIceState: (PeerConnection.IceConnectionState) -> Unit,
) {
    val eglBaseContext: EglBase.Context get() = Rtc.eglBase.eglBaseContext

    private var pc: PeerConnection? = null
    private var audioTrack: AudioTrack? = null
    private var videoTrack: VideoTrack? = null
    private var capturer: CameraVideoCapturer? = null
    private var surfaceHelper: SurfaceTextureHelper? = null

    init { Rtc.ensure(context) }

    private fun iceServers() = listOf(
        // Google's public STUN servers: free, no auth, just tell each phone its public address/port
        // so ICE can find a peer-to-peer path through most home/office NATs.
        PeerConnection.IceServer.builder("stun:stun.l.google.com:19302").createIceServer(),
        PeerConnection.IceServer.builder("stun:stun1.l.google.com:19302").createIceServer(),
    )

    fun open() {
        val rtcConfig = PeerConnection.RTCConfiguration(iceServers()).apply {
            sdpSemantics = PeerConnection.SdpSemantics.UNIFIED_PLAN
            continualGatheringPolicy = PeerConnection.ContinualGatheringPolicy.GATHER_ONCE
        }
        pc = Rtc.factory.createPeerConnection(rtcConfig, object : PeerConnection.Observer {
            override fun onIceConnectionChange(state: PeerConnection.IceConnectionState) { onIceState(state) }
            override fun onTrack(transceiver: RtpTransceiver?) {
                (transceiver?.receiver?.track() as? VideoTrack)?.let(onRemoteVideo)
            }
            override fun onSignalingChange(p0: PeerConnection.SignalingState?) {}
            override fun onIceConnectionReceivingChange(p0: Boolean) {}
            override fun onIceGatheringChange(p0: PeerConnection.IceGatheringState?) {}
            override fun onIceCandidate(p0: IceCandidate?) {}
            override fun onIceCandidatesRemoved(p0: Array<out IceCandidate>?) {}
            override fun onAddStream(p0: MediaStream?) {}
            override fun onRemoveStream(p0: MediaStream?) {}
            override fun onDataChannel(p0: DataChannel?) {}
            override fun onRenegotiationNeeded() {}
            override fun onAddTrack(p0: RtpReceiver?, p1: Array<out MediaStream>?) {}
        })

        val audioSource = Rtc.factory.createAudioSource(MediaConstraints())
        val aTrack = Rtc.factory.createAudioTrack("atlas-audio-${UUID.randomUUID()}", audioSource)
        audioTrack = aTrack
        pc?.addTrack(aTrack, listOf("atlas-stream"))

        if (video) startCamera()
    }

    private fun startCamera() {
        val enumerator = Camera2Enumerator(context)
        val name = enumerator.deviceNames.firstOrNull { enumerator.isFrontFacing(it) } ?: enumerator.deviceNames.firstOrNull()
        val cap = name?.let { enumerator.createCapturer(it, null) } ?: return
        val helper = SurfaceTextureHelper.create("atlas-capture", Rtc.eglBase.eglBaseContext)
        val source = Rtc.factory.createVideoSource(false)
        cap.initialize(helper, context, source.capturerObserver)
        cap.startCapture(1280, 720, 30)
        val track = Rtc.factory.createVideoTrack("atlas-video-${UUID.randomUUID()}", source)
        pc?.addTrack(track, listOf("atlas-stream"))
        capturer = cap; surfaceHelper = helper; videoTrack = track
    }

    fun localVideoTrack(): VideoTrack? = videoTrack
    fun setMuted(muted: Boolean) { audioTrack?.setEnabled(!muted) }
    fun switchCamera() { capturer?.switchCamera(null) }

    /** Creates an offer, waits (briefly) for STUN candidates, and returns the SDP with them baked in. */
    suspend fun makeOffer(): SessionDescription = withContext(Dispatchers.Main) {
        val peer = pc ?: error("no peer connection")
        val created = suspendCancellableCoroutine<SessionDescription> { cont ->
            peer.createOffer(object : SimpleSdpObserver() {
                override fun onCreateSuccess(p0: SessionDescription?) {
                    if (p0 != null) cont.resume(p0, null) else cont.resumeWithException(IllegalStateException("null offer"))
                }
                override fun onCreateFailure(p0: String?) { cont.resumeWithException(IllegalStateException(p0 ?: "createOffer failed")) }
            }, MediaConstraints())
        }
        setLocalAndWaitForIce(created)
    }

    /** Sets the remote offer, creates an answer, waits for STUN candidates, and returns the answer SDP. */
    suspend fun makeAnswer(remoteOffer: SessionDescription): SessionDescription = withContext(Dispatchers.Main) {
        val peer = pc ?: error("no peer connection")
        setRemote(remoteOffer)
        val created = suspendCancellableCoroutine<SessionDescription> { cont ->
            peer.createAnswer(object : SimpleSdpObserver() {
                override fun onCreateSuccess(p0: SessionDescription?) {
                    if (p0 != null) cont.resume(p0, null) else cont.resumeWithException(IllegalStateException("null answer"))
                }
                override fun onCreateFailure(p0: String?) { cont.resumeWithException(IllegalStateException(p0 ?: "createAnswer failed")) }
            }, MediaConstraints())
        }
        setLocalAndWaitForIce(created)
    }

    suspend fun setRemoteAnswer(sdp: SessionDescription) = withContext(Dispatchers.Main) { setRemote(sdp) }

    private suspend fun setRemote(sdp: SessionDescription) {
        val peer = pc ?: error("no peer connection")
        suspendCancellableCoroutine<Unit> { cont ->
            peer.setRemoteDescription(object : SimpleSdpObserver() {
                override fun onSetSuccess() { cont.resume(Unit, null) }
                override fun onSetFailure(p0: String?) { cont.resumeWithException(IllegalStateException(p0 ?: "setRemoteDescription failed")) }
            }, sdp)
        }
    }

    private suspend fun setLocalAndWaitForIce(sdp: SessionDescription): SessionDescription {
        val peer = pc ?: error("no peer connection")
        suspendCancellableCoroutine<Unit> { cont ->
            peer.setLocalDescription(object : SimpleSdpObserver() {
                override fun onSetSuccess() { cont.resume(Unit, null) }
                override fun onSetFailure(p0: String?) { cont.resumeWithException(IllegalStateException(p0 ?: "setLocalDescription failed")) }
            }, sdp)
        }
        // peer.localDescription keeps getting the newly-found candidates baked into it as they
        // arrive, even before gathering is fully done, so a capped wait is safe either way.
        withTimeoutOrNull(ICE_GATHER_TIMEOUT_MS) {
            while (peer.iceGatheringState() != PeerConnection.IceGatheringState.COMPLETE) delay(150)
        }
        return peer.localDescription ?: sdp
    }

    fun close() {
        try { capturer?.stopCapture() } catch (_: Exception) {}
        capturer?.dispose(); surfaceHelper?.dispose(); videoTrack?.dispose(); audioTrack?.dispose()
        pc?.close(); pc?.dispose()
        pc = null; capturer = null; surfaceHelper = null; videoTrack = null; audioTrack = null
    }
}

/**
 * Drives one call end-to-end: placing/receiving it, the SDP handshake over the shared repo (see
 * the file header above), and the live [CallUiState] the UI renders. One instance lives as long
 * as the msg screen does, polling the repo's Call/ folder the same way messages get polled.
 */
class CallManager(
    private val context: Context,
    private val scope: CoroutineScope,
    private val client: MsgClient?,
    private val repo: RepoRef?,
    private val store: Store,
) {
    var ui by mutableStateOf<CallUiState?>(null); private set
    var remoteVideo by mutableStateOf<VideoTrack?>(null); private set
    var localVideo by mutableStateOf<VideoTrack?>(null); private set
    val eglBaseContext: EglBase.Context get() { Rtc.ensure(context); return Rtc.eglBase.eglBaseContext }

    private fun myName() = store.msgUserName.ifBlank { "me" }

    private val audioManager: AudioManager? by lazy { context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager }
    private var savedAudioMode = AudioManager.MODE_NORMAL
    private var savedSpeakerOn = false

    /** Routes call audio through the earpiece (default) or the loudspeaker for a louder call. */
    private fun applySpeaker(on: Boolean) {
        val am = audioManager ?: return
        am.mode = AudioManager.MODE_IN_COMMUNICATION
        am.isSpeakerphoneOn = on
    }

    fun toggleSpeaker() {
        val st = ui ?: return
        val on = !st.speakerOn
        applySpeaker(on)
        ui = st.copy(speakerOn = on)
    }

    private fun startAudioRouting(defaultSpeaker: Boolean) {
        val am = audioManager ?: return
        savedAudioMode = am.mode
        savedSpeakerOn = am.isSpeakerphoneOn
        applySpeaker(defaultSpeaker)
    }

    private fun stopAudioRouting() {
        val am = audioManager ?: return
        am.isSpeakerphoneOn = savedSpeakerOn
        am.mode = savedAudioMode
    }

    private var engine: CallEngine? = null
    private var timerJob: Job? = null
    private var pendingOfferSdp: String? = null
    private var lastOfferSha = ""; private var lastAnswerSha = ""; private var lastHangupSha = ""
    private var primed = false

    fun startCall(video: Boolean) {
        val c = client ?: return; val r = repo ?: return
        if (ui != null) return
        val callId = UUID.randomUUID().toString().take(8)
        // Video calls default to the loudspeaker (you're usually holding the phone away from your
        // ear to see the screen); voice calls default to the earpiece as before.
        startAudioRouting(defaultSpeaker = video)
        ui = CallUiState(callId, peerName = "them", outgoing = true, video = video, phase = CallPhase.RINGING_OUT, speakerOn = video)
        scope.launch {
            try {
                val eng = CallEngine(context, video, onRemoteVideo = { remoteVideo = it }, onIceState = ::onIce)
                eng.open(); engine = eng; localVideo = eng.localVideoTrack()
                val offer = eng.makeOffer()
                val body = JSONObject().apply {
                    put("callId", callId); put("from", myName()); put("ts", System.currentTimeMillis())
                    put("video", video); put("sdp", offer.description)
                }
                withContext(Dispatchers.IO) { c.writeFile(OFFER_FILE, body.toString(), "msg: call offer", r) }
                Log.d(TAG, "call placed ($callId)")
            } catch (e: Exception) {
                Log.w(TAG, "failed to place call: ${e.message}"); endLocally()
            }
        }
        scope.launch {
            delay(RING_TIMEOUT_MS)
            val st = ui
            if (st != null && st.callId == callId && st.phase == CallPhase.RINGING_OUT) {
                ui = st.copy(phase = CallPhase.ENDED, note = "No answer")
                delay(1200); endLocally()
            }
        }
    }

    fun accept() {
        val st = ui ?: return
        val c = client ?: return; val r = repo ?: return
        val offerSdp = pendingOfferSdp ?: return
        startAudioRouting(defaultSpeaker = st.video)
        ui = st.copy(phase = CallPhase.CONNECTING, speakerOn = st.video)
        scope.launch {
            try {
                val eng = CallEngine(context, st.video, onRemoteVideo = { remoteVideo = it }, onIceState = ::onIce)
                eng.open(); engine = eng; localVideo = eng.localVideoTrack()
                val answer = eng.makeAnswer(SessionDescription(SessionDescription.Type.OFFER, offerSdp))
                val body = JSONObject().apply {
                    put("callId", st.callId); put("from", myName()); put("ts", System.currentTimeMillis())
                    put("accepted", true); put("sdp", answer.description)
                }
                withContext(Dispatchers.IO) { c.writeFile(ANSWER_FILE, body.toString(), "msg: call answer", r) }
                startTimer()
            } catch (e: Exception) {
                Log.w(TAG, "failed to answer call: ${e.message}"); endLocally()
            }
        }
    }

    fun decline() {
        val st = ui ?: return
        val c = client; val r = repo
        scope.launch {
            try {
                if (c != null && r != null) {
                    val body = JSONObject().apply { put("callId", st.callId); put("from", myName()); put("ts", System.currentTimeMillis()); put("accepted", false) }
                    withContext(Dispatchers.IO) { c.writeFile(ANSWER_FILE, body.toString(), "msg: call decline", r) }
                }
            } catch (_: Exception) {}
            endLocally()
        }
    }

    fun hangup() {
        val st = ui
        val c = client; val r = repo
        if (st != null && c != null && r != null) {
            scope.launch {
                try {
                    val body = JSONObject().apply { put("callId", st.callId); put("from", myName()); put("ts", System.currentTimeMillis()) }
                    withContext(Dispatchers.IO) { c.writeFile(HANGUP_FILE, body.toString(), "msg: call end", r) }
                } catch (_: Exception) {}
            }
        }
        endLocally()
    }

    fun toggleMute() {
        val st = ui ?: return
        val m = !st.muted
        engine?.setMuted(m)
        ui = st.copy(muted = m)
    }

    fun switchCamera() { engine?.switchCamera() }

    private fun onIce(state: PeerConnection.IceConnectionState) {
        val st = ui ?: return
        when (state) {
            PeerConnection.IceConnectionState.CONNECTED, PeerConnection.IceConnectionState.COMPLETED -> {
                if (st.phase != CallPhase.CONNECTED) { ui = st.copy(phase = CallPhase.CONNECTED, note = ""); startTimer() }
            }
            PeerConnection.IceConnectionState.FAILED -> {
                ui = st.copy(note = "Connection failed")
                scope.launch { delay(1500); hangup() }
            }
            PeerConnection.IceConnectionState.DISCONNECTED -> { ui = st.copy(note = "Reconnecting…") }
            else -> {}
        }
    }

    private fun startTimer() {
        timerJob?.cancel()
        timerJob = scope.launch { while (true) { delay(1000); ui = ui?.let { it.copy(elapsedSec = it.elapsedSec + 1) } } }
    }

    private fun endLocally() {
        timerJob?.cancel(); timerJob = null
        engine?.close(); engine = null
        stopAudioRouting()
        remoteVideo = null; localVideo = null; pendingOfferSdp = null
        ui = null
    }

    /** Call from a ~1s loop — piggybacks the same repo-polling pattern the chat already uses. */
    suspend fun poll() {
        val c = client ?: return; val r = repo ?: return
        val files = try { c.listFiles(CALL_DIR, r) } catch (e: Exception) { return }
        val byLeaf = files.associateBy { it.path.substringAfterLast('/') }

        if (!primed) {
            primed = true
            lastOfferSha = byLeaf["offer.json"]?.sha ?: ""
            lastAnswerSha = byLeaf["answer.json"]?.sha ?: ""
            lastHangupSha = byLeaf["hangup.json"]?.sha ?: ""
            // A live offer already sitting in Call/ when this screen (re)opens — e.g. because the
            // person tapped the "X is calling you" notification from CallWatcher — should ring
            // right away instead of silently being treated as old history.
            val offerBody = byLeaf["offer.json"]?.let { runCatching { c.readFile(it.path, r) }.getOrNull() } ?: return
            val o = try { JSONObject(offerBody) } catch (_: Exception) { return }
            val callId = o.optString("callId", ""); val ts = o.optLong("ts", 0L)
            if (callId.isBlank() || System.currentTimeMillis() - ts >= RING_TIMEOUT_MS) return
            val answeredId = byLeaf["answer.json"]?.let { runCatching { c.readFile(it.path, r) }.getOrNull() }
                ?.let { runCatching { JSONObject(it).optString("callId", "") }.getOrNull() }
            val hungupId = byLeaf["hangup.json"]?.let { runCatching { c.readFile(it.path, r) }.getOrNull() }
                ?.let { runCatching { JSONObject(it).optString("callId", "") }.getOrNull() }
            if (answeredId == callId || hungupId == callId) return   // already answered/ended elsewhere
            handleOffer(offerBody)
            return
        }
        byLeaf["offer.json"]?.let { f -> if (f.sha != lastOfferSha) { lastOfferSha = f.sha; c.readFile(f.path, r)?.let(::handleOffer) } }
        byLeaf["answer.json"]?.let { f -> if (f.sha != lastAnswerSha) { lastAnswerSha = f.sha; c.readFile(f.path, r)?.let(::handleAnswer) } }
        byLeaf["hangup.json"]?.let { f -> if (f.sha != lastHangupSha) { lastHangupSha = f.sha; c.readFile(f.path, r)?.let(::handleHangup) } }
    }

    private fun handleOffer(body: String) {
        val o = try { JSONObject(body) } catch (_: Exception) { return }
        val callId = o.optString("callId", ""); val from = o.optString("from", "them"); val ts = o.optLong("ts", 0L)
        if (callId.isBlank() || from == myName()) return
        if (System.currentTimeMillis() - ts > RING_TIMEOUT_MS) { Log.d(TAG, "missed call from $from"); return }
        if (ui != null) return   // already on/starting/receiving a call — ignore for now
        val sdp = o.optString("sdp", ""); if (sdp.isBlank()) return
        pendingOfferSdp = sdp
        ui = CallUiState(callId, peerName = from, outgoing = false, video = o.optBoolean("video", false), phase = CallPhase.RINGING_IN)
        scope.launch {
            delay(RING_TIMEOUT_MS)
            val st = ui
            if (st != null && st.callId == callId && st.phase == CallPhase.RINGING_IN) endLocally()
        }
    }

    private fun handleAnswer(body: String) {
        val o = try { JSONObject(body) } catch (_: Exception) { return }
        val st = ui ?: return
        if (o.optString("callId", "") != st.callId || !st.outgoing) return
        if (!o.optBoolean("accepted", false)) {
            ui = st.copy(phase = CallPhase.ENDED, note = "Declined")
            scope.launch { delay(1500); endLocally() }
            return
        }
        val sdp = o.optString("sdp", ""); if (sdp.isBlank()) return
        val eng = engine ?: return
        ui = st.copy(phase = CallPhase.CONNECTING)
        scope.launch {
            try { eng.setRemoteAnswer(SessionDescription(SessionDescription.Type.ANSWER, sdp)) }
            catch (e: Exception) { Log.w(TAG, "bad answer: ${e.message}"); endLocally() }
        }
    }

    private fun handleHangup(body: String) {
        val o = try { JSONObject(body) } catch (_: Exception) { return }
        val st = ui ?: return
        if (o.optString("callId", "") != st.callId || o.optString("from", "") == myName()) return
        ui = st.copy(phase = CallPhase.ENDED, note = "Call ended")
        scope.launch { delay(1000); endLocally() }
    }

    fun dispose() { timerJob?.cancel(); engine?.close(); engine = null }
}

// ---------------- UI ----------------

@Composable
private fun VideoView(track: VideoTrack?, eglBaseContext: EglBase.Context, modifier: Modifier = Modifier, mirror: Boolean = false) {
    val ctx = LocalContext.current
    val renderer = remember {
        SurfaceViewRenderer(ctx).apply {
            init(eglBaseContext, null)
            setMirror(mirror)
            setScalingType(RendererCommon.ScalingType.SCALE_ASPECT_FILL)
        }
    }
    DisposableEffect(track) {
        track?.addSink(renderer)
        onDispose { track?.removeSink(renderer) }
    }
    DisposableEffect(Unit) { onDispose { renderer.release() } }
    AndroidView(factory = { renderer }, modifier = modifier)
}

@Composable
private fun CallButton(label: String, color: Color, onClick: () -> Unit) {
    TextButton(onClick = onClick) { Text(label, color = color, fontFamily = TermFont, fontWeight = FontWeight.Bold, fontSize = 15.sp) }
}

/** Full-screen call UI: ringing (either direction), connecting, and the live call itself. */
@Composable
fun CallOverlay(
    state: CallUiState,
    localVideo: VideoTrack?,
    remoteVideo: VideoTrack?,
    eglBaseContext: EglBase.Context,
    onAccept: () -> Unit,
    onDecline: () -> Unit,
    onHangup: () -> Unit,
    onToggleMute: () -> Unit,
    onSwitchCamera: () -> Unit,
    onToggleSpeaker: () -> Unit,
) {
    val view = LocalView.current
    DisposableEffect(Unit) { view.keepScreenOn = true; onDispose { view.keepScreenOn = false } }

    Dialog(
        onDismissRequest = { if (state.phase != CallPhase.RINGING_IN) onHangup() },
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Box(Modifier.fillMaxSize().background(Color.Black)) {
            val showVideo = state.video && (state.phase == CallPhase.CONNECTING || state.phase == CallPhase.CONNECTED)
            if (showVideo) {
                VideoView(remoteVideo, eglBaseContext, Modifier.fillMaxSize())
                VideoView(
                    localVideo, eglBaseContext, mirror = true,
                    modifier = Modifier.align(Alignment.TopEnd).padding(16.dp).size(110.dp, 150.dp).clip(RoundedCornerShape(8.dp))
                )
            }
            Column(Modifier.align(Alignment.Center).padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                if (!(showVideo && state.phase == CallPhase.CONNECTED)) {
                    Text(state.peerName, color = Ink, fontFamily = TermFont, fontWeight = FontWeight.Bold, fontSize = 22.sp)
                    Spacer(Modifier.height(8.dp))
                    Text(
                        when (state.phase) {
                            CallPhase.RINGING_OUT -> "calling…"
                            CallPhase.RINGING_IN -> if (state.video) "incoming video call…" else "incoming call…"
                            CallPhase.CONNECTING -> "connecting…"
                            CallPhase.CONNECTED -> "%d:%02d".format(state.elapsedSec / 60, state.elapsedSec % 60)
                            CallPhase.ENDED -> state.note.ifBlank { "call ended" }
                        },
                        color = Dim, fontFamily = TermFont, fontSize = 14.sp
                    )
                    if (state.note.isNotBlank() && state.phase != CallPhase.ENDED) {
                        Spacer(Modifier.height(4.dp))
                        Text(state.note, color = Warn, fontFamily = TermFont, fontSize = 12.sp)
                    }
                }
            }
            // A dedicated row anchored to the bottom, spaced generously and never sharing space with
            // anything else on screen — this is what keeps [mute]/[speaker]/[flip]/[end] (or
            // [decline]/[accept]) from ever fighting another row for width the way a top button bar
            // can if it isn't given its own scroll container (see the msg screen's [call]/[video call]
            // row, which wraps in horizontalScroll for the same reason).
            Row(Modifier.align(Alignment.BottomCenter).padding(bottom = 40.dp), horizontalArrangement = Arrangement.spacedBy(20.dp)) {
                when (state.phase) {
                    CallPhase.RINGING_IN -> { CallButton("[decline]", Warn, onDecline); CallButton("[accept]", Accent, onAccept) }
                    CallPhase.RINGING_OUT, CallPhase.CONNECTING -> CallButton("[cancel]", Warn, onHangup)
                    CallPhase.CONNECTED -> {
                        CallButton(if (state.muted) "[unmute]" else "[mute]", Ink, onToggleMute)
                        CallButton(if (state.speakerOn) "[speaker: on]" else "[speaker]", if (state.speakerOn) Accent else Ink, onToggleSpeaker)
                        if (state.video) CallButton("[flip]", Ink, onSwitchCamera)
                        CallButton("[end]", Warn, onHangup)
                    }
                    CallPhase.ENDED -> {}
                }
            }
        }
    }
}
