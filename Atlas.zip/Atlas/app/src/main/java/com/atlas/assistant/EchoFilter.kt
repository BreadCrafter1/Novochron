package com.atlas.assistant

import java.util.Locale

/**
 * While Novochron talks, its own voice leaks back into the microphone. This decides whether speech heard
 * during that time is the user really interrupting, or just Novochron's voice coming back.
 * Everything is measured against the text Novochron is currently saying ("spoken").
 */
object EchoFilter {

    /** Words that count as an interruption on their own, as long as Novochron did not just say them. */
    val QUICK = setOf(
        "stop", "wait", "hold", "pause", "quiet", "enough", "cancel", "shush", "silence", "nevermind",
        "yes", "yeah", "yep", "yup", "no", "nope", "okay", "ok", "sure"
    )

    private val FILLER = setOf(
        "a", "an", "the", "of", "to", "in", "on", "at", "and", "or", "is", "it", "its", "i", "im", "so",
        "um", "uh", "hm", "hmm", "oh", "ah", "my", "me", "be", "do", "for", "that", "this", "with", "as",
        "are", "was", "by", "if", "we", "he", "she", "they", "you", "your", "then", "just"
    )

    private val STOP_ONLY = Regex(
        "^(?:(?:okay|ok|hey|please|novochron|just)\\s+)*" +
            "(?:stop|wait|hold on|hold up|pause|quiet|be quiet|enough|shut up|shush|silence|never ?mind|cancel|that'?s enough)" +
            "(?:\\s+(?:talking|please|it|now|there|novochron))*$"
    )

    fun tokens(s: String): List<String> =
        s.lowercase(Locale.US).replace('’', '\'')
            .split(Regex("[^a-z0-9']+"))
            .map { it.trim('\'') }
            .filter { it.isNotEmpty() }

    private fun isSignal(w: String) = w in QUICK || (w.length >= 3 && w !in FILLER)

    private fun distance(a: String, b: String, cap: Int): Int {
        if (kotlin.math.abs(a.length - b.length) > cap) return cap + 1
        var prev = IntArray(b.length + 1) { it }
        for (i in 1..a.length) {
            val cur = IntArray(b.length + 1)
            cur[0] = i
            for (j in 1..b.length) {
                val cost = if (a[i - 1] == b[j - 1]) 0 else 1
                cur[j] = minOf(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + cost)
            }
            prev = cur
        }
        return prev[b.length]
    }

    /** Same word, allowing one or two letters of speech-recognition noise on longer words. */
    private fun same(a: String, b: String): Boolean {
        if (a == b) return true
        if (a.length < 4 || b.length < 4) return false
        val cap = if (maxOf(a.length, b.length) >= 8) 2 else 1
        return distance(a, b, cap) <= cap
    }

    private fun inSpoken(w: String, spoken: Collection<String>): Boolean = spoken.any { same(w, it) }

    /** Meaningful words in [heard] that Novochron did not say. Empty means it was almost surely its own echo. */
    fun novelWords(heard: String, spoken: String): List<String> {
        val sp = tokens(spoken).toHashSet()
        return tokens(heard).filter { isSignal(it) && !inSpoken(it, sp) }
    }

    /** Two or more unfamiliar words, or one quick word like "stop" that Novochron did not just say. */
    fun isInterruption(novel: List<String>): Boolean =
        novel.size >= 2 || novel.any { it in QUICK }

    /** Removes the start of [heard] if it is Novochron's own words leaking in ahead of what the user said. */
    fun stripEcho(heard: String, spoken: String): String {
        val words = heard.trim().split(Regex("\\s+")).filter { it.isNotEmpty() }
        val sp = tokens(spoken)
        if (words.isEmpty() || sp.isEmpty()) return heard.trim()
        val norm = words.map { tokens(it).joinToString("") }
        var best = 0
        for (start in sp.indices) {
            var k = 0
            while (k < norm.size && start + k < sp.size && norm[k].isNotEmpty() && same(norm[k], sp[start + k])) k++
            if (k > best) best = k
        }
        return if (best >= 2) words.drop(best).joinToString(" ") else heard.trim()
    }

    fun isStopOnly(text: String): Boolean =
        STOP_ONLY.containsMatchIn(text.lowercase(Locale.US).replace('’', '\'').trim().trimEnd('.', '!', '?', ','))
}
