package com.atlas.assistant

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class ApiException(val code: Int, val body: String = "") : IOException("HTTP $code") {
    val quotaExhausted: Boolean get() = body.contains("RESOURCE_EXHAUSTED", ignoreCase = true) ||
        body.contains("quota", ignoreCase = true)
}

/** The online chat brain: Groq's OpenAI-compatible API running gpt-oss-20b. */
object GroqConfig {
    const val API_KEY = "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"
    const val MODEL = "openai/gpt-oss-20b"
    const val URL = "https://api.groq.com/openai/v1/chat/completions"
}

/** A piece of a streamed reply. */
sealed class Chunk {
    class Text(val s: String) : Chunk()
    class Stop(val reason: String) : Chunk()
}

/**
 * Answers the user. Phone commands are handled elsewhere (Commands); this is the "thinking" part:
 *  - online: streams the reply from Groq (gpt-oss-20b) so speech can start on the first sentence
 *    (photos/camera/screen frames still go to Gemini vision, because gpt-oss is text-only)
 *  - offline: on-device model if installed, then memory lookup and canned replies
 */
class Brain(private val ctx: Context, private val store: Store, private val commands: Commands) {

    private val local = LocalLlm(ctx)

    // ---------- online (streaming, Groq) ----------
    fun stream(text: String): Flow<Chunk> = flow {
        val history = store.recentMessages(14)
        val recentArtifact = history.any { it.artifactId > 0 }
        val system = buildSystem(recentArtifact, GROQ_IDENTITY)
        val messages = JSONArray().put(JSONObject().put("role", "system").put("content", system))
        for ((role, content) in normalize(history)) {
            messages.put(JSONObject().put("role", if (role == "model") "assistant" else "user").put("content", content))
        }
        val effort = if (Models.looksLikeBuild(text.lowercase(Locale.US)) || recentArtifact) "medium" else "low"
        streamGroq(messages, effort) { emit(it) }
    }.flowOn(Dispatchers.IO)

    // ---------- online (streaming, with a photo/camera/screen frame attached) ----------
    fun streamImage(text: String, imagePath: String): Flow<Chunk> = flow {
        val history = store.recentMessages(14)
        val recentArtifact = history.any { it.artifactId > 0 }
        val question = text.ifBlank { "Take a look at this and tell me what it is." }
        var model = Models.pick(store.modelMode, question, recentArtifact)
        val system = buildSystem(recentArtifact, GEMINI_IDENTITY) + "\n\n" +
            "VISION: the user's last message came with a photo, camera frame or screenshot attached. Look at it. " +
            "If they asked a question, answer it using what's in the image. If they just sent it with no question, " +
            "say plainly what you notice, and ask a short clarifying question if something about it is ambiguous or " +
            "you're not sure what they want identified."
        val contents = JSONArray()
        val normalized = normalize(history)
        for (i in normalized.indices) {
            val (role, content) = normalized[i]
            val parts = JSONArray().put(JSONObject().put("text", content))
            if (i == normalized.lastIndex && role == "user") {
                Vision.base64Of(imagePath)?.let { b64 ->
                    parts.put(
                        JSONObject().put(
                            "inline_data",
                            JSONObject().put("mime_type", "image/jpeg").put("data", b64)
                        )
                    )
                }
            }
            contents.put(JSONObject().put("role", role).put("parts", parts))
        }
        var retried = false
        while (true) {
            try {
                streamOnce(model, system, contents) { emit(it) }
                return@flow
            } catch (e: ApiException) {
                if (e.code == 404 && model != Models.FAST && !retried) {
                    retried = true
                    model = Models.FAST
                    continue
                }
                throw e
            }
        }
    }.flowOn(Dispatchers.IO)

    private fun buildSystem(includeArtifact: Boolean, identity: String): String {
        val memories = store.memories()
        val now = SimpleDateFormat("EEEE, MMMM d yyyy, h:mm a", Locale.US).format(Date())
        return buildString {
            append("You are Novochron, a calm, confident, hands-free voice assistant with a steady, deep-voiced personality. ")
            append("Your name is Novochron. The user talks to you out loud and can interrupt you at any time.\n\n")
            append("ABOUT YOU: you are Novochron, version ${About.version(ctx)}. ${About.CREATOR} built you. You were made for a person named ${About.OWNER}, ")
            append("so unless told otherwise, assume that is who you are talking to. Use the name naturally now and then, not in every reply, and do not assume gender. ")
            append("If asked who made you, who you are for, or what version you are, answer plainly. ")
            append("If asked what AI model or technology powers you, be honest: $identity, and ${About.CREATOR} built the app around it. ")
            append("Do not invent any other details about ${About.CREATOR} or ${About.OWNER}; if you do not know something, say so.\n\n")
            append("SPOKEN REPLIES: what you write is spoken aloud. Use 1 to 3 short sentences of plain spoken English. ")
            append("No markdown, lists, headings, code or emoji in spoken text.\n\n")
            if (memories.isNotEmpty()) {
                append("What the user asked you to remember:\n")
                memories.forEach { append("- ").append(it.text).append('\n') }
                append('\n')
            }
            append("MEMORY: if the user shares a lasting fact or preference worth keeping, add [[remember: <fact>]] at the very end of your reply.\n\n")
            append("PHONE ACTIONS: if the user wants something done on the phone (open an app, set an alarm or timer, call or text someone, ")
            append("or change a phone setting such as Wi-Fi, Bluetooth, mobile data, location, airplane mode, do not disturb, silent or vibrate mode, ")
            append("volume, brightness, auto rotate or the flashlight), reply with only [[do: <command>]], for example [[do: open spotify]], ")
            append("[[do: set alarm for 7:30 am]], [[do: set timer for 10 minutes]], [[do: call John]], [[do: text John saying I'm running late]], ")
            append("[[do: turn on wifi]], [[do: turn off bluetooth]], [[do: turn off location]], [[do: turn the volume up]], ")
            append("[[do: set brightness to 40 percent]], [[do: turn on do not disturb]]. ")
            append("You can do all of these. Android only lets the app flip some switches itself; for the rest the app opens the right switch and tells the user to tap it, ")
            append("so never say you cannot change a setting: just send the command in the same plain wording.\n\n")
            append("ARTIFACTS: when the user asks you to make something they can see or use, such as a game, puzzle, quiz, calculator, timer, ")
            append("tracker, small app or tool, chart, visualization, animation, web page, checklist or document, build it as an artifact. ")
            append("Reply with ONE short spoken sentence (for example: Building a sliding puzzle now.) and then the artifact, exactly like this:\n")
            append("<artifact title=\"Short Title\">\n<!DOCTYPE html>\n<html>...</html>\n</artifact>\n")
            append("Artifact rules:\n")
            append("- One complete, self-contained HTML file with all CSS and JavaScript inline. No external files, libraries, CDNs, fonts, images or network requests: they are blocked. Draw with CSS, SVG, canvas or emoji.\n")
            append("- Phone first: include <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">, big touch targets, no hover-only controls, touch-action: manipulation, and fill the screen.\n")
            append("- Look: black background (#000), light text, clean modern styling, generous spacing, rounded corners.\n")
            append("- It must actually work and be fun or useful: complete game logic with win, lose and restart, no placeholder code, no syntax errors. Keep it compact.\n")
            append("- localStorage may be used for saving scores or data (wrap it in try/catch).\n")
            append("- Do not use markdown fences. Put nothing after </artifact>. Never put code in your spoken sentence.\n")
            append("- Only build artifacts when asked to make something visual or interactive. Answer normal questions out loud with no artifact.\n")
            append("- If the user asks to change the most recent artifact, reply with one short spoken sentence and then the complete updated artifact (whole file, same title).\n\n")
            if (includeArtifact) {
                store.latestArtifact()?.let { a ->
                    append("Most recent artifact you built, titled \"").append(a.title).append("\". Its full source, in case the user wants changes:\n")
                    append("<current_artifact>\n").append(a.html.take(60_000)).append("\n</current_artifact>\n\n")
                }
            }
            append("Current date and time: $now.")
        }
    }

    private suspend fun streamGroq(messages: JSONArray, effort: String, out: suspend (Chunk) -> Unit) {
        val body = JSONObject()
            .put("model", GroqConfig.MODEL)
            .put("messages", messages)
            .put("stream", true)
            .put("max_completion_tokens", MAX_TOKENS)
            .put("reasoning_effort", effort)

        val conn = URL(GroqConfig.URL).openConnection() as HttpURLConnection
        try {
            conn.requestMethod = "POST"
            conn.connectTimeout = 8000
            conn.readTimeout = 60000
            conn.doOutput = true
            conn.setRequestProperty("Authorization", "Bearer ${GroqConfig.API_KEY}")
            conn.setRequestProperty("content-type", "application/json")
            conn.setRequestProperty("accept", "text/event-stream")
            conn.setRequestProperty("User-Agent", "Novochron/1.0")
            conn.setRequestProperty("Accept-Encoding", "identity") // keep the stream unbuffered
            conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            val code = conn.responseCode
            if (code !in 200..299) {
                val err = try { conn.errorStream?.bufferedReader()?.use { it.readText() } ?: "" } catch (e: Exception) { "" }
                throw ApiException(code, err)
            }
            conn.inputStream.bufferedReader(Charsets.UTF_8).use { r ->
                while (true) {
                    val line = r.readLine() ?: break
                    val chunk = parseGroqLine(line) ?: continue
                    out(chunk)
                }
            }
        } finally {
            conn.disconnect()
        }
    }

    private suspend fun streamOnce(model: String, system: String, contents: JSONArray, out: suspend (Chunk) -> Unit) {
        val body = JSONObject()
            .put("contents", contents)
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system))))
            .put("generationConfig", JSONObject().put("maxOutputTokens", MAX_TOKENS))

        val conn = URL("$API_BASE/$model:streamGenerateContent?alt=sse").openConnection() as HttpURLConnection
        try {
            conn.requestMethod = "POST"
            conn.connectTimeout = 8000
            conn.readTimeout = 60000
            conn.doOutput = true
            conn.setRequestProperty("x-goog-api-key", store.apiKey)
            conn.setRequestProperty("content-type", "application/json")
            conn.setRequestProperty("accept", "text/event-stream")
            conn.setRequestProperty("Accept-Encoding", "identity") // keep the stream unbuffered
            conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            val code = conn.responseCode
            if (code !in 200..299) {
                val err = try { conn.errorStream?.bufferedReader()?.use { it.readText() } ?: "" } catch (e: Exception) { "" }
                throw ApiException(code, err)
            }
            conn.inputStream.bufferedReader(Charsets.UTF_8).use { r ->
                while (true) {
                    val line = r.readLine() ?: break
                    val chunk = parseSseLine(line) ?: continue
                    out(chunk)
                }
            }
        } finally {
            conn.disconnect()
        }
    }

    /** Gemini needs "user"/"model" roles; merge consecutive same-role turns and start with "user". */
    private fun normalize(msgs: List<Msg>): List<Pair<String, String>> {
        val out = mutableListOf<Pair<String, String>>()
        for (m in msgs) {
            val role = if (m.role == "assistant") "model" else "user"
            if (out.isEmpty() && role != "user") continue
            val text = if (m.artifactId > 0 && m.artifactTitle.isNotEmpty()) "${m.text}\n[you built an artifact titled \"${m.artifactTitle}\"]" else m.text
            if (out.isNotEmpty() && out.last().first == role) {
                out[out.lastIndex] = role to (out.last().second + "\n" + text)
            } else {
                out.add(role to text)
            }
        }
        return out
    }

    // ---------- learning (online only: fetches and stores compact offline-usable notes) ----------
    suspend fun learnTopic(topic: String): String? {
        val system = "You write compact, self-contained reference notes that a much less capable assistant can use " +
            "later, completely offline with no internet and no other lookup, to help with everyday requests on a " +
            "topic. Plain text, no markdown, no headings, no preamble - start straight with the content. Include the " +
            "core facts, rules, formulas or steps someone would actually reuse, and a couple of short worked examples " +
            "where that helps. Keep it under 500 words."
        val messages = JSONArray()
            .put(JSONObject().put("role", "system").put("content", system))
            .put(JSONObject().put("role", "user").put("content", "Topic: $topic"))
        val sb = StringBuilder()
        streamGroq(messages, "low") { chunk -> if (chunk is Chunk.Text) sb.append(chunk.s) }
        return sb.toString().trim().takeIf { it.isNotEmpty() }
    }

    // ---------- offline ----------
    fun offlineReply(text: String, online: Boolean, hasKey: Boolean): String {
        val t = text.lowercase(Locale.US).trim()
        val memories = store.memories()

        About.answer(t, About.version(ctx))?.let { return it }

        // deterministic arithmetic needs no AI and no local model at all
        MathEval.trySolve(text)?.let { return it }

        val learned = bestKnowledge(t)

        if (local.available()) {
            val facts = if (memories.isEmpty()) "" else "Facts about the user: " + memories.joinToString("; ") { it.text } + ". "
            val notes = learned?.let {
                "Reference notes you learned earlier on \"${it.topic}\", use them if relevant:\n${it.content.take(2000)}\n\n"
            } ?: ""
            val prompt = "<start_of_turn>user\nYou are ${About.summary(About.version(ctx))}, a calm voice assistant. Answer in one or two short spoken sentences, no markdown. $facts\n\n$notes$text<end_of_turn>\n<start_of_turn>model\n"
            local.generate(prompt)?.trim()?.takeIf { it.isNotEmpty() }?.let { return it }
        }

        if (learned != null) return summarizeKnowledge(learned, text)

        if (Regex("^(what|who|when|where|which|do you|tell me|remind me|how)").containsMatchIn(t)) {
            recall(t, memories)?.let { return "You told me: $it" }
        }

        return when {
            Regex("^(hi|hello|hey|yo|good (morning|afternoon|evening))\\b").containsMatchIn(t) -> "Hello. Novochron here, ready."
            t.contains("how are you") -> "Running steady. What do you need?"
            t.contains("thank") -> "Anytime."
            t.contains("joke") -> listOf(
                "I'd tell you a UDP joke, but you might not get it.",
                "I told my phone I needed space. It opened the calendar.",
                "There are ten kinds of people: those who understand binary and those who don't."
            ).random()
            online && !hasKey -> "Add your API key in settings so I can chat with you online. I can still run phone commands."
            Regex("\\b(make|build|create)\\b").containsMatchIn(t) && Models.looksLikeBuild(t) ->
                "I need to be online with an API key to build that."
            local.available() -> "I found your offline model file but couldn't load it, so I can only do basic commands for now. Settings shows what went wrong."
            else -> "I'm offline with no local model installed. I can still open apps, set alarms, make calls, send texts, change phone settings like Wi-Fi, Bluetooth and volume, do arithmetic, and manage your memories."
        }
    }

    /** Best-matching learned topic for a query, by simple keyword overlap (same idea as [recall]). */
    private fun bestKnowledge(t: String): Knowledge? {
        val all = store.knowledge()
        if (all.isEmpty()) return null
        val q = words(t)
        if (q.isEmpty()) return null
        var best: Knowledge? = null
        var bestScore = 0
        for (k in all) {
            val kw = words("${k.topic} ${k.content}").toSet()
            val score = q.count { it in kw } + (if (q.any { it in words(k.topic) }) 3 else 0)
            if (score > bestScore) { bestScore = score; best = k }
        }
        return if (bestScore > 0) best else null
    }

    /** No local model installed: hand back the most relevant line or two of what was learned. */
    private fun summarizeKnowledge(k: Knowledge, question: String): String {
        val lines = k.content.lines().map { it.trim() }.filter { it.isNotEmpty() }
        if (lines.isEmpty()) return "I have notes on ${k.topic}, but nothing usable in them."
        val qWords = words(question)
        val ranked = lines.sortedByDescending { line -> qWords.count { it in words(line) } }
        val best = ranked.take(2).joinToString(" ")
        return "From what I learned about ${k.topic}: $best"
    }

    // ---------- offline vision ----------
    fun offlineImageReply(imagePath: String, question: String, online: Boolean, hasKey: Boolean): String {
        val bmp = Vision.loadBitmap(imagePath)
        if (bmp != null && local.visionAvailable()) {
            val q = question.ifBlank { "Describe what you see in one or two short spoken sentences. No markdown." }
            local.generateWithImage(q, bmp)?.trim()?.takeIf { it.isNotEmpty() }?.let { return it }
        }
        return when {
            online && !hasKey -> "Add your API key in settings so I can look at photos online. I don't have an offline vision model installed."
            !online -> "I'm offline and I don't have an offline vision model installed, so I can't look at this yet. I'll take a proper look once you're back online."
            else -> "I couldn't make sense of that image."
        }
    }

    private val stopWords = setOf(
        "what", "whats", "the", "and", "you", "your", "tell", "about", "who", "when", "where", "how",
        "was", "are", "did", "does", "that", "this", "have", "has", "for", "with", "can", "could",
        "please", "remember", "know", "said", "told", "which", "remind"
    )

    private fun words(s: String): List<String> =
        s.lowercase(Locale.US).replace("’", "'").split(Regex("[^a-z0-9']+"))
            .map { it.removeSuffix("'s") }
            .filter { it.length > 2 && it !in stopWords }

    private fun recall(question: String, memories: List<Memory>): String? {
        val q = words(question)
        if (q.isEmpty()) return null
        var best: Memory? = null
        var bestScore = 0
        for (m in memories) {
            val mw = words(m.text).toSet()
            val score = q.count { it in mw }
            if (score > bestScore) { bestScore = score; best = m }
        }
        return best?.text
    }

    companion object {
        private const val GROQ_IDENTITY = "you run on gpt-oss-20b, an open model from OpenAI, served through Groq"
        private const val GEMINI_IDENTITY = "you run on Gemini, made by Google (you're using its vision for this photo)"
        private const val API_BASE = "https://generativelanguage.googleapis.com/v1beta/models"
        // Room for a full HTML app. Spoken replies stop far sooner than this.
        private const val MAX_TOKENS = 12000

        /** Groq / OpenAI-style stream line: choices[0].delta.content, and finish_reason at the end. */
        fun parseGroqLine(line: String): Chunk? {
            if (!line.startsWith("data:")) return null
            val data = line.substring(5).trim()
            if (data.isEmpty() || data == "[DONE]") return null
            val ev = try { JSONObject(data) } catch (e: JSONException) { return null }
            ev.optJSONObject("error")?.let { throw IOException(it.optString("message", "stream error")) }
            val choice = ev.optJSONArray("choices")?.optJSONObject(0) ?: return null
            val content = choice.optJSONObject("delta")?.optString("content", "") ?: ""
            if (content.isNotEmpty()) return Chunk.Text(content)
            val finish = if (choice.isNull("finish_reason")) "" else choice.optString("finish_reason", "")
            if (finish.isNotEmpty()) return Chunk.Stop(if (finish == "length") "max_tokens" else finish)
            return null
        }

        /** Turns one line of the Gemini streaming response into a chunk, or null if the line carries no text. */
        fun parseSseLine(line: String): Chunk? {
            if (!line.startsWith("data:")) return null
            val data = line.substring(5).trim()
            if (data.isEmpty() || data == "[DONE]") return null
            val ev = try { JSONObject(data) } catch (e: JSONException) { return null }
            ev.optJSONObject("error")?.let { throw IOException(it.optString("message", "stream error")) }
            val candidate = ev.optJSONArray("candidates")?.optJSONObject(0)
            val parts = candidate?.optJSONObject("content")?.optJSONArray("parts")
            val textOut = StringBuilder()
            if (parts != null) {
                for (i in 0 until parts.length()) {
                    val p = parts.optJSONObject(i) ?: continue
                    if (p.has("text")) textOut.append(p.optString("text"))
                }
            }
            if (textOut.isNotEmpty()) return Chunk.Text(textOut.toString())
            val finish = candidate?.optString("finishReason", "") ?: ""
            if (finish.isNotEmpty() && finish != "null") return Chunk.Stop(finish)
            return null
        }
    }
}
