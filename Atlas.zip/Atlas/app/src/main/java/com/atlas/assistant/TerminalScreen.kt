package com.atlas.assistant

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch

/**
 * Full-screen terminal: local sandbox shell + GitHub login/repo/build commands (see Terminal.kt),
 * with an optional real-shell bridge to Termux. Opened from the [term] key next to [lib]/[map]/[set].
 */
@Composable
fun TerminalScreen(engine: Engine, onClose: () -> Unit) {
    val terminal = engine.terminal
    val lines by terminal.lines.collectAsState()
    var input by remember { mutableStateOf("") }
    val listState = rememberLazyListState()
    val scope = rememberCoroutineScope()
    var busy by remember { mutableStateOf(false) }

    LaunchedEffect(lines.size) {
        if (lines.isNotEmpty()) listState.animateScrollToItem(lines.size - 1)
    }

    fun submit() {
        val text = input
        if (text.isBlank() && !terminal.awaitingCommitBody) return
        input = ""
        scope.launch {
            busy = true
            if (terminal.awaitingCommitBody) terminal.feedCommitLine(text) else terminal.run(text)
            busy = false
        }
    }

    Column(
        Modifier
            .fillMaxSize()
            .background(Color.Black)
            .padding(12.dp)
    ) {
        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                "[ terminal ]",
                color = Accent,
                fontFamily = TermFont,
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp
            )
            TermTextKey("[close]", onClick = onClose)
        }
        Spacer(Modifier.height(6.dp))
        LazyColumn(
            state = listState,
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .background(Color(0xFF060606))
                .padding(8.dp)
        ) {
            items(lines) { line ->
                Text(
                    line,
                    color = Ink,
                    fontFamily = TermFont,
                    fontSize = 13.sp,
                    modifier = Modifier.padding(vertical = 1.dp)
                )
            }
            if (busy) {
                item {
                    Text("…", color = Dim, fontFamily = TermFont, fontSize = 13.sp)
                }
            }
        }
        Spacer(Modifier.height(8.dp))
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text(
                if (terminal.awaitingCommitBody) ">" else "$",
                color = Accent,
                fontFamily = TermFont,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(end = 6.dp)
            )
            OutlinedTextField(
                value = input,
                onValueChange = { input = it },
                modifier = Modifier.weight(1f),
                singleLine = true,
                textStyle = androidx.compose.ui.text.TextStyle(fontFamily = TermFont, fontSize = 14.sp, color = Ink),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                keyboardActions = KeyboardActions(onSend = { submit() }),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Accent,
                    unfocusedBorderColor = Dim,
                    cursorColor = Accent
                )
            )
            TextButton(onClick = { submit() }) { Text("run", color = Accent, fontFamily = TermFont) }
        }
    }
}
