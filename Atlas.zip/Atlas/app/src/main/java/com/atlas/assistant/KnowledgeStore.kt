package com.atlas.assistant

import android.content.Context
import java.io.File

/**
 * Learned "learn X" notes, kept as plain, human-readable/editable .txt files in Novochron's own
 * folder — Atlas/Knowledge/<topic>.txt — instead of hidden inside the SQLite database. Same idea as
 * Atlas/Maps/places.json: visible in any file manager, easy to inspect, edit by hand, or back up.
 *
 * Falls back to a private "Knowledge" folder in app storage until "own folder" access is granted,
 * the same fallback Store.kt uses for the database and Maps.kt uses for places.json.
 */
object KnowledgeStore {

    private fun dir(ctx: Context): File {
        val d = if (AtlasStorage.hasAccess() && AtlasStorage.ensureDirs()) AtlasStorage.knowledgeDir()
        else File(ctx.filesDir, "Knowledge")
        try { d.mkdirs() } catch (e: Exception) { }
        return d
    }

    private fun slug(topic: String): String {
        val cleaned = topic.trim().lowercase().replace(Regex("[^a-z0-9]+"), "-").trim('-')
        return cleaned.ifBlank { "topic" }.take(60)
    }

    /** Stable id derived from the topic's slug, so ids survive app restarts without a separate index file. */
    fun idFor(topic: String): Long = slug(topic).hashCode().toLong() and 0x7fffffffL

    private fun files(ctx: Context): Array<File> =
        dir(ctx).listFiles { f -> f.isFile && f.name.endsWith(".txt") } ?: emptyArray()

    @Synchronized
    fun save(ctx: Context, topic: String, content: String) {
        val t = topic.trim()
        val c = content.trim()
        if (t.isEmpty() || c.isEmpty()) return
        val f = File(dir(ctx), slug(t) + ".txt")
        try {
            // first line preserves the original topic wording (the slug can lose casing/punctuation);
            // everything after the first newline is the actual reference content.
            f.writeText(t + "\n" + c)
        } catch (e: Exception) { }
        prune(ctx)
    }

    @Synchronized
    fun all(ctx: Context): List<Knowledge> = files(ctx).mapNotNull { f ->
        try {
            val raw = f.readText()
            val nl = raw.indexOf('\n')
            val topic = (if (nl >= 0) raw.substring(0, nl) else raw).trim().ifBlank { f.nameWithoutExtension }
            val content = if (nl >= 0) raw.substring(nl + 1) else ""
            Knowledge(idFor(topic), topic, content, f.lastModified())
        } catch (e: Exception) {
            null
        }
    }.sortedByDescending { it.ts }

    @Synchronized
    fun delete(ctx: Context, id: Long) {
        for (f in files(ctx)) {
            try {
                val raw = f.readText()
                val topic = raw.substringBefore('\n').trim().ifBlank { f.nameWithoutExtension }
                if (idFor(topic) == id) f.delete()
            } catch (e: Exception) { }
        }
    }

    @Synchronized
    fun clear(ctx: Context) {
        for (f in files(ctx)) { try { f.delete() } catch (e: Exception) { } }
    }

    /** Keeps this from growing forever — keep only the 60 most recently learned/updated topics. */
    private fun prune(ctx: Context) {
        val list = files(ctx)
        if (list.size <= 60) return
        list.sortedBy { it.lastModified() }.take(list.size - 60).forEach { try { it.delete() } catch (e: Exception) { } }
    }
}
