package com.atlas.assistant

import android.graphics.Paint as AndroidPaint
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.drawscope.scale
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.res.imageResource
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.max
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.random.Random

/**
 * "[sim]": a Universe-Sandbox-style 3D system viewer. Two systems are built in — the real Solar
 * System and the Proxima Centauri system — with real relative orbital distances/periods (see
 * OrbitMath.kt). Bodies are drawn as textured, lit spheres against a procedural starfield, moons
 * appear when you zoom into their planet, tapping any body flies the camera to it and opens an info
 * card, and dragging/pinching freely orbits and zooms the camera around the whole scene at any time.
 * Entirely offline — no network, no external engine, just Canvas + trig + bundled texture bitmaps.
 */

private const val PLANET_SCALE = 2.1   // "AU-equivalent" size multiplier for planets/moons — see focusDistanceFor
private const val STAR_SCALE = 3.2

private sealed class Selection {
    data class PlanetSel(val body: OrbitMath.Body) : Selection()
    data class MoonSel(val moon: OrbitMath.Moon, val parent: OrbitMath.Body) : Selection()
}

@Composable
fun SolarSystemScreen(onClose: () -> Unit) {
    var usingProxima by remember { mutableStateOf(false) }
    val bodies = remember(usingProxima) { if (usingProxima) OrbitMath.PROXIMA_SYSTEM else OrbitMath.SOLAR_SYSTEM }
    val textures = rememberBodyTextures(bodies)
    val stars = rememberStarField()

    var tDays by remember(usingProxima) { mutableFloatStateOf(0f) }
    var playing by remember { mutableStateOf(true) }
    var speed by remember { mutableFloatStateOf(1f) }
    var frameTick by remember(usingProxima) { mutableIntStateOf(0) }

    val defaultDistance = if (usingProxima) 3.0 else 40.0
    val camera = remember(usingProxima) { OrbitMath.Camera(yaw = 0.6, pitch = 0.5, distanceAu = defaultDistance) }

    var selection by remember(usingProxima) { mutableStateOf<Selection?>(null) }
    var focused by remember(usingProxima) { mutableStateOf<OrbitMath.Body?>(null) }
    var preFocusDistance by remember(usingProxima) { mutableStateOf(defaultDistance) }

    fun focusOn(body: OrbitMath.Body?) {
        if (body != null && focused == null) preFocusDistance = camera.distanceAu
        focused = body
        selection = body?.let { Selection.PlanetSel(it) }
    }

    val daysPerSecond = Math.pow(10.0, (speed - 1.0) / 1.3).toFloat()

    // Single ticker: advances sim time (if playing), animates the camera toward its current goal
    // (system overview, or gliding to sit on the focused body), and redraws every frame either way —
    // so drag/pinch/tap all feel live even while paused.
    LaunchedEffect(usingProxima) {
        while (true) {
            delay(16)
            if (playing) tDays += daysPerSecond * 0.016f
            frameTick++

            val goalTarget = focused?.let { OrbitMath.position(it, tDays.toDouble()) } ?: OrbitMath.Vec3(0.0, 0.0, 0.0)
            val goalDist = focused?.let { focusDistanceFor(it) } ?: preFocusDistance
            val lerp = 0.16
            camera.target = OrbitMath.Vec3(
                camera.target.x + (goalTarget.x - camera.target.x) * lerp,
                camera.target.y + (goalTarget.y - camera.target.y) * lerp,
                camera.target.z + (goalTarget.z - camera.target.z) * lerp
            )
            camera.distanceAu += (goalDist - camera.distanceAu) * lerp
        }
    }

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        Column(Modifier.fillMaxSize().padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                TermTextKey("[back]", onClick = onClose)
                Spacer(Modifier.weight(1f))
                Text("sim", color = Accent, fontFamily = TermFont, fontSize = 18.sp)
                Spacer(Modifier.weight(1f))
                TermTextKey(
                    if (usingProxima) "[proxima]" else "[solar]",
                    tone = Accent,
                    onClick = { usingProxima = !usingProxima; selection = null; focused = null; tDays = 0f }
                )
            }
            Spacer(Modifier.height(8.dp))

            Box(
                Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .border(1.dp, Line)
                    .pointerInput(usingProxima) {
                        detectTransformGestures { _, pan, zoom, _ ->
                            camera.yaw -= pan.x * 0.006
                            camera.pitch = (camera.pitch - pan.y * 0.006).coerceIn(-1.5, 1.5)
                            val minDist = if (focused != null) focusDistanceFor(focused!!) * 0.15 else 0.05
                            camera.distanceAu = (camera.distanceAu / zoom).coerceIn(minDist, 250.0)
                        }
                    }
                    .pointerInput(bodies, focused, usingProxima) {
                        detectTapGestures { tap ->
                            val w = size.width.toFloat(); val h = size.height.toFloat()
                            val focusedBody = focused

                            // moons of the focused body are tappable first — they sit "in front"
                            if (focusedBody != null && focusedBody.moons.isNotEmpty()) {
                                val planetPos = OrbitMath.position(focusedBody, tDays.toDouble())
                                var bestMoon: OrbitMath.Moon? = null
                                var bestDist = 46f
                                focusedBody.moons.forEach { m ->
                                    val mp = moonWorldPos(planetPos, m, tDays.toDouble())
                                    val (sx, sy, _) = camera.project(mp, w, h)
                                    val d = OrbitMath.dist(tap.x, tap.y, sx, sy)
                                    if (d < bestDist) { bestDist = d; bestMoon = m }
                                }
                                if (bestMoon != null) {
                                    selection = Selection.MoonSel(bestMoon!!, focusedBody)
                                    return@detectTapGestures
                                }
                            }

                            var best: OrbitMath.Body? = null
                            var bestDist = 46f
                            bodies.forEach { b ->
                                val p = OrbitMath.position(b, tDays.toDouble())
                                val (sx, sy, _) = camera.project(p, w, h)
                                val d = OrbitMath.dist(tap.x, tap.y, sx, sy)
                                if (d < bestDist) { bestDist = d; best = b }
                            }
                            if (best != null) {
                                focusOn(best)
                            } else if (focusedBody != null) {
                                selection = Selection.PlanetSel(focusedBody) // empty tap while zoomed: back to planet info
                            }
                        }
                    }
            ) {
                val _tick = frameTick // read to force a redraw every tick, even while paused/idle
                SystemCanvas(bodies, tDays, camera, textures, stars, focused)

                if (focused != null) {
                    Box(Modifier.align(Alignment.TopStart).padding(6.dp)) {
                        TermTextKey("[system view]", tone = Accent, onClick = { focusOn(null) })
                    }
                }
            }

            InfoCard(selection)

            Spacer(Modifier.height(6.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                TermTextKey(if (playing) "[pause]" else "[play]", onClick = { playing = !playing })
                Spacer(Modifier.width(10.dp))
                Text("speed", color = Dim, fontFamily = TermFont, fontSize = 11.sp)
                Slider(
                    value = speed,
                    onValueChange = { speed = it },
                    valueRange = 0f..8f,
                    colors = SliderDefaults.colors(thumbColor = Accent, activeTrackColor = Accent, inactiveTrackColor = Line),
                    modifier = Modifier.weight(1f).padding(horizontal = 8.dp)
                )
                TermTextKey("[reset t]", onClick = { tDays = 0f })
            }
            Text(
                "Drag to orbit · pinch to zoom · tap a body to fly to it",
                color = Dim, fontFamily = TermFont, fontSize = 11.sp
            )
        }
    }
}

/** Distance (in the same "AU-equivalent" space used for drawing) that nicely frames [body] and, if any, its farthest moon. */
private fun focusDistanceFor(body: OrbitMath.Body): Double {
    val factor = if (body.isStar) STAR_SCALE else PLANET_SCALE
    val planetNeed = body.radiusUnits * factor * 3.0
    val farMoon = body.moons.maxOfOrNull { it.orbitVisualUnits } ?: 0.0
    val moonNeed = farMoon * PLANET_SCALE * 2.14
    return maxOf(planetNeed, moonNeed, 0.02)
}

/** World (AU-equivalent) position of a moon: its planet's real position plus its exaggerated local orbit offset. */
private fun moonWorldPos(planetPos: OrbitMath.Vec3, moon: OrbitMath.Moon, tDays: Double): OrbitMath.Vec3 {
    val off = OrbitMath.moonLocalOffset(moon, tDays)
    return planetPos + OrbitMath.Vec3(off.x * PLANET_SCALE, off.y * PLANET_SCALE, off.z * PLANET_SCALE)
}

private fun fmt(v: Double): String {
    val r = Math.round(v * 100.0) / 100.0
    return if (r == r.toLong().toDouble()) r.toLong().toString() else r.toString()
}

private fun fmtInt(v: Double): String {
    val n = Math.round(v)
    return if (n >= 100000) String.format("%,d", n) else n.toString()
}

@Composable
private fun rememberBodyTextures(bodies: List<OrbitMath.Body>): Map<Int, ImageBitmap> {
    val ids = remember(bodies) {
        val s = LinkedHashSet<Int>()
        bodies.forEach { b ->
            b.textureRes?.let { s.add(it) }
            b.moons.forEach { m -> m.textureRes?.let { s.add(it) } }
        }
        s.toList()
    }
    val map = LinkedHashMap<Int, ImageBitmap>()
    for (id in ids) map[id] = ImageBitmap.imageResource(id = id)
    return map
}

@Composable
private fun rememberStarField(count: Int = 420): List<OrbitMath.Vec3> = remember {
    val rnd = Random(7)
    (0 until count).map {
        val u = rnd.nextDouble(-1.0, 1.0)
        val theta = rnd.nextDouble(0.0, 2 * Math.PI)
        val s = sqrt((1 - u * u).coerceAtLeast(0.0))
        OrbitMath.Vec3(s * cos(theta), u, s * sin(theta))
    }
}

@Composable
private fun InfoCard(selection: Selection?) {
    when (selection) {
        null -> {}
        is Selection.PlanetSel -> {
            val b = selection.body
            Spacer(Modifier.height(8.dp))
            Text(b.name, color = Accent, fontFamily = TermFont, fontSize = 14.sp)
            val facts = buildString {
                if (b.isStar) append("system star") else {
                    append("${fmt(b.orbitAu)} AU out · orbits every ${fmt(b.periodDays)} days")
                    if (b.periodDays > 700) append(" (${fmt(b.periodDays / 365.25)} yr)")
                }
                if (b.radiusKm > 0) append(" · radius ${fmtInt(b.radiusKm)} km")
                if (b.massEarths > 0) {
                    append(if (b.isStar) " · ${fmt(b.massEarths / 333000.0)}\u00d7 Sun mass" else " · ${fmt(b.massEarths)}\u00d7 Earth mass")
                }
                if (b.dayLengthHours != 0.0) append(" · day ${fmt(kotlin.math.abs(b.dayLengthHours))}h${if (b.dayLengthHours < 0) " (retrograde)" else ""}")
                if (b.meanTempC.isNotEmpty()) append(" · ${b.meanTempC}")
                if (b.moons.isNotEmpty()) append(" · ${b.moons.size} moon${if (b.moons.size > 1) "s" else ""} shown")
            }
            Text(facts, color = Ink, fontFamily = TermFont, fontSize = 11.sp)
            if (b.blurb.isNotEmpty()) {
                Spacer(Modifier.height(2.dp))
                Text(b.blurb, color = Dim, fontFamily = TermFont, fontSize = 11.sp)
            }
        }
        is Selection.MoonSel -> {
            val m = selection.moon; val p = selection.parent
            Spacer(Modifier.height(8.dp))
            Text("${m.name} — moon of ${p.name}", color = Accent, fontFamily = TermFont, fontSize = 14.sp)
            Text(
                "radius ${fmtInt(m.radiusKm)} km · orbits ${p.name} every ${fmt(m.periodDays)} days" +
                    if (m.retrograde) " (retrograde)" else "",
                color = Ink, fontFamily = TermFont, fontSize = 11.sp
            )
        }
    }
}

@Composable
private fun SystemCanvas(
    bodies: List<OrbitMath.Body>,
    tDays: Float,
    camera: OrbitMath.Camera,
    textures: Map<Int, ImageBitmap>,
    stars: List<OrbitMath.Vec3>,
    focused: OrbitMath.Body?
) {
    Canvas(Modifier.fillMaxSize()) {
        val w = size.width; val h = size.height

        drawSpaceBackground(stars, camera, w, h)

        // orbit rings for top-level bodies
        bodies.forEach { b ->
            if (b.isStar || b.orbitAu <= 0.0) return@forEach
            drawRing(camera, w, h, steps = 110) { frac ->
                OrbitMath.position(b.copy(startAngleDeg = 0.0, periodDays = 1.0), frac)
            }
            val labelPos = camera.project(OrbitMath.position(b.copy(startAngleDeg = 0.0, periodDays = 1.0), 0.0), w, h)
            drawContext.canvas.nativeCanvas.drawText(
                "${fmt(b.orbitAu)} AU", labelPos.first + 4f, labelPos.second - 4f, labelPaint
            )
        }

        // moon orbit rings, only for the focused planet
        val planetPosForMoons = focused?.let { OrbitMath.position(it, tDays.toDouble()) }
        if (focused != null && planetPosForMoons != null) {
            focused.moons.forEach { m ->
                drawRing(camera, w, h, steps = 72) { frac ->
                    val fake = m.copy(startAngleDeg = 0.0, periodDays = 1.0)
                    planetPosForMoons + OrbitMath.Vec3(
                        OrbitMath.moonLocalOffset(fake, frac).x * PLANET_SCALE,
                        OrbitMath.moonLocalOffset(fake, frac).y * PLANET_SCALE,
                        OrbitMath.moonLocalOffset(fake, frac).z * PLANET_SCALE
                    )
                }
            }
        }

        // gather everything to draw (planets/star, + focused planet's moons), sorted back-to-front
        data class Drawable(val name: String, val pos: OrbitMath.Vec3, val radiusUnits: Double, val color: Long, val tex: Int?, val isStar: Boolean, val hasRings: Boolean, val dayH: Double, val periodD: Double)

        val drawables = mutableListOf<Drawable>()
        bodies.forEach { b ->
            drawables += Drawable(b.name, OrbitMath.position(b, tDays.toDouble()), b.radiusUnits, b.color, b.textureRes, b.isStar, b.hasRings, b.dayLengthHours, b.periodDays)
        }
        if (focused != null && planetPosForMoons != null) {
            focused.moons.forEach { m ->
                drawables += Drawable(m.name, moonWorldPos(planetPosForMoons, m, tDays.toDouble()), m.radiusUnits, m.color, m.textureRes, false, false, 0.0, m.periodDays)
            }
        }

        val withDepth = drawables.map { d ->
            val (sx, sy, scale) = camera.project(d.pos, w, h)
            Triple(d, Offset(sx, sy), scale)
        }.sortedBy { it.third }

        withDepth.forEach { (d, pos, scale) ->
            val factor = if (d.isStar) STAR_SCALE else PLANET_SCALE
            val r = (d.radiusUnits * factor * min(max(scale, 0.15), 6.0)).toFloat().coerceIn(2.5f, 260f)

            if (d.isStar) {
                drawCircle(color = Color(d.color).copy(alpha = 0.22f), radius = r * 2.6f, center = pos)
                drawCircle(color = Color(d.color).copy(alpha = 0.12f), radius = r * 4.2f, center = pos)
            }

            val toStar = camera.dirToStar(d.pos)
            val image = d.tex?.let { textures[it] }
            val rotPeriod = when {
                d.dayH != 0.0 -> kotlin.math.abs(d.dayH) / 24.0
                d.periodD > 0 -> d.periodD
                else -> 27.0
            }
            val dayDir = if (d.dayH < 0) -1.0 else 1.0
            var rotFrac = ((dayDir * tDays / rotPeriod).toFloat()) % 1f
            if (rotFrac < 0f) rotFrac += 1f

            drawTexturedSphere(image, Color(d.color), pos, r, rotFrac, toStar, lit = !d.isStar)

            if (d.hasRings && r > 4f) drawRings(pos, r, camera)
        }
    }
}

private fun androidx.compose.ui.graphics.drawscope.DrawScope.drawSpaceBackground(
    stars: List<OrbitMath.Vec3>, camera: OrbitMath.Camera, w: Float, h: Float
) {
    drawRect(color = Color(0xFF01020A), size = Size(w, h))

    // soft Milky Way band, subtly parallaxed by camera yaw so it feels like part of the scene
    val bandShift = (camera.yaw * 40.0).toFloat()
    drawRect(
        brush = Brush.linearGradient(
            colors = listOf(Color.Transparent, Color(0x2A9FA8D0), Color(0x1A6E76A8), Color.Transparent),
            start = Offset(-w * 0.3f + bandShift, h * 1.1f),
            end = Offset(w * 1.2f + bandShift, -h * 0.2f)
        ),
        size = Size(w, h)
    )
    drawRect(
        brush = Brush.radialGradient(
            colors = listOf(Color(0x18C9D6FF), Color.Transparent),
            center = Offset(w * 0.55f + bandShift * 0.5f, h * 0.35f),
            radius = w * 0.65f
        ),
        size = Size(w, h)
    )

    val focal = h * 0.9
    stars.forEach { dir ->
        val cy = cos(camera.yaw); val sy = sin(camera.yaw)
        val x1 = dir.x * cy - dir.z * sy
        val z1 = dir.x * sy + dir.z * cy
        val cp = cos(camera.pitch); val sp = sin(camera.pitch)
        val y2 = dir.y * cp - z1 * sp
        val z2 = dir.y * sp + z1 * cp
        val denom = z2 + 2.2
        if (denom <= 0.35) return@forEach
        val persp = focal / denom
        val sx = w / 2 + (x1 * persp).toFloat()
        val sy2 = h / 2 - (y2 * persp).toFloat()
        if (sx < -20 || sx > w + 20 || sy2 < -20 || sy2 > h + 20) return@forEach
        val brightness = (0.35 + 0.65 * ((dir.x * 37 + dir.y * 91 + dir.z * 53) % 1.0).let { if (it < 0) it + 1 else it }).toFloat()
        val sizePx = (0.6f + brightness * 1.5f)
        drawCircle(color = Color.White.copy(alpha = (0.35f + brightness * 0.55f).coerceIn(0f, 1f)), radius = sizePx, center = Offset(sx, sy2))
    }
}

private fun androidx.compose.ui.graphics.drawscope.DrawScope.drawRing(
    camera: OrbitMath.Camera, w: Float, h: Float, steps: Int, pointAt: (Double) -> OrbitMath.Vec3
) {
    var prev: Offset? = null
    for (i in 0..steps) {
        val frac = i.toDouble() / steps
        val p = pointAt(frac)
        val (sx, sy, _) = camera.project(p, w, h)
        val cur = Offset(sx, sy)
        if (prev != null) drawLine(color = Line, start = prev, end = cur, strokeWidth = 1f)
        prev = cur
    }
}

/** Normalized-ish screen-space direction from a body toward the star (system origin) — used for fake lighting. */
private fun OrbitMath.Camera.dirToStar(bodyPos: OrbitMath.Vec3): Offset {
    val len = sqrt(bodyPos.x * bodyPos.x + bodyPos.y * bodyPos.y + bodyPos.z * bodyPos.z)
    if (len < 1e-6) return Offset(0.4f, -0.4f) // the star itself: arbitrary, unused (not lit)
    val dx = -bodyPos.x / len; val dy = -bodyPos.y / len; val dz = -bodyPos.z / len
    val cy = cos(yaw); val sy = sin(yaw)
    val x1 = dx * cy - dz * sy
    val z1 = dx * sy + dz * cy
    val cp = cos(pitch); val sp = sin(pitch)
    val y2 = dy * cp - z1 * sp
    val mag = sqrt(x1 * x1 + y2 * y2).let { if (it < 1e-6) 1.0 else it }
    return Offset((x1 / mag).toFloat(), (-y2 / mag).toFloat())
}

private fun androidx.compose.ui.graphics.drawscope.DrawScope.drawTexturedSphere(
    image: ImageBitmap?, fallback: Color, center: Offset, radius: Float, rotFrac: Float, toStar: Offset, lit: Boolean
) {
    val r = radius.coerceAtLeast(1.5f)
    val clip = Path().apply { addOval(Rect(center.x - r, center.y - r, center.x + r, center.y + r)) }
    clipPath(clip) {
        if (image != null) {
            val texW = image.width; val texH = image.height
            val cropW = texH.coerceAtMost(texW)
            val baseX = (((rotFrac * texW).toInt()) % texW + texW) % texW
            val dstOx = (center.x - r).toInt(); val dstOy = (center.y - r).toInt()
            val dstWpx = (r * 2).toInt().coerceAtLeast(1); val dstHpx = (r * 2).toInt().coerceAtLeast(1)
            val firstW = min(cropW, texW - baseX)
            val firstDstW = (dstWpx.toLong() * firstW / cropW).toInt().coerceAtLeast(1)
            drawImage(
                image = image,
                srcOffset = IntOffset(baseX, 0),
                srcSize = IntSize(firstW, texH),
                dstOffset = IntOffset(dstOx, dstOy),
                dstSize = IntSize(firstDstW, dstHpx)
            )
            if (firstW < cropW) {
                val remaining = cropW - firstW
                val remainDstW = (dstWpx - firstDstW).coerceAtLeast(1)
                drawImage(
                    image = image,
                    srcOffset = IntOffset(0, 0),
                    srcSize = IntSize(remaining, texH),
                    dstOffset = IntOffset(dstOx + firstDstW, dstOy),
                    dstSize = IntSize(remainDstW, dstHpx)
                )
            }
        } else {
            drawRect(color = fallback, topLeft = Offset(center.x - r, center.y - r), size = Size(r * 2, r * 2))
        }

        if (lit) {
            val darkCenter = Offset(center.x - toStar.x * r * 0.6f, center.y - toStar.y * r * 0.6f)
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(Color.Transparent, Color.Transparent, Color.Black.copy(alpha = 0.82f)),
                    center = darkCenter, radius = r * 1.55f
                ),
                radius = r, center = center
            )
            val hiCenter = Offset(center.x + toStar.x * r * 0.35f - r * 0.1f, center.y + toStar.y * r * 0.35f - r * 0.1f)
            drawCircle(
                brush = Brush.radialGradient(colors = listOf(Color.White.copy(alpha = 0.16f), Color.Transparent), center = hiCenter, radius = r * 0.85f),
                radius = r, center = center
            )
        } else {
            drawCircle(brush = Brush.radialGradient(colors = listOf(Color.White.copy(alpha = 0.35f), Color.Transparent), center = center, radius = r * 1.1f), radius = r, center = center)
        }
    }
    drawCircle(color = Color.Black.copy(alpha = 0.45f), radius = r, center = center, style = Stroke(width = 1f))
}

private fun androidx.compose.ui.graphics.drawscope.DrawScope.drawRings(center: Offset, planetR: Float, camera: OrbitMath.Camera) {
    val flatten = (0.28 + 0.5 * (1.0 - kotlin.math.abs(sin(camera.pitch)))).coerceIn(0.16, 0.62).toFloat()
    val outerR = planetR * 2.1f
    scale(1f, flatten, pivot = center) {
        val bands = listOf(
            0.55f to Color(0xFFCBB68A).copy(alpha = 0.55f),
            0.7f to Color(0xFF8F7C58).copy(alpha = 0.4f),
            0.85f to Color(0xFFE0D2AE).copy(alpha = 0.5f),
            1.0f to Color(0xFFA6926A).copy(alpha = 0.35f)
        )
        var prevFrac = 0.42f
        bands.forEach { (frac, color) ->
            drawCircle(color = color, radius = outerR * frac, center = center, style = Stroke(width = outerR * (frac - prevFrac) + 1f))
            prevFrac = frac
        }
    }
}

private val labelPaint = AndroidPaint().apply {
    color = android.graphics.Color.argb(140, 140, 150, 140)
    textSize = 22f
    isAntiAlias = true
    typeface = android.graphics.Typeface.MONOSPACE
}
