package com.atlas.assistant

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.weight
import androidx.compose.foundation.layout.width
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathFillType
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.random.Random

/**
 * "[sim]": a small Universe-Sandbox-style 3D orbit viewer. Two systems are built in — the real Solar
 * System and the Proxima Centauri system (Proxima b/c and the disputed inner candidate d) — with real
 * relative orbital periods and distances (circular-orbit approximation; see OrbitMath.kt). Bodies are
 * drawn with procedural shading per [OrbitMath.Texture] (bands for the gas giants, continents/clouds
 * for Earth, rings for Saturn) against a generated starfield + Milky Way band, and each planet with
 * moons shows them as small orbiting dots around it — real moon orbits are far too small to draw to
 * true AU scale next to a whole solar system, so those are screen-space decoration, but each still
 * turns at its own real orbital period. One-finger drag orbits the camera, pinch zooms, tap a body for
 * its numbers. Entirely offline — no network, no external engine, just Canvas + trig.
 */
@Composable
fun SolarSystemScreen(onClose: () -> Unit) {
    var usingProxima by remember { mutableStateOf(false) }
    val bodies = remember(usingProxima) { if (usingProxima) OrbitMath.PROXIMA_SYSTEM else OrbitMath.SOLAR_SYSTEM }
    // Static scatter for the asteroid + Kuiper belts (Proxima has none) — seeded once per system swap,
    // not regenerated every frame; see OrbitMath.generateBeltPoints.
    val belts = remember(usingProxima) {
        if (usingProxima) emptyList() else OrbitMath.SOLAR_SYSTEM_BELTS
    }
    val beltPoints = remember(usingProxima) {
        belts.map { it to OrbitMath.generateBeltPoints(it) }
    }

    var tDays by remember(usingProxima) { mutableFloatStateOf(0f) }
    var playing by remember { mutableStateOf(true) }
    var speed by remember { mutableFloatStateOf(1f) } // simulated days per real second, before the exponential scale below

    // Zoomed out far enough that the outermost real orbit sweeps across the frame — inner planets end
    // up a tight little cluster near the star, which is the true-to-scale look (not a rendering bug).
    val camera = remember(usingProxima) {
        OrbitMath.Camera(yaw = 0.5, pitch = 0.55, viewRadiusAu = OrbitMath.outerAuOfWithBelts(bodies, belts) * 1.12)
    }
    var selected by remember(usingProxima) { mutableStateOf<OrbitMath.Body?>(null) }
    // Tapping a planet re-centres the camera on it and zooms in (see the tap handler below); real moon
    // orbits are far too small to draw to true AU scale next to a whole solar system, so this is how you
    // actually get close enough to see a planet's own moons.
    var focusBody by remember(usingProxima) { mutableStateOf<OrbitMath.Body?>(null) }
    val stars = remember { generateStarfield() }

    // Days-per-real-second actually applied: speed=1 -> ~1 day/s, speed=5 -> ~1 year/s-ish. Exponential
    // so one slider covers both "watch Mercury" and "watch Neptune" time scales.
    val daysPerSecond = Math.pow(10.0, (speed - 1.0) / 1.3).toFloat()

    LaunchedEffect(playing, daysPerSecond, usingProxima) {
        if (!playing) return@LaunchedEffect
        while (true) {
            delay(32)
            tDays += daysPerSecond * 0.032f
        }
    }

    val tDaysState = androidx.compose.runtime.rememberUpdatedState(tDays)

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        Column(Modifier.fillMaxSize().padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                TermTextKey("[back]", onClick = onClose)
                Spacer(Modifier.weight(1f))
                Text("sim", color = Accent, fontFamily = TermFont, fontSize = 18.sp)
                Spacer(Modifier.weight(1f))
                TermTextKey(
                    if (usingProxima) "[proxima]" else "[solar]",
                    tone = Accent,
                    onClick = {
                        usingProxima = !usingProxima; selected = null; focusBody = null; tDays = 0f
                        val newBodies = if (usingProxima) OrbitMath.PROXIMA_SYSTEM else OrbitMath.SOLAR_SYSTEM
                        val newBelts = if (usingProxima) emptyList() else OrbitMath.SOLAR_SYSTEM_BELTS
                        camera.viewRadiusAu = OrbitMath.outerAuOfWithBelts(newBodies, newBelts) * 1.12
                        camera.yaw = 0.5; camera.pitch = 0.55
                    }
                )
            }
            Spacer(Modifier.height(8.dp))

            Box(
                Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .border(1.dp, Line)
                    .pointerInput(usingProxima) {
                        detectTransformGestures { _, pan, zoom, _ ->
                            camera.yaw -= pan.x * 0.006
                            camera.pitch = (camera.pitch - pan.y * 0.006).coerceIn(-1.4, 1.4)
                            val outerAu = OrbitMath.outerAuOf(bodies)
                            camera.viewRadiusAu = (camera.viewRadiusAu / zoom).coerceIn(0.003, outerAu * 4.0)
                        }
                    }
                    .pointerInput(bodies, usingProxima) {
                        detectTapGestures { tap ->
                            val w = size.width.toFloat(); val h = size.height.toFloat()
                            val t = tDaysState.value.toDouble()
                            val outerAu = OrbitMath.outerAuOf(bodies)
                            val focusPos = focusBody?.let { OrbitMath.position(it, t) }
                                ?: OrbitMath.Vec3(0.0, 0.0, 0.0)
                            var best: OrbitMath.Body? = null
                            var bestDist = Float.MAX_VALUE
                            bodies.forEach { b ->
                                val p = OrbitMath.position(b, t)
                                val rel = OrbitMath.Vec3(p.x - focusPos.x, p.y - focusPos.y, p.z - focusPos.z)
                                val (sx, sy, _) = camera.project(rel, w, h)
                                val rr = OrbitMath.bodyPixelRadius(b, camera.pxPerAu(w, h), min(w, h))
                                val d = OrbitMath.dist(tap.x, tap.y, sx, sy)
                                val tol = max(rr + 8f, 30f)
                                if (d < tol && d < bestDist) { bestDist = d; best = b }
                            }
                            val tapped = best
                            if (tapped != null) {
                                selected = tapped
                                if (!tapped.isStar && tapped != focusBody) {
                                    focusBody = tapped
                                    camera.viewRadiusAu = OrbitMath.focusViewRadiusFor(tapped, min(w, h), 130.0)
                                } else if (tapped.isStar && focusBody != null) {
                                    focusBody = null
                                    camera.viewRadiusAu = outerAu * 1.12
                                }
                            } else if (focusBody != null) {
                                // tapped empty space while zoomed into a planet: back out to the overview
                                focusBody = null; selected = null; camera.viewRadiusAu = outerAu * 1.12
                            }
                        }
                    }
            ) {
                OrbitCanvas(bodies, beltPoints, tDays, camera, stars, selected, focusBody)
            }

            selected?.let { b ->
                Spacer(Modifier.height(8.dp))
                Text(
                    if (b.isStar) "${b.name} — the system's star"
                    else "${b.name} — ${fmt(b.orbitAu)} AU out, orbits every ${fmt(b.periodDays)} days" +
                        if (b.periodDays > 700) " (${fmt(b.periodDays / 365.25)} years)" else "",
                    color = Ink, fontFamily = TermFont, fontSize = 12.sp
                )
            }

            Spacer(Modifier.height(6.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                TermTextKey(if (playing) "[pause]" else "[play]", onClick = { playing = !playing })
                Spacer(Modifier.width(10.dp))
                Text("speed", color = Dim, fontFamily = TermFont, fontSize = 11.sp)
                Slider(
                    value = speed,
                    onValueChange = { speed = it },
                    valueRange = 0f..8f,
                    colors = SliderDefaults.colors(thumbColor = Accent, activeTrackColor = Accent, inactiveTrackColor = Line),
                    modifier = Modifier.weight(1f).padding(horizontal = 8.dp)
                )
                TermTextKey("[reset t]", onClick = { tDays = 0f })
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                TermTextKey(
                    "[overview]",
                    onClick = {
                        focusBody = null; selected = null
                        camera.viewRadiusAu = OrbitMath.outerAuOfWithBelts(bodies, belts) * 1.12
                        camera.yaw = 0.5; camera.pitch = 0.55
                    }
                )
            }
            Text(
                "Drag to orbit · pinch to zoom · tap a body to zoom into it, tap empty space to back out",
                color = Dim, fontFamily = TermFont, fontSize = 11.sp
            )
        }
    }
}

private fun fmt(v: Double): String {
    val r = Math.round(v * 100.0) / 100.0
    return if (r == r.toLong().toDouble()) r.toLong().toString() else r.toString()
}

/** A star's position as size-independent fractions, plus its look — regenerating the canvas is cheap
 *  compared to regenerating this list, so it's built once and reused at whatever size it's drawn. */
private class Star(val fx: Float, val fy: Float, val radius: Float, val alpha: Float, val tint: Color)

private fun generateStarfield(): List<Star> {
    val rnd = Random(20240609)
    return List(500) {
        val bright = rnd.nextFloat()
        val r = if (bright > 0.985f) 1.6f else if (bright > 0.9f) 1.1f else 0.6f
        val tintRoll = rnd.nextFloat()
        val tint = when {
            tintRoll > 0.85f -> Color(0xFFB4C8FF)
            tintRoll > 0.7f -> Color(0xFFFFDCB4)
            else -> Color.White
        }
        Star(rnd.nextFloat(), rnd.nextFloat(), r, 0.35f + bright * 0.6f, tint)
    }
}

private fun DrawScope.drawStarfield(stars: List<Star>) {
    val w = size.width; val h = size.height
    // soft diagonal dust band, evoking the Milky Way behind the system
    rotate(degrees = -20f, pivot = Offset(w * 0.5f, h * 0.55f)) {
        drawRect(
            brush = Brush.verticalGradient(
                colors = listOf(
                    Color(0x00282C3C), Color(0x1A78788C), Color(0x29BEB9C8), Color(0x1A78788C), Color(0x00282C3C)
                ),
                startY = h * 0.05f, endY = h
            ),
            topLeft = Offset(-w * 0.5f, -h * 0.5f),
            size = Size(w * 2f, h * 2f)
        )
    }
    stars.forEach { s ->
        drawCircle(color = s.tint.copy(alpha = s.alpha), radius = s.radius, center = Offset(s.fx * w, s.fy * h))
    }
}

@Composable
private fun OrbitCanvas(
    bodies: List<OrbitMath.Body>,
    beltPoints: List<Pair<OrbitMath.Belt, List<OrbitMath.BeltPoint>>>,
    tDays: Float,
    camera: OrbitMath.Camera,
    stars: List<Star>,
    selected: OrbitMath.Body?,
    focusBody: OrbitMath.Body?
) {
    Canvas(Modifier.fillMaxSize()) {
        val w = size.width; val h = size.height
        drawStarfield(stars)

        val outerAu = OrbitMath.outerAuOf(bodies)
        val focusPos = focusBody?.let { OrbitMath.position(it, tDays.toDouble()) } ?: OrbitMath.Vec3(0.0, 0.0, 0.0)
        fun relative(p: OrbitMath.Vec3) = OrbitMath.Vec3(p.x - focusPos.x, p.y - focusPos.y, p.z - focusPos.z)

        // faint AU distance rings around the star, labelled — hidden while focused on a planet (they're
        // centred on the star, which is off-frame by then)
        if (focusBody == null) {
            val ringSteps = 4
            for (i in 1..ringSteps) {
                val au = (outerAu / ringSteps) * i
                var prev: Offset? = null
                for (j in 0..72) {
                    val ang = (j / 72.0) * 2 * Math.PI
                    val p = OrbitMath.Vec3(au * cos(ang), au * sin(ang), 0.0)
                    val (sx, sy, _) = camera.project(p, w, h)
                    val cur = Offset(sx, sy)
                    if (prev != null) drawLine(color = Color(0x28C8C8C8), start = prev, end = cur, strokeWidth = 1f)
                    prev = cur
                }
            }
        }

        // asteroid + Kuiper belts — static dot scatter, drawn before the orbit paths/planets so bodies
        // and their orbit lines sit visually on top; hidden while focused on a planet, same as the AU
        // rings above (they're centred on the star, which is off-frame by then)
        if (focusBody == null && beltPoints.isNotEmpty()) {
            beltPoints.forEach { (belt, points) ->
                val base = Color(belt.color)
                points.forEach { p ->
                    val (sx, sy, _) = camera.project(OrbitMath.Vec3(p.x, p.y, p.z), w, h)
                    val alpha = 0.18f + p.jitter * 0.35f
                    val r = 1.0f + p.jitter * 0.9f
                    drawCircle(color = base.copy(alpha = alpha), radius = r, center = Offset(sx, sy))
                }
            }
        }

        // orbit paths — true AU distances, so inner planets cluster tight and outer ones sweep wide,
        // drawn relative to whatever the camera is centred on
        bodies.forEach { b ->
            if (b.isStar || b.orbitAu <= 0.0) return@forEach
            var prev: Offset? = null
            val steps = 120
            for (i in 0..steps) {
                val frac = i.toDouble() / steps
                val fakeBody = b.copy(startAngleDeg = 0.0, periodDays = 1.0)
                val p = relative(OrbitMath.position(fakeBody, frac))
                val (sx, sy, _) = camera.project(p, w, h)
                val cur = Offset(sx, sy)
                if (prev != null) drawLine(color = Color(0x59DCC88C), start = prev, end = cur, strokeWidth = 1f)
                prev = cur
            }
        }

        // bodies themselves, back-to-front by projected depth so nearer ones draw on top
        val withDepth = bodies.map { b ->
            val p = relative(OrbitMath.position(b, tDays.toDouble()))
            val (sx, sy, depth) = camera.project(p, w, h)
            Triple(b, Offset(sx, sy), depth)
        }.sortedBy { it.third }

        withDepth.forEach { (b, pos, _) ->
            val r = OrbitMath.bodyPixelRadius(b, camera.pxPerAu(w, h), min(w, h))

            if (b.isStar) {
                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(Color(b.color).copy(alpha = 0.35f), Color(b.color).copy(alpha = 0f)),
                        center = pos, radius = r * 3f
                    ),
                    radius = r * 3f, center = pos
                )
            }

            if (b.rings) drawRingHalf(pos, r, back = true)
            drawTexturedBody(b, pos, r)
            if (b.rings) drawRingHalf(pos, r, back = false)

            if (b.moons.isNotEmpty()) drawMoons(b, pos, r, tDays)

            if (b == selected) {
                drawCircle(color = Accent, radius = r + 6f, center = pos, style = Stroke(width = 1.5f))
            }
        }

        // HUD, bottom-left — a running mission-clock/speed readout
        drawContext.canvas.nativeCanvas.apply {
            val paint = android.graphics.Paint().apply {
                color = android.graphics.Color.argb(217, 232, 232, 232)
                textSize = 26f
                isAntiAlias = true
            }
            val totalDays = tDays.toLong()
            val years = totalDays / 365
            val days = totalDays % 365
            val focusLabel = focusBody?.let { "   focused: ${it.name}" } ?: ""
            drawText("t + $years y $days d$focusLabel", 12f, h - 14f, paint)
        }
    }
}

/** Draws the near or far half of a ring system (so it can be layered behind then in front of the sphere). */
private fun DrawScope.drawRingHalf(center: Offset, r: Float, back: Boolean) {
    val rxOut = r * 2.3f; val ryOut = r * 0.75f
    val rxIn = r * 1.35f; val ryIn = r * 0.44f
    val path = Path().apply {
        fillType = PathFillType.EvenOdd
        addOval(Rect(center.x - rxOut, center.y - ryOut, center.x + rxOut, center.y + ryOut))
        addOval(Rect(center.x - rxIn, center.y - ryIn, center.x + rxIn, center.y + ryIn))
    }
    val halfClip = Path().apply {
        val top = center.y - ryOut - 4f; val bottom = center.y + ryOut + 4f
        if (back) addRect(Rect(center.x - rxOut - 4f, top, center.x + rxOut + 4f, center.y))
        else addRect(Rect(center.x - rxOut - 4f, center.y, center.x + rxOut + 4f, bottom))
    }
    clipPath(halfClip) {
        drawPath(path, color = Color(0xFFD2BE96).copy(alpha = 0.55f))
    }
}

private fun DrawScope.drawMoons(b: OrbitMath.Body, center: Offset, r: Float, tDays: Float) {
    b.moons.forEach { m ->
        val orbitR = r * m.orbitFactor.toFloat()
        val ang = (if (m.periodDays > 0) (tDays / m.periodDays.toFloat()) else 0f) * 2 * Math.PI.toFloat()
        val mx = center.x + cos(ang) * orbitR
        val my = center.y + sin(ang) * orbitR * 0.55f
        val mr = max(1.2f, r * m.radiusUnits.toFloat() * 0.5f)
        drawOval(
            color = Color.White.copy(alpha = 0.10f),
            topLeft = Offset(center.x - orbitR, center.y - orbitR * 0.55f),
            size = Size(orbitR * 2f, orbitR * 1.1f),
            style = Stroke(width = 1f)
        )
        drawCircle(color = Color(m.color), radius = mr, center = Offset(mx, my))
    }
}

/** Procedural shading for each [OrbitMath.Texture] — no downloaded images, just gradients + a few
 *  overlay shapes clipped to the sphere, shaded darker on the trailing side for a spherical look. */
private fun DrawScope.drawTexturedBody(b: OrbitMath.Body, center: Offset, r: Float) {
    val base = Color(b.color)
    val circle = Path().apply { addOval(Rect(center.x - r, center.y - r, center.x + r, center.y + r)) }
    clipPath(circle) {
        val lightCenter = Offset(center.x - r * 0.35f, center.y - r * 0.35f)
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(base.copy(alpha = 1f), base.copy(alpha = 0.55f)),
                center = lightCenter, radius = r * 1.6f
            ),
            radius = r, center = center
        )
        when (b.texture) {
            OrbitMath.Texture.GAS_BANDED -> {
                val bandColors = listOf(
                    base.copy(alpha = 0.35f), Color.White.copy(alpha = 0.12f),
                    base.copy(alpha = 0.30f), Color.Black.copy(alpha = 0.10f), base.copy(alpha = 0.25f)
                )
                bandColors.forEachIndexed { i, c ->
                    val bandY = center.y - r + (2 * r / bandColors.size) * i
                    drawRect(
                        color = c,
                        topLeft = Offset(center.x - r, bandY),
                        size = Size(r * 2f, 2 * r / bandColors.size + 1f)
                    )
                }
            }
            OrbitMath.Texture.EARTH -> {
                val rnd = Random(b.name.hashCode())
                repeat(6) {
                    val bx = center.x + (rnd.nextFloat() - 0.5f) * r * 1.6f
                    val by = center.y + (rnd.nextFloat() - 0.5f) * r * 1.6f
                    drawCircle(color = Color(0xFF3C9646).copy(alpha = 0.8f), radius = r * (0.18f + rnd.nextFloat() * 0.2f), center = Offset(bx, by))
                }
                drawArc(
                    color = Color.White.copy(alpha = 0.35f), startAngle = 20f, sweepAngle = 140f,
                    useCenter = false, topLeft = Offset(center.x - r, center.y - r * 0.6f), size = Size(r * 2f, r * 0.8f),
                    style = Stroke(width = r * 0.12f)
                )
            }
            OrbitMath.Texture.MARS -> {
                val rnd = Random(b.name.hashCode())
                repeat(5) {
                    val bx = center.x + (rnd.nextFloat() - 0.5f) * r * 1.5f
                    val by = center.y + (rnd.nextFloat() - 0.5f) * r * 1.5f
                    drawCircle(color = Color(0xFF7A2E14).copy(alpha = 0.35f), radius = r * (0.15f + rnd.nextFloat() * 0.2f), center = Offset(bx, by))
                }
                drawOval(color = Color.White.copy(alpha = 0.75f), topLeft = Offset(center.x - r * 0.5f, center.y - r * 1.0f), size = Size(r, r * 0.4f))
            }
            OrbitMath.Texture.ROCK -> {
                val rnd = Random(b.name.hashCode())
                repeat(18) {
                    val bx = center.x + (rnd.nextFloat() - 0.5f) * r * 1.7f
                    val by = center.y + (rnd.nextFloat() - 0.5f) * r * 1.7f
                    drawCircle(color = Color.Black.copy(alpha = 0.12f), radius = r * 0.06f, center = Offset(bx, by))
                }
            }
            OrbitMath.Texture.VENUS, OrbitMath.Texture.ICE, OrbitMath.Texture.ICE_DARK,
            OrbitMath.Texture.SUN, OrbitMath.Texture.RED_STAR -> { /* base gradient above is enough */ }
        }
        // terminator shading — darker crescent opposite the light, for a spherical (not flat-disc) read
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(Color.Transparent, Color.Black.copy(alpha = 0.08f), Color.Black.copy(alpha = 0.5f)),
                center = lightCenter, radius = r * 1.05f
            ),
            radius = r, center = center
        )
    }
    drawCircle(color = Color.Black.copy(alpha = 0.6f), radius = r, center = center, style = Stroke(width = 1f))
}
