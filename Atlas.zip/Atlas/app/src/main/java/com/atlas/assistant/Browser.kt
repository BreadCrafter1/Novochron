package com.atlas.assistant

import android.net.Uri
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder

/** A bookmark or a history line for the [web] browser. */
data class WebEntry(val title: String, val url: String, val ts: Long = System.currentTimeMillis())

/** One selectable search engine: [key] is what gets stored, [template] is the URL up to `q=`. */
data class SearchEngine(val key: String, val short: String, val label: String, val template: String)

/**
 * The small, UI-free half of the [web] browser: what the address bar does with whatever was typed,
 * which search engines exist, and how bookmarks / history are written to and read from preferences.
 */
object Web {

    val engines = listOf(
        SearchEngine("ddg", "ddg", "DuckDuckGo", "https://duckduckgo.com/?q="),
        SearchEngine("google", "google", "Google", "https://www.google.com/search?q="),
        SearchEngine("brave", "brave", "Brave Search", "https://search.brave.com/search?q="),
        SearchEngine("bing", "bing", "Bing", "https://www.bing.com/search?q=")
    )

    fun engine(key: String): SearchEngine = engines.firstOrNull { it.key == key } ?: engines[0]

    /** The engine after [key] in the list, wrapping around (used by the options dialog). */
    fun nextEngine(key: String): SearchEngine {
        val i = engines.indexOfFirst { it.key == key }
        return engines[(i + 1).mod(engines.size)]
    }

    val defaultBookmarks = listOf(
        WebEntry("Wikipedia", "https://www.wikipedia.org/", 0L),
        WebEntry("GitHub", "https://github.com/", 0L),
        WebEntry("Hacker News", "https://news.ycombinator.com/", 0L)
    )

    // Things that look like a link but must never be opened from the address bar.
    private val BLOCKED = Regex(
        "^(javascript|file|data|content|intent|about|blob|view-source|tel|mailto|sms|geo|market):",
        RegexOption.IGNORE_CASE
    )
    private val HOSTLIKE = Regex("^(?:[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?\\.)+[a-zA-Z]{2,24}(?::\\d{1,5})?(?:[/?#]\\S*)?$")
    private val IPV4 = Regex("^\\d{1,3}(?:\\.\\d{1,3}){3}(?::\\d{1,5})?(?:[/?#]\\S*)?$")
    private val LOCALHOST = Regex("^localhost(?::\\d{1,5})?(?:[/?#]\\S*)?$", RegexOption.IGNORE_CASE)

    /**
     * Turns whatever was typed (or spoken) into a URL to load:
     * - a web address ("example.com/page", "https://example.com") becomes an https:// URL. Plain http://
     *   is upgraded to https; Android blocks cleartext traffic for this app anyway.
     * - anything else is a search on [engineKey].
     * Returns null for empty input, or for links that aren't web pages (file:, javascript:, intent: ...).
     */
    fun resolve(input: String, engineKey: String): String? {
        val s = input.trim()
        if (s.isEmpty()) return null
        val hasSpace = s.any { it.isWhitespace() }
        if (!hasSpace && BLOCKED.containsMatchIn(s)) return null
        val idx = s.indexOf("://")
        if (idx > 0 && !hasSpace) {
            return when (s.substring(0, idx).lowercase()) {
                "https" -> s
                "http" -> "https://" + s.substring(idx + 3)
                else -> null
            }
        }
        if (!hasSpace && (HOSTLIKE.matches(s) || IPV4.matches(s) || LOCALHOST.matches(s))) return "https://$s"
        return engine(engineKey).template + URLEncoder.encode(s, "UTF-8")
    }

    /** "https://www.example.com/a/b" -> "example.com" (falls back to the input when it can't be parsed). */
    fun hostOf(url: String): String =
        try { Uri.parse(url).host?.removePrefix("www.")?.ifBlank { null } ?: url } catch (e: Exception) { url }

    // ---- bookmarks / history <-> JSON string in SharedPreferences ----

    fun encode(list: List<WebEntry>): String {
        val arr = JSONArray()
        for (e in list) arr.put(JSONObject().put("t", e.title).put("u", e.url).put("ts", e.ts))
        return arr.toString()
    }

    fun decode(json: String?): List<WebEntry> {
        if (json.isNullOrBlank()) return emptyList()
        return try {
            val arr = JSONArray(json)
            val out = ArrayList<WebEntry>()
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                val u = o.optString("u")
                if (u.isNotBlank()) out.add(WebEntry(o.optString("t"), u, o.optLong("ts")))
            }
            out
        } catch (e: Exception) {
            emptyList()
        }
    }
}
