package com.atlas.assistant

import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * Real (if simplified) orbital mechanics + a small 3D->2D camera for the `[sim]` screen (see
 * SolarSystemScreen.kt). Orbits are treated as circular in the orbital plane (good enough at
 * Universe-Sandbox-viewer fidelity — every body's actual eccentricity is small except Mercury/Pluto,
 * and this is a visualiser, not an ephemeris) and each body's own axial tilt/inclination is applied
 * as a plane rotation, so orbits genuinely nest in 3D rather than being flattened onto one plane.
 *
 * Moons are NOT placed at their real AU distance from their planet — at system scale that distance
 * is smaller than a pixel. Instead each moon carries [Moon.orbitVisualUnits], a deliberately
 * exaggerated distance used only when that planet is the focused body (see FocusCamera / the moon
 * ring rendered around a zoomed-in planet). Their periods, sizes and the rest of their facts are real.
 */
object OrbitMath {

    data class Vec3(val x: Double, val y: Double, val z: Double) {
        operator fun plus(o: Vec3) = Vec3(x + o.x, y + o.y, z + o.z)
    }

    /** A moon of some [Body]. Orbit distance here is a display convenience, not to AU scale — see class doc. */
    data class Moon(
        val name: String,
        val color: Long,
        val radiusUnits: Double,        // relative visual size, same unit family as Body.radiusUnits
        val orbitVisualUnits: Double,   // exaggerated distance used only in the focused/zoomed view
        val periodDays: Double,         // real orbital period
        val radiusKm: Double,
        val inclinationDeg: Double = 0.0,
        val startAngleDeg: Double = 0.0,
        val textureRes: Int? = null,
        val retrograde: Boolean = false
    )

    /** A body orbiting the system's star (star itself: orbitAu = 0, isStar = true). */
    data class Body(
        val name: String,
        val color: Long,                // 0xAARRGGBB, used as a fallback/tint when there's no texture
        val radiusUnits: Double,        // relative visual size only — NOT to scale with orbit distance
        val orbitAu: Double,            // semi-major axis, astronomical units (0 for the star)
        val periodDays: Double,         // orbital period (0 for the star)
        val inclinationDeg: Double = 0.0,
        val startAngleDeg: Double = 0.0,
        val isStar: Boolean = false,
        val textureRes: Int? = null,
        val hasRings: Boolean = false,
        val radiusKm: Double = 0.0,
        val massEarths: Double = 0.0,   // relative to Earth's mass (relative to the Sun's, for a star)
        val dayLengthHours: Double = 0.0, // axial rotation period; negative = retrograde
        val meanTempC: String = "",
        val blurb: String = "",
        val moons: List<Moon> = emptyList()
    )

    /** Position of [body] at time [t] days after epoch, in AU, in the system's 3D reference frame. */
    fun position(body: Body, tDays: Double): Vec3 {
        if (body.isStar || body.orbitAu == 0.0) return Vec3(0.0, 0.0, 0.0)
        val angle = Math.toRadians(body.startAngleDeg) + (2 * Math.PI) * (tDays / body.periodDays)
        val xOrb = body.orbitAu * cos(angle)
        val yOrb = body.orbitAu * sin(angle)
        val inc = Math.toRadians(body.inclinationDeg)
        val y = yOrb * cos(inc)
        val z = yOrb * sin(inc)
        return Vec3(xOrb, y, z)
    }

    /** Local position of a moon around its (already-positioned) planet, in the same visual units as radiusUnits. */
    fun moonLocalOffset(moon: Moon, tDays: Double): Vec3 {
        val dir = if (moon.retrograde) -1.0 else 1.0
        val angle = Math.toRadians(moon.startAngleDeg) + dir * (2 * Math.PI) * (tDays / moon.periodDays)
        val xOrb = moon.orbitVisualUnits * cos(angle)
        val yOrb = moon.orbitVisualUnits * sin(angle)
        val inc = Math.toRadians(moon.inclinationDeg)
        return Vec3(xOrb, yOrb * cos(inc), yOrb * sin(inc))
    }

    /**
     * Free-roaming orbit camera: rotates around [target] (yaw/pitch), sits [distanceAu] back from it,
     * then projects with a simple perspective divide. [target] can be animated so the camera can glide
     * from a wide system view in to sit right on top of one body ("zoom to a planet") and the drag
     * gesture can also translate [target] directly, so the view isn't locked to the system origin.
     */
    class Camera(var yaw: Double, var pitch: Double, var distanceAu: Double, var target: Vec3 = Vec3(0.0, 0.0, 0.0)) {
        fun project(pWorld: Vec3, screenW: Float, screenH: Float): Triple<Float, Float, Double> {
            val p = Vec3(pWorld.x - target.x, pWorld.y - target.y, pWorld.z - target.z)
            val cy = cos(yaw); val sy = sin(yaw)
            val x1 = p.x * cy - p.z * sy
            val z1 = p.x * sy + p.z * cy
            val cp = cos(pitch); val sp = sin(pitch)
            val y2 = p.y * cp - z1 * sp
            val z2 = p.y * sp + z1 * cp

            val camZ = z2 + distanceAu
            val focal = screenH * 0.9
            val perspective = focal / camZ.coerceAtLeast(distanceAu * 0.05)
            val sx = screenW / 2 + (x1 * perspective).toFloat()
            val sy2 = screenH / 2 - (y2 * perspective).toFloat()
            return Triple(sx, sy2, perspective)
        }

        /** Right/up unit vectors in world space for the current yaw only — used to pan [target] by a drag. */
        fun rightUp(): Pair<Vec3, Vec3> {
            val cy = cos(yaw); val sy = sin(yaw)
            val right = Vec3(cy, 0.0, -sy)
            val up = Vec3(0.0, 1.0, 0.0)
            return right to up
        }
    }

    /** The Sun + 8 planets, circular-orbit approximation. Distances in AU, periods in Earth days. */
    val SOLAR_SYSTEM: List<Body> = listOf(
        Body(
            "Sun", 0xFFFFD84A, 6.0, 0.0, 0.0, isStar = true, textureRes = R.drawable.tex_sun,
            radiusKm = 696340.0, massEarths = 333000.0, dayLengthHours = 609.0,
            meanTempC = "~5,500°C surface",
            blurb = "A G-type main-sequence star. Fuses hydrogen into helium in its core; everything " +
                "in the system orbits it and it holds about 99.8% of the system's total mass."
        ),
        Body(
            "Mercury", 0xFF9E9E9E, 0.9, 0.39, 88.0, 7.0, 20.0, textureRes = R.drawable.tex_mercury,
            radiusKm = 2439.7, massEarths = 0.055, dayLengthHours = 1407.6, meanTempC = "167°C (swings ±300°)",
            blurb = "The smallest and innermost planet — a cratered, airless rock closer in size to the " +
                "Moon than to Earth. No atmosphere means brutal day/night temperature swings."
        ),
        Body(
            "Venus", 0xFFE0C46E, 1.4, 0.72, 224.7, 3.4, 80.0, textureRes = R.drawable.tex_venus,
            radiusKm = 6051.8, massEarths = 0.815, dayLengthHours = -5832.5, meanTempC = "464°C",
            blurb = "Earth-sized but choked in a runaway-greenhouse CO2 atmosphere — the hottest " +
                "planet in the system. It spins backwards, and so slowly a Venus day outlasts its year."
        ),
        Body(
            "Earth", 0xFF4FA8FF, 1.5, 1.00, 365.25, 0.0, 160.0, textureRes = R.drawable.tex_earth,
            radiusKm = 6371.0, massEarths = 1.0, dayLengthHours = 24.0, meanTempC = "15°C",
            blurb = "The only known planet with liquid surface water and life. One large moon, formed " +
                "(most likely) from a giant impact early in the solar system's history.",
            moons = listOf(
                Moon("Moon", 0xFFC9C9C9, 0.45, 3.2, 27.3, 1737.4, textureRes = R.drawable.tex_moon)
            )
        ),
        Body(
            "Mars", 0xFFFF6A4F, 1.1, 1.52, 687.0, 1.85, 260.0, textureRes = R.drawable.tex_mars,
            radiusKm = 3389.5, massEarths = 0.107, dayLengthHours = 24.7, meanTempC = "-65°C",
            blurb = "The rust-red desert planet — thin CO2 atmosphere, polar ice caps, the largest " +
                "volcano and canyon in the system, and two small, oddly-shaped captured moons.",
            moons = listOf(
                Moon("Phobos", 0xFF9A8C7C, 0.14, 1.7, 0.32, 11.3),
                Moon("Deimos", 0xFF8C8272, 0.10, 2.5, 1.26, 6.2)
            )
        ),
        Body(
            "Jupiter", 0xFFE0B27A, 3.4, 5.20, 4331.0, 1.3, 30.0, textureRes = R.drawable.tex_jupiter,
            radiusKm = 69911.0, massEarths = 317.8, dayLengthHours = 9.9, meanTempC = "-110°C",
            blurb = "The largest planet by far — a gas giant of mostly hydrogen and helium, banded by " +
                "storms including the centuries-old Great Red Spot, with dozens of moons.",
            moons = listOf(
                Moon("Io", 0xFFE0C060, 0.30, 2.2, 1.77, 1821.6),
                Moon("Europa", 0xFFD8CFAE, 0.26, 2.9, 3.55, 1560.8),
                Moon("Ganymede", 0xFFA69078, 0.42, 3.7, 7.15, 2634.1),
                Moon("Callisto", 0xFF7A6E60, 0.39, 4.6, 16.7, 2410.3)
            )
        ),
        Body(
            "Saturn", 0xFFE8D6A0, 3.0, 9.58, 10747.0, 2.5, 300.0, textureRes = R.drawable.tex_saturn,
            hasRings = true, radiusKm = 58232.0, massEarths = 95.2, dayLengthHours = 10.7, meanTempC = "-140°C",
            blurb = "Famous for its bright, wide ring system of ice and rock. Least dense planet in " +
                "the system — it would float in water — with Titan, a moon with its own thick atmosphere.",
            moons = listOf(
                Moon("Titan", 0xFFD9A85C, 0.44, 3.4, 15.95, 2574.7),
                Moon("Rhea", 0xFFBFBFBF, 0.22, 4.4, 4.5, 763.8),
                Moon("Enceladus", 0xFFE8F4FF, 0.14, 5.2, 1.37, 252.1)
            )
        ),
        Body(
            "Uranus", 0xFF8FDDE8, 2.2, 19.20, 30589.0, 0.77, 120.0, textureRes = R.drawable.tex_uranus,
            hasRings = true, radiusKm = 25362.0, massEarths = 14.5, dayLengthHours = -17.2, meanTempC = "-195°C",
            blurb = "An ice giant tipped almost completely on its side (98° axial tilt), likely from an " +
                "ancient collision, so its poles take turns facing the Sun through its 84-year orbit.",
            moons = listOf(
                Moon("Titania", 0xFFA9A9A9, 0.20, 2.6, 8.7, 788.4),
                Moon("Oberon", 0xFF9B9B9B, 0.19, 3.3, 13.5, 761.4)
            )
        ),
        Body(
            "Neptune", 0xFF5C7CFF, 2.1, 30.05, 59800.0, 1.77, 200.0, textureRes = R.drawable.tex_neptune,
            radiusKm = 24622.0, massEarths = 17.1, dayLengthHours = 16.1, meanTempC = "-200°C",
            blurb = "The windiest planet — supersonic storms in a deep-blue methane atmosphere. Its " +
                "large moon Triton orbits backwards and is probably a captured Kuiper Belt object.",
            moons = listOf(
                Moon("Triton", 0xFFBFD3E0, 0.30, 2.8, 5.88, 1353.4, retrograde = true)
            )
        )
    )

    /**
     * Proxima Centauri system: the star plus its confirmed/candidate planets. Distances and periods
     * are the published estimates (Proxima b: Anglada-Escudé et al. 2016; Proxima c and the disputed
     * inner candidate d: later radial-velocity work) — real numbers, not placeholders, though c and d
     * are far less certain than b. No moons are confirmed here, so none are shown. No real imagery
     * exists for any of these, so they're rendered from a procedural shaded sphere rather than a texture.
     */
    val PROXIMA_SYSTEM: List<Body> = listOf(
        Body(
            "Proxima Centauri", 0xFFFF5C3D, 2.0, 0.0, 0.0, isStar = true,
            radiusKm = 107000.0, massEarths = 41000.0, meanTempC = "~2,970°C surface",
            blurb = "A small, dim, flare-prone red dwarf — the closest star to the Sun at 4.24 light-" +
                "years — orbited by at least one, and maybe as many as three, small planets."
        ),
        Body(
            "Proxima d", 0xFFB0B0B0, 0.5, 0.029, 5.15, 20.0, 0.0,
            massEarths = 0.26, meanTempC = "~90°C (est.)",
            blurb = "A disputed sub-Earth candidate on a very tight 5-day orbit, right at the edge of " +
                "current detection limits — real, but the least certain of the three."
        ),
        Body(
            "Proxima b", 0xFF4FD1A5, 1.0, 0.0485, 11.19, 10.0, 140.0,
            massEarths = 1.07, meanTempC = "~-39°C (est., no atmosphere assumed)",
            blurb = "A roughly Earth-mass planet sitting in Proxima's habitable zone — the closest " +
                "known potentially rocky exoplanet to the Sun. Whether it holds an atmosphere is unknown."
        ),
        Body(
            "Proxima c", 0xFF9E7BFF, 0.9, 1.49, 1928.0, 40.0, 260.0,
            massEarths = 7.0, meanTempC = "~-234°C (est.)",
            blurb = "A cold, distant mini-Neptune-class candidate on a roughly 5.3-year orbit, far " +
                "outside the habitable zone."
        )
    )

    fun angleFromCenter(x: Float, y: Float, cx: Float, cy: Float) = atan2((y - cy).toDouble(), (x - cx).toDouble())

    fun dist(x1: Float, y1: Float, x2: Float, y2: Float): Float {
        val dx = x1 - x2; val dy = y1 - y2
        return sqrt((dx * dx + dy * dy).toDouble()).toFloat()
    }
}
