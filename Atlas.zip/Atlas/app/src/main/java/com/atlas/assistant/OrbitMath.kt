package com.atlas.assistant

import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.random.Random

/**
 * Real (if simplified) orbital mechanics + a small 3D->2D camera for the `[sim]` screen (see
 * SolarSystemScreen.kt). Orbits are treated as circular in the orbital plane (good enough at
 * Universe-Sandbox-viewer fidelity — every body's actual eccentricity is small except Mercury/Pluto,
 * and this is a visualiser, not an ephemeris) and each body's own axial tilt/inclination is applied
 * as a plane rotation, so orbits genuinely nest in 3D rather than being flattened onto one plane.
 */
object OrbitMath {

    data class Vec3(val x: Double, val y: Double, val z: Double)

    /** A decorative moon, drawn in screen-space around its planet (see [Body.moons] doc below). */
    data class Moon(
        val name: String,
        val color: Long,
        val radiusUnits: Double,  // relative to its own planet's drawn radius
        val orbitFactor: Double,  // orbit radius, in units of the planet's drawn radius
        val periodDays: Double
    )

    /** What kind of procedural shading [Body] gets — see textureBrush() in SolarSystemScreen.kt. */
    enum class Texture { SUN, RED_STAR, ROCK, VENUS, EARTH, MARS, GAS_BANDED, ICE, ICE_DARK }

    /** A body orbiting [Body.parent] (null = the star itself, sits at the system origin). */
    data class Body(
        val name: String,
        val color: Long,          // 0xAARRGGBB
        val radiusUnits: Double,  // relative visual size only — NOT to scale with orbit distance
        val orbitAu: Double,      // semi-major axis, astronomical units (0 for the star)
        val periodDays: Double,   // orbital period (0 for the star)
        val inclinationDeg: Double = 0.0, // tilt of the orbital plane vs the system's reference plane
        val startAngleDeg: Double = 0.0,
        val isStar: Boolean = false,
        val texture: Texture = Texture.ROCK,
        val rings: Boolean = false,
        // Real moon orbits are far too small to draw to true AU scale next to a whole solar system —
        // these are screen-space decorations (orbitFactor is relative to the drawn planet, not AU),
        // but each still turns at its own real orbital period, so the motion means something.
        val moons: List<Moon> = emptyList()
    )

    /** Position of [body] at time [t] days after epoch, in AU, in the system's 3D reference frame. */
    fun position(body: Body, tDays: Double): Vec3 {
        if (body.isStar || body.orbitAu == 0.0) return Vec3(0.0, 0.0, 0.0)
        val angle = Math.toRadians(body.startAngleDeg) + (2 * Math.PI) * (tDays / body.periodDays)
        val xOrb = body.orbitAu * cos(angle)
        val yOrb = body.orbitAu * sin(angle)
        val inc = Math.toRadians(body.inclinationDeg)
        // rotate the orbital plane about the x-axis by its inclination
        val y = yOrb * cos(inc)
        val z = yOrb * sin(inc)
        return Vec3(xOrb, y, z)
    }

    /**
     * Orbit camera: yaw/pitch rotate the view for the 3D tilt; zoom is driven purely by [viewRadiusAu]
     * (how many AU are visible across ~half the frame), never by depth. An earlier version divided a
     * pixel-scale focal length by an AU-scale depth (`focal / camZ`) — a unit mismatch that made
     * on-screen size swing wildly with camera angle and could even grow when zooming out, at the mercy
     * of whatever clamp caught it. `project()` now returns depth only for draw-order sorting.
     */
    class Camera(var yaw: Double, var pitch: Double, var viewRadiusAu: Double) {
        /** @return (screenX, screenY, depth) — depth is post-rotation z, for back-to-front sorting only. */
        fun project(p: Vec3, screenW: Float, screenH: Float): Triple<Float, Float, Double> {
            // Rotate world point by -yaw around Y, then -pitch around X, so the camera "orbits" the origin.
            val cy = cos(yaw); val sy = sin(yaw)
            val x1 = p.x * cy - p.z * sy
            val z1 = p.x * sy + p.z * cy
            val cp = cos(pitch); val sp = sin(pitch)
            val y2 = p.y * cp - z1 * sp
            val z2 = p.y * sp + z1 * cp

            val pxPerAu = min(screenW, screenH) * 0.48 / viewRadiusAu
            val sx = screenW / 2 + (x1 * pxPerAu).toFloat()
            val sy2 = screenH / 2 - (y2 * pxPerAu).toFloat()
            return Triple(sx, sy2, z2)
        }

        fun pxPerAu(screenW: Float, screenH: Float): Double = min(screenW, screenH) * 0.48 / viewRadiusAu
    }

    /** The 8 planets (+ Sun), circular-orbit approximation. Distances in AU, periods in Earth days. */
    val SOLAR_SYSTEM: List<Body> = listOf(
        Body("Sun", 0xFFFFD84A, 6.0, 0.0, 0.0, isStar = true, texture = Texture.SUN),
        Body("Mercury", 0xFF9E9E9E, 0.9, 0.39, 88.0, 7.0, 20.0, texture = Texture.ROCK),
        Body("Venus", 0xFFE0C46E, 1.4, 0.72, 224.7, 3.4, 80.0, texture = Texture.VENUS),
        Body(
            "Earth", 0xFF4FA8FF, 1.5, 1.00, 365.25, 0.0, 160.0, texture = Texture.EARTH,
            moons = listOf(Moon("Moon", 0xFFC9C9C9, 0.27, 2.4, 27.3))
        ),
        Body(
            "Mars", 0xFFFF6A4F, 1.1, 1.52, 687.0, 1.85, 260.0, texture = Texture.MARS,
            moons = listOf(
                Moon("Phobos", 0xFF8A7D6E, 0.16, 1.9, 0.32),
                Moon("Deimos", 0xFF8A7D6E, 0.13, 2.6, 1.26)
            )
        ),
        Body(
            "Jupiter", 0xFFE0B27A, 3.4, 5.20, 4331.0, 1.3, 30.0, texture = Texture.GAS_BANDED,
            moons = listOf(
                Moon("Io", 0xFFE8D08A, 0.30, 1.7, 1.77),
                Moon("Europa", 0xFFCFCABF, 0.28, 2.1, 3.55),
                Moon("Ganymede", 0xFF9C9284, 0.35, 2.6, 7.15),
                Moon("Callisto", 0xFF6E655A, 0.33, 3.1, 16.7)
            )
        ),
        Body(
            "Saturn", 0xFFE8D6A0, 3.0, 9.58, 10747.0, 2.5, 300.0, texture = Texture.GAS_BANDED, rings = true,
            moons = listOf(Moon("Titan", 0xFFD8B26A, 0.32, 3.4, 15.9))
        ),
        Body(
            "Uranus", 0xFF8FDDE8, 2.2, 19.20, 30589.0, 0.77, 120.0, texture = Texture.ICE,
            moons = listOf(Moon("Titania", 0xFFB9B9B9, 0.20, 2.0, 8.7))
        ),
        Body(
            "Neptune", 0xFF5C7CFF, 2.1, 30.05, 59800.0, 1.77, 200.0, texture = Texture.ICE_DARK,
            moons = listOf(Moon("Triton", 0xFFD9CBB0, 0.20, 2.0, 5.9))
        )
    )

    /**
     * Proxima Centauri system: the star plus its confirmed/candidate planets. Distances and periods
     * are the published estimates (Proxima b: Anglada-Escudé et al. 2016; Proxima c and the disputed
     * inner candidate d: later radial-velocity work) — real numbers, not placeholders, though c and d
     * are far less certain than b.
     */
    val PROXIMA_SYSTEM: List<Body> = listOf(
        Body("Proxima Centauri", 0xFFFF5C3D, 2.0, 0.0, 0.0, isStar = true, texture = Texture.RED_STAR),
        Body("Proxima d", 0xFFB0B0B0, 0.5, 0.029, 5.15, 20.0, 0.0, texture = Texture.ROCK),
        Body("Proxima b", 0xFF4FD1A5, 1.0, 0.0485, 11.19, 10.0, 140.0, texture = Texture.EARTH),
        Body("Proxima c", 0xFF9E7BFF, 0.9, 1.49, 1928.0, 40.0, 260.0, texture = Texture.ICE)
    )

    /**
     * A ring of small bodies drawn as a static scatter of dots rather than individually-tracked
     * orbits — the main asteroid belt (between Mars and Jupiter) and the Kuiper belt (beyond
     * Neptune). Real ones hold millions of objects on their own independent orbits; here [count]
     * points are seeded once (see [generateBeltPoints]) at true-to-scale distances so the *shape*
     * and *extent* of the belt reads correctly at a glance, same spirit as the rest of this
     * visualiser (real distances, not a compressed cartoon), without actually simulating each one.
     */
    data class Belt(
        val name: String,
        val innerAu: Double,
        val outerAu: Double,
        val color: Long,      // 0xAARRGGBB, base tint (per-dot alpha/size is jittered)
        val count: Int,
        val thicknessAu: Double, // scatter above/below the plane, roughly the belt's real vertical spread
        val seed: Long
    )

    /** One static dot in a [Belt]'s scatter, already in AU in the system's reference frame. */
    data class BeltPoint(val x: Double, val y: Double, val z: Double, val jitter: Float)

    val ASTEROID_BELT = Belt(
        name = "Asteroid Belt", innerAu = 2.1, outerAu = 3.3,
        color = 0xFFBBAA88, count = 900, thicknessAu = 0.15, seed = 770_01L
    )
    val KUIPER_BELT = Belt(
        name = "Kuiper Belt", innerAu = 30.0, outerAu = 50.0,
        color = 0xFF9FB8D8, count = 1400, thicknessAu = 0.6, seed = 770_02L
    )

    /** Both belts of the real Solar System. The Proxima system has none. */
    val SOLAR_SYSTEM_BELTS: List<Belt> = listOf(ASTEROID_BELT, KUIPER_BELT)

    /** Seeded once per [belt] (same seed every time) so the scatter doesn't reshuffle every recompose. */
    fun generateBeltPoints(belt: Belt): List<BeltPoint> {
        val rnd = Random(belt.seed)
        return List(belt.count) {
            // area-uniform radius (not linear) so density doesn't artificially bunch near the inner edge
            val r = sqrt(rnd.nextDouble(belt.innerAu * belt.innerAu, belt.outerAu * belt.outerAu))
            val theta = rnd.nextDouble(0.0, 2 * Math.PI)
            val z = (rnd.nextDouble() - 0.5) * belt.thicknessAu
            BeltPoint(r * cos(theta), r * sin(theta), z, rnd.nextFloat())
        }
    }

    /** Like [outerAuOf], but also accounts for any belts so the default framing shows them fully. */
    fun outerAuOfWithBelts(bodies: List<Body>, belts: List<Belt>): Double =
        maxOf(outerAuOf(bodies), belts.maxOfOrNull { it.outerAu } ?: 0.0)

    fun angleFromCenter(x: Float, y: Float, cx: Float, cy: Float) = atan2((y - cy).toDouble(), (x - cx).toDouble())

    fun dist(x1: Float, y1: Float, x2: Float, y2: Float): Float {
        val dx = x1 - x2; val dy = y1 - y2
        return sqrt((dx * dx + dy * dy).toDouble()).toFloat()
    }

    fun outerAuOf(bodies: List<Body>): Double = bodies.maxOf { it.orbitAu }.coerceAtLeast(1.0)

    // Body pixel size is directly proportional to pxPerAu — the exact same rate the orbit distances
    // themselves scale at. That's what makes zoom strictly monotonic: zoom out -> pxPerAu drops ->
    // every body shrinks by the same factor as the orbits around it, full stop, no separate curve that
    // could ever push it the other way. (An earlier version compared against a fixed "default zoom"
    // baseline with a sqrt curve — that decoupled body size from true zoom level and let the sun's
    // fixed pixel size swallow the inner planets at the default overview.) At true AU scale, a
    // visible-sized sun will still overlap Mercury/Venus/Earth at the full-system view — that's not a
    // bug, it's the real ratio of the sun's size to their orbits; that's also exactly what the
    // reference screenshot shows (a small tight cluster near the star). Zoom in / tap a planet to
    // separate them.
    const val PLANET_SCALE = 0.09

    /** Screen radius for a body, directly proportional to the current AU-to-pixel ratio. */
    fun bodyPixelRadius(b: Body, pxPerAu: Double, minScreenDim: Float): Float {
        val sizeMult = if (b.isStar) 3.2 else 2.1
        val floor = if (b.isStar) 4f else 2f
        val raw = (b.radiusUnits * sizeMult * PLANET_SCALE * pxPerAu).toFloat()
        return raw.coerceIn(floor, minScreenDim * 0.42f)
    }

    /** viewRadiusAu that frames [b] as a [desiredPx]-ish close-up, given the current screen size. */
    fun focusViewRadiusFor(b: Body, minScreenDim: Float, desiredPx: Double): Double {
        val sizeMult = if (b.isStar) 3.2 else 2.1
        return ((b.radiusUnits * sizeMult * PLANET_SCALE * minScreenDim * 0.48) / desiredPx).coerceAtLeast(0.0005)
    }
}
