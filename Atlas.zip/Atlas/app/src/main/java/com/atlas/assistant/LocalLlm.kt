package com.atlas.assistant

import android.content.Context
import android.graphics.Bitmap
import com.google.mediapipe.tasks.genai.llminference.GraphOptions
import com.google.mediapipe.tasks.genai.llminference.LlmInference
import com.google.mediapipe.tasks.genai.llminference.LlmInferenceSession
import java.io.File
import java.util.Locale

/**
 * Optional offline brain. Drop a MediaPipe-format Gemma model - ANY file name ending in .task -
 * into /storage/emulated/0/Atlas/Models/ (needs "All files access", see Settings), or into
 * Android/data/com.novochron.assistant/files/, and Novochron can chat with no internet. A file called
 * exactly model.task wins if there are several; otherwise the newest model file is used.
 *
 * Vision (photos, camera and screen frames while fully offline) needs a multimodal ".task" model
 * such as a converted Gemma 3n E2B/E4B build - a text-only Gemma model will not accept images.
 * [visionAvailable] fails closed: if the installed model does not support image input, or the
 * MediaPipe vision session cannot be created for any reason, offline vision is treated as
 * unavailable rather than crashing, and Brain falls back to "connect to look at this photo".
 */
class LocalLlm(private val ctx: Context) {
    private var llm: LlmInference? = null
    private var loadedPath: String? = null
    private var visionSession: LlmInferenceSession? = null
    private var visionChecked = false
    private var visionOk = false

    fun available(): Boolean = findModel(ctx) != null

    @Synchronized
    fun generate(prompt: String): String? {
        if (!available()) return null
        return try {
            ensureLlm()
            val out = llm?.generateResponse(prompt)
            lastLoadError = null
            out
        } catch (e: Throwable) {
            lastLoadError = describeError(e)
            null
        }
    }

    /** True if an offline vision-capable session could be stood up for the installed model. */
    @Synchronized
    fun visionAvailable(): Boolean {
        if (!available()) return false
        try { ensureLlm() } catch (e: Throwable) { lastLoadError = describeError(e); return false }
        if (visionChecked) return visionOk
        visionChecked = true
        visionOk = try {
            val session = LlmInferenceSession.createFromOptions(
                llm,
                LlmInferenceSession.LlmInferenceSessionOptions.builder()
                    .setTopK(40)
                    .setGraphOptions(GraphOptions.builder().setEnableVisionModality(true).build())
                    .build()
            )
            visionSession = session
            true
        } catch (e: Throwable) {
            // model has no vision modality (e.g. a text-only Gemma build) - that's fine,
            // offline text chat still works, only offline photo/camera/screen understanding doesn't.
            false
        }
        return visionOk
    }

    /** Describes or answers a question about a bitmap, entirely on-device. Null if unavailable. */
    @Synchronized
    fun generateWithImage(prompt: String, bitmap: Bitmap): String? {
        if (!visionAvailable()) return null
        val session = visionSession ?: return null
        return try {
            session.addQueryChunk(prompt)
            addImage(session, bitmap)
            val result = session.generateResponse()
            // each session is single-turn once an image is added; drop it so the next call gets a fresh one
            visionSession = null
            visionChecked = false
            result
        } catch (e: Throwable) {
            visionSession = null
            visionChecked = false
            null
        }
    }

    /**
     * Hands a Bitmap to the session as MediaPipe's MPImage. Done by reflection because newer tasks-genai builds
     * only ship the image classes at runtime, not on the compile classpath, so naming them directly won't build.
     */
    private fun addImage(session: LlmInferenceSession, bitmap: Bitmap) {
        val builderClass = Class.forName("com.google.mediapipe.framework.image.BitmapImageBuilder")
        val builder = builderClass.getConstructor(Bitmap::class.java).newInstance(bitmap)
        val mpImage = builderClass.getMethod("build").invoke(builder)
        val mpImageClass = Class.forName("com.google.mediapipe.framework.image.MPImage")
        session.javaClass.getMethod("addImage", mpImageClass).invoke(session, mpImage)
    }

    private fun ensureLlm() {
        val file = modelFile(ctx)
        val path = file.absolutePath
        if (llm != null && loadedPath == path) return
        // first load, or the model file was swapped for a different one: start clean
        try { llm?.close() } catch (e: Throwable) { }
        llm = null; loadedPath = null; visionSession = null; visionChecked = false; visionOk = false
        loadState = "loading"

        val name = file.name.lowercase(Locale.US)
        // Gemma 3n builds take images; give them room for one image per request
        val multimodal = "3n" in name || "e2b" in name || "e4b" in name
        var failure: Throwable? = null
        for (tokens in maxTokenGuesses(name)) {
            try {
                val b = LlmInference.LlmInferenceOptions.builder()
                    .setModelPath(path)
                    .setMaxTokens(tokens)
                if (multimodal) b.setMaxNumImages(1)
                llm = LlmInference.createFromOptions(ctx, b.build())
                loadedPath = path
                loadState = "loaded"
                return
            } catch (e: Throwable) {
                failure = e
            }
        }
        loadState = "error"
        throw failure ?: IllegalStateException("the model did not load")
    }

    /** What Settings shows about the offline model: what was found, where, and why anything was skipped. */
    data class ModelScan(
        val file: File?,
        val where: String,
        val looked: List<String>,
        val notes: List<String>
    ) {
        val found: Boolean get() = file != null

        fun describe(): String = buildString {
            if (file != null) {
                append("Offline AI model: found ${file.name} (${sizeText(file)}) in $where.")
                lastLoadError?.let { append(" It didn't load: $it") }
            } else {
                append("Offline AI model: none found. Looked in ${looked.joinToString(" and ")}. ")
                append("Put a .task model file (any name) in one of them. Commands and memory still work offline.")
            }
            notes.forEach { append("\n• ").append(it) }
        }
    }

    companion object {
        /** Why the last attempt to load the model failed (null if it hasn't failed). Shown in Settings. */
        @Volatile var lastLoadError: String? = null

        /** "not loaded" / "loading" / "loaded" / "error" — shown on the `[debug]` overlay (see DebugOverlay.kt). */
        @Volatile var loadState: String = "not loaded"

        private val MODEL_EXT = setOf("task", "bin", "litertlm")
        // model-ish formats this build can't load, so we can say so instead of silently ignoring them
        private val WRONG_EXT = setOf("tflite", "gguf", "safetensors")
        private const val MIN_BYTES = 50L * 1024 * 1024 // real language models are far bigger; skips stray tiny .task/.bin files

        private fun isModel(f: File): Boolean =
            f.isFile && f.extension.lowercase(Locale.US) in MODEL_EXT &&
                (f.name.equals("model.task", ignoreCase = true) || f.length() >= MIN_BYTES)

        /** Folders searched, best first, each with a short label for Settings. */
        private fun searchDirs(ctx: Context): List<Pair<String, File>> {
            val dirs = mutableListOf<Pair<String, File>>()
            if (AtlasStorage.hasAccess()) dirs += "Atlas/Models" to AtlasStorage.modelsDir()
            ctx.getExternalFilesDir(null)?.let {
                val base = "Android/data/${ctx.packageName}/files"
                dirs += base to it
                dirs += "$base/Models" to File(it, "Models")
            }
            return dirs
        }

        private fun pick(files: Array<File>): File? {
            val hits = files.filter { isModel(it) }
            return hits.firstOrNull { it.name.equals("model.task", ignoreCase = true) }
                ?: hits.filter { it.extension.equals("task", ignoreCase = true) }.maxByOrNull { it.lastModified() }
                ?: hits.maxByOrNull { it.lastModified() }
        }

        /**
         * Context sizes to try, best guess first. Model files bake in a context length, and MediaPipe wants
         * maxTokens to fit it. Google's file names say it (…_ekv2048.task); Gemma 3n is 4096; otherwise we
         * try a few common sizes and keep the first that loads.
         */
        private fun maxTokenGuesses(lowerName: String): List<Int> {
            Regex("ekv(\\d+)").find(lowerName)?.groupValues?.get(1)?.toIntOrNull()?.let { return listOf(it) }
            return if ("3n" in lowerName) listOf(4096) else listOf(1024, 2048, 4096, 1280, 512)
        }

        /** The model file that will be used, or null if none is installed. Any *.task name works. */
        fun findModel(ctx: Context): File? {
            for ((_, dir) in searchDirs(ctx)) {
                val files = try { dir.listFiles() } catch (e: Exception) { null } ?: continue
                pick(files)?.let { return it }
            }
            return null
        }

        /** Kept for older call sites: the found model, or the default path if nothing is installed. */
        fun modelFile(ctx: Context): File = findModel(ctx) ?: File(AtlasStorage.modelsDir(), "model.task")

        /** Full readout for Settings, including hints for the usual reasons a model isn't picked up. */
        fun scan(ctx: Context): ModelScan {
            val notes = mutableListOf<String>()
            if (!AtlasStorage.hasAccess()) {
                notes += "Novochron can't look inside Atlas/Models until you grant “All files access” (use the button below)."
            }
            val dirs = searchDirs(ctx)
            var found: File? = null
            var where = ""
            for ((label, dir) in dirs) {
                val files = try { dir.listFiles() } catch (e: Exception) { null } ?: continue
                if (found == null) pick(files)?.let { found = it; where = label }
                for (f in files) {
                    if (!f.isFile) continue
                    val name = f.name.lowercase(Locale.US)
                    val ext = f.extension.lowercase(Locale.US)
                    when {
                        ext in WRONG_EXT ->
                            notes += "${f.name} in $label is a .$ext file. This build loads MediaPipe .task model files instead."
                        ext in MODEL_EXT && !isModel(f) ->
                            notes += "${f.name} in $label is only ${sizeText(f)}, too small for a language model. Is the download finished?"
                        ".task" in name && ext !in MODEL_EXT ->
                            notes += "${f.name} in $label doesn't end in .task. Unfinished download, or an extra extension like .txt?"
                    }
                }
            }
            return ModelScan(found, where, dirs.map { it.first }, notes.distinct().take(4))
        }

        internal fun sizeText(f: File): String {
            val mb = f.length() / (1024.0 * 1024.0)
            return if (mb >= 1024) String.format(Locale.US, "%.1f GB", mb / 1024) else String.format(Locale.US, "%.0f MB", mb)
        }

        private fun describeError(e: Throwable): String {
            val msg = (e.message ?: "").lineSequence().firstOrNull { it.isNotBlank() }?.trim().orEmpty()
            val name = e.javaClass.simpleName
            return (if (msg.isEmpty()) name else "$name: $msg").take(160)
        }
    }
}
