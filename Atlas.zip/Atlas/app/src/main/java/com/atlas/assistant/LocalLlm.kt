package com.atlas.assistant

import android.content.Context
import android.graphics.Bitmap
import com.google.mediapipe.framework.image.BitmapImageBuilder
import com.google.mediapipe.tasks.genai.llminference.GraphOptions
import com.google.mediapipe.tasks.genai.llminference.LlmInference
import com.google.mediapipe.tasks.genai.llminference.LlmInferenceSession
import java.io.File

/**
 * Optional offline brain. If a MediaPipe-format model (e.g. Gemma) exists at
 * /storage/emulated/0/Atlas/Models/model.task (once Novochron has its own folder), or otherwise at
 * Android/data/com.novochron.assistant/files/model.task, Novochron can chat with no internet.
 *
 * Vision (photos, camera and screen frames while fully offline) needs a multimodal ".task" model
 * such as a converted Gemma 3n E2B/E4B build - a text-only Gemma model will not accept images.
 * [visionAvailable] fails closed: if the installed model does not support image input, or the
 * MediaPipe vision session cannot be created for any reason, offline vision is treated as
 * unavailable rather than crashing, and Brain falls back to "connect to look at this photo".
 */
class LocalLlm(private val ctx: Context) {
    private var llm: LlmInference? = null
    private var visionSession: LlmInferenceSession? = null
    private var visionChecked = false
    private var visionOk = false

    fun available(): Boolean = modelFile(ctx).exists()

    @Synchronized
    fun generate(prompt: String): String? {
        if (!available()) return null
        return try {
            ensureLlm()
            llm?.generateResponse(prompt)
        } catch (e: Throwable) {
            null
        }
    }

    /** True if an offline vision-capable session could be stood up for the installed model. */
    @Synchronized
    fun visionAvailable(): Boolean {
        if (!available()) return false
        if (visionChecked) return visionOk
        visionChecked = true
        visionOk = try {
            ensureLlm()
            val session = LlmInferenceSession.createFromOptions(
                llm,
                LlmInferenceSession.LlmInferenceSessionOptions.builder()
                    .setTopK(40)
                    .setGraphOptions(GraphOptions.builder().setEnableVisionModality(true).build())
                    .build()
            )
            visionSession = session
            true
        } catch (e: Throwable) {
            // model.task has no vision modality (e.g. a text-only Gemma build) - that's fine,
            // offline text chat still works, only offline photo/camera/screen understanding doesn't.
            false
        }
        return visionOk
    }

    /** Describes or answers a question about a bitmap, entirely on-device. Null if unavailable. */
    @Synchronized
    fun generateWithImage(prompt: String, bitmap: Bitmap): String? {
        if (!visionAvailable()) return null
        val session = visionSession ?: return null
        return try {
            session.addQueryChunk(prompt)
            session.addImage(BitmapImageBuilder(bitmap).build())
            val result = session.generateResponse()
            // each session is single-turn once an image is added; drop it so the next call gets a fresh one
            visionSession = null
            visionChecked = false
            result
        } catch (e: Throwable) {
            visionSession = null
            visionChecked = false
            null
        }
    }

    private fun ensureLlm() {
        if (llm != null) return
        val opts = LlmInference.LlmInferenceOptions.builder()
            .setModelPath(modelFile(ctx).absolutePath)
            .setMaxTokens(512)
            .build()
        llm = LlmInference.createFromOptions(ctx, opts)
    }

    companion object {
        fun modelFile(ctx: Context): File = File(ctx.getExternalFilesDir(null), "model.task")
    }
}
