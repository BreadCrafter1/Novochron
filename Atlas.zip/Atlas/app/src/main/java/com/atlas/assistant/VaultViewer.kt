package com.atlas.assistant

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.ExifInterface
import android.media.MediaPlayer
import android.net.Uri
import android.view.Gravity
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.MediaController
import android.widget.VideoView
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculatePan
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChanged
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.content.FileProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import java.io.File

/**
 * The vault's media viewer: photos (pinch / double-tap to zoom, swipe for the next one), audio (play,
 * pause, seek, +/-10 s) and video (built-in player with the usual seek bar) - all played inside the app.
 * Files are pulled from the vault repo once into cache/vault/ (see [vaultCacheFile]) and reused after that.
 */

enum class VaultKind { IMAGE, AUDIO, VIDEO, OTHER }

private val IMAGE_EXT = setOf("jpg", "jpeg", "png", "webp", "gif", "bmp", "heic", "heif")
private val AUDIO_EXT = setOf("mp3", "m4a", "aac", "wav", "ogg", "oga", "opus", "flac", "amr", "3gpp")
private val VIDEO_EXT = setOf("mp4", "m4v", "mov", "3gp", "webm", "mkv")

fun vaultKind(path: String): VaultKind {
    val ext = path.substringAfterLast('.', "").lowercase()
    return when (ext) {
        in IMAGE_EXT -> VaultKind.IMAGE
        in AUDIO_EXT -> VaultKind.AUDIO
        in VIDEO_EXT -> VaultKind.VIDEO
        else -> VaultKind.OTHER
    }
}

fun vaultKindLabel(k: VaultKind): String = when (k) {
    VaultKind.IMAGE -> "img"
    VaultKind.AUDIO -> "aud"
    VaultKind.VIDEO -> "vid"
    VaultKind.OTHER -> "file"
}

private fun vaultMime(path: String): String = when (path.substringAfterLast('.', "").lowercase()) {
    "jpg", "jpeg" -> "image/jpeg"
    "png" -> "image/png"
    "webp" -> "image/webp"
    "gif" -> "image/gif"
    "bmp" -> "image/bmp"
    "heic", "heif" -> "image/heic"
    "mp3" -> "audio/mpeg"
    "m4a", "aac" -> "audio/mp4"
    "wav" -> "audio/wav"
    "ogg", "oga", "opus" -> "audio/ogg"
    "flac" -> "audio/flac"
    "mp4", "m4v" -> "video/mp4"
    "mov" -> "video/quicktime"
    "3gp" -> "video/3gpp"
    "webm" -> "video/webm"
    "mkv" -> "video/x-matroska"
    "pdf" -> "application/pdf"
    "txt", "md" -> "text/plain"
    else -> "*/*"
}

// ---------------- cache ----------------

/** The size is part of the name, so a file that was replaced in the repo is fetched again instead of served stale. */
fun vaultCacheFile(ctx: Context, f: RepoFile): File =
    File(ctx.cacheDir, "vault/${f.size}_${f.path.substringAfterLast('/')}")

/** Downloads [f] into the cache (or returns the cached copy). Throws on network/API errors; null if it no longer exists. */
suspend fun vaultFetch(ctx: Context, client: MsgClient, repo: RepoRef, f: RepoFile): File? = withContext(Dispatchers.IO) {
    val dest = vaultCacheFile(ctx, f)
    if (dest.exists() && dest.length() > 0) return@withContext dest
    if (client.downloadFile(f.path, repo, dest)) dest else null
}

/** Keeps the cache from growing forever: oldest files go first once it passes [maxBytes]. */
fun vaultTrimCache(ctx: Context, maxBytes: Long = 300L * 1024 * 1024) {
    try {
        val files = File(ctx.cacheDir, "vault").listFiles()?.filter { it.isFile } ?: return
        var total = files.sumOf { it.length() }
        for (f in files.sortedBy { it.lastModified() }) {
            if (total <= maxBytes) break
            total -= f.length()
            f.delete()
        }
    } catch (e: Exception) { }
}

private val thumbGate = Semaphore(3)               // at most three thumbnails downloading at once
private const val THUMB_MAX_BYTES = 8L * 1024 * 1024 // bigger photos get a label instead of a surprise download

private fun vaultDecodeSampled(file: File, maxDim: Int): Bitmap? = try {
    val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    BitmapFactory.decodeFile(file.absolutePath, bounds)
    var sample = 1
    while (bounds.outWidth / sample > maxDim * 2 || bounds.outHeight / sample > maxDim * 2) sample *= 2
    val opts = BitmapFactory.Options().apply { inSampleSize = sample }
    val raw = BitmapFactory.decodeFile(file.absolutePath, opts)
    if (raw == null) null else {
        // Phone photos are often stored sideways with an "orientation" tag - honour it.
        val degrees = try {
            when (ExifInterface(file.absolutePath).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)) {
                ExifInterface.ORIENTATION_ROTATE_90 -> 90f
                ExifInterface.ORIENTATION_ROTATE_180 -> 180f
                ExifInterface.ORIENTATION_ROTATE_270 -> 270f
                else -> 0f
            }
        } catch (e: Exception) { 0f }
        if (degrees == 0f) raw else Bitmap.createBitmap(raw, 0, 0, raw.width, raw.height, Matrix().apply { postRotate(degrees) }, true)
    }
} catch (e: Throwable) { null }   // OutOfMemoryError included: a photo too big to show shouldn't crash the app

// ---------------- thumbnails ----------------

/** A small square: the photo itself for images, a kind label for everything else. */
@Composable
fun VaultThumb(f: RepoFile, client: MsgClient, repo: RepoRef?, modifier: Modifier = Modifier) {
    val ctx = LocalContext.current
    val kind = vaultKind(f.path)
    var bmp by remember(f.path, f.size) { mutableStateOf<Bitmap?>(null) }
    LaunchedEffect(f.path, f.size) {
        if (kind == VaultKind.IMAGE && repo != null && f.size <= THUMB_MAX_BYTES) {
            bmp = try {
                thumbGate.withPermit {
                    val file = vaultFetch(ctx, client, repo, f)
                    if (file == null) null else withContext(Dispatchers.IO) { vaultDecodeSampled(file, 256) }
                }
            } catch (e: Exception) { null }
        }
    }
    Box(modifier.background(Raised), contentAlignment = Alignment.Center) {
        val b = bmp
        if (b != null) {
            Image(b.asImageBitmap(), contentDescription = null, modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        } else {
            Text("[${vaultKindLabel(kind)}]", color = Dim, fontFamily = TermFont, fontSize = 11.sp)
        }
        if (kind == VaultKind.VIDEO || kind == VaultKind.AUDIO) {
            Text(if (kind == VaultKind.VIDEO) "▶" else "♪", color = Accent, fontFamily = TermFont, fontSize = 18.sp,
                modifier = Modifier.align(Alignment.BottomEnd).padding(4.dp))
        }
    }
}

// ---------------- the full-screen viewer ----------------

/**
 * Full-screen pager over [items] starting at [startIndex]. [onDelete] is offered in the corner; it's up to
 * the caller to confirm and to close the viewer.
 */
@Composable
fun VaultViewer(
    items: List<RepoFile>,
    startIndex: Int,
    client: MsgClient,
    repo: RepoRef,
    onDelete: (RepoFile) -> Unit,
    onClose: () -> Unit
) {
    if (items.isEmpty()) { LaunchedEffect(Unit) { onClose() }; return }
    val ctx = LocalContext.current
    val pager = rememberPagerState(initialPage = startIndex.coerceIn(0, items.lastIndex)) { items.size }
    val loaded = remember { mutableStateMapOf<String, File>() }
    val current = items.getOrNull(pager.currentPage)

    Dialog(onDismissRequest = onClose, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Box(Modifier.fillMaxSize().background(Color.Black)) {
            HorizontalPager(pager, Modifier.fillMaxSize(), key = { items[it].path }) { page ->
                val f = items[page]
                VaultPage(
                    f = f, active = pager.currentPage == page, client = client, repo = repo, ctx = ctx,
                    onLoaded = { loaded[f.path] = it }
                )
            }

            Column(
                Modifier.align(Alignment.TopStart).fillMaxWidth().statusBarsPadding()
                    .background(Color(0x99000000)).padding(horizontal = 12.dp, vertical = 6.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(
                            current?.path?.substringAfterLast('/') ?: "", color = Ink, fontFamily = TermFont, fontSize = 13.sp,
                            maxLines = 1, overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            "${pager.currentPage + 1} / ${items.size}" + (current?.let { " · " + humanVaultSize(it.size) } ?: ""),
                            color = Dim, fontFamily = TermFont, fontSize = 11.sp
                        )
                    }
                    TextButton(onClick = onClose) { Text("[close]", color = Ink, fontFamily = TermFont, fontSize = 14.sp) }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    val file = current?.let { loaded[it.path] }
                    TextButton(
                        onClick = {
                            val cf = file; val cu = current
                            if (cf != null && cu != null) openExternally(ctx, cf, cu.path)
                        },
                        enabled = file != null
                    ) {
                        Text("[open with…]", color = Accent, fontFamily = TermFont, fontSize = 12.sp)
                    }
                    TextButton(onClick = { current?.let(onDelete) }) {
                        Text("[delete]", color = Warn, fontFamily = TermFont, fontSize = 12.sp)
                    }
                }
            }
        }
    }
}

@Composable
private fun VaultPage(f: RepoFile, active: Boolean, client: MsgClient, repo: RepoRef, ctx: Context, onLoaded: (File) -> Unit) {
    var file by remember(f.path, f.size) { mutableStateOf<File?>(null) }
    var error by remember(f.path, f.size) { mutableStateOf("") }
    LaunchedEffect(f.path, f.size) {
        error = ""
        try {
            val got = vaultFetch(ctx, client, repo, f)
            if (got == null) error = "This file is no longer in the repo." else { file = got; onLoaded(got) }
        } catch (e: Exception) {
            error = if (e is GitHubApiException) "GitHub error ${e.code}." else (e.message ?: "Couldn't download this file.")
        }
    }

    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        val local = file
        when {
            error.isNotEmpty() -> CenterNote(error, Warn)
            local == null -> CenterNote("Loading ${humanVaultSize(f.size)}…", Dim)
            else -> when (vaultKind(f.path)) {
                VaultKind.IMAGE -> ImagePage(local)
                VaultKind.AUDIO -> AudioPage(local, f.path.substringAfterLast('/'), active)
                VaultKind.VIDEO -> VideoPage(local, active)
                VaultKind.OTHER -> CenterNote("No in-app preview for this type of file.\nUse [open with…] above.", Dim)
            }
        }
    }
}

@Composable
private fun CenterNote(text: String, color: Color) {
    Text(text, color = color, fontFamily = TermFont, fontSize = 13.sp, textAlign = TextAlign.Center, modifier = Modifier.padding(24.dp))
}

// ---------------- photos ----------------

@Composable
private fun ImagePage(file: File) {
    var bmp by remember(file) { mutableStateOf<Bitmap?>(null) }
    var failed by remember(file) { mutableStateOf(false) }
    LaunchedEffect(file) {
        val b = withContext(Dispatchers.IO) { vaultDecodeSampled(file, 2048) }
        if (b == null) failed = true else bmp = b
    }
    val b = bmp
    when {
        b != null -> ZoomableImage(b)
        failed -> CenterNote("Couldn't decode this image.\nTry [open with…].", Warn)
        else -> CenterNote("Decoding…", Dim)
    }
}

/** Pinch to zoom, drag to pan when zoomed, double-tap to toggle. At 1x a single finger is left alone so the pager can swipe. */
@Composable
private fun ZoomableImage(bmp: Bitmap) {
    var scale by remember(bmp) { mutableStateOf(1f) }
    var offset by remember(bmp) { mutableStateOf(Offset.Zero) }
    var box by remember { mutableStateOf(IntSize.Zero) }

    fun clamp(o: Offset, s: Float): Offset {
        val mx = box.width * (s - 1f) / 2f
        val my = box.height * (s - 1f) / 2f
        return Offset(o.x.coerceIn(-mx, mx), o.y.coerceIn(-my, my))
    }

    Box(
        Modifier
            .fillMaxSize()
            .onSizeChanged { box = it }
            .pointerInput(bmp) {
                detectTapGestures(onDoubleTap = {
                    if (scale > 1f) { scale = 1f; offset = Offset.Zero } else scale = 2.5f
                })
            }
            .pointerInput(bmp) {
                awaitEachGesture {
                    awaitFirstDown(requireUnconsumed = false)
                    do {
                        val event = awaitPointerEvent()
                        if (event.changes.size > 1 || scale > 1f) {
                            val newScale = (scale * event.calculateZoom()).coerceIn(1f, 5f)
                            scale = newScale
                            offset = if (newScale > 1f) clamp(offset + event.calculatePan(), newScale) else Offset.Zero
                            event.changes.forEach { if (it.positionChanged()) it.consume() }
                        }
                    } while (event.changes.any { it.pressed })
                }
            }
    ) {
        Image(
            bmp.asImageBitmap(), contentDescription = "photo",
            contentScale = ContentScale.Fit,
            modifier = Modifier.fillMaxSize().graphicsLayer(
                scaleX = scale, scaleY = scale, translationX = offset.x, translationY = offset.y
            )
        )
    }
}

// ---------------- audio ----------------

@Composable
private fun AudioPage(file: File, title: String, active: Boolean) {
    var player by remember(file) { mutableStateOf<MediaPlayer?>(null) }
    var ready by remember(file) { mutableStateOf(false) }
    var playing by remember(file) { mutableStateOf(false) }
    var failed by remember(file) { mutableStateOf(false) }
    var posMs by remember(file) { mutableStateOf(0) }
    var durMs by remember(file) { mutableStateOf(0) }
    var dragging by remember(file) { mutableStateOf(false) }

    // The player only exists while this page is the one on screen - swiping away stops the sound.
    DisposableEffect(file, active) {
        val mp: MediaPlayer? = if (active) MediaPlayer() else null
        if (mp != null) {
            try {
                mp.setDataSource(file.absolutePath)
                mp.setOnPreparedListener { durMs = it.duration; ready = true; it.start(); playing = true }
                mp.setOnCompletionListener { playing = false; posMs = 0 }
                mp.setOnErrorListener { _, _, _ -> failed = true; playing = false; true }
                mp.prepareAsync()
            } catch (e: Exception) { failed = true }
            player = mp
        }
        onDispose {
            player = null; ready = false; playing = false; posMs = 0
            try { mp?.release() } catch (e: Exception) { }
        }
    }

    LaunchedEffect(player, playing, dragging) {
        while (playing && !dragging) {
            posMs = try { player?.currentPosition ?: 0 } catch (e: Exception) { 0 }
            delay(250)
        }
    }

    fun toggle() {
        val mp = player ?: return
        try {
            if (mp.isPlaying) { mp.pause(); playing = false }
            else {
                if (durMs > 0 && mp.currentPosition >= durMs - 200) mp.seekTo(0)
                mp.start(); playing = true
            }
        } catch (e: Exception) { failed = true }
    }
    fun skip(deltaMs: Int) {
        val mp = player ?: return
        try {
            val target = (mp.currentPosition + deltaMs).coerceIn(0, durMs)
            mp.seekTo(target); posMs = target
        } catch (e: Exception) { }
    }

    Column(
        Modifier.fillMaxWidth().padding(28.dp),
        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text("♪", color = Accent, fontFamily = TermFont, fontSize = 64.sp)
        Text(title, color = Ink, fontFamily = TermFont, fontSize = 14.sp, textAlign = TextAlign.Center, maxLines = 3, overflow = TextOverflow.Ellipsis)
        when {
            failed -> Text("Couldn't play this audio file. Try [open with…].", color = Warn, fontFamily = TermFont, fontSize = 12.sp, textAlign = TextAlign.Center)
            !ready -> Text(if (active) "Preparing…" else "", color = Dim, fontFamily = TermFont, fontSize = 12.sp)
            else -> {
                Slider(
                    value = posMs.toFloat().coerceIn(0f, durMs.toFloat().coerceAtLeast(1f)),
                    onValueChange = { dragging = true; posMs = it.toInt() },
                    onValueChangeFinished = { try { player?.seekTo(posMs) } catch (e: Exception) { }; dragging = false },
                    valueRange = 0f..durMs.toFloat().coerceAtLeast(1f),
                    colors = SliderDefaults.colors(thumbColor = Accent, activeTrackColor = Accent, inactiveTrackColor = Line)
                )
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(clock(posMs), color = Dim, fontFamily = TermFont, fontSize = 11.sp)
                    Text(clock(durMs), color = Dim, fontFamily = TermFont, fontSize = 11.sp)
                }
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    TextButton(onClick = { skip(-10_000) }) { Text("[-10s]", color = Ink, fontFamily = TermFont, fontSize = 14.sp) }
                    TextButton(onClick = { toggle() }) {
                        Text(if (playing) "[❚❚ pause]" else "[▶ play]", color = Accent, fontFamily = TermFont, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                    }
                    TextButton(onClick = { skip(10_000) }) { Text("[+10s]", color = Ink, fontFamily = TermFont, fontSize = 14.sp) }
                }
            }
        }
    }
}

// ---------------- video ----------------

@Composable
private fun VideoPage(file: File, active: Boolean) {
    var failed by remember(file) { mutableStateOf(false) }
    if (failed) { CenterNote("Couldn't play this video.\nTry [open with…].", Warn); return }
    if (!active) { CenterNote("▶", Dim); return }        // only the visible page holds a player

    AndroidView(
        modifier = Modifier.fillMaxSize(),
        factory = { c ->
            FrameLayout(c).apply {
                layoutParams = ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
                val vv = VideoView(c)
                addView(vv, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT, Gravity.CENTER))
                val mc = MediaController(c)
                mc.setAnchorView(this)
                vv.setMediaController(mc)
                vv.setOnPreparedListener { it.isLooping = false; vv.start() }
                vv.setOnErrorListener { _, _, _ -> failed = true; true }
                vv.setVideoURI(Uri.fromFile(file))
                tag = vv
            }
        },
        onRelease = { (it.tag as? VideoView)?.stopPlayback() }
    )
}

// ---------------- helpers ----------------

private fun openExternally(ctx: Context, file: File, path: String) {
    try {
        val uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.fileprovider", file)
        val intent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, vaultMime(path))
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        ctx.startActivity(intent)
    } catch (e: Exception) {
        android.widget.Toast.makeText(ctx, "No app found to open this file.", android.widget.Toast.LENGTH_SHORT).show()
    }
}

private fun clock(ms: Int): String {
    val s = ms / 1000
    return "%d:%02d".format(s / 60, s % 60)
}

fun humanVaultSize(bytes: Long): String = when {
    bytes >= 1_048_576L -> String.format(java.util.Locale.US, "%.1f MB", bytes / 1_048_576.0)
    bytes >= 1024L -> "${bytes / 1024} KB"
    else -> "$bytes B"
}
