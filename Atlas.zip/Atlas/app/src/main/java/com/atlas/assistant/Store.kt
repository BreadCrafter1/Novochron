package com.atlas.assistant

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

data class Msg(
    val id: Long,
    val role: String,
    val text: String,
    val ts: Long,
    val artifactId: Long = 0,
    val artifactTitle: String = "",
    /** Path to a photo/camera/screen frame attached to this message, or "" if none. */
    val imagePath: String = ""
)
data class Memory(val id: Long, val text: String, val ts: Long)
data class Artifact(val id: Long, val title: String, val html: String, val ts: Long)
data class ArtifactInfo(val id: Long, val title: String, val ts: Long)
/** Something Novochron was told to "learn" online, kept as offline-usable reference notes. */
data class Knowledge(val id: Long, val topic: String, val content: String, val ts: Long)

/**
 * Everything is stored locally on the phone: chat history, long-term memory, artifacts, settings.
 * When Novochron has been granted its own folder on shared storage (see [AtlasStorage]), the database
 * lives at /storage/emulated/0/Atlas/atlas.db, visible in any file manager. Until that access is
 * granted, it falls back to the app's private storage so Novochron still works.
 */
class Store private constructor(ctx: Context) : SQLiteOpenHelper(ctx, dbName(), null, 4) {

    private val prefs = ctx.getSharedPreferences("novochron_prefs", Context.MODE_PRIVATE)

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            "CREATE TABLE messages (id INTEGER PRIMARY KEY AUTOINCREMENT, role TEXT NOT NULL, text TEXT NOT NULL, " +
                "ts INTEGER NOT NULL, artifact_id INTEGER NOT NULL DEFAULT 0, image_path TEXT NOT NULL DEFAULT '')"
        )
        db.execSQL("CREATE TABLE memories (id INTEGER PRIMARY KEY AUTOINCREMENT, text TEXT NOT NULL, ts INTEGER NOT NULL)")
        createArtifacts(db)
        createKnowledge(db)
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        if (oldVersion < 2) {
            db.execSQL("ALTER TABLE messages ADD COLUMN artifact_id INTEGER NOT NULL DEFAULT 0")
            createArtifacts(db)
        }
        if (oldVersion < 3) {
            db.execSQL("ALTER TABLE messages ADD COLUMN image_path TEXT NOT NULL DEFAULT ''")
        }
        if (oldVersion < 4) {
            createKnowledge(db)
        }
    }

    private fun createKnowledge(db: SQLiteDatabase) {
        db.execSQL(
            "CREATE TABLE IF NOT EXISTS knowledge (id INTEGER PRIMARY KEY AUTOINCREMENT, topic TEXT NOT NULL, " +
                "content TEXT NOT NULL, ts INTEGER NOT NULL)"
        )
    }

    private fun createArtifacts(db: SQLiteDatabase) {
        db.execSQL(
            "CREATE TABLE IF NOT EXISTS artifacts (id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL, " +
                "html TEXT NOT NULL, ts INTEGER NOT NULL)"
        )
    }

    // ---- chat history ----
    fun addMessage(role: String, text: String, artifactId: Long = 0, imagePath: String = "") {
        val v = ContentValues().apply {
            put("role", role); put("text", text); put("ts", System.currentTimeMillis())
            put("artifact_id", artifactId); put("image_path", imagePath)
        }
        writableDatabase.insert("messages", null, v)
    }

    fun recentMessages(limit: Int): List<Msg> {
        val out = ArrayList<Msg>()
        val sql = "SELECT m.id, m.role, m.text, m.ts, m.artifact_id, COALESCE(a.title, ''), m.image_path " +
            "FROM messages m LEFT JOIN artifacts a ON a.id = m.artifact_id ORDER BY m.id DESC LIMIT ${limit.coerceAtLeast(1)}"
        readableDatabase.rawQuery(sql, null).use { c ->
            while (c.moveToNext()) {
                out.add(Msg(c.getLong(0), c.getString(1), c.getString(2), c.getLong(3), c.getLong(4), c.getString(5), c.getString(6)))
            }
        }
        out.reverse()
        return out
    }

    fun clearMessages() {
        writableDatabase.delete("messages", null, null)
    }

    // ---- artifacts (apps, puzzles and pages Novochron builds) ----
    fun addArtifact(title: String, html: String): Long {
        val v = ContentValues().apply {
            put("title", title.ifBlank { "Untitled" }.take(80)); put("html", html); put("ts", System.currentTimeMillis())
        }
        val id = writableDatabase.insert("artifacts", null, v)
        // keep the library from growing forever
        writableDatabase.execSQL("DELETE FROM artifacts WHERE id NOT IN (SELECT id FROM artifacts ORDER BY id DESC LIMIT 100)")
        return id
    }

    fun artifact(id: Long): Artifact? {
        readableDatabase.rawQuery("SELECT id, title, html, ts FROM artifacts WHERE id = ?", arrayOf(id.toString())).use { c ->
            return if (c.moveToFirst()) Artifact(c.getLong(0), c.getString(1), c.getString(2), c.getLong(3)) else null
        }
    }

    fun latestArtifact(): Artifact? {
        readableDatabase.rawQuery("SELECT id, title, html, ts FROM artifacts ORDER BY id DESC LIMIT 1", null).use { c ->
            return if (c.moveToFirst()) Artifact(c.getLong(0), c.getString(1), c.getString(2), c.getLong(3)) else null
        }
    }

    fun artifacts(): List<ArtifactInfo> {
        val out = ArrayList<ArtifactInfo>()
        readableDatabase.rawQuery("SELECT id, title, ts FROM artifacts ORDER BY id DESC", null).use { c ->
            while (c.moveToNext()) out.add(ArtifactInfo(c.getLong(0), c.getString(1), c.getLong(2)))
        }
        return out
    }

    fun deleteArtifact(id: Long) {
        writableDatabase.delete("artifacts", "id = ?", arrayOf(id.toString()))
    }

    // ---- long-term memory ----
    fun addMemory(text: String) {
        val t = text.trim()
        if (t.isEmpty() || memories().any { it.text.equals(t, ignoreCase = true) }) return
        val v = ContentValues().apply { put("text", t); put("ts", System.currentTimeMillis()) }
        writableDatabase.insert("memories", null, v)
    }

    fun memories(): List<Memory> {
        val out = ArrayList<Memory>()
        readableDatabase.query("memories", null, null, null, null, null, "id ASC").use { c ->
            while (c.moveToNext()) out.add(Memory(c.getLong(0), c.getString(1), c.getLong(2)))
        }
        return out
    }

    fun forget(keyword: String): Int =
        writableDatabase.delete("memories", "LOWER(text) LIKE ?", arrayOf("%${keyword.lowercase().trim()}%"))

    fun clearMemories() {
        writableDatabase.delete("memories", null, null)
    }

    // ---- learned knowledge ("learn mathematics") ----
    /** Stores (or replaces) offline-usable reference notes on a topic, learned online. */
    fun addKnowledge(topic: String, content: String) {
        val t = topic.trim()
        val c = content.trim()
        if (t.isEmpty() || c.isEmpty()) return
        writableDatabase.delete("knowledge", "LOWER(topic) = ?", arrayOf(t.lowercase()))
        val v = ContentValues().apply { put("topic", t); put("content", c); put("ts", System.currentTimeMillis()) }
        writableDatabase.insert("knowledge", null, v)
        // keep this from growing forever
        writableDatabase.execSQL("DELETE FROM knowledge WHERE id NOT IN (SELECT id FROM knowledge ORDER BY id DESC LIMIT 60)")
    }

    fun knowledge(): List<Knowledge> {
        val out = ArrayList<Knowledge>()
        readableDatabase.query("knowledge", null, null, null, null, null, "id DESC").use { c ->
            while (c.moveToNext()) out.add(Knowledge(c.getLong(0), c.getString(1), c.getString(2), c.getLong(3)))
        }
        return out
    }

    fun deleteKnowledge(id: Long) {
        writableDatabase.delete("knowledge", "id = ?", arrayOf(id.toString()))
    }

    fun clearKnowledge() {
        writableDatabase.delete("knowledge", null, null)
    }

    // ---- settings ----
    var apiKey: String
        get() = prefs.getString("api_key", "") ?: ""
        set(v) { prefs.edit().putString("api_key", v).apply() }

    /** Offline fallback voice only (the online Gemini voice ignores this). Lower = deeper. */
    var pitch: Float
        get() = prefs.getFloat("pitch", 1.15f)
        set(v) { prefs.edit().putFloat("pitch", v).apply() }

    /** Let the user cut Novochron off by talking while it is speaking. */
    var interrupt: Boolean
        get() = prefs.getBoolean("interrupt", true)
        set(v) { prefs.edit().putBoolean("interrupt", v).apply() }

    /** "auto" (smart model for builds), "fast" or "smart". */
    var modelMode: String
        get() = prefs.getString("model_mode", "auto") ?: "auto"
        set(v) { prefs.edit().putString("model_mode", v).apply() }

    var batteryAsked: Boolean
        get() = prefs.getBoolean("battery_asked", false)
        set(v) { prefs.edit().putBoolean("battery_asked", v).apply() }

    /**
     * Manual online/offline toggle. When true, Novochron never touches the network even if it's
     * available: no Gemini chat, no online voice, no streaming — just phone commands, memory, offline
     * maps and the offline brain (if installed). When false (the default), Novochron decides for itself
     * based on whether the internet is actually reachable right now.
     */
    var forceOffline: Boolean
        get() = prefs.getBoolean("force_offline", false)
        set(v) { prefs.edit().putBoolean("force_offline", v).apply() }

    /** Wake-word gating: while on, Novochron ignores speech until it hears [wakeWordPhrase]. */
    var wakeWordEnabled: Boolean
        get() = prefs.getBoolean("wake_word_enabled", false)
        set(v) { prefs.edit().putBoolean("wake_word_enabled", v).apply() }

    var wakeWordPhrase: String
        get() = prefs.getString("wake_word_phrase", "novochron") ?: "novochron"
        set(v) { prefs.edit().putString("wake_word_phrase", v.trim().ifBlank { "novochron" }).apply() }

    companion object {
        @Volatile private var inst: Store? = null
        fun get(ctx: Context): Store =
            inst ?: synchronized(this) { inst ?: Store(ctx.applicationContext).also { inst = it } }

        /**
         * SQLiteOpenHelper treats a name starting with "/" as an absolute path, so once Novochron's own
         * folder is accessible we point the database straight at it; otherwise "novochron.db" resolves to
         * the normal private database directory, same as before.
         */
        private fun dbName(): String =
            if (AtlasStorage.hasAccess() && AtlasStorage.ensureDirs()) AtlasStorage.dbFile().absolutePath else "novochron.db"
    }
}
