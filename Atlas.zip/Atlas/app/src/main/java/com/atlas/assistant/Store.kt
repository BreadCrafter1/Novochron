package com.atlas.assistant

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

data class Msg(
    val id: Long,
    val role: String,
    val text: String,
    val ts: Long,
    val artifactId: Long = 0,
    val artifactTitle: String = "",
    /** Path to a photo/camera/screen frame attached to this message, or "" if none. */
    val imagePath: String = ""
)
data class Memory(val id: Long, val text: String, val ts: Long)
data class Artifact(val id: Long, val title: String, val html: String, val ts: Long)
data class ArtifactInfo(val id: Long, val title: String, val ts: Long)
/** One saved conversation, listed in the "[chats]" tab. [messageCount] and [updatedTs] are live, not stored. */
data class ChatInfo(val id: Long, val title: String, val updatedTs: Long, val messageCount: Int)
/** Something Novochron was told to "learn" online, kept as offline-usable reference notes. */
data class Knowledge(val id: Long, val topic: String, val content: String, val ts: Long)

/**
 * Everything is stored locally on the phone: chat history, long-term memory, artifacts, settings.
 * When Novochron has been granted its own folder on shared storage (see [AtlasStorage]), the database
 * lives at /storage/emulated/0/Atlas/atlas.db, visible in any file manager. Until that access is
 * granted, it falls back to the app's private storage so Novochron still works.
 */
class Store private constructor(ctx: Context) : SQLiteOpenHelper(ctx, dbName(), null, 5) {

    private val appCtx = ctx.applicationContext
    private val prefs = ctx.getSharedPreferences("novochron_prefs", Context.MODE_PRIVATE)

    init {
        migrateKnowledgeToFiles()
        ensureCurrentChat()
    }

    override fun onCreate(db: SQLiteDatabase) {
        createChats(db)
        db.execSQL(
            "CREATE TABLE messages (id INTEGER PRIMARY KEY AUTOINCREMENT, role TEXT NOT NULL, text TEXT NOT NULL, " +
                "ts INTEGER NOT NULL, artifact_id INTEGER NOT NULL DEFAULT 0, image_path TEXT NOT NULL DEFAULT '', " +
                "chat_id INTEGER NOT NULL DEFAULT 1)"
        )
        db.execSQL("CREATE TABLE memories (id INTEGER PRIMARY KEY AUTOINCREMENT, text TEXT NOT NULL, ts INTEGER NOT NULL)")
        createArtifacts(db)
        createKnowledge(db)
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        if (oldVersion < 2) {
            db.execSQL("ALTER TABLE messages ADD COLUMN artifact_id INTEGER NOT NULL DEFAULT 0")
            createArtifacts(db)
        }
        if (oldVersion < 3) {
            db.execSQL("ALTER TABLE messages ADD COLUMN image_path TEXT NOT NULL DEFAULT ''")
        }
        if (oldVersion < 4) {
            createKnowledge(db)
        }
        if (oldVersion < 5) {
            // Chats tab: every message that already exists gets folded into one "Chat 1" so nothing
            // already said is lost, then new conversations can be split off from there.
            createChats(db)
            val now = System.currentTimeMillis()
            val v = ContentValues().apply { put("title", "Chat 1"); put("created_ts", now); put("updated_ts", now) }
            val firstChatId = db.insert("chats", null, v)
            db.execSQL("ALTER TABLE messages ADD COLUMN chat_id INTEGER NOT NULL DEFAULT $firstChatId")
        }
    }

    private fun createChats(db: SQLiteDatabase) {
        db.execSQL(
            "CREATE TABLE IF NOT EXISTS chats (id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL, " +
                "created_ts INTEGER NOT NULL, updated_ts INTEGER NOT NULL)"
        )
    }

    private fun createKnowledge(db: SQLiteDatabase) {
        db.execSQL(
            "CREATE TABLE IF NOT EXISTS knowledge (id INTEGER PRIMARY KEY AUTOINCREMENT, topic TEXT NOT NULL, " +
                "content TEXT NOT NULL, ts INTEGER NOT NULL)"
        )
    }

    private fun createArtifacts(db: SQLiteDatabase) {
        db.execSQL(
            "CREATE TABLE IF NOT EXISTS artifacts (id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL, " +
                "html TEXT NOT NULL, ts INTEGER NOT NULL)"
        )
    }

    /** Makes sure at least one chat exists and [currentChatId] points at a real row, on every launch. */
    private fun ensureCurrentChat() {
        val db = writableDatabase
        val count = db.rawQuery("SELECT COUNT(*) FROM chats", null).use { c -> if (c.moveToFirst()) c.getLong(0) else 0L }
        if (count == 0L) {
            val now = System.currentTimeMillis()
            val v = ContentValues().apply { put("title", "Chat 1"); put("created_ts", now); put("updated_ts", now) }
            currentChatId = db.insert("chats", null, v)
        } else if (!chatExists(currentChatId)) {
            currentChatId = db.rawQuery("SELECT id FROM chats ORDER BY updated_ts DESC LIMIT 1", null)
                .use { c -> if (c.moveToFirst()) c.getLong(0) else 0L }
        }
    }

    private fun chatExists(id: Long): Boolean =
        readableDatabase.rawQuery("SELECT 1 FROM chats WHERE id=?", arrayOf(id.toString())).use { it.moveToFirst() }

    // ---- chats (the "[chats]" tab: separate, switchable conversations) ----

    /** Which chat new messages are read from/written to. Always points at a real row. */
    var currentChatId: Long
        get() = prefs.getLong("current_chat_id", 0L)
        set(v) { prefs.edit().putLong("current_chat_id", v).apply() }

    fun listChats(): List<ChatInfo> {
        val out = ArrayList<ChatInfo>()
        val sql = "SELECT c.id, c.title, c.updated_ts, (SELECT COUNT(*) FROM messages m WHERE m.chat_id = c.id) " +
            "FROM chats c ORDER BY c.updated_ts DESC"
        readableDatabase.rawQuery(sql, null).use { c ->
            while (c.moveToNext()) out.add(ChatInfo(c.getLong(0), c.getString(1), c.getLong(2), c.getInt(3)))
        }
        return out
    }

    /** Creates a fresh, empty chat, switches to it, and returns its id. */
    fun newChat(title: String = "New chat"): Long {
        val now = System.currentTimeMillis()
        val v = ContentValues().apply { put("title", title.ifBlank { "New chat" }.take(60)); put("created_ts", now); put("updated_ts", now) }
        val id = writableDatabase.insert("chats", null, v)
        currentChatId = id
        return id
    }

    fun renameChat(id: Long, title: String) {
        writableDatabase.update(
            "chats", ContentValues().apply { put("title", title.ifBlank { "Untitled chat" }.take(60)) },
            "id=?", arrayOf(id.toString())
        )
    }

    /** Deletes a chat and its messages. If it was the current one, falls back to the next most recent (or a fresh chat). */
    fun deleteChat(id: Long) {
        writableDatabase.delete("messages", "chat_id=?", arrayOf(id.toString()))
        writableDatabase.delete("chats", "id=?", arrayOf(id.toString()))
        if (currentChatId == id) {
            val remaining = listChats()
            currentChatId = if (remaining.isNotEmpty()) remaining.first().id else newChat("Chat 1")
        }
    }

    // ---- chat history (always scoped to currentChatId) ----
    fun addMessage(role: String, text: String, artifactId: Long = 0, imagePath: String = "") {
        val cid = currentChatId
        val now = System.currentTimeMillis()
        val v = ContentValues().apply {
            put("role", role); put("text", text); put("ts", now)
            put("artifact_id", artifactId); put("image_path", imagePath); put("chat_id", cid)
        }
        writableDatabase.insert("messages", null, v)
        writableDatabase.update("chats", ContentValues().apply { put("updated_ts", now) }, "id=?", arrayOf(cid.toString()))
    }

    fun recentMessages(limit: Int): List<Msg> {
        val out = ArrayList<Msg>()
        val cid = currentChatId
        val sql = "SELECT m.id, m.role, m.text, m.ts, m.artifact_id, COALESCE(a.title, ''), m.image_path " +
            "FROM messages m LEFT JOIN artifacts a ON a.id = m.artifact_id " +
            "WHERE m.chat_id = $cid ORDER BY m.id DESC LIMIT ${limit.coerceAtLeast(1)}"
        readableDatabase.rawQuery(sql, null).use { c ->
            while (c.moveToNext()) {
                out.add(Msg(c.getLong(0), c.getString(1), c.getString(2), c.getLong(3), c.getLong(4), c.getString(5), c.getString(6)))
            }
        }
        out.reverse()
        return out
    }

    /** Clears only the current chat's messages, not the other saved chats. */
    fun clearMessages() {
        writableDatabase.delete("messages", "chat_id=?", arrayOf(currentChatId.toString()))
    }

    // ---- artifacts (apps, puzzles and pages Novochron builds) ----
    fun addArtifact(title: String, html: String): Long {
        val v = ContentValues().apply {
            put("title", title.ifBlank { "Untitled" }.take(80)); put("html", html); put("ts", System.currentTimeMillis())
        }
        val id = writableDatabase.insert("artifacts", null, v)
        // keep the library from growing forever
        writableDatabase.execSQL("DELETE FROM artifacts WHERE id NOT IN (SELECT id FROM artifacts ORDER BY id DESC LIMIT 100)")
        return id
    }

    fun artifact(id: Long): Artifact? {
        readableDatabase.rawQuery("SELECT id, title, html, ts FROM artifacts WHERE id = ?", arrayOf(id.toString())).use { c ->
            return if (c.moveToFirst()) Artifact(c.getLong(0), c.getString(1), c.getString(2), c.getLong(3)) else null
        }
    }

    fun latestArtifact(): Artifact? {
        readableDatabase.rawQuery("SELECT id, title, html, ts FROM artifacts ORDER BY id DESC LIMIT 1", null).use { c ->
            return if (c.moveToFirst()) Artifact(c.getLong(0), c.getString(1), c.getString(2), c.getLong(3)) else null
        }
    }

    fun artifacts(): List<ArtifactInfo> {
        val out = ArrayList<ArtifactInfo>()
        readableDatabase.rawQuery("SELECT id, title, ts FROM artifacts ORDER BY id DESC", null).use { c ->
            while (c.moveToNext()) out.add(ArtifactInfo(c.getLong(0), c.getString(1), c.getLong(2)))
        }
        return out
    }

    fun deleteArtifact(id: Long) {
        writableDatabase.delete("artifacts", "id = ?", arrayOf(id.toString()))
    }

    // ---- long-term memory ----
    fun addMemory(text: String) {
        val t = text.trim()
        if (t.isEmpty() || memories().any { it.text.equals(t, ignoreCase = true) }) return
        val v = ContentValues().apply { put("text", t); put("ts", System.currentTimeMillis()) }
        writableDatabase.insert("memories", null, v)
    }

    fun memories(): List<Memory> {
        val out = ArrayList<Memory>()
        readableDatabase.query("memories", null, null, null, null, null, "id ASC").use { c ->
            while (c.moveToNext()) out.add(Memory(c.getLong(0), c.getString(1), c.getLong(2)))
        }
        return out
    }

    fun forget(keyword: String): Int =
        writableDatabase.delete("memories", "LOWER(text) LIKE ?", arrayOf("%${keyword.lowercase().trim()}%"))

    fun clearMemories() {
        writableDatabase.delete("memories", null, null)
    }

    // ---- learned knowledge ("learn mathematics") ----
    // Kept as plain .txt files in Atlas/Knowledge/ (see KnowledgeStore) rather than in this database,
    // so learned notes are visible and editable in a file manager, the same way places.json is.

    /** Stores (or replaces) offline-usable reference notes on a topic, learned online. */
    fun addKnowledge(topic: String, content: String) = KnowledgeStore.save(appCtx, topic, content)

    fun knowledge(): List<Knowledge> = KnowledgeStore.all(appCtx)

    fun deleteKnowledge(id: Long) = KnowledgeStore.delete(appCtx, id)

    fun clearKnowledge() = KnowledgeStore.clear(appCtx)

    /** One-time upgrade: moves any knowledge rows from an older version's database into the folder. */
    private fun migrateKnowledgeToFiles() {
        try {
            val rows = ArrayList<Pair<String, String>>()
            readableDatabase.query("knowledge", null, null, null, null, null, null).use { c ->
                while (c.moveToNext()) rows.add(c.getString(1) to c.getString(2))
            }
            if (rows.isEmpty()) return
            rows.forEach { (topic, content) -> KnowledgeStore.save(appCtx, topic, content) }
            writableDatabase.delete("knowledge", null, null)
        } catch (e: Exception) {
            // no "knowledge" table (fresh install) or migration failed — nothing to carry over
        }
    }

    // ---- settings ----
    /**
     * Baked into BuildConfig at build time (see app/build.gradle.kts) rather than typed into Settings,
     * at the user's request — nothing in the app can view, change or clear it. The key itself is never
     * committed to the repo: it comes from a local gradle property/local.properties entry for a
     * developer build, or a GitHub Actions repo secret for a CI build (see android-build.yml) — Google
     * auto-revokes a Gemini key the moment it sees one committed in plain text to a public repo.
     */
    val apiKey: String get() = BuildConfig.GEMINI_API_KEY

    // ---- GitHub (terminal's "gh"/"repo" commands, see GitHub.kt and Terminal.kt) ----
    /** OAuth device-flow access token, or "" if not logged in. Never a password. */
    var githubToken: String
        get() = prefs.getString("github_token", "") ?: ""
        set(v) { prefs.edit().putString("github_token", v).apply() }
    var githubUser: String
        get() = prefs.getString("github_user", "") ?: ""
        set(v) { prefs.edit().putString("github_user", v).apply() }
    /** The active repo as "owner/name", or "" if none picked yet ("repo use owner/name"). */
    var githubRepo: String
        get() = prefs.getString("github_repo", "") ?: ""
        set(v) { prefs.edit().putString("github_repo", v.trim()).apply() }
    var githubBranch: String
        get() = prefs.getString("github_branch", "main") ?: "main"
        set(v) { prefs.edit().putString("github_branch", v.trim().ifBlank { "main" }).apply() }

    /** The repo two people drop into "msg" to use it as a shared mailbox - separate from the build repo above. */
    var msgRepo: String
        get() = prefs.getString("msg_repo", "") ?: ""
        set(v) { prefs.edit().putString("msg_repo", v.trim()).apply() }
    /** Shown as the sender name on your own bubbles, and used to tell "me" from "them". */
    var msgUserName: String
        get() = prefs.getString("msg_user_name", "") ?: ""
        set(v) { prefs.edit().putString("msg_user_name", v.trim()).apply() }

    /** Background alerts for new msg messages (see MsgWatchService.kt). Off until the user turns it on in msg. */
    var msgNotify: Boolean
        get() = prefs.getBoolean("msg_notify", false)
        set(v) { prefs.edit().putBoolean("msg_notify", v).apply() }
    /** Read incoming msg messages aloud - who they're from and what they said (see MsgWatcher). Off until turned on in msg. */
    var msgSpeak: Boolean
        get() = prefs.getBoolean("msg_speak", false)
        set(v) { prefs.edit().putBoolean("msg_speak", v).apply() }
    /** "instant" = checks every few seconds (keeps the phone awake, uses more battery); "saver" = every ~5 minutes. */
    var msgNotifyMode: String
        get() = prefs.getString("msg_notify_mode", "instant") ?: "instant"
        set(v) { prefs.edit().putString("msg_notify_mode", if (v == "saver") "saver" else "instant").apply() }

    /** Offline fallback voice only (the online Gemini voice ignores this). Lower = deeper. */
    var pitch: Float
        get() = prefs.getFloat("pitch", 1.15f)
        set(v) { prefs.edit().putFloat("pitch", v).apply() }

    /** Let the user cut Novochron off by talking while it is speaking. */
    var interrupt: Boolean
        get() = prefs.getBoolean("interrupt", true)
        set(v) { prefs.edit().putBoolean("interrupt", v).apply() }

    /**
     * Locked to "auto" at the user's request: Novochron always picks the model itself — the fast one
     * normally, the smarter one when it detects a "build me a ___" request — rather than a fixed choice.
     * See Models.pick() for the actual switching logic.
     */
    val modelMode: String get() = "auto"

    var batteryAsked: Boolean
        get() = prefs.getBoolean("battery_asked", false)
        set(v) { prefs.edit().putBoolean("battery_asked", v).apply() }

    /**
     * Manual online/offline toggle. When true, Novochron never touches the network even if it's
     * available: no Gemini chat, no online voice, no streaming — just phone commands, memory, offline
     * maps and the offline brain (if installed). When false (the default), Novochron decides for itself
     * based on whether the internet is actually reachable right now.
     */
    var forceOffline: Boolean
        get() = prefs.getBoolean("force_offline", false)
        set(v) { prefs.edit().putBoolean("force_offline", v).apply() }

    /** Last-used [map] layer: "dark" (default), "mono", "sat" or "roads". */
    var mapLayer: String
        get() = prefs.getString("map_layer", "dark") ?: "dark"
        set(v) { prefs.edit().putString("map_layer", v).apply() }

    /** Whether the [map] is tilted into 3D (extruded buildings). Independent of the layer above. */
    var map3d: Boolean
        get() = prefs.getBoolean("map_3d", false)
        set(v) { prefs.edit().putBoolean("map_3d", v).apply() }

    // ---- [web] browser (see Browser.kt / BrowserScreen.kt) ----

    /** Search engine used for anything typed in [web] that isn't an address: "ddg" (default), "google", "brave", "bing". */
    var webEngine: String
        get() = prefs.getString("web_engine", "ddg") ?: "ddg"
        set(v) { prefs.edit().putString("web_engine", v).apply() }

    /** Darken web pages so they sit properly on the black theme. */
    var webDark: Boolean
        get() = prefs.getBoolean("web_dark", true)
        set(v) { prefs.edit().putBoolean("web_dark", v).apply() }

    /** Ask sites for their desktop layout instead of the mobile one. */
    var webDesktop: Boolean
        get() = prefs.getBoolean("web_desktop", false)
        set(v) { prefs.edit().putBoolean("web_desktop", v).apply() }

    /** Private mode: no history is kept, and cookies / cache are wiped when [web] closes. */
    var webPrivate: Boolean
        get() = prefs.getBoolean("web_private", false)
        set(v) { prefs.edit().putBoolean("web_private", v).apply() }

    /** Bookmarks. A few starter ones until the first time the list is saved. */
    fun webBookmarks(): List<WebEntry> =
        if (prefs.contains("web_bookmarks")) Web.decode(prefs.getString("web_bookmarks", null)) else Web.defaultBookmarks

    fun saveWebBookmarks(list: List<WebEntry>) {
        prefs.edit().putString("web_bookmarks", Web.encode(list.take(60))).apply()
    }

    /** Recently visited pages, newest first (never recorded in private mode). */
    fun webHistory(): List<WebEntry> = Web.decode(prefs.getString("web_history", null))

    fun saveWebHistory(list: List<WebEntry>) {
        prefs.edit().putString("web_history", Web.encode(list.take(60))).apply()
    }

    fun clearWebHistory() {
        prefs.edit().remove("web_history").apply()
    }

    /** The open [web] tabs (address, title, group, start-page flag) from the last time the browser
     *  was closed, as JSON (see [Web.encodeTabs]/[Web.decodeTabs]); empty when there's nothing to
     *  restore, e.g. after closing every tab or leaving [web] in private mode. */
    var webTabsJson: String
        get() = prefs.getString("web_tabs", "") ?: ""
        set(v) { prefs.edit().putString("web_tabs", v).apply() }

    /** Index, within [webTabsJson], of the tab that was active when it was last saved. */
    var webActiveTab: Long
        get() = prefs.getLong("web_active_tab", 0L)
        set(v) { prefs.edit().putLong("web_active_tab", v).apply() }

    /** Show the animated line-art character behind the conversation. */
    var mascotOn: Boolean
        get() = prefs.getBoolean("mascot_on", true)
        set(v) { prefs.edit().putBoolean("mascot_on", v).apply() }

    /** Wake-word gating: while on, Novochron ignores speech until it hears [wakeWordPhrase]. */
    var wakeWordEnabled: Boolean
        get() = prefs.getBoolean("wake_word_enabled", false)
        set(v) { prefs.edit().putBoolean("wake_word_enabled", v).apply() }

    var wakeWordPhrase: String
        get() = prefs.getString("wake_word_phrase", "novochron") ?: "novochron"
        set(v) { prefs.edit().putString("wake_word_phrase", v.trim().ifBlank { "novochron" }).apply() }

    /**
     * When on, a local Silero VAD model listens alongside the speech recognizer and cuts a turn
     * short the instant it detects real silence, instead of waiting on the recognizer's own fixed
     * silence timer. Off by default: running two mic captures at once is fine on most phones but
     * silently starves the recognizer of audio on some (there's no way to detect this in advance -
     * see VadEndpointer's class doc), so this stays opt-in rather than risking a silent "stuck
     * listening" for everyone. If the model or the extra mic tap can't start on this device (see
     * VadEndpointer.start), Novochron just keeps using the old fixed timer for that session, same
     * as if this were off.
     */
    var instantResponseEnabled: Boolean
        get() = prefs.getBoolean("instant_response_enabled", false)
        set(v) { prefs.edit().putBoolean("instant_response_enabled", v).apply() }

    /** A correction [CorrectionTracker] is waiting on a yes/no answer for ("should I always do it that way?"). */
    var pendingPreferenceNote: String
        get() = prefs.getString("pending_pref_note", "") ?: ""
        set(v) { prefs.edit().putString("pending_pref_note", v).apply() }

    /** Show the developer/power-user debug overlay (VAD speech probability, API latency, model load state). */
    var debugOverlayOn: Boolean
        get() = prefs.getBoolean("debug_overlay_on", false)
        set(v) { prefs.edit().putBoolean("debug_overlay_on", v).apply() }

    companion object {
        @Volatile private var inst: Store? = null
        fun get(ctx: Context): Store =
            inst ?: synchronized(this) { inst ?: Store(ctx.applicationContext).also { inst = it } }

        /**
         * SQLiteOpenHelper treats a name starting with "/" as an absolute path, so once Novochron's own
         * folder is accessible we point the database straight at it; otherwise "novochron.db" resolves to
         * the normal private database directory, same as before.
         */
        private fun dbName(): String =
            if (AtlasStorage.hasAccess() && AtlasStorage.ensureDirs()) AtlasStorage.dbFile().absolutePath else "novochron.db"
    }
}
