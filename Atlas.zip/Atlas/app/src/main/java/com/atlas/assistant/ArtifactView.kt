package com.atlas.assistant

import android.annotation.SuppressLint
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView

/**
 * Builds the sandbox an artifact runs in. JavaScript is on, but the page cannot reach the network,
 * the phone's files, or anything else in the app, and it cannot navigate away.
 */
@SuppressLint("SetJavaScriptEnabled")
fun makeWebView(ctx: Context, a: Artifact): WebView {
    val web = WebView(ctx)
    web.setBackgroundColor(android.graphics.Color.BLACK)
    val s = web.settings
    s.javaScriptEnabled = true
    s.domStorageEnabled = true        // lets games save scores (private to this one artifact)
    s.allowFileAccess = false
    s.allowContentAccess = false
    s.blockNetworkLoads = true
    web.webViewClient = object : WebViewClient() {
        override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean = true
    }
    web.webChromeClient = WebChromeClient() // lets alert() and confirm() show up
    web.loadDataWithBaseURL("https://a${a.id}.novochron.local/", a.html, "text/html", "UTF-8", null)
    return web
}

@Composable
fun ArtifactScreen(artifact: Artifact, onClose: () -> Unit) {
    val ctx = LocalContext.current
    var reload by remember { mutableIntStateOf(0) }
    val holder = remember { arrayOfNulls<WebView>(1) }

    BackHandler(onBack = onClose)
    DisposableEffect(Unit) {
        onDispose {
            // stop the page (timers, sounds) as soon as the screen closes
            holder[0]?.let { it.onPause(); it.loadUrl("about:blank") }
            holder[0] = null
        }
    }

    Column(Modifier.fillMaxSize().background(Color.Black)) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            TextButton(onClick = onClose) { Text("Close", color = Ink) }
            Text(
                artifact.title,
                color = Color.White,
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.weight(1f)
            )
            TextButton(onClick = { reload++ }) { Text("Restart", color = Dim) }
            TextButton(onClick = {
                val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText(artifact.title, artifact.html))
                Toast.makeText(ctx, "Code copied", Toast.LENGTH_SHORT).show()
            }) { Text("Copy code", color = Dim) }
        }
        key(reload) {
            AndroidView(
                modifier = Modifier.weight(1f).fillMaxWidth(),
                factory = { c -> makeWebView(c, artifact).also { holder[0] = it } }
            )
        }
    }
}

@Composable
fun LibraryDialog(engine: Engine, onOpen: (Long) -> Unit, onDismiss: () -> Unit) {
    var list by remember { mutableStateOf(engine.store.artifacts()) }
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Color(0xFF0D0D0D),
        title = { Text("Library", color = Ink) },
        text = {
            if (list.isEmpty()) {
                Text(
                    "Nothing here yet. Try saying “make a memory game” or “build a tip calculator”.",
                    color = Dim,
                    fontSize = 14.sp
                )
            } else {
                LazyColumn(Modifier.heightIn(max = 380.dp)) {
                    items(list, key = { it.id }) { a ->
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                a.title,
                                color = Ink,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                modifier = Modifier
                                    .weight(1f)
                                    .clickable { onOpen(a.id); onDismiss() }
                                    .padding(vertical = 12.dp)
                            )
                            TextButton(onClick = {
                                engine.store.deleteArtifact(a.id)
                                list = engine.store.artifacts()
                                engine.refresh()
                            }) { Text("Delete", color = Dim) }
                        }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Close", color = Accent) } }
    )
}
