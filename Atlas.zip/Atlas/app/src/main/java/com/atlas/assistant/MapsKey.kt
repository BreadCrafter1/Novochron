package com.atlas.assistant

import android.content.Context
import android.content.pm.PackageManager

/**
 * The Google Maps key is baked into the manifest at build time (see app/build.gradle.kts and
 * README > "Map setup"), so the app can't take it from Settings. What it CAN do is check whether a key
 * made it into this build, and tell you how to add one if not, rather than showing a blank grey map.
 */
object MapsKey {
    private const val META = "com.google.android.geo.API_KEY"

    @Suppress("DEPRECATION")
    fun isConfigured(ctx: Context): Boolean = try {
        val info = ctx.packageManager.getApplicationInfo(ctx.packageName, PackageManager.GET_META_DATA)
        !info.metaData?.getString(META).isNullOrBlank()
    } catch (e: Exception) {
        false
    }

    /** Short plain-text steps, shown on the map screen when no key is in the build. */
    const val SETUP_STEPS =
        "1. Open gradle.properties in the project's root folder.\n" +
            "2. Put your key after MAPS_API_KEY= (no quotes or spaces).\n" +
            "3. Rebuild and reinstall the app.\n\n" +
            "No key yet? In console.cloud.google.com, enable “Maps SDK for Android”, then " +
            "APIs & Services > Credentials > Create API key. Details in README > Map setup."
}
