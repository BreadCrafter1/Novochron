package com.atlas.assistant

import java.util.Locale

/**
 * A genuinely offline "solve mathematics" path: no AI, no learned notes, just arithmetic. This runs
 * before anything else in [Brain.offlineReply], so basic maths keeps working even with no local model
 * installed and no knowledge ever learned. "learn mathematics" (see [Brain.learnTopic]) adds reference
 * notes on top of this for things this evaluator can't do (word problems, concepts, proofs) — those
 * still need either the online brain or a local LLM to reason over the notes.
 *
 * Deliberately conservative about *when* it fires: only on an explicit trigger word ("what's",
 * "calculate", "solve"...), a "percent of" phrase, an "<expr> = <number>" equation, or text that is
 * *nothing but* a bare arithmetic expression. Ordinary sentences that merely contain a number and a
 * hyphen (a time range, a house number) are left alone.
 */
object MathEval {

    private val TRIGGER = Regex("\\b(what'?s|what is|whats|calculate|compute|solve|evaluate)\\b", RegexOption.IGNORE_CASE)
    private val PERCENT_OF = Regex(
        "([-+]?\\d+(?:\\.\\d+)?)\\s*%?\\s*(?:percent|per ?cent)\\s*of\\s*([-+]?\\d+(?:\\.\\d+)?)",
        RegexOption.IGNORE_CASE
    )
    private val PERCENT_SIGN_OF = Regex("([-+]?\\d+(?:\\.\\d+)?)\\s*%\\s*of\\s*([-+]?\\d+(?:\\.\\d+)?)", RegexOption.IGNORE_CASE)
    private val HAS_X = Regex("\\bx\\b", RegexOption.IGNORE_CASE)
    // e.g. "2x + 3 = 7", "-x = 4", "x=9"
    private val LINEAR_EQ = Regex("([-+]?\\d*\\.?\\d*)x([-+]\\d+\\.?\\d*)?=([-+]?\\d+\\.?\\d*)", RegexOption.IGNORE_CASE)

    private val WORD_OPS = listOf(
        "multiplied by" to "*", "divided by" to "/", "to the power of" to "^",
        "plus" to "+", "minus" to "-", "times" to "*", "multiply" to "*", "divide" to "/", "over" to "/"
    )

    /** Returns a spoken-friendly answer, or null if this doesn't look like something to compute. */
    fun trySolve(raw: String): String? {
        val text = raw.trim()
        if (text.isEmpty()) return null

        percentOf(text)?.let { return it }

        if (HAS_X.containsMatchIn(text) && text.contains("=")) {
            linear(text)?.let { return it }
        }

        val hasTrigger = TRIGGER.containsMatchIn(text)
        val nonMathChars = text.replace(Regex("[0-9.+\\-*/^() %]"), "")
        val looksLikeBareExpression = nonMathChars.isBlank() && Regex("[0-9]").containsMatchIn(text)
        if (!hasTrigger && !looksLikeBareExpression) return null

        val expr = toExpression(text) ?: return null
        if (!expr.any { it.isDigit() }) return null
        val value = try { Parser(expr).parse() } catch (e: Exception) { null } ?: return null
        return format(value)
    }

    private fun percentOf(text: String): String? {
        val m = PERCENT_OF.find(text) ?: PERCENT_SIGN_OF.find(text) ?: return null
        val pct = m.groupValues[1].toDoubleOrNull() ?: return null
        val base = m.groupValues[2].toDoubleOrNull() ?: return null
        return format(pct / 100.0 * base)
    }

    private fun linear(text: String): String? {
        val m = LINEAR_EQ.find(text.replace(" ", "").lowercase(Locale.US)) ?: return null
        val aStr = m.groupValues[1]
        val a = when {
            aStr.isBlank() -> 1.0
            aStr == "-" -> -1.0
            aStr == "+" -> 1.0
            else -> aStr.toDoubleOrNull() ?: return null
        }
        if (a == 0.0) return null
        val bStr = m.groupValues[2]
        val b = if (bStr.isBlank()) 0.0 else bStr.toDoubleOrNull() ?: return null
        val c = m.groupValues[3].toDoubleOrNull() ?: return null
        return "x = ${format((c - b) / a)}"
    }

    private fun toExpression(text: String): String? {
        var s = text.lowercase(Locale.US)
        s = TRIGGER.replace(s, " ")
        WORD_OPS.sortedByDescending { it.first.length }.forEach { (word, sym) -> s = s.replace(word, " $sym ") }
        s = s.replace("squared", "^2").replace("cubed", "^3")
        s = s.replace(Regex("[^-0-9.+*/^() ]"), " ")
        s = s.trim()
        return s.ifBlank { null }
    }

    private fun format(v: Double): String {
        val rounded = Math.round(v * 10000.0) / 10000.0
        return if (rounded == rounded.toLong().toDouble()) rounded.toLong().toString() else rounded.toString()
    }

    /** Minimal recursive-descent parser: + - * / ^, unary minus, parentheses. */
    private class Parser(private val s: String) {
        private var i = 0

        fun parse(): Double {
            val v = expr()
            skip()
            if (i != s.length) throw IllegalArgumentException("trailing input")
            return v
        }

        private fun skip() { while (i < s.length && s[i] == ' ') i++ }

        private fun expr(): Double {
            var v = term()
            while (true) {
                skip()
                if (i < s.length && (s[i] == '+' || s[i] == '-')) {
                    val op = s[i]; i++
                    val t = term()
                    v = if (op == '+') v + t else v - t
                } else break
            }
            return v
        }

        private fun term(): Double {
            var v = factor()
            while (true) {
                skip()
                if (i < s.length && (s[i] == '*' || s[i] == '/')) {
                    val op = s[i]; i++
                    val f = factor()
                    v = if (op == '*') v * f else v / f
                } else break
            }
            return v
        }

        private fun factor(): Double {
            val base = unary()
            skip()
            if (i < s.length && s[i] == '^') {
                i++
                val exp = factor()
                return Math.pow(base, exp)
            }
            return base
        }

        private fun unary(): Double {
            skip()
            if (i < s.length && s[i] == '-') { i++; return -unary() }
            if (i < s.length && s[i] == '+') { i++; return unary() }
            return primary()
        }

        private fun primary(): Double {
            skip()
            if (i < s.length && s[i] == '(') {
                i++
                val v = expr()
                skip()
                if (i < s.length && s[i] == ')') i++ else throw IllegalArgumentException("missing )")
                return v
            }
            val start = i
            while (i < s.length && (s[i].isDigit() || s[i] == '.')) i++
            if (start == i) throw IllegalArgumentException("expected a number at $i")
            return s.substring(start, i).toDouble()
        }
    }
}
