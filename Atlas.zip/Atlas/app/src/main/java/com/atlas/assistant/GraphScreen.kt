package com.atlas.assistant

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.weight
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** One plotted formula: its raw text, an assigned colour, whether it's shown, and its last error (if any). */
private class PlotLine(text: String, val color: Color) {
    var text by mutableStateOf(text)
    var visible by mutableStateOf(true)
    var error: String? = null
}

private val PlotPalette = listOf(
    Color(0xFF3DFF5C), // Accent green
    Color(0xFF5CC8FF), // cyan
    Color(0xFFFF9A3D), // orange
    Color(0xFFFF5CD8), // pink
    Color(0xFFFFE85C), // yellow
    Color(0xFFB35CFF)  // purple
)

/**
 * "[graph]": a Desmos-style calculator. Type one or more `y = ...` formulas (functions of `x`); each
 * is compiled by [GraphMath] and sampled per pixel column across whatever range is currently in view.
 * Drag to pan, pinch to zoom (or use two fingers) — the same as any graphing-calculator app. Fully
 * offline: no network call, just the small expression compiler in GraphMath.kt.
 */
@Composable
fun GraphScreen(onClose: () -> Unit) {
    val lines = remember {
        mutableStateListOf(
            PlotLine("y = sin(x)", PlotPalette[0])
        )
    }
    // View transform: (centerX, centerY) is the world point at the middle of the canvas;
    // unitsPerPx controls zoom (world units per screen pixel — smaller = more zoomed in).
    var centerX by remember { mutableFloatStateOf(0f) }
    var centerY by remember { mutableFloatStateOf(0f) }
    var unitsPerPx by remember { mutableFloatStateOf(0.02f) }

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        Column(Modifier.fillMaxSize().padding(16.dp)) {
            Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                TermTextKey("[back]", onClick = onClose)
                Spacer(Modifier.weight(1f))
                Text("graph", color = Accent, fontFamily = TermFont, fontSize = 18.sp)
                Spacer(Modifier.weight(1f))
                TermTextKey("[reset]", onClick = {
                    centerX = 0f; centerY = 0f; unitsPerPx = 0.02f
                })
            }
            Spacer(Modifier.height(10.dp))

            Box(
                Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .border(1.dp, Line)
                    .clip(androidx.compose.foundation.shape.RectangleShape)
                    .pointerInput(Unit) {
                        detectTransformGestures { _, pan, zoom, _ ->
                            if (zoom != 1f) {
                                unitsPerPx = (unitsPerPx / zoom).coerceIn(0.0002f, 500f)
                            }
                            centerX -= pan.x * unitsPerPx
                            centerY += pan.y * unitsPerPx // screen y grows downward; world y grows upward
                        }
                    }
            ) {
                GraphCanvas(lines, centerX, centerY, unitsPerPx)
            }

            Spacer(Modifier.height(10.dp))
            Text(
                "Drag to pan · pinch to zoom · functions of x (sin, cos, sqrt, abs, ln, exp, pi, e, ^)",
                color = Dim, fontFamily = TermFont, fontSize = 11.sp
            )
            Spacer(Modifier.height(6.dp))

            LazyColumn(Modifier.fillMaxWidth().height(if (lines.size > 3) 190.dp else (lines.size * 62).dp)) {
                items(lines.size) { idx ->
                    val line = lines[idx]
                    Row(
                        Modifier.fillMaxWidth().padding(vertical = 4.dp),
                        verticalAlignment = androidx.compose.ui.Alignment.CenterVertically
                    ) {
                        Box(
                            Modifier.size(14.dp).clip(CircleShape).background(line.color)
                                .clickable { line.visible = !line.visible }
                                .then(if (!line.visible) Modifier.border(1.dp, Dim, CircleShape) else Modifier)
                        )
                        Spacer(Modifier.width(8.dp))
                        OutlinedTextField(
                            value = line.text,
                            onValueChange = { line.text = it },
                            singleLine = true,
                            textStyle = TextStyle(fontFamily = TermFont, fontSize = 14.sp, color = Ink),
                            colors = fieldColors(),
                            modifier = Modifier.weight(1f)
                        )
                        Spacer(Modifier.width(8.dp))
                        TermTextKey("[x]", onClick = {
                            if (lines.size > 1) lines.removeAt(idx)
                        })
                    }
                    line.error?.let {
                        Text("  $it", color = Warn, fontFamily = TermFont, fontSize = 11.sp)
                    }
                }
                item {
                    TermTextKey(
                        "[+ add formula]",
                        onClick = {
                            val color = PlotPalette[lines.size % PlotPalette.size]
                            lines.add(PlotLine("", color))
                        }
                    )
                }
            }
        }
    }
}

@Composable
private fun GraphCanvas(lines: List<PlotLine>, centerX: Float, centerY: Float, unitsPerPx: Float) {
    Canvas(Modifier.fillMaxSize()) {
        val w = size.width
        val h = size.height
        val upp = unitsPerPx.toDouble()

        fun worldToScreenX(wx: Double) = ((wx - centerX) / upp + w / 2).toFloat()
        fun worldToScreenY(wy: Double) = (h / 2 - (wy - centerY) / upp).toFloat()

        // --- grid ---
        val step = GraphMath.niceStep(upp * 80.0) // aim for ~80px between gridlines
        val minX = centerX - w / 2 * upp
        val maxX = centerX + w / 2 * upp
        val minY = centerY - h / 2 * upp
        val maxY = centerY + h / 2 * upp

        var gx = Math.floor(minX / step) * step
        while (gx <= maxX) {
            val sx = worldToScreenX(gx)
            val bold = Math.abs(gx) < step / 1000.0
            drawLine(
                color = if (bold) Dim else Line,
                start = Offset(sx, 0f), end = Offset(sx, h),
                strokeWidth = if (bold) 2f else 1f
            )
            gx += step
        }
        var gy = Math.floor(minY / step) * step
        while (gy <= maxY) {
            val sy = worldToScreenY(gy)
            val bold = Math.abs(gy) < step / 1000.0
            drawLine(
                color = if (bold) Dim else Line,
                start = Offset(0f, sy), end = Offset(w, sy),
                strokeWidth = if (bold) 2f else 1f
            )
            gy += step
        }

        // --- curves: sample once per pixel column, skip huge jumps (asymptotes) ---
        lines.forEach { line ->
            if (!line.visible || line.text.isBlank()) { line.error = null; return@forEach }
            val f = try {
                GraphMath.compile(line.text)
            } catch (e: Exception) {
                line.error = e.message ?: "can't parse this formula"
                return@forEach
            }
            line.error = null

            var prev: Offset? = null
            var px = 0
            val maxJumpPx = h * 4 // if the curve leaps more than this between adjacent columns, it's a break/asymptote
            while (px <= w.toInt()) {
                val wx = centerX + (px - w / 2) * upp
                val y = try { f(wx) } catch (e: Exception) { Double.NaN }
                if (y.isNaN() || y.isInfinite()) {
                    prev = null
                } else {
                    val cur = Offset(px.toFloat(), worldToScreenY(y))
                    val p = prev
                    if (p != null && Math.abs(cur.y - p.y) < maxJumpPx) {
                        drawLine(color = line.color, start = p, end = cur, strokeWidth = 3f, cap = StrokeCap.Round)
                    }
                    prev = cur
                }
                px += 2 // every other pixel is plenty smooth and much cheaper than every pixel
            }
        }
    }
}
