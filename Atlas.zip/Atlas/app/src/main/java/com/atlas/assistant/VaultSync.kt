package com.atlas.assistant

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject

/**
 * Multi-device sync of memory and places via the same GitHub vault repo (see VaultScreen.kt / GitHub.kt) —
 * so a second phone signed into the same repo can pick up the first phone's learned notes and saved
 * places. Deliberately simple: [push] snapshots everything local into two JSON files under Vault/Sync/,
 * [pull] reads those files back and adds anything not already present locally (matched by topic, or by
 * place label) — it never deletes or overwrites a local entry. A real two-way sync with conflict
 * resolution is out of scope for what's meant to be a "keep two phones roughly caught up" feature.
 */
object VaultSync {
    private const val KNOWLEDGE_PATH = "Vault/Sync/knowledge.json"
    private const val PLACES_PATH = "Vault/Sync/places.json"

    private fun knowledgeToJson(ctx: Context): String {
        val arr = JSONArray()
        KnowledgeStore.all(ctx).forEach { k -> arr.put(JSONObject().put("topic", k.topic).put("content", k.content)) }
        return arr.toString()
    }

    private fun placesToJson(ctx: Context): String {
        val arr = JSONArray()
        Maps.get(ctx).places().forEach { p -> arr.put(JSONObject().put("label", p.label).put("lat", p.lat).put("lon", p.lon)) }
        return arr.toString()
    }

    /** Uploads this phone's learned notes and saved places to the vault repo, overwriting the previous snapshot. */
    suspend fun push(ctx: Context, github: GitHub): String = withContext(Dispatchers.IO) {
        github.commitBytes(KNOWLEDGE_PATH, knowledgeToJson(ctx).toByteArray(Charsets.UTF_8), "Sync memory via Atlas")
        github.commitBytes(PLACES_PATH, placesToJson(ctx).toByteArray(Charsets.UTF_8), "Sync places via Atlas")
        "Pushed ${KnowledgeStore.all(ctx).size} note(s) and ${Maps.get(ctx).places().size} place(s) to the vault."
    }

    /** Downloads the vault's snapshot (if any) and merges in whatever this phone doesn't already have. */
    suspend fun pull(ctx: Context, github: GitHub): String = withContext(Dispatchers.IO) {
        var addedNotes = 0
        var addedPlaces = 0

        val knowledgeBytes = try { github.readFileBytes(KNOWLEDGE_PATH) } catch (e: Exception) { null }
        if (knowledgeBytes != null) {
            val arr = try { JSONArray(String(knowledgeBytes, Charsets.UTF_8)) } catch (e: Exception) { JSONArray() }
            val existingTopics = KnowledgeStore.all(ctx).map { it.topic.lowercase() }.toSet()
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                val topic = o.optString("topic")
                if (topic.isNotBlank() && topic.lowercase() !in existingTopics) {
                    KnowledgeStore.save(ctx, topic, o.optString("content"))
                    addedNotes++
                }
            }
        }

        val placesBytes = try { github.readFileBytes(PLACES_PATH) } catch (e: Exception) { null }
        if (placesBytes != null) {
            val arr = try { JSONArray(String(placesBytes, Charsets.UTF_8)) } catch (e: Exception) { JSONArray() }
            val maps = Maps.get(ctx)
            val existingLabels = maps.places().map { it.label.lowercase() }.toSet()
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                val label = o.optString("label")
                if (label.isNotBlank() && label.lowercase() !in existingLabels) {
                    maps.savePlace(label, o.optDouble("lat"), o.optDouble("lon"))
                    addedPlaces++
                }
            }
        }

        when {
            knowledgeBytes == null && placesBytes == null -> "Nothing to pull yet — push from another device first."
            else -> "Pulled in $addedNotes new note(s) and $addedPlaces new place(s)."
        }
    }
}
