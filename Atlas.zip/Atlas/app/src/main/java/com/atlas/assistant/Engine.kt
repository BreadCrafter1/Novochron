package com.atlas.assistant

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import java.io.File
import java.io.IOException

/**
 * Single shared brain + voice, used by the typed chat box and by the always-on listener service.
 *
 * Live conversation model: the microphone never stops. While Novochron is thinking or speaking, everything
 * the microphone hears goes through [onHeard], which drops Novochron's own voice (echo) and lets a real
 * interruption cut the reply off and start a new turn.
 */
class Engine private constructor(private val app: Context) {

    val store: Store = Store.get(app)
    val commands = Commands(app, store)
    /** Shared with the [term] screen (TerminalScreen) so a typed/spoken command like "build the app"
     *  shows up in the terminal transcript too, and both share the same GitHub login state. */
    val terminal = Terminal(app, store)
    private val brain = Brain(app, store, commands)
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)

    private var turnJob: Job? = null
    private var turnId = 0
    private var stopAfterReply = false
    private var exitAfterReply = false

    // what Novochron is saying now (or said last), used to recognise its own echo
    private val spoken = StringBuilder()
    private var replyOpen = false       // a reply is in progress and not yet saved to the chat
    private var speaking = false        // from the first spoken sentence until speech ends or is cut off
        set(v) { field = v; AssistantState.speaking.value = v }
    private var echoUntil = 0L          // short window after speech ends when trailing echo can still arrive
    private var interrupted = false
    private var interruptedAt = 0L
    private var lockUntil = 0L
    private val riskyAccepts = ArrayList<Long>()

    private val speaker = Speaker(app, store) { onSpeechDone() }

    // ---- vision: photos, camera and the screencast's latest frame ----
    /** Most recent screen frame while screencast is on, kept only in memory (deleted when replaced/stopped). */
    @Volatile private var latestScreenFrame: String? = null

    // ---- wake word ----
    private var wakeEngaged = false
    private var wakeTimeoutJob: Job? = null
    /** Set by AssistantService: called whenever Novochron should go back to gated/idle wake listening
     *  (after a wake turn finishes, or the "did you say anything" timeout fires) so the service can
     *  hand the microphone back to the low-power engine (see PorcupineWake) instead of the full
     *  recognizer, if one is available. */
    var onDedicatedWakeRearm: (() -> Unit)? = null

    init {
        commands.onStopListening = { stopAfterReply = true }
        commands.onSetWakeWord = { setWakeWordEnabled(it) }
        commands.onOpenArtifact = { showArtifact(it) }
        commands.onOpenLibrary = { AssistantState.showLibrary.value = true }
        commands.onOpenStats = { AssistantState.showStats.value = true }
        commands.onExitApp = { exitAfterReply = true }
        AssistantState.forceOffline.value = store.forceOffline
        AssistantState.wakeWordOn.value = store.wakeWordEnabled
        AssistantState.mascotOn.value = store.mascotOn
        refresh()
    }

    fun refresh() {
        AssistantState.messages.value = store.recentMessages(80)
    }

    /** Flips the manual online/offline toggle and persists it. */
    fun setForceOffline(v: Boolean) {
        store.forceOffline = v
        AssistantState.forceOffline.value = v
    }

    /** Shows or hides the character behind the conversation and persists it. */
    fun setMascotOn(v: Boolean) {
        store.mascotOn = v
        AssistantState.mascotOn.value = v
    }

    /** Flips wake-word gating and persists it; takes effect on the very next thing Novochron hears. */
    fun setWakeWordEnabled(v: Boolean) {
        store.wakeWordEnabled = v
        AssistantState.wakeWordOn.value = v
        wakeEngaged = false
        wakeTimeoutJob?.cancel()
        if (AssistantState.voiceOn.value) setIdleStatus()
        onDedicatedWakeRearm?.invoke()
    }

    /**
     * Called by AssistantService's low-power wake engine (PorcupineWake) when it hears the phrase.
     * Unlike the fallback path in [onHeard], the dedicated engine only signals detection — it has no
     * accompanying text — so this just arms the same "Yes?" window the classic path uses.
     */
    fun onDedicatedWakeDetected() {
        if (!store.wakeWordEnabled) return
        engageWake("")
    }

    /**
     * Fully closes Novochron: stops voice/listening and ends the whole app process. Used by the exit
     * button on the main screen and the "turn off, computer" voice command.
     */
    fun requestExit(announce: Boolean = true) {
        if (announce) say("Shutting down.")
        if (AssistantState.voiceOn.value) {
            app.startService(Intent(app, AssistantService::class.java).setAction(AssistantService.ACTION_STOP))
        }
        scope.launch {
            delay(if (announce) 1200L else 300L)
            AssistantState.exitRequested.value = true
            delay(150)
            try { android.os.Process.killProcess(android.os.Process.myPid()) } catch (e: Exception) { }
        }
    }

    fun clearChat() {
        store.clearMessages()
        refresh()
    }

    // ------------------------------------------------------------------ input

    /**
     * Runs a full turn for typed text or a finished voice utterance. While screencast is on, whatever
     * the user says or types goes along with the freshest screen frame, so "what does this button do"
     * works while Novochron watches the screen with you.
     */
    fun submit(text: String) {
        val clean = text.trim()
        if (clean.isEmpty()) return
        cancelTurn()
        interrupted = false
        AssistantState.heard.value = ""
        wakeTimeoutJob?.cancel() // a real turn is starting; the 7s "did they say anything" timeout no longer applies
        val id = ++turnId
        val framePath = if (AssistantState.screencastOn.value) latestScreenFrame else null
        turnJob = scope.launch {
            if (framePath != null) runImageTurn(id, framePath, clean) else runTurn(id, clean)
        }
    }

    /** A photo taken with the camera, picked from the gallery, or a single "scan this" camera frame. */
    fun submitPhoto(bitmap: Bitmap, question: String) {
        cancelTurn()
        interrupted = false
        AssistantState.heard.value = ""
        val id = ++turnId
        turnJob = scope.launch {
            val path = withContext(Dispatchers.IO) { Vision.save(app, bitmap) }
            runImageTurn(id, path, question)
        }
    }

    /** Called by the screencast service with each freshly captured screen frame. Kept in memory only. */
    fun onScreenFrame(path: String) {
        val old = latestScreenFrame
        latestScreenFrame = path
        if (old != null && old != path) File(old).delete()
    }

    /** Stops attaching screen frames to future turns and forgets the last one. */
    fun stopScreencast() {
        latestScreenFrame?.let { File(it).delete() }
        latestScreenFrame = null
        AssistantState.screencastOn.value = false
    }

    /** Everything the microphone hears comes here, including while Novochron is talking. */
    fun onHeard(text: String, final: Boolean) {
        val clean = text.trim()
        if (clean.isEmpty()) return

        // Wake-word gating: while armed (and not already engaged by a recent wake word), ignore
        // everything except the wake phrase itself, only checked once a phrase is finished — partial
        // results are too jittery to trust for this. Once heard, whatever follows in the same breath
        // (or the very next thing said) goes through as a normal turn.
        if (store.wakeWordEnabled && !wakeEngaged && !speaking) {
            if (!final) return
            // "deactivate mode 2" works straight away, without having to say the wake phrase first
            val plain = clean.trim().trimEnd('.', '!', '?', ',').lowercase(java.util.Locale.US)
            if (Commands.WAKE_OFF.matches(plain)) {
                submit(clean)
                return
            }
            val after = WakeWord.strip(clean, store.wakeWordPhrase) ?: return
            engageWake(after)
            return
        }

        val now = System.currentTimeMillis()
        val wasInterrupted = interrupted && now - interruptedAt < 10_000
        val relevant = speaking || wasInterrupted || now < echoUntil

        if (!relevant) {
            if (final) submit(clean) else AssistantState.heard.value = clean
            return
        }

        // Novochron is talking (or just stopped): work out whether this is the user or just Novochron's echo
        if (!store.interrupt || (now < lockUntil && !wasInterrupted)) {
            if (final) AssistantState.heard.value = ""
            return
        }
        val said = spoken.toString()
        val real = wasInterrupted || EchoFilter.isInterruption(EchoFilter.novelWords(clean, said))
        if (!real) {
            if (final) AssistantState.heard.value = ""
            return
        }

        if (!final) {
            if (!wasInterrupted) {
                interrupted = true
                interruptedAt = now
                cutOff()
            }
            AssistantState.heard.value = clean
            return
        }

        interrupted = false
        echoUntil = 0L
        val userText = EchoFilter.stripEcho(clean, said)
        if (userText.isBlank()) { cutOff(); return }
        if (EchoFilter.isStopOnly(userText)) { cutOff(); AssistantState.heard.value = ""; return }
        noteRiskyAccept(now)
        submit(userText)
    }

    /** Speak a line without touching chat history (used by "Test voice"). */
    fun say(text: String) {
        cancelTurn()
        spoken.setLength(0)
        beginSpeech()
        appendSpoken(text)
        speaker.enqueue(text)
        speaker.end()
    }

    /** Stop everything Novochron is saying or doing right now. */
    fun stopSpeaking() {
        cancelTurn()
    }

    // ------------------------------------------------------------------ turns

    private suspend fun runTurn(id: Int, text: String) {
        store.addMessage("user", text)
        refresh()
        spoken.setLength(0)
        replyOpen = true
        AssistantState.status.value = "Thinking…"
        try {
            val topic = LEARN_REGEX.find(text)?.groupValues?.get(1)?.trim()
            if (!topic.isNullOrBlank()) {
                learnTopic(id, topic)
                return
            }
            if (OPEN_TERMINAL_REGEX.containsMatchIn(text)) {
                AssistantState.showTerminal.value = true
                finishSimple(id, "Terminal's open.")
                return
            }
            if (GH_LOGIN_REGEX.containsMatchIn(text)) {
                AssistantState.showTerminal.value = true
                scope.launch { terminal.run("gh login") }
                finishSimple(id, "Opening the terminal — follow the code there to finish logging into GitHub.")
                return
            }
            val ghCmd = when {
                GH_LOGOUT_REGEX.containsMatchIn(text) -> "gh logout"
                GH_REPOS_REGEX.containsMatchIn(text) -> "gh repos"
                GH_BUILD_REGEX.containsMatchIn(text) -> "repo run"
                GH_STATUS_REGEX.containsMatchIn(text) -> "repo status"
                else -> GH_USE_REPO_REGEX.find(text)?.let { "repo use ${it.groupValues[1].trim()}" }
                    ?: GH_LS_REGEX.find(text)?.let { "repo ls ${it.groupValues[1].trim()}" }
                    ?: GH_CAT_REGEX.find(text)?.let { "repo cat ${it.groupValues[1].trim()}" }
            }
            if (ghCmd != null) {
                githubTurn(id, ghCmd)
                return
            }
            // Learning/adaptive: notices repeated corrections ("no, always X") and, once seen twice,
            // asks whether to make it a standing preference. Checked before normal commands so a
            // correction is never mistaken for an unrelated phone command.
            CorrectionTracker.intercept(app, store, text)?.let { reply ->
                finishSimple(id, reply)
                return
            }

            UsageStats.log(app, text)

            val pluginCmd = PluginManager.matchCommand(app, text)
            if (pluginCmd != null) {
                runPlugin(id, pluginCmd)
                return
            }

            val cmd = commands.handle(text)
            if (cmd != null) {
                finishSimple(id, cmd)
                return
            }
            val online = !store.forceOffline && Net.isOnline(app)
            val hasKey = store.apiKey.isNotBlank()
            if (online && hasKey && streamOnline(id, text)) return

            val reply = withContext(Dispatchers.Default) { brain.offlineReply(text, online, hasKey) }
            finishSimple(id, reply)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            finishSimple(id, "Something went wrong on my end.")
        }
    }

    /** "learn mathematics" etc: fetches compact offline-usable notes online and stores them for later. */
    private suspend fun learnTopic(id: Int, topic: String) {
        val online = !store.forceOffline && Net.isOnline(app)
        val hasKey = store.apiKey.isNotBlank()
        if (!online || !hasKey) {
            finishSimple(id, "I need to be online with an API key to learn something new. I'll remember it offline once I have.")
            return
        }
        AssistantState.status.value = "Learning “$topic”…"
        try {
            val content = withContext(Dispatchers.IO) { brain.learnTopic(topic) }
            if (id != turnId) return
            if (content.isNullOrBlank()) {
                finishSimple(id, "I couldn't learn that just now. Try again in a moment.")
                return
            }
            store.addKnowledge(topic, content)
            finishSimple(id, "Learned it. I can help with $topic offline now.")
        } catch (e: CancellationException) {
            throw e
        } catch (e: ApiException) {
            finishSimple(id, if (e.code == 400 || e.code == 403) "Your API key was rejected. Check it in settings." else "I couldn't learn that just now. Try again in a moment.")
        } catch (e: Exception) {
            finishSimple(id, "I couldn't learn that just now. Try again in a moment.")
        }
    }

    /** Runs one Terminal command (see Terminal.kt) for a natural-language GitHub trigger recognised in
     *  [runTurn] (e.g. "build the app" -> "repo run"), and speaks back whatever the terminal printed. */
    private suspend fun githubTurn(id: Int, terminalCmd: String) {
        AssistantState.status.value = "Working…"
        val before = terminal.lines.value.size
        withTimeoutOrNull(30_000) { terminal.run(terminalCmd) }
        if (id != turnId) return
        // terminal.lines now has the echoed "$ <cmd>" line plus whatever it printed - skip the echo.
        val added = terminal.lines.value.drop(before + 1)
        val reply = added.joinToString("\n").ifBlank { "Done, but say \"open terminal\" for the full output." }
        finishSimple(id, reply)
    }

    /** Runs one Atlas/Plugins/*.js command (see PluginManager.kt) and speaks back whatever it returns. */
    private suspend fun runPlugin(id: Int, matched: MatchedPlugin) {
        AssistantState.status.value = "Running “${matched.info.command}”…"
        val result = withTimeoutOrNull(8_000) { PluginManager.run(app, matched) }
        if (id != turnId) return
        finishSimple(id, result?.ifBlank { "Done." } ?: "That plugin timed out.")
    }

    /** Runs a full turn for a photo, camera frame or screen frame, with an optional spoken/typed question. */
    private suspend fun runImageTurn(id: Int, imagePath: String, question: String) {
        store.addMessage("user", question.ifBlank { "[photo]" }, 0, imagePath)
        refresh()
        spoken.setLength(0)
        replyOpen = true
        AssistantState.status.value = "Looking…"
        try {
            val online = !store.forceOffline && Net.isOnline(app)
            val hasKey = store.apiKey.isNotBlank()
            if (online && hasKey && streamImageOnline(id, question, imagePath)) return

            val reply = withContext(Dispatchers.Default) { brain.offlineImageReply(imagePath, question, online, hasKey) }
            finishSimple(id, reply)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            finishSimple(id, "Something went wrong looking at that.")
        }
    }

    /** Streams the reply from Gemini. Returns false if nothing came back and the offline brain should answer. */
    private suspend fun streamOnline(id: Int, text: String): Boolean = consumeStream(id, brain.stream(text))

    private suspend fun streamImageOnline(id: Int, question: String, imagePath: String): Boolean =
        consumeStream(id, brain.streamImage(question, imagePath))

    private suspend fun consumeStream(id: Int, source: Flow<Chunk>): Boolean {
        var artifactId = 0L
        var truncated = false
        var lastK = -1
        val parser = ReplyParser(
            onSentence = { if (id == turnId) sayPart(it) },
            onTag = { name, arg ->
                if (id == turnId) when (name) {
                    "remember" -> store.addMemory(arg)
                    "do" -> commands.handle(arg)?.let { sayPart(it) }
                }
            },
            onArtifactStart = { if (id == turnId) AssistantState.status.value = "Building “$it”…" },
            onArtifact = { title, html, complete ->
                if (id == turnId && html.isNotBlank()) {
                    artifactId = store.addArtifact(title, html)
                    truncated = !complete
                }
            }
        )

        var failure: String? = null
        try {
            source.collect { chunk ->
                if (id != turnId) throw CancellationException("superseded")
                when (chunk) {
                    is Chunk.Text -> {
                        parser.feed(chunk.s)
                        if (parser.building) {
                            val k = parser.artifactChars / 1000
                            if (k != lastK) {
                                lastK = k
                                AssistantState.status.value = "Building “${parser.artifactTitle}” · ${k}k"
                            }
                        }
                    }
                    is Chunk.Stop -> if (chunk.reason == "max_tokens") truncated = true
                }
            }
            parser.finish()
        } catch (e: CancellationException) {
            throw e
        } catch (e: ApiException) {
            failure = when {
                e.code == 400 || e.code == 403 -> "Your API key was rejected. Check it in settings."
                e.quotaExhausted -> "Your Gemini API quota has run out. Check your usage in Google AI Studio."
                e.code == 429 -> "I'm being rate limited. Give me a moment and try again."
                else -> null
            }
            if (failure == null && spoken.isBlank() && artifactId == 0L) return false
        } catch (e: IOException) {
            if (spoken.isBlank() && artifactId == 0L) return false
        }
        if (id != turnId) return true

        if (failure != null) {
            finishSimple(id, failure)
            return true
        }
        if (artifactId > 0) {
            sayPart(if (truncated) "It's ready, but it got cut off, so it may be broken." else "It's ready.")
        } else if (spoken.isBlank()) {
            sayPart("Done.")
        }
        speaker.end()
        saveReply(artifactId)
        if (artifactId > 0) showArtifact(artifactId)
        return true
    }

    private fun finishSimple(id: Int, reply: String) {
        if (id != turnId) return
        sayPart(reply)
        speaker.end()
        saveReply(0L)
    }

    private fun saveReply(artifactId: Long) {
        store.addMessage("assistant", spoken.toString().trim(), artifactId)
        replyOpen = false
        refresh()
    }

    // ------------------------------------------------------------------ speech

    private fun beginSpeech() {
        speaking = true
        speaker.begin()
    }

    private fun appendSpoken(s: String) {
        if (spoken.isNotEmpty()) spoken.append(' ')
        spoken.append(s)
    }

    private fun sayPart(s: String) {
        if (!speaking) beginSpeech()
        appendSpoken(s)
        AssistantState.status.value = "Speaking…"
        speaker.enqueue(s)
    }

    private fun onSpeechDone() {
        speaking = false
        echoUntil = System.currentTimeMillis() + ECHO_GRACE_MS
        if (exitAfterReply) {
            exitAfterReply = false
            requestExit(announce = false) // "Shutting down." was already spoken as the command's reply
            return
        }
        // one wake word = one turn, same as "Hey Google": go back to gated listening after replying
        if (store.wakeWordEnabled) {
            wakeEngaged = false
            wakeTimeoutJob?.cancel()
            onDedicatedWakeRearm?.invoke()
        }
        if (stopAfterReply) {
            stopAfterReply = false
            if (AssistantState.voiceOn.value) {
                app.startService(Intent(app, AssistantService::class.java).setAction(AssistantService.ACTION_STOP))
                return
            }
        }
        setIdleStatus()
    }

    private fun setIdleStatus() {
        AssistantState.status.value = when {
            !AssistantState.voiceOn.value -> "Idle"
            store.wakeWordEnabled && !wakeEngaged -> "Say “${store.wakeWordPhrase}”…"
            else -> "Listening…"
        }
    }

    /** A wake word was just heard. [leftover] is whatever was said right after it, if anything. */
    private fun engageWake(leftover: String) {
        wakeEngaged = true
        wakeTimeoutJob?.cancel()
        if (leftover.isNotBlank()) {
            submit(leftover)
        } else {
            AssistantState.status.value = "Yes?"
            AssistantState.heard.value = ""
            wakeTimeoutJob = scope.launch {
                delay(WAKE_ENGAGE_MS)
                if (wakeEngaged) {
                    wakeEngaged = false
                    setIdleStatus()
                    onDedicatedWakeRearm?.invoke()
                }
            }
        }
    }

    /** Ends the current turn: stops the network stream, cuts speech, and keeps what was already said in the chat. */
    private fun cancelTurn() {
        turnJob?.cancel()
        turnJob = null
        turnId++
        if (replyOpen && spoken.isNotBlank()) {
            store.addMessage("assistant", spoken.toString().trim() + " …")
            refresh()
        }
        replyOpen = false
        speaker.stop()
        speaking = false
    }

    /** The user talked over Novochron. */
    private fun cutOff() {
        cancelTurn()
        setIdleStatus()
    }

    /**
     * If Novochron keeps "hearing" itself, three false alarms in a short time switch interrupting off for a
     * minute and a half (headphones avoid the problem completely).
     */
    private fun noteRiskyAccept(now: Long) {
        riskyAccepts.add(now)
        riskyAccepts.removeAll { now - it > 25_000 }
        if (riskyAccepts.size >= 3) {
            riskyAccepts.clear()
            lockUntil = now + 90_000
            AssistantState.status.value = "Hearing my own voice. Headphones work best."
        }
    }

    private fun showArtifact(id: Long) {
        AssistantState.openArtifact.value = id
        if (!AssistantState.appVisible) {
            try {
                app.startActivity(
                    Intent(app, MainActivity::class.java).addFlags(
                        Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT
                    )
                )
            } catch (e: Exception) {
                // Android blocked opening the app from the background: the chat card is still there
            }
        }
    }

    companion object {
        private const val ECHO_GRACE_MS = 1200L
        private const val WAKE_ENGAGE_MS = 7000L
        // "learn mathematics", "learn about photosynthesis", "study French verbs", "memorize the periodic table"
        private val LEARN_REGEX = Regex("^(?:learn|study|memorize)\\s+(?:about\\s+)?(.+)$", RegexOption.IGNORE_CASE)

        // ---- terminal / GitHub natural-language triggers (see Terminal.kt and GitHub.kt) ----
        private val OPEN_TERMINAL_REGEX = Regex("^(?:open|show)\\s+(?:the\\s+)?terminal$", RegexOption.IGNORE_CASE)
        private val GH_LOGIN_REGEX = Regex(
            "^(?:log\\s*in|connect|link)(?:\\s+(?:to|with))?(?:\\s+my)?\\s+github(?:\\s+account)?$",
            RegexOption.IGNORE_CASE
        )
        private val GH_LOGOUT_REGEX = Regex("^(?:log\\s*out of|disconnect(?:\\s+from)?)\\s+github$", RegexOption.IGNORE_CASE)
        private val GH_REPOS_REGEX = Regex("^(?:list|show)\\s+my\\s+repos(?:itories)?$", RegexOption.IGNORE_CASE)
        private val GH_USE_REPO_REGEX = Regex("^(?:use|switch to|set)\\s+repo(?:\\s+to)?\\s+(.+)$", RegexOption.IGNORE_CASE)
        private val GH_LS_REGEX = Regex("^(?:list|show)\\s+(?:the\\s+)?files?(?:\\s+in(?:\\s+the\\s+repo)?)?(?:\\s+in\\s+(.+))?$", RegexOption.IGNORE_CASE)
        private val GH_CAT_REGEX = Regex("^(?:show|read|open|cat)\\s+file\\s+(.+)$", RegexOption.IGNORE_CASE)
        private val GH_BUILD_REGEX = Regex(
            "^(?:build (?:this|the) app|build it|run the build|trigger (?:a |the )?build|kick off (?:a |the )?build)$",
            RegexOption.IGNORE_CASE
        )
        private val GH_STATUS_REGEX = Regex(
            "^(?:check|what'?s)\\s+the\\s+build\\s+status|is the build done\\??$",
            RegexOption.IGNORE_CASE
        )

        @Volatile private var inst: Engine? = null
        fun get(ctx: Context): Engine =
            inst ?: synchronized(this) { inst ?: Engine(ctx.applicationContext).also { inst = it } }
    }
}
