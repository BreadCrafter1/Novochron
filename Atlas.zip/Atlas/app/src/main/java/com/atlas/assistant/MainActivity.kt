package com.atlas.assistant

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.graphics.BitmapFactory
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.Canvas
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withStyle
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.layout.ContentScale
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.LocalTextStyle
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import java.io.File
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

// Termux-style terminal theme: black surfaces, white monospace text, green prompt, sharp corners.
val Accent = Color(0xFF3DFF5C)       // terminal green — the "~" in the prompt, titles, primary actions
val Ink = Color(0xFFE8E8E8)          // body text — Termux-style near-white
val Dim = Color(0xFF8C8C8C)          // secondary/status text — grey
val Line = Color(0xFF262626)         // hairline borders
val CardBg = Color(0xFF000000)       // pure black, log lines sit directly on it
val Raised = Color(0xFF101010)       // slightly raised panel, still near-black
val Warn = Color(0xFFFF5C5C)         // recording / active-danger accent (screencast, power)
val TermFont = FontFamily.Monospace
private const val CURSOR = "█"

class MainActivity : ComponentActivity() {

    private val permLauncher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) startVoice()
        else AssistantState.status.value = "Microphone permission is required"
    }

    private val cameraPermLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) AssistantState.cameraOpen.value = true
        else AssistantState.status.value = "Camera permission is required"
    }

    private val photoPickerLauncher = registerForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri == null) return@registerForActivityResult
        val bmp = Vision.fromUri(this, uri)
        if (bmp != null) Engine.get(this).submitPhoto(bmp, "")
        else AssistantState.status.value = "Couldn't open that photo."
    }

    private val screenCaptureLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == Activity.RESULT_OK && result.data != null) {
            val intent = Intent(this, ScreenCastService::class.java)
                .putExtra(ScreenCastService.EXTRA_RESULT_CODE, result.resultCode)
                .putExtra(ScreenCastService.EXTRA_DATA, result.data)
            ContextCompat.startForegroundService(this, intent)
        } else {
            AssistantState.status.value = "Screencast permission was declined."
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        hideSystemBars()
        val engine = Engine.get(this)
        handleOpenIntent(intent)
        MsgWatchService.refresh(this)   // bring message alerts back if they're switched on (no-op otherwise)
        setContent {
            NovochronApp(
                engine,
                onToggle = { toggleVoice(it) },
                onOverlay = { openOverlaySettings() },
                onBattery = { requestBatteryExemption() },
                onStorage = { requestStorageAccess() },
                onOpenCamera = { openCamera() },
                onPickPhoto = { pickPhoto() },
                onToggleScreencast = { toggleScreencast(it) }
            )
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleOpenIntent(intent)
    }

    /** Tapping a message alert lands straight in msg. */
    private fun handleOpenIntent(i: Intent?) {
        if (i?.getBooleanExtra(MsgNotifier.EXTRA_OPEN_MSG, false) == true) {
            i.removeExtra(MsgNotifier.EXTRA_OPEN_MSG)
            AssistantState.showMsg.value = true
        }
    }

    private fun openCamera() {
        if (checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
            AssistantState.cameraOpen.value = true
        } else {
            cameraPermLauncher.launch(Manifest.permission.CAMERA)
        }
    }

    private fun pickPhoto() {
        photoPickerLauncher.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
    }

    /** Turning screencast on asks Android's system "start recording your screen?" dialog once. */
    private fun toggleScreencast(on: Boolean) {
        if (on) {
            val mgr = getSystemService(MediaProjectionManager::class.java)
            screenCaptureLauncher.launch(mgr.createScreenCaptureIntent())
        } else {
            startService(Intent(this, ScreenCastService::class.java).setAction(ScreenCastService.ACTION_STOP))
        }
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        // Re-hide on every focus regain: the status/nav bars reappear after things like the
        // system share sheet, a permission dialog, or the recents switcher, and don't hide
        // themselves back again on their own.
        if (hasFocus) hideSystemBars()
    }

    private fun hideSystemBars() {
        WindowCompat.setDecorFitsSystemWindows(window, false)
        val controller = WindowCompat.getInsetsController(window, window.decorView)
        controller.hide(WindowInsetsCompat.Type.systemBars())
        controller.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
    }

    override fun onStart() {
        super.onStart()
        AssistantState.appVisible = true
    }

    override fun onStop() {
        super.onStop()
        AssistantState.appVisible = false
    }

    private fun toggleVoice(on: Boolean) {
        if (!on) {
            startService(Intent(this, AssistantService::class.java).setAction(AssistantService.ACTION_STOP))
            return
        }
        val wanted = buildList {
            add(Manifest.permission.RECORD_AUDIO)
            if (Build.VERSION.SDK_INT >= 33) add(Manifest.permission.POST_NOTIFICATIONS)
            add(Manifest.permission.CALL_PHONE)
            add(Manifest.permission.READ_CONTACTS)
            add(Manifest.permission.SEND_SMS)
            add(Manifest.permission.ACCESS_FINE_LOCATION)
            add(Manifest.permission.ACCESS_COARSE_LOCATION)
            if (Build.VERSION.SDK_INT >= 31) add(Manifest.permission.BLUETOOTH_CONNECT)
            if (Build.VERSION.SDK_INT < 30) add(Manifest.permission.WRITE_EXTERNAL_STORAGE)
        }.filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (wanted.isEmpty()) startVoice() else permLauncher.launch(wanted.toTypedArray())
    }

    private fun startVoice() {
        ContextCompat.startForegroundService(this, Intent(this, AssistantService::class.java))
        askBatteryOnce()
    }

    /** Background listening survives much better when the battery saver is told to leave Novochron alone. */
    private fun askBatteryOnce() {
        val store = Store.get(this)
        val pm = getSystemService(PowerManager::class.java)
        if (store.batteryAsked || pm.isIgnoringBatteryOptimizations(packageName)) return
        store.batteryAsked = true
        requestBatteryExemption()
    }

    @SuppressLint("BatteryLife")
    private fun requestBatteryExemption() {
        try {
            startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
        } catch (e: Exception) {
            try {
                startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
            } catch (e2: Exception) {
                // no settings screen available on this phone
            }
        }
    }

    private fun openOverlaySettings() {
        startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
    }

    /** Lets the user grant "All files access" so Novochron's data lives in its own visible folder at /storage/emulated/0/Atlas. */
    private fun requestStorageAccess() {
        if (Build.VERSION.SDK_INT < 30) return // handled by the normal WRITE_EXTERNAL_STORAGE runtime permission above
        try {
            startActivity(AtlasStorage.requestAccessIntent(this))
        } catch (e: Exception) {
            try {
                startActivity(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION))
            } catch (e2: Exception) {
                // no settings screen available on this phone
            }
        }
    }
}

/** Walks ContextWrapper layers to find the hosting Activity, since a Compose LocalContext is often wrapped. */
fun android.content.Context.findActivity(): Activity? {
    var c = this
    while (c is android.content.ContextWrapper) {
        if (c is Activity) return c
        c = c.baseContext
    }
    return null
}

@Composable
fun fieldColors() = OutlinedTextFieldDefaults.colors(
    focusedTextColor = Ink,
    unfocusedTextColor = Ink,
    focusedBorderColor = Accent,
    unfocusedBorderColor = Line,
    cursorColor = Accent,
    focusedContainerColor = Color.Black,
    unfocusedContainerColor = Color.Black
)

@Composable
fun switchColors() = SwitchDefaults.colors(
    checkedThumbColor = Color.Black,
    checkedTrackColor = Accent,
    uncheckedThumbColor = Dim,
    uncheckedTrackColor = Raised
)

@Composable
fun NovochronApp(
    engine: Engine,
    onToggle: (Boolean) -> Unit,
    onOverlay: () -> Unit,
    onBattery: () -> Unit,
    onStorage: () -> Unit,
    onOpenCamera: () -> Unit,
    onPickPhoto: () -> Unit,
    onToggleScreencast: (Boolean) -> Unit
) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Accent,
            onPrimary = Color.Black,
            background = Color.Black,
            surface = Color.Black,
            onSurface = Ink,
            onBackground = Ink
        )
    ) {
        val openId by AssistantState.openArtifact.collectAsState()
        val open = remember(openId) { if (openId > 0) engine.store.artifact(openId) else null }
        val cameraOpen by AssistantState.cameraOpen.collectAsState()
        val showMap by AssistantState.showMap.collectAsState()
        val showTerminal by AssistantState.showTerminal.collectAsState()
        val showVault by AssistantState.showVault.collectAsState()
        val showMsg by AssistantState.showMsg.collectAsState()
        val showGraph by AssistantState.showGraph.collectAsState()
        val showSolar by AssistantState.showSolar.collectAsState()
        val showStats by AssistantState.showStats.collectAsState()
        val showWeb by AssistantState.showWeb.collectAsState()
        val exitRequested by AssistantState.exitRequested.collectAsState()
        val localCtx = LocalContext.current
        LaunchedEffect(exitRequested) {
            if (exitRequested) localCtx.findActivity()?.finishAndRemoveTask()
        }
        if (cameraOpen) {
            CameraScreen(engine) { AssistantState.cameraOpen.value = false }
        } else if (showMap) {
            MapScreen(engine) { AssistantState.showMap.value = false }
        } else if (showWeb) {
            BrowserScreen(engine) { AssistantState.showWeb.value = false }
        } else if (showTerminal) {
            TerminalScreen(engine) { AssistantState.showTerminal.value = false }
        } else if (showVault) {
            VaultScreen(engine) { AssistantState.showVault.value = false }
        } else if (showMsg) {
            MsgScreen(engine) { AssistantState.showMsg.value = false }
        } else if (showGraph) {
            GraphScreen { AssistantState.showGraph.value = false }
        } else if (showSolar) {
            SolarSystemScreen { AssistantState.showSolar.value = false }
        } else if (showStats) {
            UsageStatsScreen { AssistantState.showStats.value = false }
        } else if (open != null) {
            ArtifactScreen(open) { AssistantState.openArtifact.value = 0 }
        } else {
            MainScreen(engine, onToggle, onOverlay, onBattery, onStorage, onOpenCamera, onPickPhoto, onToggleScreencast)
        }
    }
}

/** What the on-screen character should be doing, from the live app state. */
private fun mascotModeFor(speaking: Boolean, status: String, heard: String, typing: Boolean): MascotMode = when {
    speaking -> MascotMode.SPEAKING
    status.startsWith("Thinking") || status.startsWith("Looking") ||
        status.startsWith("Learning") || status.startsWith("Building") -> MascotMode.THINKING
    heard.isNotEmpty() || typing || status.startsWith("Yes?") -> MascotMode.LISTENING
    else -> MascotMode.IDLE
}

/** Keeps light text readable when it is drawn on top of the character. */
private val LogShadow = Shadow(Color.Black, Offset.Zero, 8f)

@Composable
fun MainScreen(
    engine: Engine,
    onToggle: (Boolean) -> Unit,
    onOverlay: () -> Unit,
    onBattery: () -> Unit,
    onStorage: () -> Unit,
    onOpenCamera: () -> Unit,
    onPickPhoto: () -> Unit,
    onToggleScreencast: (Boolean) -> Unit
) {
    val messages by AssistantState.messages.collectAsState()
    val voiceOn by AssistantState.voiceOn.collectAsState()
    val status by AssistantState.status.collectAsState()
    val heard by AssistantState.heard.collectAsState()
    val showLibrary by AssistantState.showLibrary.collectAsState()
    val forceOffline by AssistantState.forceOffline.collectAsState()
    val screencastOn by AssistantState.screencastOn.collectAsState()
    val wakeWordOn by AssistantState.wakeWordOn.collectAsState()
    val speaking by AssistantState.speaking.collectAsState()
    val mascotOn by AssistantState.mascotOn.collectAsState()
    var debugOn by remember { mutableStateOf(engine.store.debugOverlayOn) }
    var input by remember { mutableStateOf("") }
    var showSettings by remember { mutableStateOf(false) }
    // [hide] / [show]: tuck the conversation away to see the character, without losing anything
    var chatVisible by rememberSaveable { mutableStateOf(true) }
    val listState = rememberLazyListState()
    val isLandscape = LocalConfiguration.current.orientation == Configuration.ORIENTATION_LANDSCAPE

    LaunchedEffect(messages.size, chatVisible) {
        if (chatVisible && messages.isNotEmpty()) listState.animateScrollToItem(messages.size - 1)
    }

    fun send() {
        if (input.isNotBlank()) {
            engine.submit(input)
            input = ""
        }
    }

    val mode = mascotModeFor(speaking, status, if (voiceOn) heard else "", input.isNotEmpty())
    // anything happening keeps her awake a bit longer (she dozes off after ~40 s of nothing)
    val nudge = messages.size * 31 + input.length * 7 + status.hashCode()

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        if (mascotOn) MascotBackdrop(mode, nudge, Modifier.fillMaxSize())

        Column(Modifier.fillMaxSize().padding(if (isLandscape) 10.dp else 16.dp)) {
            // all the buttons are in the top two rows, so the conversation gets everything below
            TermHeaderBar(
                compact = isLandscape,
                onLibrary = { AssistantState.showLibrary.value = true },
                onMap = { AssistantState.showMap.value = true },
                onWeb = { AssistantState.showWeb.value = true },
                onVault = { AssistantState.showVault.value = true },
                onTerminal = { AssistantState.showTerminal.value = true },
                onGraph = { AssistantState.showGraph.value = true },
                onSolar = { AssistantState.showSolar.value = true },
                onMsg = { AssistantState.showMsg.value = true },
                onStats = { AssistantState.showStats.value = true },
                onSettings = { showSettings = true },
                onExit = { engine.requestExit(announce = false) }
            )
            TermControlRow(
                compact = isLandscape,
                voiceOn = voiceOn,
                online = !forceOffline,
                wakeWordOn = wakeWordOn,
                screencastOn = screencastOn,
                onVoice = { onToggle(!voiceOn) },
                onOnline = { engine.setForceOffline(!forceOffline) },
                onWake = { engine.setWakeWordEnabled(!wakeWordOn) },
                onCamera = onOpenCamera,
                onPhoto = onPickPhoto,
                onCast = { onToggleScreencast(!screencastOn) },
                chatVisible = chatVisible,
                onChat = { chatVisible = !chatVisible },
                debugOn = debugOn,
                onDebug = { debugOn = !debugOn; engine.store.debugOverlayOn = debugOn }
            )
            StatusBlock(
                text = if (voiceOn && heard.isNotEmpty()) "“$heard”" else status,
                offline = forceOffline,
                wakePhrase = if (wakeWordOn) engine.store.wakeWordPhrase else "",
                canClear = messages.isNotEmpty(),
                onClear = { engine.clearChat() }
            )

            if (chatVisible) {
                MessageLog(messages, listState, Modifier.weight(1f).fillMaxWidth())
            } else {
                Spacer(Modifier.weight(1f).fillMaxWidth()) // keeps the prompt at the bottom
            }
            if (screencastOn) ScreencastHint()
            InputBar(input, { input = it }, ::send)
        }

        if (debugOn) DebugOverlay(Modifier.align(Alignment.TopEnd).padding(top = 84.dp, end = 8.dp))
    }

    if (showSettings) SettingsDialog(engine, onOverlay, onBattery, onStorage) { showSettings = false }
    if (showLibrary) {
        LibraryDialog(
            engine,
            onOpen = { AssistantState.openArtifact.value = it },
            onDismiss = { AssistantState.showLibrary.value = false }
        )
    }
}

/** A plain text button: `[lib]`, `[map]`... Optionally bold / coloured. */
@Composable
fun TermTextKey(label: String, tone: Color = Ink, bold: Boolean = false, size: Int = 13, hpad: Int = 8, onClick: () -> Unit) {
    Text(
        label,
        color = tone,
        fontFamily = TermFont,
        fontSize = size.sp,
        fontWeight = if (bold) FontWeight.Bold else FontWeight.Normal,
        maxLines = 1,
        style = TextStyle(shadow = LogShadow),
        modifier = Modifier.clickable(onClick = onClick).padding(horizontal = hpad.dp, vertical = 12.dp)
    )
}

/** A power symbol drawn as a vector, so it never depends on a font having the glyph. */
@Composable
fun PowerIcon(onClick: () -> Unit) {
    Canvas(
        Modifier
            .size(40.dp)
            .clickable(onClick = onClick)
            .padding(10.dp)
            .semantics { contentDescription = "Power off" }
    ) {
        val stroke = size.minDimension * 0.12f
        val r = size.minDimension / 2f - stroke
        drawArc(
            color = Warn,
            startAngle = -55f,
            sweepAngle = 290f,
            useCenter = false,
            topLeft = Offset(center.x - r, center.y - r),
            size = Size(r * 2f, r * 2f),
            style = Stroke(width = stroke, cap = StrokeCap.Round)
        )
        drawLine(
            color = Warn,
            start = Offset(center.x, stroke / 2f),
            end = Offset(center.x, center.y),
            strokeWidth = stroke,
            cap = StrokeCap.Round
        )
    }
}

/** Row 1: the prompt on the left, then [lib] [map] [set] and the power button. */
@Composable
fun TermHeaderBar(
    compact: Boolean,
    onLibrary: () -> Unit,
    onMap: () -> Unit,
    onWeb: () -> Unit,
    onVault: () -> Unit,
    onTerminal: () -> Unit,
    onGraph: () -> Unit,
    onSolar: () -> Unit,
    onMsg: () -> Unit,
    onStats: () -> Unit,
    onSettings: () -> Unit,
    onExit: () -> Unit
) {
    var confirmExit by remember { mutableStateOf(false) }
    val widthDp = LocalConfiguration.current.screenWidthDp
    val promptSp = if (widthDp < 400) 14 else if (widthDp < 440) 16 else 18
    val hpad = if (widthDp < 440) 5 else 8
    Row(
        Modifier.fillMaxWidth().height(if (compact) 40.dp else 48.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(
            "root@novochron:~$",
            color = Ink,
            fontFamily = TermFont,
            fontSize = promptSp.sp,
            fontWeight = FontWeight.Bold,
            maxLines = 1,
            style = TextStyle(shadow = LogShadow)
        )
        // Scrolls sideways instead of overflowing — weighted so it only claims the space left over
        // between the prompt and the power button, which otherwise more buttons could push off-screen.
        Row(
            Modifier.weight(1f).horizontalScroll(rememberScrollState()).padding(horizontal = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            TermTextKey("[lib]", hpad = hpad, onClick = onLibrary)
            TermTextKey("[map]", hpad = hpad, onClick = onMap)
            TermTextKey("[web]", hpad = hpad, onClick = onWeb)
            TermTextKey("[vault]", hpad = hpad, onClick = onVault)
            TermTextKey("[term]", hpad = hpad, onClick = onTerminal)
            TermTextKey("[graph]", hpad = hpad, onClick = onGraph)
            TermTextKey("[sim]", hpad = hpad, onClick = onSolar)
            TermTextKey("[msg]", hpad = hpad, onClick = onMsg)
            TermTextKey("[stats]", hpad = hpad, onClick = onStats)
            TermTextKey("[set]", hpad = hpad, onClick = onSettings)
        }
        PowerIcon { confirmExit = true }
    }
    if (confirmExit) {
        AlertDialog(
            onDismissRequest = { confirmExit = false },
            containerColor = Color(0xFF0B0B0B),
            title = { Text("[ shut down ]", color = Warn, fontFamily = TermFont, fontWeight = FontWeight.Bold) },
            text = { Text("Close Novochron completely? Voice and background listening will stop.", color = Ink, fontFamily = TermFont, fontSize = 13.sp) },
            confirmButton = {
                TextButton(onClick = { confirmExit = false; onExit() }) { Text("Turn off", color = Warn, fontFamily = TermFont) }
            },
            dismissButton = {
                TextButton(onClick = { confirmExit = false }) { Text("Cancel", color = Ink, fontFamily = TermFont) }
            }
        )
    }
}

/**
 * Row 2: LIVE/OFF indicator, then the switches (voice, online, wake) and the quick actions
 * ([cam] [img] [cast]). A switch that is on is bold and bracketed, one that is off is dim and plain.
 * It scrolls sideways if a narrow screen can't fit everything.
 */
@Composable
fun TermControlRow(
    compact: Boolean,
    voiceOn: Boolean,
    online: Boolean,
    wakeWordOn: Boolean,
    screencastOn: Boolean,
    onVoice: () -> Unit,
    onOnline: () -> Unit,
    onWake: () -> Unit,
    onCamera: () -> Unit,
    onPhoto: () -> Unit,
    onCast: () -> Unit,
    chatVisible: Boolean,
    onChat: () -> Unit,
    debugOn: Boolean = false,
    onDebug: () -> Unit = {}
) {
    val hp = if (LocalConfiguration.current.screenWidthDp < 440) 5 else 8
    Row(
        Modifier
            .fillMaxWidth()
            .height(if (compact) 38.dp else 44.dp)
            .horizontalScroll(rememberScrollState()),
        verticalAlignment = Alignment.CenterVertically
    ) {
        TermTextKey(if (voiceOn) "LIVE" else "OFF", tone = if (voiceOn) Accent else Dim, bold = voiceOn, size = 11, hpad = hp, onClick = onVoice)
        TermTextKey(if (voiceOn) "[voice]" else "voice", tone = if (voiceOn) Ink else Dim, bold = voiceOn, hpad = hp, onClick = onVoice)
        TermTextKey(if (online) "[online]" else "online", tone = if (online) Ink else Dim, bold = online, hpad = hp, onClick = onOnline)
        TermTextKey(if (wakeWordOn) "[wake]" else "wake", tone = if (wakeWordOn) Ink else Dim, bold = wakeWordOn, hpad = hp, onClick = onWake)
        Spacer(Modifier.width(12.dp))
        TermTextKey("[cam]", hpad = hp, onClick = onCamera)
        TermTextKey("[img]", hpad = hp, onClick = onPhoto)
        TermTextKey(if (screencastOn) "[stop]" else "[cast]", tone = if (screencastOn) Warn else Ink, bold = screencastOn, hpad = hp, onClick = onCast)
        TermTextKey(if (chatVisible) "[hide]" else "[show]", bold = !chatVisible, hpad = hp, onClick = onChat)
        TermTextKey(if (debugOn) "[debug]" else "debug", tone = if (debugOn) Accent else Dim, bold = debugOn, hpad = hp, onClick = onDebug)
    }
}

/**
 * What Novochron is doing / just heard, right under the buttons; plus the offline and wake-word notes.
 * When there is a conversation to clear, `[clear chat]` sits at the right-hand end of the same block so
 * it is always one tap away, whatever the screen width (the control row above scrolls sideways).
 */
@Composable
fun StatusBlock(
    text: String,
    offline: Boolean,
    wakePhrase: String,
    canClear: Boolean = false,
    onClear: () -> Unit = {}
) {
    Row(Modifier.fillMaxWidth().padding(top = 2.dp, bottom = 4.dp), verticalAlignment = Alignment.Top) {
        Column(Modifier.weight(1f)) {
            Text(
                text,
                color = Dim,
                fontFamily = TermFont,
                fontSize = 13.sp,
                lineHeight = 17.sp,
                style = TextStyle(shadow = LogShadow)
            )
            if (offline) {
                Text(
                    "# offline: commands, memory + learned notes only",
                    color = Dim,
                    fontFamily = TermFont,
                    fontSize = 11.sp,
                    style = TextStyle(shadow = LogShadow)
                )
            }
            if (wakePhrase.isNotEmpty()) {
                Text(
                    "# say “$wakePhrase” to wake it up",
                    color = Dim,
                    fontFamily = TermFont,
                    fontSize = 11.sp,
                    style = TextStyle(shadow = LogShadow)
                )
            }
        }
        if (canClear) ClearChatKey(onClear)
    }
}

/**
 * Quick "clear chat history". One tap arms it (`[confirm?]`, red, for 3 seconds), a second tap wipes the
 * conversation, so a stray touch while scrolling can't delete everything. [busy], when true (a clear that
 * hits the network, e.g. wiping the shared repo, is in flight), shows `[clearing…]` and disables taps so
 * a second tap can't fire mid-delete.
 */
@Composable
fun ClearChatKey(onClear: () -> Unit, busy: Boolean = false) {
    var armed by remember { mutableStateOf(false) }
    LaunchedEffect(armed) {
        if (armed) {
            delay(3000)
            armed = false
        }
    }
    Text(
        if (busy) "[clearing…]" else if (armed) "[confirm?]" else "[clear chat]",
        color = if (armed) Warn else Ink,
        fontFamily = TermFont,
        fontSize = 13.sp,
        fontWeight = if (armed) FontWeight.Bold else FontWeight.Normal,
        maxLines = 1,
        style = TextStyle(shadow = LogShadow),
        modifier = Modifier
            .semantics { contentDescription = "Clear chat history" }
            .clickable(enabled = !busy) {
                if (armed) {
                    armed = false
                    onClear()
                } else {
                    armed = true
                }
            }
            .padding(horizontal = 8.dp, vertical = 4.dp)
    )
}

@Composable
fun ScreencastHint() {
    Text(
        "# watching your screen — ask about what's on it any time",
        color = Warn,
        fontFamily = TermFont,
        fontSize = 11.sp,
        maxLines = 1,
        overflow = TextOverflow.Ellipsis,
        style = TextStyle(shadow = LogShadow),
        modifier = Modifier.padding(top = 4.dp)
    )
}

@Composable
fun MessageLog(messages: List<Msg>, listState: LazyListState, modifier: Modifier) {
    if (messages.isEmpty()) {
        Box(modifier, contentAlignment = Alignment.Center) {
            Text(
                "# turn voice on (or say the wake word) and just talk\n" +
                    "# you can interrupt me any time\n\n" +
                    "try: “make me a sudoku puzzle”\n“build a tip calculator”\n“open YouTube”\n" +
                    "“set an alarm for 6:30 AM”\n“call Mom”\n“learn mathematics”",
                color = Dim,
                fontFamily = TermFont,
                fontSize = 13.sp,
                lineHeight = 20.sp,
                style = TextStyle(shadow = LogShadow)
            )
        }
    } else {
        LazyColumn(state = listState, modifier = modifier, verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(messages, key = { it.id }) { m ->
                Bubble(m) { id -> AssistantState.openArtifact.value = id }
            }
        }
    }
}

private fun promptText(rest: String) = buildAnnotatedString {
    withStyle(SpanStyle(fontWeight = FontWeight.Bold)) { append("$") }
    append(" ")
    append(rest)
}

/** The prompt at the bottom: `$`, the text field, and RUN (the keyboard's enter / send key also runs it). */
@Composable
fun InputBar(input: String, onInputChange: (String) -> Unit, onSend: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Text("$", color = Ink, fontFamily = TermFont, fontSize = 18.sp, fontWeight = FontWeight.Bold, style = TextStyle(shadow = LogShadow))
        Spacer(Modifier.width(14.dp))
        BasicTextField(
            value = input,
            onValueChange = onInputChange,
            modifier = Modifier.weight(1f),
            textStyle = TextStyle(fontFamily = TermFont, color = Ink, fontSize = 16.sp),
            singleLine = true,
            cursorBrush = SolidColor(Ink),
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
            keyboardActions = KeyboardActions(onSend = { onSend() }),
            decorationBox = { inner ->
                Box(contentAlignment = Alignment.CenterStart) {
                    if (input.isEmpty()) {
                        Text("type a command…", color = Dim, fontFamily = TermFont, fontSize = 16.sp)
                    }
                    inner()
                }
            }
        )
        Text(
            "RUN",
            color = Ink,
            fontFamily = TermFont,
            fontWeight = FontWeight.Bold,
            fontSize = 15.sp,
            style = TextStyle(shadow = LogShadow),
            modifier = Modifier.clickable(onClick = onSend).padding(horizontal = 8.dp, vertical = 12.dp)
        )
    }
}

/**
 * Terminal-log style: no chat bubbles. What you said is a prompt line ("$ hello"); what Novochron
 * says is plain output underneath, the way a shell session scrolls.
 */
@Composable
fun Bubble(m: Msg, onOpen: (Long) -> Unit) {
    val user = m.role == "user"
    Column(Modifier.fillMaxWidth()) {
        if (user) {
            Text(
                promptText(m.text),
                color = Ink,
                fontFamily = TermFont,
                fontSize = 13.5.sp,
                lineHeight = 18.sp,
                style = TextStyle(shadow = LogShadow)
            )
        }
        if (m.imagePath.isNotEmpty()) {
            val bmp = remember(m.imagePath) { Vision.loadBitmap(m.imagePath)?.asImageBitmap() }
            bmp?.let {
                Spacer(Modifier.height(4.dp))
                Image(
                    bitmap = it,
                    contentDescription = null,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(2.dp))
                        .border(1.dp, Line, RoundedCornerShape(2.dp))
                )
            }
        }
        if (!user && m.text.isNotEmpty() && m.text != "[photo]") {
            Text(
                m.text,
                color = Color(0xFFCFCFCF),
                fontFamily = TermFont,
                fontSize = 13.5.sp,
                lineHeight = 18.sp,
                style = TextStyle(shadow = LogShadow)
            )
        }
        if (m.artifactId > 0 && m.artifactTitle.isNotEmpty()) {
            Spacer(Modifier.height(6.dp))
            Row(
                Modifier
                    .clip(RoundedCornerShape(2.dp))
                    .background(Ink)
                    .clickable { onOpen(m.artifactId) }
                    .padding(horizontal = 10.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    "> run ${m.artifactTitle}",
                    color = Color.Black,
                    fontFamily = TermFont,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp
                )
            }
        }
    }
}

@Composable
fun ToggleRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, color = Ink, fontSize = 15.sp, modifier = Modifier.weight(1f))
        Switch(checked = checked, onCheckedChange = onChange, colors = switchColors())
    }
}

@Composable
fun SettingsDialog(engine: Engine, onOverlay: () -> Unit, onBattery: () -> Unit, onStorage: () -> Unit, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    var pitch by remember { mutableFloatStateOf(engine.store.pitch) }
    var interrupt by remember { mutableStateOf(engine.store.interrupt) }
    var mascot by remember { mutableStateOf(engine.store.mascotOn) }
    var wakePhrase by remember { mutableStateOf(engine.store.wakeWordPhrase) }
    var picovoiceKey by remember { mutableStateOf(engine.store.picovoiceAccessKey) }
    var wakeBuiltin by remember { mutableStateOf(engine.store.wakeEngineBuiltin) }
    val forceOffline by AssistantState.forceOffline.collectAsState()
    val wakeWordOn by AssistantState.wakeWordOn.collectAsState()
    var learned by remember { mutableStateOf(engine.store.knowledge()) }
    // "Clear photos in directory" (top of the list): how many photos are saved, the confirm step, and the result line
    val scope = rememberCoroutineScope()
    var photoStats by remember { mutableStateOf(0 to 0L) }
    var photoTick by remember { mutableIntStateOf(0) }
    var photoMsg by remember { mutableStateOf("") }
    var confirmClearPhotos by remember { mutableStateOf(false) }
    // Locked photo section at the bottom of Settings. The photo ships as AES-GCM ciphertext
    // (res/raw/vault_photo.enc, see VaultCrypto.kt) — vaultPhoto only holds the decoded bitmap
    // while the vault is open, and is dropped (nulled out) again on Lock or on leaving Settings.
    var vaultPasswordInput by remember { mutableStateOf("") }
    var vaultWrongPassword by remember { mutableStateOf(false) }
    var vaultUnlocking by remember { mutableStateOf(false) }
    var vaultPhoto by remember { mutableStateOf<ImageBitmap?>(null) }
    LaunchedEffect(photoTick) {
        photoStats = withContext(Dispatchers.IO) { AtlasStorage.photoStats(ctx) }
    }
    // Re-checked every couple of seconds while Settings is open, so dropping a model file in (or granting
    // "All files access") shows up here without closing and reopening anything.
    var modelScan by remember { mutableStateOf(LocalLlm.scan(ctx)) }
    var storageOk by remember { mutableStateOf(AtlasStorage.hasAccess()) }
    LaunchedEffect(Unit) {
        while (true) {
            delay(2000)
            val (scan, access) = withContext(Dispatchers.IO) {
                if (AtlasStorage.hasAccess()) AtlasStorage.ensureDirs()
                LocalLlm.scan(ctx) to AtlasStorage.hasAccess()
            }
            modelScan = scan
            storageOk = access
        }
    }
    val modelFound = modelScan.found
    val customWakeFileFound = File(AtlasStorage.modelsDir(), "wakeword.ppn").exists()
    val dedicatedWakeReady = picovoiceKey.isNotBlank() && (customWakeFileFound || PorcupineWake.BUILTINS.contains(wakeBuiltin))
    val batteryOk = ctx.getSystemService(PowerManager::class.java)?.isIgnoringBatteryOptimizations(ctx.packageName) == true
    val writeOk = Controls.canWriteSettings(ctx)
    val dndOk = Controls.hasDndAccess(ctx)

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Color(0xFF060606),
        title = { Text("[ settings ]", color = Accent, fontFamily = TermFont, fontWeight = FontWeight.Bold) },
        text = {
        CompositionLocalProvider(LocalTextStyle provides LocalTextStyle.current.copy(fontFamily = TermFont)) {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                // Deliberately the very first thing in Settings
                TextButton(onClick = { photoMsg = ""; confirmClearPhotos = true }) {
                    Text("Clear photos in directory", color = Warn)
                }
                Text(
                    (if (photoStats.first == 0) "No saved photos in Atlas/Photos."
                    else "${photoStats.first} saved photo${if (photoStats.first == 1) "" else "s"} " +
                        "(${humanBytes(photoStats.second)}) in Atlas/Photos.") +
                        (if (photoMsg.isNotEmpty()) "\n$photoMsg" else ""),
                    color = if (photoMsg.isNotEmpty()) Accent else Dim,
                    fontSize = 12.sp
                )

                if (BuildConfig.GEMINI_API_KEY.isNotBlank()) {
                    Text("Gemini API key (online brain and voice): bundled with this build ✓", color = Accent, fontSize = 12.sp)
                } else {
                    Text(
                        "Gemini API key: not in this build (offline-only). Add GEMINI_API_KEY to gradle.properties/local.properties " +
                            "and rebuild, or set it as a GitHub Actions secret for CI builds (see README > Gemini setup).",
                        color = Warn,
                        fontSize = 12.sp
                    )
                }
                // The Maps key is baked in at build time (it can't be typed in here) - this just shows whether it's in.
                if (MapsKey.isConfigured(ctx)) {
                    Text("Google Maps key: included in this build ✓", color = Accent, fontSize = 12.sp)
                } else {
                    Text(
                        "Google Maps key: not in this build. Put it in gradle.properties as MAPS_API_KEY=… and rebuild (see README > Map setup).",
                        color = Warn,
                        fontSize = 12.sp
                    )
                }

                Text("Model: Auto ✓", color = Accent, fontSize = 12.sp)
                Text(
                    "Auto switches models on its own: Gemini 3.5 Flash when you ask Novochron to build something, " +
                        "the faster 3.1 Flash Lite for everything else. Locked to Auto — no manual switch anymore.",
                    color = Dim,
                    fontSize = 12.sp
                )

                ToggleRow("Force offline (ignore the internet)", forceOffline) {
                    engine.setForceOffline(it)
                }
                Text(
                    "When on, Novochron never goes online even if it can: phone commands, memory, offline " +
                        "maps and the offline brain only. Turn off to let it use Gemini again whenever there's a connection.",
                    color = Dim,
                    fontSize = 12.sp
                )

                Text("Wake word", color = Dim, fontSize = 12.sp)
                ToggleRow("Wait for a wake word instead of always listening", wakeWordOn) {
                    engine.setWakeWordEnabled(it)
                }
                OutlinedTextField(
                    value = wakePhrase,
                    onValueChange = { wakePhrase = it },
                    singleLine = true,
                    placeholder = { Text("novochron", color = Dim, fontFamily = TermFont) },
                    colors = fieldColors(),
                    modifier = Modifier.fillMaxWidth()
                )
                Text(
                    "Say \"hey $wakePhrase\" (or just \"$wakePhrase\") to wake it up; it goes back to waiting " +
                        "after each reply, the same way \"Hey Google\" works. Used only as the fallback below, " +
                        "or whenever the dedicated engine can't run.",
                    color = Dim,
                    fontSize = 12.sp
                )

                Text("Low-power wake engine (Porcupine)", color = Dim, fontSize = 12.sp)
                Text(
                    if (dedicatedWakeReady)
                        "Ready: Novochron listens with a tiny dedicated keyword-spotting model, the same shape " +
                            "as \"Hey Google\" — it barely touches the battery while waiting. The typed phrase " +
                            "above is only used as a fallback if this engine fails to start."
                    else
                        "Not set up yet: without this, wake-word waits by reusing the full speech recognizer, " +
                            "which costs the same battery as Voice being on.",
                    color = if (dedicatedWakeReady) Accent else Dim,
                    fontSize = 12.sp
                )
                OutlinedTextField(
                    value = picovoiceKey,
                    onValueChange = { picovoiceKey = it },
                    singleLine = true,
                    label = { Text("Picovoice AccessKey (free, console.picovoice.ai)", color = Dim, fontSize = 11.sp) },
                    visualTransformation = PasswordVisualTransformation(),
                    colors = fieldColors(),
                    modifier = Modifier.fillMaxWidth()
                )
                if (customWakeFileFound) {
                    Text("Using custom word: Atlas/Models/wakeword.ppn", color = Accent, fontSize = 12.sp)
                } else {
                    Text("Built-in word (or drop a custom Atlas/Models/wakeword.ppn to override):", color = Dim, fontSize = 12.sp)
                    Row(
                        Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        PorcupineWake.BUILTINS.forEach { name ->
                            val selected = wakeBuiltin.equals(name, ignoreCase = true)
                            Box(
                                Modifier
                                    .clip(RoundedCornerShape(20.dp))
                                    .background(if (selected) Accent else Raised)
                                    .clickable { wakeBuiltin = name; engine.store.wakeEngineBuiltin = name }
                                    .padding(horizontal = 12.dp, vertical = 6.dp)
                            ) {
                                Text(name.lowercase().replace('_', ' '), color = if (selected) Color.Black else Ink, fontSize = 12.sp)
                            }
                        }
                    }
                }
                Text(
                    "Trained a different word for free at console.picovoice.ai? Drop its .ppn file in as " +
                        "Atlas/Models/wakeword.ppn and it's used automatically instead of the picker above.",
                    color = Dim,
                    fontSize = 12.sp
                )

                Text("Learned topics (“learn mathematics”, online only)", color = Dim, fontSize = 12.sp)
                if (learned.isEmpty()) {
                    Text("Nothing learned yet.", color = Dim, fontSize = 12.sp)
                } else {
                    learned.forEach { k ->
                        Row(
                            Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("• ${k.topic}", color = Ink, fontSize = 13.sp, modifier = Modifier.weight(1f))
                            TextButton(onClick = {
                                engine.store.deleteKnowledge(k.id)
                                learned = engine.store.knowledge()
                            }) { Text("remove", color = Warn, fontSize = 12.sp) }
                        }
                    }
                }
                Text(
                    "Say “learn <topic>” while online with an API key set; Novochron fetches compact reference notes " +
                        "and keeps them as plain text files in Atlas/Knowledge/ (one per topic, editable by hand) so " +
                        "it can use them offline afterward. Direct arithmetic (“what's 45 " +
                        "times 12”, “solve 2x+3=7”) always works offline with no learning needed.",
                    color = Dim,
                    fontSize = 12.sp
                )

                ToggleRow("Show the character behind the conversation", mascot) {
                    mascot = it
                    engine.setMascotOn(it)
                }
                Text(
                    "The line-art girl in the background: her drawn mouth moves while Novochron talks, and she does silly things when idle. Turn off to save a little battery.",
                    color = Dim,
                    fontSize = 12.sp
                )

                ToggleRow("Let me interrupt while Novochron talks", interrupt) {
                    interrupt = it
                    engine.store.interrupt = it
                }
                Text(
                    "Works best with headphones. On the phone speaker, Novochron may sometimes hear itself.",
                    color = Dim,
                    fontSize = 12.sp
                )

                Text(
                    "Online, Novochron speaks with a bright Gemini voice styled after an anime girl character. " +
                        "This slider only shapes the offline fallback voice (lower is deeper).",
                    color = Dim,
                    fontSize = 12.sp
                )
                Slider(
                    value = pitch,
                    onValueChange = { pitch = it; engine.store.pitch = it },
                    valueRange = 0.8f..1.6f,
                    colors = SliderDefaults.colors(thumbColor = Accent, activeTrackColor = Accent)
                )
                TextButton(onClick = { engine.say("Systems online. What do you need?") }) { Text("Test voice", color = Accent) }
                TextButton(onClick = onBattery) {
                    Text(if (batteryOk) "Background running: allowed" else "Keep Novochron running in the background", color = Accent)
                }
                TextButton(onClick = onOverlay) { Text("Allow opening apps from the background", color = Accent) }
                Text("Phone controls", color = Dim, fontSize = 12.sp)
                Text(
                    "Say “turn on Bluetooth”, “turn off Wi-Fi”, “turn up the volume”, “do not disturb on”. Novochron flips " +
                        "volume, silent mode, brightness, auto-rotate and Do Not Disturb itself. Android does not let any app " +
                        "flip Wi-Fi, mobile data, location or airplane mode, so for those Novochron opens the switch and you tap it.",
                    color = Dim,
                    fontSize = 12.sp
                )
                TextButton(onClick = { Controls.openWriteSettings(ctx) }) {
                    Text(if (writeOk) "Brightness and auto-rotate control: allowed" else "Allow brightness and auto-rotate control", color = Accent)
                }
                TextButton(onClick = { Controls.openDndAccess(ctx) }) {
                    Text(if (dndOk) "Do Not Disturb and silent mode: allowed" else "Allow Do Not Disturb and silent mode", color = Accent)
                }
                TextButton(onClick = { engine.clearChat() }) { Text("Clear chat history", color = Accent) }
                TextButton(onClick = { engine.store.clearMemories() }) { Text("Clear memory", color = Accent) }
                TextButton(onClick = { engine.store.clearKnowledge(); learned = emptyList() }) { Text("Clear learned topics", color = Accent) }
                TextButton(onClick = onStorage) {
                    Text(
                        if (storageOk) "Own folder: /storage/emulated/0/Atlas" else "Give Novochron its own folder on this phone",
                        color = Accent
                    )
                }
                if (!storageOk) {
                    Text(
                        "Without this, chat history and memory stay in the app's private storage, and Novochron can't see a model file in Atlas/Models.",
                        color = Dim,
                        fontSize = 12.sp
                    )
                }
                Text(About.summary(About.version(ctx)), color = Dim, fontSize = 12.sp)
                Text(
                    modelScan.describe(),
                    color = if (modelFound) Accent else Dim,
                    fontSize = 12.sp
                )
                Text(
                    "Camera, photos and screencast work online right away with your API key. Offline, they " +
                        "only work if the installed model supports images (a multimodal Gemma 3n build, not a " +
                        "text-only model) — otherwise Novochron will say so and look properly once you're back online.",
                    color = Dim,
                    fontSize = 12.sp
                )

                // Deliberately the very last thing in Settings — a password-encrypted photo (see
                // VaultCrypto.kt). The photo is only ever decoded to a bitmap in memory while
                // vaultPhoto is non-null; there's no plaintext copy of it in the APK or on disk.
                Spacer(Modifier.height(4.dp))
                Box(Modifier.fillMaxWidth().height(1.dp).background(Line))
                Spacer(Modifier.height(4.dp))
                Text("Vault (encrypted photo)", color = Dim, fontSize = 12.sp)
                if (vaultPhoto == null) {
                    OutlinedTextField(
                        value = vaultPasswordInput,
                        onValueChange = { vaultPasswordInput = it; vaultWrongPassword = false },
                        singleLine = true,
                        enabled = !vaultUnlocking,
                        placeholder = { Text("password", color = Dim, fontFamily = TermFont) },
                        visualTransformation = PasswordVisualTransformation(),
                        colors = fieldColors(),
                        modifier = Modifier.fillMaxWidth()
                    )
                    TextButton(
                        enabled = !vaultUnlocking && vaultPasswordInput.isNotEmpty(),
                        onClick = {
                            val attempt = vaultPasswordInput
                            vaultUnlocking = true
                            vaultWrongPassword = false
                            scope.launch {
                                // PBKDF2 + AES-GCM is real CPU work — off the main thread so the
                                // dialog doesn't freeze while it runs.
                                val bytes = withContext(Dispatchers.Default) {
                                    VaultCrypto.decryptVaultPhoto(ctx, R.raw.vault_photo, attempt)
                                }
                                val bmp = bytes?.let { BitmapFactory.decodeByteArray(it, 0, it.size) }
                                if (bmp != null) {
                                    vaultPhoto = bmp.asImageBitmap()
                                    vaultPasswordInput = ""
                                } else {
                                    vaultWrongPassword = true
                                }
                                vaultUnlocking = false
                            }
                        }
                    ) { Text(if (vaultUnlocking) "Unlocking…" else "Unlock", color = Accent, fontFamily = TermFont) }
                    if (vaultWrongPassword) {
                        Text("Incorrect password.", color = Warn, fontSize = 12.sp)
                    }
                } else {
                    Image(
                        bitmap = vaultPhoto!!,
                        contentDescription = "Vault photo",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(6.dp))
                    )
                    Text(
                        "Taken on the 10th of September, 2026.",
                        color = Ink,
                        fontSize = 12.sp
                    )
                    TextButton(onClick = {
                        // Drop the only in-memory reference to the decoded photo.
                        vaultPhoto = null
                        vaultPasswordInput = ""
                    }) { Text("Lock", color = Accent, fontFamily = TermFont) }
                }
            }
        }
        },
        confirmButton = {
            TextButton(onClick = {
                engine.store.wakeWordPhrase = wakePhrase
                engine.store.picovoiceAccessKey = picovoiceKey
                onDismiss()
            }) { Text("Save", color = Accent, fontFamily = TermFont) }
        }
    )

    if (confirmClearPhotos) {
        AlertDialog(
            onDismissRequest = { confirmClearPhotos = false },
            containerColor = Color(0xFF0B0B0B),
            title = { Text("[ clear photos ]", color = Warn, fontFamily = TermFont, fontWeight = FontWeight.Bold) },
            text = {
                Text(
                    "Delete every photo in Atlas/Photos (camera shots, gallery picks and screen frames)? " +
                        "Photos shown in the chat will stop appearing. This can't be undone.",
                    color = Ink,
                    fontFamily = TermFont,
                    fontSize = 13.sp
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    confirmClearPhotos = false
                    scope.launch {
                        val n = withContext(Dispatchers.IO) { AtlasStorage.clearPhotos(ctx) }
                        photoMsg = when {
                            n == 0 -> "No photos found to delete."
                            n == 1 -> "Deleted 1 photo."
                            else -> "Deleted $n photos."
                        }
                        if (!AtlasStorage.hasAccess()) {
                            photoMsg += " Atlas/Photos needs \"All files access\" (button below) before it can be cleared."
                        }
                        photoTick++
                    }
                }) { Text("Delete", color = Warn, fontFamily = TermFont) }
            },
            dismissButton = {
                TextButton(onClick = { confirmClearPhotos = false }) { Text("Cancel", color = Ink, fontFamily = TermFont) }
            }
        )
    }
}

private fun humanBytes(bytes: Long): String = when {
    bytes >= 1_048_576L -> String.format(java.util.Locale.US, "%.1f MB", bytes / 1_048_576.0)
    bytes >= 1024L -> "${bytes / 1024} KB"
    else -> "$bytes B"
}
