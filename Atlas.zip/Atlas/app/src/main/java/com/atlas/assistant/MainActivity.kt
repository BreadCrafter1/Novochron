package com.atlas.assistant

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.LocalTextStyle
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import java.io.File
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

// Termux-style terminal theme: black surfaces, phosphor-green text, sharp corners, monospace.
val Accent = Color(0xFFF2F2F2)        // bright terminal white — prompts, borders, primary actions
val Ink = Color(0xFFD8D8D8)           // body text — soft white, easy to read, not as hot as Accent
val Dim = Color(0xFF8A8A8A)           // secondary/status text — muted gray
val Line = Color(0xFF2A2A2A)          // hairline borders
val CardBg = Color(0xFF000000)        // pure black, log lines sit directly on it
val Raised = Color(0xFF141414)        // slightly raised panel, still near-black
val Warn = Color(0xFFFF5C5C)          // recording / active-danger accent (live scan, screencast, wake armed)
val TermFont = FontFamily.Monospace
private const val CURSOR = "█"

class MainActivity : ComponentActivity() {

    private val permLauncher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) startVoice()
        else AssistantState.status.value = "Microphone permission is required"
    }

    private val cameraPermLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) AssistantState.cameraOpen.value = true
        else AssistantState.status.value = "Camera permission is required"
    }

    private val photoPickerLauncher = registerForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri == null) return@registerForActivityResult
        val bmp = Vision.fromUri(this, uri)
        if (bmp != null) Engine.get(this).submitPhoto(bmp, "")
        else AssistantState.status.value = "Couldn't open that photo."
    }

    private val screenCaptureLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == Activity.RESULT_OK && result.data != null) {
            val intent = Intent(this, ScreenCastService::class.java)
                .putExtra(ScreenCastService.EXTRA_RESULT_CODE, result.resultCode)
                .putExtra(ScreenCastService.EXTRA_DATA, result.data)
            ContextCompat.startForegroundService(this, intent)
        } else {
            AssistantState.status.value = "Screencast permission was declined."
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val engine = Engine.get(this)
        setContent {
            NovochronApp(
                engine,
                onToggle = { toggleVoice(it) },
                onOverlay = { openOverlaySettings() },
                onBattery = { requestBatteryExemption() },
                onStorage = { requestStorageAccess() },
                onOpenCamera = { openCamera() },
                onPickPhoto = { pickPhoto() },
                onToggleScreencast = { toggleScreencast(it) }
            )
        }
    }

    private fun openCamera() {
        if (checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
            AssistantState.cameraOpen.value = true
        } else {
            cameraPermLauncher.launch(Manifest.permission.CAMERA)
        }
    }

    private fun pickPhoto() {
        photoPickerLauncher.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
    }

    /** Turning screencast on asks Android's system "start recording your screen?" dialog once. */
    private fun toggleScreencast(on: Boolean) {
        if (on) {
            val mgr = getSystemService(MediaProjectionManager::class.java)
            screenCaptureLauncher.launch(mgr.createScreenCaptureIntent())
        } else {
            startService(Intent(this, ScreenCastService::class.java).setAction(ScreenCastService.ACTION_STOP))
        }
    }

    override fun onStart() {
        super.onStart()
        AssistantState.appVisible = true
    }

    override fun onStop() {
        super.onStop()
        AssistantState.appVisible = false
    }

    private fun toggleVoice(on: Boolean) {
        if (!on) {
            startService(Intent(this, AssistantService::class.java).setAction(AssistantService.ACTION_STOP))
            return
        }
        val wanted = buildList {
            add(Manifest.permission.RECORD_AUDIO)
            if (Build.VERSION.SDK_INT >= 33) add(Manifest.permission.POST_NOTIFICATIONS)
            add(Manifest.permission.CALL_PHONE)
            add(Manifest.permission.READ_CONTACTS)
            add(Manifest.permission.SEND_SMS)
            add(Manifest.permission.ACCESS_FINE_LOCATION)
            add(Manifest.permission.ACCESS_COARSE_LOCATION)
            if (Build.VERSION.SDK_INT >= 31) add(Manifest.permission.BLUETOOTH_CONNECT)
            if (Build.VERSION.SDK_INT < 30) add(Manifest.permission.WRITE_EXTERNAL_STORAGE)
        }.filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (wanted.isEmpty()) startVoice() else permLauncher.launch(wanted.toTypedArray())
    }

    private fun startVoice() {
        ContextCompat.startForegroundService(this, Intent(this, AssistantService::class.java))
        askBatteryOnce()
    }

    /** Background listening survives much better when the battery saver is told to leave Novochron alone. */
    private fun askBatteryOnce() {
        val store = Store.get(this)
        val pm = getSystemService(PowerManager::class.java)
        if (store.batteryAsked || pm.isIgnoringBatteryOptimizations(packageName)) return
        store.batteryAsked = true
        requestBatteryExemption()
    }

    @SuppressLint("BatteryLife")
    private fun requestBatteryExemption() {
        try {
            startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
        } catch (e: Exception) {
            try {
                startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
            } catch (e2: Exception) {
                // no settings screen available on this phone
            }
        }
    }

    private fun openOverlaySettings() {
        startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
    }

    /** Lets the user grant "All files access" so Novochron's data lives in its own visible folder at /storage/emulated/0/Atlas. */
    private fun requestStorageAccess() {
        if (Build.VERSION.SDK_INT < 30) return // handled by the normal WRITE_EXTERNAL_STORAGE runtime permission above
        try {
            startActivity(AtlasStorage.requestAccessIntent(this))
        } catch (e: Exception) {
            try {
                startActivity(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION))
            } catch (e2: Exception) {
                // no settings screen available on this phone
            }
        }
    }
}

/** Walks ContextWrapper layers to find the hosting Activity, since a Compose LocalContext is often wrapped. */
fun android.content.Context.findActivity(): Activity? {
    var c = this
    while (c is android.content.ContextWrapper) {
        if (c is Activity) return c
        c = c.baseContext
    }
    return null
}

@Composable
fun fieldColors() = OutlinedTextFieldDefaults.colors(
    focusedTextColor = Ink,
    unfocusedTextColor = Ink,
    focusedBorderColor = Color.Transparent,
    unfocusedBorderColor = Color.Transparent,
    cursorColor = Accent,
    focusedContainerColor = Color.Black,
    unfocusedContainerColor = Color.Black
)

@Composable
fun switchColors() = SwitchDefaults.colors(
    checkedThumbColor = Color.Black,
    checkedTrackColor = Accent,
    uncheckedThumbColor = Dim,
    uncheckedTrackColor = Raised
)

@Composable
fun NovochronApp(
    engine: Engine,
    onToggle: (Boolean) -> Unit,
    onOverlay: () -> Unit,
    onBattery: () -> Unit,
    onStorage: () -> Unit,
    onOpenCamera: () -> Unit,
    onPickPhoto: () -> Unit,
    onToggleScreencast: (Boolean) -> Unit
) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Accent,
            onPrimary = Color.Black,
            background = Color.Black,
            surface = Color.Black,
            onSurface = Ink,
            onBackground = Ink
        )
    ) {
        val openId by AssistantState.openArtifact.collectAsState()
        val open = remember(openId) { if (openId > 0) engine.store.artifact(openId) else null }
        val cameraOpen by AssistantState.cameraOpen.collectAsState()
        val showMap by AssistantState.showMap.collectAsState()
        val exitRequested by AssistantState.exitRequested.collectAsState()
        val localCtx = LocalContext.current
        LaunchedEffect(exitRequested) {
            if (exitRequested) localCtx.findActivity()?.finishAndRemoveTask()
        }
        if (cameraOpen) {
            CameraScreen(engine) { AssistantState.cameraOpen.value = false }
        } else if (showMap) {
            MapScreen(engine) { AssistantState.showMap.value = false }
        } else if (open != null) {
            ArtifactScreen(open) { AssistantState.openArtifact.value = 0 }
        } else {
            MainScreen(engine, onToggle, onOverlay, onBattery, onStorage, onOpenCamera, onPickPhoto, onToggleScreencast)
        }
    }
}

@Composable
fun MainScreen(
    engine: Engine,
    onToggle: (Boolean) -> Unit,
    onOverlay: () -> Unit,
    onBattery: () -> Unit,
    onStorage: () -> Unit,
    onOpenCamera: () -> Unit,
    onPickPhoto: () -> Unit,
    onToggleScreencast: (Boolean) -> Unit
) {
    val messages by AssistantState.messages.collectAsState()
    val voiceOn by AssistantState.voiceOn.collectAsState()
    val status by AssistantState.status.collectAsState()
    val heard by AssistantState.heard.collectAsState()
    val showLibrary by AssistantState.showLibrary.collectAsState()
    val forceOffline by AssistantState.forceOffline.collectAsState()
    val screencastOn by AssistantState.screencastOn.collectAsState()
    val wakeWordOn by AssistantState.wakeWordOn.collectAsState()
    var input by remember { mutableStateOf("") }
    var showSettings by remember { mutableStateOf(false) }
    val listState = rememberLazyListState()
    val isLandscape = LocalConfiguration.current.orientation == Configuration.ORIENTATION_LANDSCAPE

    LaunchedEffect(messages.size) {
        if (messages.isNotEmpty()) listState.animateScrollToItem(messages.size - 1)
    }

    fun send() {
        if (input.isNotBlank()) {
            engine.submit(input)
            input = ""
        }
    }

    Column(Modifier.fillMaxSize().background(Color.Black).padding(if (isLandscape) 10.dp else 16.dp)) {
        // Everything except the input line lives up here — a Termux-style top strip — so the log
        // below gets the full width and height of the screen instead of being squeezed by controls.
        TermHeaderBar(
            onLibrary = { AssistantState.showLibrary.value = true },
            onMap = { AssistantState.showMap.value = true },
            onSettings = { showSettings = true },
            onExit = { engine.requestExit(announce = false) }
        )
        TopControlStrip(
            engine = engine,
            voiceOn = voiceOn,
            status = status,
            heard = heard,
            forceOffline = forceOffline,
            wakeWordOn = wakeWordOn,
            onToggle = onToggle,
            onOpenCamera = onOpenCamera,
            onPickPhoto = onPickPhoto,
            screencastOn = screencastOn,
            onToggleScreencast = onToggleScreencast
        )

        MessageLog(messages, listState, Modifier.weight(1f).fillMaxWidth().padding(top = 8.dp))
        if (screencastOn) ScreencastHint()
        InputBar(input, { input = it }, ::send)
    }

    if (showSettings) SettingsDialog(engine, onOverlay, onBattery, onStorage) { showSettings = false }
    if (showLibrary) {
        LibraryDialog(
            engine,
            onOpen = { AssistantState.openArtifact.value = it },
            onDismiss = { AssistantState.showLibrary.value = false }
        )
    }
}

@Composable
fun TermHeaderBar(onLibrary: () -> Unit, onMap: () -> Unit, onSettings: () -> Unit, onExit: () -> Unit) {
    var confirmExit by remember { mutableStateOf(false) }
    Row(
        Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(
            "root@novochron:~$",
            color = Accent,
            fontFamily = TermFont,
            fontSize = 16.sp,
            fontWeight = FontWeight.Bold,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.weight(1f, fill = false)
        )
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            HeaderChip("lib", onLibrary)
            HeaderChip("map", onMap)
            HeaderChip("set", onSettings)
            Spacer(Modifier.width(8.dp))
            PowerButton { confirmExit = true }
        }
    }
    if (confirmExit) {
        AlertDialog(
            onDismissRequest = { confirmExit = false },
            containerColor = Color(0xFF060606),
            title = { Text("[ shut down ]", color = Warn, fontFamily = TermFont, fontWeight = FontWeight.Bold) },
            text = { Text("Close Novochron completely? Voice and background listening will stop.", color = Ink, fontFamily = TermFont, fontSize = 13.sp) },
            confirmButton = {
                TextButton(onClick = { confirmExit = false; onExit() }) { Text("Turn off", color = Warn, fontFamily = TermFont) }
            },
            dismissButton = {
                TextButton(onClick = { confirmExit = false }) { Text("Cancel", color = Ink, fontFamily = TermFont) }
            }
        )
    }
}

@Composable
fun HeaderChip(label: String, onClick: () -> Unit) {
    Box(
        Modifier
            .clip(RoundedCornerShape(2.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 9.dp, vertical = 5.dp)
    ) {
        Text("[$label]", color = Ink, fontFamily = TermFont, fontSize = 12.sp)
    }
}

/** A dedicated, unmistakable shutdown control — plain red glyph, larger than surrounding text so it's not missed. */
@Composable
fun PowerButton(onClick: () -> Unit) {
    Box(
        Modifier
            .clickable(onClick = onClick)
            .padding(horizontal = 6.dp, vertical = 5.dp)
    ) {
        Text("⏻", color = Warn, fontFamily = TermFont, fontWeight = FontWeight.Bold, fontSize = 16.sp)
    }
}

/** Plain-text tap-to-toggle used in the compact top strip — bracketed and bright when on, dim when off. */
@Composable
fun ToggleChip(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Box(
        Modifier
            .clickable { onChange(!checked) }
            .padding(horizontal = 6.dp, vertical = 6.dp)
    ) {
        Text(
            if (checked) "[$label]" else label,
            color = if (checked) Accent else Dim,
            fontFamily = TermFont,
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold
        )
    }
}

/**
 * Everything that used to sit in a tall column above the log (status box, voice/online/wake toggles,
 * camera/photo/screencast actions) condensed into one horizontally-scrollable strip plus a single status
 * line, so the message log below gets a wide, long view of the conversation instead of being pushed down.
 */
@Composable
fun TopControlStrip(
    engine: Engine,
    voiceOn: Boolean,
    status: String,
    heard: String,
    forceOffline: Boolean,
    wakeWordOn: Boolean,
    onToggle: (Boolean) -> Unit,
    onOpenCamera: () -> Unit,
    onPickPhoto: () -> Unit,
    screencastOn: Boolean,
    onToggleScreencast: (Boolean) -> Unit
) {
    Column(Modifier.fillMaxWidth().padding(top = 6.dp)) {
        Row(
            Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            TermStatusBox(voiceOn, size = 40.dp, onClick = { onToggle(!voiceOn) })
            ToggleChip("voice", voiceOn, onToggle)
            ToggleChip("online", !forceOffline) { engine.setForceOffline(!it) }
            ToggleChip("wake", wakeWordOn) { engine.setWakeWordEnabled(it) }
            Spacer(Modifier.width(4.dp))
            IconTextButton("cam", onClick = onOpenCamera)
            IconTextButton("img", onClick = onPickPhoto)
            IconTextButton(if (screencastOn) "stop" else "cast", active = screencastOn) { onToggleScreencast(!screencastOn) }
        }
        Spacer(Modifier.height(4.dp))
        Text(
            if (voiceOn && heard.isNotEmpty()) "\u201c$heard\u201d" else status,
            color = Dim,
            fontFamily = TermFont,
            fontSize = 12.sp,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
        if (forceOffline) {
            Text(
                "# offline: commands, memory + learned notes only",
                color = Dim,
                fontFamily = TermFont,
                fontSize = 11.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
        if (wakeWordOn) {
            Text(
                "# say \u201c${engine.store.wakeWordPhrase}\u201d to wake it up",
                color = Dim,
                fontFamily = TermFont,
                fontSize = 11.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
fun ScreencastHint() {
    Text(
        "# watching your screen — ask about what's on it any time",
        color = Warn,
        fontFamily = TermFont,
        fontSize = 11.sp,
        modifier = Modifier.padding(top = 4.dp)
    )
}

@Composable
fun MessageLog(messages: List<Msg>, listState: LazyListState, modifier: Modifier) {
    if (messages.isEmpty()) {
        Box(modifier, contentAlignment = Alignment.Center) {
            Text(
                "# turn voice on (or say the wake word) and just talk\n" +
                    "# you can interrupt me any time\n\n" +
                    "try: “make me a sudoku puzzle”\n“build a tip calculator”\n“open YouTube”\n" +
                    "“set an alarm for 6:30 AM”\n“call Mom”\n“learn mathematics”",
                color = Dim,
                fontFamily = TermFont,
                fontSize = 13.sp,
                lineHeight = 20.sp
            )
        }
    } else {
        LazyColumn(state = listState, modifier = modifier, verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(messages, key = { it.id }) { m ->
                Bubble(m) { id -> AssistantState.openArtifact.value = id }
            }
        }
    }
}

@Composable
fun InputBar(input: String, onInputChange: (String) -> Unit, onSend: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Text("$", color = Accent, fontFamily = TermFont, fontSize = 18.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.width(6.dp))
        OutlinedTextField(
            value = input,
            onValueChange = onInputChange,
            modifier = Modifier.weight(1f),
            placeholder = { Text("type a command…", color = Dim, fontFamily = TermFont) },
            textStyle = TextStyle(fontFamily = TermFont, color = Ink, fontSize = 15.sp),
            singleLine = true,
            shape = RoundedCornerShape(2.dp),
            colors = fieldColors(),
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
            keyboardActions = KeyboardActions(onSend = { onSend() })
        )
        Spacer(Modifier.width(8.dp))
        Text(
            "RUN",
            color = Accent,
            fontFamily = TermFont,
            fontWeight = FontWeight.Bold,
            fontSize = 15.sp,
            modifier = Modifier.clickable(onClick = onSend).padding(horizontal = 4.dp, vertical = 8.dp)
        )
    }
}

/** A blinking text indicator instead of a boxed status light — reads LIVE or OFF, no fill. */
@Composable
fun TermStatusBox(active: Boolean, size: Dp = 84.dp, onClick: () -> Unit) {
    val transition = rememberInfiniteTransition(label = "blink")
    val alpha by transition.animateFloat(
        initialValue = if (active) 1f else 0.4f,
        targetValue = if (active) 0.55f else 0.9f,
        animationSpec = infiniteRepeatable(animation = tween(700), repeatMode = RepeatMode.Reverse),
        label = "blinkAlpha"
    )
    val compact = size < 60.dp
    Box(
        modifier = Modifier.clickable(onClick = onClick).padding(horizontal = 6.dp, vertical = 6.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            if (active) "LIVE" else "OFF",
            color = (if (active) Accent else Dim).copy(alpha = alpha),
            fontFamily = TermFont,
            fontWeight = FontWeight.Bold,
            fontSize = if (compact) 11.sp else 15.sp,
            letterSpacing = if (compact) 0.sp else 1.sp
        )
    }
}

@Composable
fun IconTextButton(label: String, active: Boolean = false, onClick: () -> Unit) {
    Box(
        Modifier
            .clickable(onClick = onClick)
            .padding(horizontal = 8.dp, vertical = 8.dp)
    ) {
        Text("[$label]", color = if (active) Warn else Ink, fontFamily = TermFont, fontSize = 13.sp)
    }
}

/**
 * Terminal-log style: no chat bubbles, just left-aligned "you $ ..." / "novochron > ..." lines with a
 * thin divider, the way a shell session scrolls.
 */
@Composable
fun Bubble(m: Msg, onOpen: (Long) -> Unit) {
    val user = m.role == "user"
    val prompt = if (user) "you $" else "novochron >"
    val promptColor = if (user) Ink else Accent
    Column(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 10.dp, vertical = 8.dp)
    ) {
        Text(prompt, color = promptColor, fontFamily = TermFont, fontWeight = FontWeight.Bold, fontSize = 12.sp)
        Spacer(Modifier.height(2.dp))
        if (m.imagePath.isNotEmpty()) {
            val bmp = remember(m.imagePath) { Vision.loadBitmap(m.imagePath)?.asImageBitmap() }
            bmp?.let {
                Image(
                    bitmap = it,
                    contentDescription = null,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(2.dp))
                )
                Spacer(Modifier.height(6.dp))
            }
        }
        if (m.text.isNotEmpty() && m.text != "[photo]") {
            Text(m.text, color = Ink, fontFamily = TermFont, fontSize = 14.sp, lineHeight = 19.sp)
        }
        if (m.artifactId > 0 && m.artifactTitle.isNotEmpty()) {
            Spacer(Modifier.height(8.dp))
            Row(
                Modifier
                    .clickable { onOpen(m.artifactId) }
                    .padding(vertical = 2.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    "> run ${m.artifactTitle}",
                    color = Accent,
                    fontFamily = TermFont,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp
                )
            }
        }
    }
}

@Composable
fun ToggleRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, color = Ink, fontSize = 15.sp, modifier = Modifier.weight(1f))
        Switch(checked = checked, onCheckedChange = onChange, colors = switchColors())
    }
}

@Composable
fun SettingsDialog(engine: Engine, onOverlay: () -> Unit, onBattery: () -> Unit, onStorage: () -> Unit, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    var key by remember { mutableStateOf(engine.store.apiKey) }
    var pitch by remember { mutableFloatStateOf(engine.store.pitch) }
    var interrupt by remember { mutableStateOf(engine.store.interrupt) }
    var mode by remember { mutableStateOf(engine.store.modelMode) }
    var wakePhrase by remember { mutableStateOf(engine.store.wakeWordPhrase) }
    var picovoiceKey by remember { mutableStateOf(engine.store.picovoiceAccessKey) }
    var wakeBuiltin by remember { mutableStateOf(engine.store.wakeEngineBuiltin) }
    val forceOffline by AssistantState.forceOffline.collectAsState()
    val wakeWordOn by AssistantState.wakeWordOn.collectAsState()
    var learned by remember { mutableStateOf(engine.store.knowledge()) }
    // Re-checked every couple of seconds while Settings is open, so dropping a model file in (or granting
    // "All files access") shows up here without closing and reopening anything.
    var modelScan by remember { mutableStateOf(LocalLlm.scan(ctx)) }
    var storageOk by remember { mutableStateOf(AtlasStorage.hasAccess()) }
    LaunchedEffect(Unit) {
        while (true) {
            delay(2000)
            val (scan, access) = withContext(Dispatchers.IO) {
                if (AtlasStorage.hasAccess()) AtlasStorage.ensureDirs()
                LocalLlm.scan(ctx) to AtlasStorage.hasAccess()
            }
            modelScan = scan
            storageOk = access
        }
    }
    val modelFound = modelScan.found
    val customWakeFileFound = File(AtlasStorage.modelsDir(), "wakeword.ppn").exists()
    val dedicatedWakeReady = picovoiceKey.isNotBlank() && (customWakeFileFound || PorcupineWake.BUILTINS.contains(wakeBuiltin))
    val batteryOk = ctx.getSystemService(PowerManager::class.java)?.isIgnoringBatteryOptimizations(ctx.packageName) == true
    val writeOk = Controls.canWriteSettings(ctx)
    val dndOk = Controls.hasDndAccess(ctx)

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Color(0xFF060606),
        title = { Text("[ settings ]", color = Accent, fontFamily = TermFont, fontWeight = FontWeight.Bold) },
        text = {
        CompositionLocalProvider(LocalTextStyle provides LocalTextStyle.current.copy(fontFamily = TermFont)) {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Gemini API key (online brain and voice)", color = Dim, fontSize = 12.sp)
                OutlinedTextField(
                    value = key,
                    onValueChange = { key = it },
                    singleLine = true,
                    visualTransformation = PasswordVisualTransformation(),
                    colors = fieldColors()
                )
                // The Maps key is baked in at build time (it can't be typed in here) - this just shows whether it's in.
                if (MapsKey.isConfigured(ctx)) {
                    Text("Google Maps key: included in this build ✓", color = Accent, fontSize = 12.sp)
                } else {
                    Text(
                        "Google Maps key: not in this build. Put it in gradle.properties as MAPS_API_KEY=… and rebuild (see README > Map setup).",
                        color = Warn,
                        fontSize = 12.sp
                    )
                }

                Text("Model", color = Dim, fontSize = 12.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                    listOf("auto" to "Auto", "fast" to "Fast", "smart" to "Smart").forEach { (k, label) ->
                        val selected = mode == k
                        Box(
                            Modifier
                                .clickable { mode = k; engine.store.modelMode = k }
                                .padding(vertical = 6.dp)
                        ) {
                            Text(
                                if (selected) "[$label]" else label,
                                color = if (selected) Accent else Ink,
                                fontFamily = TermFont,
                                fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
                                fontSize = 13.sp
                            )
                        }
                    }
                }
                Text(
                    "Auto uses Gemini 3.5 Flash when you ask Novochron to build something, and the faster 3.1 Flash Lite for everything else.",
                    color = Dim,
                    fontSize = 12.sp
                )

                ToggleRow("Force offline (ignore the internet)", forceOffline) {
                    engine.setForceOffline(it)
                }
                Text(
                    "When on, Novochron never goes online even if it can: phone commands, memory, offline " +
                        "maps and the offline brain only. Turn off to let it use Gemini again whenever there's a connection.",
                    color = Dim,
                    fontSize = 12.sp
                )

                Text("Wake word", color = Dim, fontSize = 12.sp)
                ToggleRow("Wait for a wake word instead of always listening", wakeWordOn) {
                    engine.setWakeWordEnabled(it)
                }
                OutlinedTextField(
                    value = wakePhrase,
                    onValueChange = { wakePhrase = it },
                    singleLine = true,
                    placeholder = { Text("novochron", color = Dim, fontFamily = TermFont) },
                    colors = fieldColors(),
                    modifier = Modifier.fillMaxWidth()
                )
                Text(
                    "Say \"hey $wakePhrase\" (or just \"$wakePhrase\") to wake it up; it goes back to waiting " +
                        "after each reply, the same way \"Hey Google\" works. Used only as the fallback below, " +
                        "or whenever the dedicated engine can't run.",
                    color = Dim,
                    fontSize = 12.sp
                )

                Text("Low-power wake engine (Porcupine)", color = Dim, fontSize = 12.sp)
                Text(
                    if (dedicatedWakeReady)
                        "Ready: Novochron listens with a tiny dedicated keyword-spotting model, the same shape " +
                            "as \"Hey Google\" — it barely touches the battery while waiting. The typed phrase " +
                            "above is only used as a fallback if this engine fails to start."
                    else
                        "Not set up yet: without this, wake-word waits by reusing the full speech recognizer, " +
                            "which costs the same battery as Voice being on.",
                    color = if (dedicatedWakeReady) Accent else Dim,
                    fontSize = 12.sp
                )
                OutlinedTextField(
                    value = picovoiceKey,
                    onValueChange = { picovoiceKey = it },
                    singleLine = true,
                    label = { Text("Picovoice AccessKey (free, console.picovoice.ai)", color = Dim, fontSize = 11.sp) },
                    visualTransformation = PasswordVisualTransformation(),
                    colors = fieldColors(),
                    modifier = Modifier.fillMaxWidth()
                )
                if (customWakeFileFound) {
                    Text("Using custom word: Atlas/Models/wakeword.ppn", color = Accent, fontSize = 12.sp)
                } else {
                    Text("Built-in word (or drop a custom Atlas/Models/wakeword.ppn to override):", color = Dim, fontSize = 12.sp)
                    Row(
                        Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        PorcupineWake.BUILTINS.forEach { name ->
                            val selected = wakeBuiltin.equals(name, ignoreCase = true)
                            val label = name.lowercase().replace('_', ' ')
                            Box(
                                Modifier
                                    .clickable { wakeBuiltin = name; engine.store.wakeEngineBuiltin = name }
                                    .padding(vertical = 6.dp)
                            ) {
                                Text(
                                    if (selected) "[$label]" else label,
                                    color = if (selected) Accent else Ink,
                                    fontFamily = TermFont,
                                    fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
                                    fontSize = 12.sp
                                )
                            }
                        }
                    }
                }
                Text(
                    "Trained a different word for free at console.picovoice.ai? Drop its .ppn file in as " +
                        "Atlas/Models/wakeword.ppn and it's used automatically instead of the picker above.",
                    color = Dim,
                    fontSize = 12.sp
                )

                Text("Learned topics (“learn mathematics”, online only)", color = Dim, fontSize = 12.sp)
                if (learned.isEmpty()) {
                    Text("Nothing learned yet.", color = Dim, fontSize = 12.sp)
                } else {
                    learned.forEach { k ->
                        Row(
                            Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("• ${k.topic}", color = Ink, fontSize = 13.sp, modifier = Modifier.weight(1f))
                            TextButton(onClick = {
                                engine.store.deleteKnowledge(k.id)
                                learned = engine.store.knowledge()
                            }) { Text("remove", color = Warn, fontSize = 12.sp) }
                        }
                    }
                }
                Text(
                    "Say “learn <topic>” while online with an API key set; Novochron fetches compact reference notes " +
                        "and keeps them as plain text files in Atlas/Knowledge/ (one per topic, editable by hand) so " +
                        "it can use them offline afterward. Direct arithmetic (“what's 45 " +
                        "times 12”, “solve 2x+3=7”) always works offline with no learning needed.",
                    color = Dim,
                    fontSize = 12.sp
                )

                ToggleRow("Let me interrupt while Novochron talks", interrupt) {
                    interrupt = it
                    engine.store.interrupt = it
                }
                Text(
                    "Works best with headphones. On the phone speaker, Novochron may sometimes hear itself.",
                    color = Dim,
                    fontSize = 12.sp
                )

                Text(
                    "Online, Novochron speaks with a bright Gemini voice styled after an anime girl character. " +
                        "This slider only shapes the offline fallback voice (lower is deeper).",
                    color = Dim,
                    fontSize = 12.sp
                )
                Slider(
                    value = pitch,
                    onValueChange = { pitch = it; engine.store.pitch = it },
                    valueRange = 0.8f..1.6f,
                    colors = SliderDefaults.colors(thumbColor = Accent, activeTrackColor = Accent)
                )
                TextButton(onClick = { engine.say("Systems online. What do you need?") }) { Text("Test voice", color = Accent) }
                TextButton(onClick = onBattery) {
                    Text(if (batteryOk) "Background running: allowed" else "Keep Novochron running in the background", color = Accent)
                }
                TextButton(onClick = onOverlay) { Text("Allow opening apps from the background", color = Accent) }
                Text("Phone controls", color = Dim, fontSize = 12.sp)
                Text(
                    "Say “turn on Bluetooth”, “turn off Wi-Fi”, “turn up the volume”, “do not disturb on”. Novochron flips " +
                        "volume, silent mode, brightness, auto-rotate and Do Not Disturb itself. Android does not let any app " +
                        "flip Wi-Fi, mobile data, location or airplane mode, so for those Novochron opens the switch and you tap it.",
                    color = Dim,
                    fontSize = 12.sp
                )
                TextButton(onClick = { Controls.openWriteSettings(ctx) }) {
                    Text(if (writeOk) "Brightness and auto-rotate control: allowed" else "Allow brightness and auto-rotate control", color = Accent)
                }
                TextButton(onClick = { Controls.openDndAccess(ctx) }) {
                    Text(if (dndOk) "Do Not Disturb and silent mode: allowed" else "Allow Do Not Disturb and silent mode", color = Accent)
                }
                TextButton(onClick = { engine.clearChat() }) { Text("Clear chat history", color = Accent) }
                TextButton(onClick = { engine.store.clearMemories() }) { Text("Clear memory", color = Accent) }
                TextButton(onClick = { engine.store.clearKnowledge(); learned = emptyList() }) { Text("Clear learned topics", color = Accent) }
                TextButton(onClick = onStorage) {
                    Text(
                        if (storageOk) "Own folder: /storage/emulated/0/Atlas" else "Give Novochron its own folder on this phone",
                        color = Accent
                    )
                }
                if (!storageOk) {
                    Text(
                        "Without this, chat history and memory stay in the app's private storage, and Novochron can't see a model file in Atlas/Models.",
                        color = Dim,
                        fontSize = 12.sp
                    )
                }
                Text(About.summary(About.version(ctx)), color = Dim, fontSize = 12.sp)
                Text(
                    modelScan.describe(),
                    color = if (modelFound) Accent else Dim,
                    fontSize = 12.sp
                )
                Text(
                    "Camera, photos and screencast work online right away with your API key. Offline, they " +
                        "only work if the installed model supports images (a multimodal Gemma 3n build, not a " +
                        "text-only model) — otherwise Novochron will say so and look properly once you're back online.",
                    color = Dim,
                    fontSize = 12.sp
                )
            }
        }
        },
        confirmButton = {
            TextButton(onClick = {
                engine.store.apiKey = key.trim()
                engine.store.wakeWordPhrase = wakePhrase
                engine.store.picovoiceAccessKey = picovoiceKey
                onDismiss()
            }) { Text("Save", color = Accent, fontFamily = TermFont) }
        }
    )
}
