package com.atlas.assistant

import android.content.res.Configuration
import android.location.Location
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.roundToInt
import java.util.Locale

/**
 * Novochron's own themed "map": not downloaded street tiles (no API key, no network needed, works
 * fully offline anywhere), but a radar-style plot centred on the phone's last known GPS fix, drawn in
 * the same green-on-black terminal style as the rest of the app. Saved places (see [Maps]) show up as
 * dots; tapping anywhere drops a pin, and Novochron works out that point's real-world lat/lon from
 * where you tapped (using the same on-screen scale the grid and place dots use) and reports the
 * straight-line distance from here with the same haversine math it already uses for "how far is home".
 * Supports both portrait (map above, details below) and landscape (map beside details).
 */
@Composable
fun MapScreen(engine: Engine, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val maps = remember { Maps.get(ctx) }
    var places by remember { mutableStateOf(maps.places()) }
    var here by remember { mutableStateOf(maps.currentLocation()) }
    // lat, lon of the dropped pin
    var pin by remember { mutableStateOf<Pair<Double, Double>?>(null) }
    var pinLabel by remember { mutableStateOf("") }
    var zoomKm by remember { mutableFloatStateOf(2f) } // half-width of the visible plot, in km
    var savedFlash by remember { mutableStateOf(false) }
    val isLandscape = LocalConfiguration.current.orientation == Configuration.ORIENTATION_LANDSCAPE

    LaunchedEffect(Unit) {
        maps.start()
        while (true) {
            here = maps.currentLocation()
            delay(4000)
        }
    }
    LaunchedEffect(savedFlash) {
        if (savedFlash) { delay(1200); savedFlash = false }
    }

    Column(
        Modifier
            .fillMaxSize()
            .background(Color.Black)
            .padding(horizontal = if (isLandscape) 10.dp else 16.dp, vertical = 12.dp)
    ) {
        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("[ map ]", color = Accent, fontFamily = TermFont, fontWeight = FontWeight.Bold, fontSize = 18.sp)
            TextButton(onClick = onClose) { Text("[close]", color = Ink, fontFamily = TermFont, fontSize = 13.sp) }
        }
        Spacer(Modifier.height(8.dp))

        val canvasBlock: @Composable (Modifier) -> Unit = { mod ->
            MapCanvas(
                here = here,
                places = places,
                pin = pin,
                zoomKm = zoomKm,
                modifier = mod
            ) { lat, lon -> pin = lat to lon }
        }
        val sidebarBlock: @Composable (Modifier) -> Unit = { mod ->
            MapSidebar(
                modifier = mod,
                maps = maps,
                here = here,
                pin = pin,
                pinLabel = pinLabel,
                onPinLabel = { pinLabel = it },
                zoomKm = zoomKm,
                onZoom = { zoomKm = it },
                savedFlash = savedFlash,
                onSave = {
                    val p = pin ?: return@MapSidebar
                    maps.savePlace(pinLabel.ifBlank { "pinned point" }, p.first, p.second)
                    places = maps.places()
                    savedFlash = true
                },
                onClearPin = { pin = null; pinLabel = "" },
                onForget = { label -> maps.forgetPlace(label); places = maps.places() }
            )
        }

        if (isLandscape) {
            Row(Modifier.weight(1f).fillMaxWidth()) {
                canvasBlock(Modifier.weight(1.3f).fillMaxHeight())
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f).fillMaxHeight().verticalScroll(rememberScrollState())) {
                    sidebarBlock(Modifier.fillMaxWidth())
                }
            }
        } else {
            canvasBlock(Modifier.weight(1f).fillMaxWidth())
            Spacer(Modifier.height(10.dp))
            Column(Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState())) {
                sidebarBlock(Modifier.fillMaxWidth())
            }
        }
    }
}

@Composable
private fun MapCanvas(
    here: Location?,
    places: List<Place>,
    pin: Pair<Double, Double>?,
    zoomKm: Float,
    modifier: Modifier = Modifier,
    onTap: (Double, Double) -> Unit
) {
    Box(
        modifier
            .clip(RoundedCornerShape(8.dp))
            .background(CardBg)
            .border(1.dp, Line, RoundedCornerShape(8.dp))
    ) {
        Canvas(
            Modifier
                .fillMaxSize()
                .pointerInput(here, zoomKm) {
                    detectTapGestures { offset ->
                        val center = here ?: return@detectTapGestures
                        val pxPerKm = min(size.width, size.height) / (2f * zoomKm)
                        val dxKm = (offset.x - size.width / 2f) / pxPerKm
                        // screen y grows downward; "up" on screen = north = positive latitude delta
                        val dyKm = (size.height / 2f - offset.y) / pxPerKm
                        val dLat = dyKm / 111.32
                        val dLon = dxKm / (111.32 * cos(Math.toRadians(center.latitude)).coerceAtLeast(0.01))
                        onTap(center.latitude + dLat, center.longitude + dLon)
                    }
                }
        ) {
            val pxPerKm = min(size.width, size.height) / (2f * zoomKm)
            val cx = size.width / 2f
            val cy = size.height / 2f

            // range rings, every 25% of the zoom radius, radar-style
            for (frac in listOf(0.25f, 0.5f, 0.75f, 1f)) {
                drawCircle(
                    color = Line,
                    radius = frac * zoomKm * pxPerKm,
                    center = Offset(cx, cy),
                    style = Stroke(width = 1.5f)
                )
            }
            // crosshair
            drawLine(Line, Offset(cx, 0f), Offset(cx, size.height), strokeWidth = 1.5f)
            drawLine(Line, Offset(0f, cy), Offset(size.width, cy), strokeWidth = 1.5f)

            if (here == null) {
                drawContext.canvas.nativeCanvas.drawText(
                    "no location fix yet",
                    cx,
                    cy,
                    android.graphics.Paint().apply {
                        color = android.graphics.Color.parseColor("#4E8C56")
                        textAlign = android.graphics.Paint.Align.CENTER
                        textSize = 32f
                        isAntiAlias = true
                    }
                )
            } else {
                // saved places
                for (p in places) {
                    val dLat = p.lat - here.latitude
                    val dLon = p.lon - here.longitude
                    val dyKm = dLat * 111.32
                    val dxKm = dLon * 111.32 * cos(Math.toRadians(here.latitude))
                    val x = cx + dxKm.toFloat() * pxPerKm
                    val y = cy - dyKm.toFloat() * pxPerKm
                    if (x in 0f..size.width && y in 0f..size.height) {
                        drawCircle(Ink, radius = 7f, center = Offset(x, y))
                        drawContext.canvas.nativeCanvas.drawText(
                            p.label,
                            x + 10f,
                            y + 6f,
                            android.graphics.Paint().apply {
                                color = android.graphics.Color.parseColor("#BFFFC7")
                                textSize = 28f
                                isAntiAlias = true
                            }
                        )
                    }
                }
                // pinned point
                pin?.let { (lat, lon) ->
                    val dLat = lat - here.latitude
                    val dLon = lon - here.longitude
                    val dyKm = dLat * 111.32
                    val dxKm = dLon * 111.32 * cos(Math.toRadians(here.latitude))
                    val x = cx + dxKm.toFloat() * pxPerKm
                    val y = cy - dyKm.toFloat() * pxPerKm
                    drawCircle(Warn, radius = 9f, center = Offset(x, y), style = Stroke(width = 3f))
                    drawLine(Warn, Offset(x - 12f, y), Offset(x + 12f, y), strokeWidth = 2.5f)
                    drawLine(Warn, Offset(x, y - 12f), Offset(x, y + 12f), strokeWidth = 2.5f)
                }
                // "you are here" — pulsing-looking double dot at the centre
                drawCircle(Accent, radius = 14f, center = Offset(cx, cy), style = Stroke(width = 2f))
                drawCircle(Accent, radius = 6f, center = Offset(cx, cy))
            }
        }
    }
}

@Composable
private fun MapSidebar(
    modifier: Modifier,
    maps: Maps,
    here: Location?,
    pin: Pair<Double, Double>?,
    pinLabel: String,
    onPinLabel: (String) -> Unit,
    zoomKm: Float,
    onZoom: (Float) -> Unit,
    savedFlash: Boolean,
    onSave: () -> Unit,
    onClearPin: () -> Unit,
    onForget: (String) -> Unit
) {
    Column(modifier, verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text(
            if (here != null) String.format(Locale.US, "Here: %.5f, %.5f", here.latitude, here.longitude)
            else "No location fix yet — step outside or check location permission.",
            color = Dim,
            fontFamily = TermFont,
            fontSize = 12.sp
        )

        Text("Zoom: ±${String.format(Locale.US, "%.1f", zoomKm)} km", color = Dim, fontFamily = TermFont, fontSize = 12.sp)
        Slider(
            value = zoomKm,
            onValueChange = onZoom,
            valueRange = 0.2f..50f,
            colors = SliderDefaults.colors(thumbColor = Accent, activeTrackColor = Accent, inactiveTrackColor = Line)
        )

        HorizontalDivider(color = Line)

        if (pin == null) {
            Text("Tap the map to drop a pin.", color = Dim, fontFamily = TermFont, fontSize = 13.sp)
        } else {
            Text(String.format(Locale.US, "Pinned: %.5f, %.5f", pin.first, pin.second), color = Ink, fontFamily = TermFont, fontSize = 13.sp)
            if (here != null) {
                val km = Maps.haversineKm(here.latitude, here.longitude, pin.first, pin.second)
                val text = if (km < 1.0) "${(km * 1000).roundToInt()} m away" else "${String.format(Locale.US, "%.2f", km)} km away"
                Text("Distance from here: $text", color = Accent, fontFamily = TermFont, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            }
            OutlinedTextField(
                value = pinLabel,
                onValueChange = onPinLabel,
                singleLine = true,
                label = { Text("Save this point as…", color = Dim, fontSize = 11.sp) },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Text),
                colors = fieldColors(),
                modifier = Modifier.fillMaxWidth()
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                TextButton(onClick = onSave) { Text("[save place]", color = Accent, fontFamily = TermFont, fontSize = 13.sp) }
                TextButton(onClick = onClearPin) { Text("[clear pin]", color = Warn, fontFamily = TermFont, fontSize = 13.sp) }
            }
            if (savedFlash) Text("Saved.", color = Accent, fontFamily = TermFont, fontSize = 12.sp)
        }

        HorizontalDivider(color = Line)

        Text("Saved places", color = Dim, fontFamily = TermFont, fontSize = 12.sp)
        val places = maps.places()
        if (places.isEmpty()) {
            Text("None yet. Try “remember this place as home”.", color = Dim, fontFamily = TermFont, fontSize = 12.sp)
        } else {
            places.forEach { p ->
                Row(
                    Modifier.fillMaxWidth().clickable { onPinLabel(p.label) },
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    val dist = here?.let { " · ${String.format(Locale.US, "%.2f", Maps.haversineKm(it.latitude, it.longitude, p.lat, p.lon))} km" } ?: ""
                    Text("• ${p.label}$dist", color = Ink, fontFamily = TermFont, fontSize = 13.sp, modifier = Modifier.weight(1f))
                    TextButton(onClick = { onForget(p.label) }) { Text("remove", color = Warn, fontFamily = TermFont, fontSize = 12.sp) }
                }
            }
        }
    }
}
