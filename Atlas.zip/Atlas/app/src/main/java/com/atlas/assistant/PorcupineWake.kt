package com.atlas.assistant

import ai.picovoice.porcupine.Porcupine
import ai.picovoice.porcupine.PorcupineException
import ai.picovoice.porcupine.PorcupineManager
import ai.picovoice.porcupine.PorcupineManagerCallback
import android.content.Context
import java.io.File

/**
 * A real dedicated low-power wake engine, the same shape as "Hey Google": a tiny always-on
 * keyword-spotting model (Picovoice Porcupine) listens continuously on its own, using a small fraction
 * of the CPU/battery a full speech recognizer needs, and only wakes the rest of Novochron up once it
 * actually hears the phrase. This replaces WakeWord's old approach of gating the full SpeechRecognizer,
 * which cost the same battery as Voice being on. See AssistantService for how the two are switched
 * between: Porcupine runs while idle and waiting, the full recognizer only runs for the follow-on
 * command right after a wake is detected.
 *
 * Needs a free AccessKey from console.picovoice.ai, pasted into Settings. The word itself is either
 * one of Porcupine's built-in words (see [BUILTINS] — picked in Settings) or a custom word trained for
 * free at console.picovoice.ai and dropped in as Atlas/Models/wakeword.ppn, the same "put a model in
 * the folder" pattern Novochron already uses for the offline LLM (see LocalLlm). A custom file always
 * wins over the built-in picker when both are present.
 *
 * [available] fails closed: with no AccessKey, or if the chosen built-in name doesn't exist in the
 * installed SDK version, Novochron just falls back to the old always-on-recognizer gating rather than
 * silently not listening at all.
 */
class PorcupineWake(private val ctx: Context) {
    private var manager: PorcupineManager? = null
    @Volatile private var running = false

    private fun customKeywordFile(): File = File(AtlasStorage.modelsDir(), "wakeword.ppn")

    private fun builtin(name: String): Porcupine.BuiltInKeyword? = try {
        Porcupine.BuiltInKeyword.valueOf(name.trim().uppercase())
    } catch (e: Exception) {
        null
    }

    fun available(): Boolean {
        val store = Store.get(ctx)
        if (store.picovoiceAccessKey.isBlank()) return false
        return (AtlasStorage.hasAccess() && customKeywordFile().exists()) || builtin(store.wakeEngineBuiltin) != null
    }

    /** Starts low-power listening. [onWake] fires on a background thread the instant the phrase is heard. */
    @Synchronized
    fun start(onWake: () -> Unit): Boolean {
        if (running) return true
        val store = Store.get(ctx)
        val key = store.picovoiceAccessKey.trim()
        if (key.isBlank()) return false
        return try {
            val builder = PorcupineManager.Builder().setAccessKey(key).setSensitivity(0.65f)
            val custom = customKeywordFile()
            if (AtlasStorage.hasAccess() && custom.exists()) {
                builder.setKeywordPath(custom.absolutePath)
            } else {
                val kw = builtin(store.wakeEngineBuiltin) ?: return false
                builder.setKeyword(kw)
            }
            manager = builder.build(ctx, object : PorcupineManagerCallback {
                override fun invoke(keywordIndex: Int) = onWake()
            })
            manager?.start()
            running = true
            true
        } catch (e: PorcupineException) {
            manager = null
            running = false
            false
        } catch (e: Exception) {
            manager = null
            running = false
            false
        }
    }

    @Synchronized
    fun stop() {
        try { manager?.stop() } catch (e: Exception) { }
        try { manager?.delete() } catch (e: Exception) { }
        manager = null
        running = false
    }

    companion object {
        const val DEFAULT_BUILTIN = "COMPUTER"

        /**
         * A representative subset of Porcupine's built-in wake words to offer in Settings. Exact enum
         * names can shift slightly between SDK versions — [builtin] fails closed (falls back to the
         * classic engine) rather than crashing if one doesn't match the installed version.
         */
        val BUILTINS = listOf(
            "COMPUTER", "JARVIS", "PORCUPINE", "BUMBLEBEE", "TERMINATOR",
            "ALEXA", "OK_GOOGLE", "HEY_GOOGLE", "HEY_SIRI", "PICOVOICE"
        )
    }
}
