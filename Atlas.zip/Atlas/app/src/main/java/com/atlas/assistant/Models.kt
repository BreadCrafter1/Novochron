package com.atlas.assistant

/** Picks which Gemini model answers a request. */
object Models {
    const val FAST = "gemini-3.1-flash-lite"
    const val SMART = "gemini-3.5-flash"

    private val BUILD = Regex(
        "\\b(make|build|create|code|generate|design|program|develop)\\b.*\\b(game|puzzle|app|application|tool|calculator|" +
            "web ?site|web ?page|page|quiz|timer|tracker|visuali[sz]ation|chart|animation|simulation|widget|dashboard|" +
            "checklist|clock|converter|generator|planner|sudoku|maze|snake|tetris|crossword|trivia|flashcards?|" +
            "to-?do|piano|soundboard|artifact|program|script)\\b"
    )

    private val CHANGE = Regex(
        "\\b(change|make it|make the|add|remove|update|modify|fix|improve|redesign|bigger|smaller|faster|slower|" +
            "harder|easier|another level|different|rewrite)\\b"
    )

    fun looksLikeBuild(text: String) = BUILD.containsMatchIn(text.lowercase())

    /** mode: "auto" (smart model only for builds), "fast" or "smart". */
    fun pick(mode: String, text: String, recentArtifact: Boolean): String = when (mode) {
        "fast" -> FAST
        "smart" -> SMART
        else -> {
            val t = text.lowercase()
            if (looksLikeBuild(t) || (recentArtifact && CHANGE.containsMatchIn(t))) SMART else FAST
        }
    }
}
