package com.atlas.assistant

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import androidx.core.app.NotificationCompat

/**
 * Lets Novochron "watch your screen" while you talk to it: grabs a screenshot every few seconds via
 * MediaProjection and hands it to [Engine.onScreenFrame], which attaches the freshest one to
 * whatever you say or type next (see Engine.submit). This is a separate mode from the camera —
 * it shows Novochron your screen, not the room around you.
 *
 * Screen capture is online-only in the sense that MediaProjection itself needs no internet, but
 * making sense of a frame still goes through the same online/offline vision path as a photo: with
 * a connection and an API key it uses Gemini, otherwise the on-device vision model if one is
 * installed, otherwise it says so.
 */
class ScreenCastService : Service() {

    private var mediaProjection: MediaProjection? = null
    private var virtualDisplay: android.hardware.display.VirtualDisplay? = null
    private var imageReader: ImageReader? = null
    private val thread = HandlerThread("novochron-screencast").apply { start() }
    private val handler = Handler(thread.looper)
    private val captureLoop = object : Runnable {
        override fun run() {
            if (!AssistantState.screencastOn.value) return
            grabFrame()
            handler.postDelayed(this, CAPTURE_INTERVAL_MS)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopCapture()
            return START_NOT_STICKY
        }
        val resultCode = intent?.getIntExtra(EXTRA_RESULT_CODE, 0) ?: 0
        val data = intent?.getParcelableExtra<Intent>(EXTRA_DATA)
        if (resultCode == 0 || data == null) {
            stopSelf()
            return START_NOT_STICKY
        }

        // Android requires the foreground service (with the mediaProjection type) to already be
        // running before MediaProjectionManager.getMediaProjection() is called.
        try {
            startForegroundNotification()
        } catch (e: Exception) {
            stopSelf()
            return START_NOT_STICKY
        }

        val mgr = getSystemService(MediaProjectionManager::class.java)
        val projection = try {
            mgr.getMediaProjection(resultCode, data)
        } catch (e: Exception) {
            null
        }
        if (projection == null) {
            AssistantState.status.value = "Couldn't start screencast."
            stopCapture()
            return START_NOT_STICKY
        }
        mediaProjection = projection
        projection.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { stopCapture() }
        }, handler)

        val metrics = resources.displayMetrics
        val width = metrics.widthPixels.coerceAtLeast(1)
        val height = metrics.heightPixels.coerceAtLeast(1)
        val density = metrics.densityDpi

        val reader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2)
        imageReader = reader
        try {
            virtualDisplay = projection.createVirtualDisplay(
                "NovochronScreenCast", width, height, density,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                reader.surface, null, handler
            )
        } catch (e: Exception) {
            stopCapture()
            return START_NOT_STICKY
        }

        AssistantState.screencastOn.value = true
        handler.postDelayed(captureLoop, 500) // let the first frame settle
        return START_STICKY
    }

    private fun grabFrame() {
        val reader = imageReader ?: return
        val image: Image = try { reader.acquireLatestImage() } catch (e: Exception) { null } ?: return
        try {
            val bmp = imageToBitmap(image)
            if (bmp != null) {
                val path = Vision.save(applicationContext, bmp)
                Engine.get(applicationContext).onScreenFrame(path)
            }
        } catch (e: Exception) {
            // drop this frame, try again on the next tick
        } finally {
            image.close()
        }
    }

    private fun imageToBitmap(image: Image): Bitmap? {
        val plane = image.planes.getOrNull(0) ?: return null
        val buffer = plane.buffer
        val pixelStride = plane.pixelStride
        val rowStride = plane.rowStride
        val rowPadding = rowStride - pixelStride * image.width
        val bmp = Bitmap.createBitmap(
            image.width + rowPadding / pixelStride, image.height, Bitmap.Config.ARGB_8888
        )
        bmp.copyPixelsFromBuffer(buffer)
        return if (rowPadding == 0) bmp else Bitmap.createBitmap(bmp, 0, 0, image.width, image.height)
    }

    private fun stopCapture() {
        AssistantState.screencastOn.value = false
        try { Engine.get(applicationContext).stopScreencast() } catch (e: Exception) { }
        handler.removeCallbacks(captureLoop)
        try { virtualDisplay?.release() } catch (e: Exception) { }
        virtualDisplay = null
        try { imageReader?.close() } catch (e: Exception) { }
        imageReader = null
        try { mediaProjection?.stop() } catch (e: Exception) { }
        mediaProjection = null
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        stopCapture()
        thread.quitSafely()
        super.onDestroy()
    }

    private fun startForegroundNotification() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH, "Novochron screencast", NotificationManager.IMPORTANCE_LOW))
        val stop = PendingIntent.getService(
            this, 2, Intent(this, ScreenCastService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE
        )
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val notif = NotificationCompat.Builder(this, CH)
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle("Novochron is watching your screen")
            .setContentText("Ask it about what's on screen. Tap Stop to end it.")
            .setContentIntent(open)
            .addAction(0, "Stop", stop)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIF_ID, notif, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else {
            startForeground(NOTIF_ID, notif)
        }
    }

    companion object {
        const val ACTION_STOP = "com.novochron.assistant.SCREENCAST_STOP"
        const val EXTRA_RESULT_CODE = "result_code"
        const val EXTRA_DATA = "data"
        private const val CH = "novochron_screencast"
        private const val NOTIF_ID = 43
        private const val CAPTURE_INTERVAL_MS = 4000L
    }
}
