package com.atlas.assistant

import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin
import kotlin.random.Random

/**
 * The brains of the on-screen character: no drawing in here, just "what is she doing right now".
 * [update] is called about 30 times a second with the clock in seconds and fills in [pose], which
 * MascotBackdrop (Mascot.kt) then draws. Kept free of Compose so it is easy to reason about.
 */
enum class MascotMode { IDLE, LISTENING, THINKING, SPEAKING }

enum class Eye { GT, ARC, DOT, LINE, CROSS, SPIRAL }
enum class Mouth { TRI, O, CAT, WAVY }
enum class Sym { NOTE, HEART, QMARK, EXCL, ZED, DROP, DOT }
enum class ActKind { WOBBLE, FLIP, HOP, DANCE, AHOGE, NONO, LEAN, YAWN, HEARTS }

class Fx {
    var k = Sym.DOT
    var x = 0.0
    var y = 0.0
    var a = 0.0
    var s = 1.0
    var r = 0.0
}

/** Everything the drawing code needs for one frame. Angles are degrees, positions are in the 600x760 art space. */
class Pose {
    var bodyDy = 0.0
    var bodyRot = 0.0
    var torsoDy = 0.0
    var pRot = -1.5
    var pDx = 0.0
    var pDy = 0.0
    var pS = 1.0
    var flip = 0.0
    var ahoge = 0.0
    var hair = 1.0
    var eyes = Eye.GT
    var mouth = Mouth.TRI
    var mo = 0.5
    var env = 0.0
    val fx = Array(9) { Fx() }
    var fxN = 0

    fun reset() {
        bodyDy = 0.0; bodyRot = 0.0; torsoDy = 0.0
        pRot = -1.5; pDx = 0.0; pDy = 0.0; pS = 1.0; flip = 0.0
        ahoge = 0.0; hair = 1.0
        eyes = Eye.GT; mouth = Mouth.TRI; mo = 0.5; env = 0.0
        fxN = 0
    }

    fun addFx(k: Sym, x: Double, y: Double, a: Double, s: Double = 1.0, r: Double = 0.0) {
        if (fxN >= fx.size) return
        val f = fx[fxN++]
        f.k = k; f.x = x; f.y = y; f.a = a; f.s = s; f.r = r
    }
}

class MascotAnimator {
    @Volatile var mode = MascotMode.IDLE

    val pose = Pose()

    /** Overall brightness of the drawing (0..1): a little brighter while she talks, dimmer while asleep. */
    var alpha = 0.30f
        private set

    /** The clock (seconds) of the last [update], used by the drawing code for the continuous sway motions. */
    var clock = 0.0
        private set

    private var listen = 0.0
    private var think = 0.0
    private var speak = 0.0
    private var sleep = 0.0

    private var lastNow = -1.0
    private var lastActive = 0.0
    private var nextAct = 4.0
    private var lastKind: ActKind? = null

    private class Act(val kind: ActKind, val t0: Double, val d: Double, val alt: Int)
    private var act: Act? = null

    private class Alt(val eyes: Eye, val mouth: Mouth)
    private val alts = listOf(
        Alt(Eye.ARC, Mouth.CAT), Alt(Eye.DOT, Mouth.O),
        Alt(Eye.CROSS, Mouth.WAVY), Alt(Eye.LINE, Mouth.CAT)
    )

    // amplitude (deg), frequency, phase - in the same order as MascotArt.LOCKS (L0, L1, L2, R0, R1, R2)
    val lockAmp = doubleArrayOf(2.4, 2.0, 2.8, 2.2, 2.6, 2.0)
    val lockFreq = doubleArrayOf(1.1, 1.4, 0.9, 1.3, 1.0, 1.6)
    val lockPhase = doubleArrayOf(0.0, 1.7, 3.1, 0.8, 2.4, 4.0)

    /** Someone did something (typed, tapped, a message arrived): she stays awake a little longer. */
    fun poke() {
        lastActive = max(lastActive, lastNow)
    }

    /** Debug/testing: start a specific idle act right now. */
    fun startAct(now: Double, kind: ActKind) {
        act = Act(kind, now, durationOf(kind), Random.nextInt(alts.size))
        lastKind = kind
    }

    fun update(now: Double) {
        val dt = if (lastNow < 0) 0.033 else min(0.1, now - lastNow)
        lastNow = now
        clock = now
        val m = mode
        val kS = 1.0 - exp(-dt * 6.0)
        speak += ((if (m == MascotMode.SPEAKING) 1.0 else 0.0) - speak) * kS
        think += ((if (m == MascotMode.THINKING) 1.0 else 0.0) - think) * kS
        listen += ((if (m == MascotMode.LISTENING) 1.0 else 0.0) - listen) * kS
        if (m != MascotMode.IDLE) lastActive = now
        val wantSleep = m == MascotMode.IDLE && now - lastActive > SLEEP_AFTER
        sleep += ((if (wantSleep) 1.0 else 0.0) - sleep) * (1.0 - exp(-dt * 1.6))

        if (m != MascotMode.IDLE || wantSleep) {
            if (act != null) { act = null; nextAct = now + 3.0 }
        } else {
            if (act == null && now >= nextAct) startRandomAct(now)
            val a = act
            if (a != null && now > a.t0 + a.d) {
                act = null
                nextAct = now + 3.5 + Random.nextDouble() * 4.5
            }
        }
        computePose(now, now)
        alpha = (0.30 + 0.16 * speak * (0.6 + 0.4 * pose.env) + 0.04 * listen - 0.08 * sleep)
            .coerceIn(0.12, 0.60).toFloat()
    }

    private fun startRandomAct(now: Double) {
        val all = ActKind.values()
        var pick: ActKind
        do { pick = all[Random.nextInt(all.size)] } while (pick == lastKind)
        startAct(now, pick)
    }

    private fun durationOf(k: ActKind): Double = when (k) {
        ActKind.WOBBLE -> 2.2
        ActKind.FLIP -> 3.8
        ActKind.HOP -> 1.7
        ActKind.DANCE -> 3.4
        ActKind.AHOGE -> 1.9
        ActKind.NONO -> 1.7
        ActKind.LEAN -> 2.4
        ActKind.YAWN -> 3.0
        ActKind.HEARTS -> 3.0
    }

    /** Test hook: force the blend values and act, then compute the pose for time [t]. */
    internal fun debugPose(t: Double, s: Double, l: Double, th: Double, z: Double, kind: ActKind?, t0: Double, alt: Int): Pose {
        speak = s; listen = l; think = th; sleep = z
        act = if (kind == null) null else Act(kind, t0, durationOf(kind), alt)
        clock = t
        computePose(t, t)
        return pose
    }

    private fun computePose(t: Double, now: Double) {
        val p = pose
        p.reset()
        val s = speak
        val l = listen
        val th = think
        val z = sleep
        val br = sin(t * 1.7)
        val brZ = sin(t * 0.9)
        p.torsoDy = 1.6 * br * (1 - z) + 2.4 * brZ * z
        p.pDy += 2.2 * br * (1 - z) + 3.5 * brZ * z
        p.pRot += 1.1 * sin(t * 0.8)
        p.ahoge += 4 * sin(t * 2.1)
        // listening: leans in, ahoge perks up
        p.pRot += -4 * l; p.pS += 0.035 * l; p.pDx += -3 * l; p.ahoge += -14 * l + 5 * sin(t * 5) * l
        // thinking: slow head sway
        p.pRot += 7 * sin(t * 1.25) * th; p.pDx += 9 * sin(t * 0.62) * th; p.pDy += -3 * th
        // sleeping: droops
        p.pRot += 8 * z; p.pDy += 10 * z; p.ahoge += 22 * z; p.hair *= 1 - 0.6 * z
        // speaking: syllable-driven mouth and bounce
        val u = t * 6.2
        val k = floor(u)
        val fr = u - k
        val amp = 0.35 + 0.65 * hash(k)
        val gap = if (hash(floor(t * 1.3) + 7) < 0.18) 0.15 else 1.0
        val env = sin(PI * fr).pow(0.8) * amp * gap
        p.env = env * s
        p.pDy += -5 * env * s; p.bodyDy += -2.5 * abs(sin(t * 3.1)) * s
        p.pRot += 3.2 * sin(t * 2.6) * s; p.pDx += 4 * sin(t * 1.9) * s
        p.hair += 1.6 * s; p.ahoge += 10 * sin(t * 7) * s

        // base expression
        if (s > 0.5) {
            p.eyes = if (hash(floor(t * 0.9) + 3) > 0.74) Eye.ARC else Eye.GT
            p.mouth = Mouth.TRI
            p.mo = 0.08 + 0.92 * env
        } else if (th > 0.5) {
            p.eyes = Eye.SPIRAL; p.mouth = Mouth.WAVY
            for (i in 0 until 3) {
                p.addFx(Sym.DOT, 452.0 + 20 * i, 96.0, 0.25 + 0.75 * max(0.0, sin(t * 4 - i * 0.9)))
            }
            p.addFx(Sym.DROP, 440.0, 200.0, 0.9, 0.9)
        } else if (z > 0.5) {
            p.eyes = Eye.LINE; p.mouth = Mouth.O
            p.mo = 0.08 + 0.14 * (0.5 + 0.5 * brZ)
            for (i in 0 until 3) {
                val v = (t * 0.25 + i / 3.0) % 1.0
                p.addFx(Sym.ZED, 428.0 + 20 * i + 8 * sin(v * 5), 190 - 110 * v, sin(PI * v) * z, 0.7 + 0.5 * v)
            }
        } else if (l > 0.5) {
            p.eyes = Eye.DOT; p.mouth = Mouth.TRI; p.mo = 0.22
        } else {
            p.mo = 0.5 + 0.04 * br
            val bk = floor(t * 2)
            if (act == null && hash(bk + 55) > 0.93 && (t * 2 - bk) < 0.5) p.eyes = Eye.DOT
        }
        val a = act
        if (a != null) applyAct(p, a, now)
    }

    private fun applyAct(p: Pose, a: Act, now: Double) {
        val u = ((now - a.t0) / a.d).coerceIn(0.0, 1.0)
        val e = sin(PI * u)
        val tau = 2 * PI
        when (a.kind) {
            ActKind.WOBBLE -> p.pRot += 12 * sin(u * 6 * PI) * (1 - u)
            ActKind.FLIP -> {
                val f = if (u < 0.16) u / 0.16 else if (u < 0.70) 1.0 else if (u < 0.86) 1 - (u - 0.70) / 0.16 else 0.0
                p.flip = f
                if (f > 0.5) {
                    val alt = alts[a.alt]
                    p.eyes = alt.eyes; p.mouth = alt.mouth; p.mo = 0.5
                }
                if (u > 0.16 && u < 0.70) {
                    val w = sin((u - 0.16) * tau * 3.2)
                    p.pRot += 5 * w; p.bodyDy += -3 * abs(w)
                }
            }
            ActKind.HOP -> {
                p.bodyDy += -34 * abs(sin(u * 3 * PI)) * (1 - 0.25 * u)
                p.ahoge += 26 * sin(u * 6 * PI); p.hair += 1.2 * e; p.eyes = Eye.ARC
            }
            ActKind.DANCE -> {
                val w = sin(u * tau * 3)
                val g = min(1.0, e * 2)
                p.pRot += -9 * w * g; p.pDx += 10 * sin(u * tau * 3 + 0.6) * g; p.bodyDy += -3 * abs(w) * g
                p.eyes = Eye.ARC; p.mouth = Mouth.CAT
                for (i in 0 until 3) {
                    val v = (u * 1.2 + i / 3.0) % 1.0
                    val right = i % 2 == 0
                    p.addFx(
                        Sym.NOTE, (if (right) 478.0 else 122.0) + 14 * sin(v * 7 + i), 330 - 230 * v,
                        sin(PI * v) * g, 1.0, if (right) 8.0 else -8.0
                    )
                }
                p.bodyRot += 4.5 * w * g
            }
            ActKind.AHOGE -> {
                p.ahoge += 85 * sin(u * tau * 4) * min(1.0, e * 1.6)
                p.addFx(Sym.EXCL, 372.0, 64.0, min(1.0, e * 2))
            }
            ActKind.NONO -> {
                p.pDx += 22 * sin(u * tau * 4) * e; p.pRot += 3 * sin(u * tau * 4) * e; p.mouth = Mouth.WAVY
                p.addFx(Sym.DROP, 446.0, 196 + 30 * u, e)
            }
            ActKind.LEAN -> {
                p.pS += 0.15 * e; p.pDy += -6 * e; p.pRot += -5 * e; p.eyes = Eye.DOT; p.mouth = Mouth.O; p.mo = 0.35
                p.addFx(Sym.QMARK, 470.0, 120.0, min(1.0, e * 2), 1.1)
            }
            ActKind.YAWN -> {
                p.eyes = Eye.LINE; p.mouth = Mouth.O; p.mo = 0.15 + 0.85 * e; p.pDy += 8 * e; p.pRot += 3 * e
            }
            ActKind.HEARTS -> {
                p.pRot += 4 * sin(u * tau * 2); p.eyes = Eye.ARC; p.mouth = Mouth.CAT
                for (i in 0 until 3) {
                    val v = (u * 1.3 + i / 3.0) % 1.0
                    p.addFx(Sym.HEART, 300.0 + (i - 1) * 70 + 14 * sin(v * 7), 150 - 110 * v, sin(PI * v), 0.9)
                }
            }
        }
    }

    companion object {
        /** Seconds of nothing happening before she dozes off. */
        const val SLEEP_AFTER = 40.0

        fun hash(n: Double): Double {
            val s = sin(n * 127.1 + 311.7) * 43758.5453
            return s - floor(s)
        }
    }
}
