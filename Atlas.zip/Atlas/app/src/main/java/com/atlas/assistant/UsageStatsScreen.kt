package com.atlas.assistant

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * "[stats]": a purely local, offline readout of what's been asked most — "you've asked me about X most
 * this week" — built straight from the rolling log [UsageStats] keeps in Atlas/Adaptive/usage.json. No
 * telemetry: this never leaves the phone, there's no server, and [UsageStats.clear] wipes it on request.
 */
@Composable
fun UsageStatsScreen(onClose: () -> Unit) {
    val ctx = LocalContext.current
    var refreshTick by remember { mutableStateOf(0) }
    val weekTotal = remember(refreshTick) { UsageStats.totalCount(ctx, 7) }
    val allTime = remember(refreshTick) { UsageStats.allTimeCount(ctx) }
    val topWeek = remember(refreshTick) { UsageStats.topCategories(ctx, 7, 10) }

    Box(Modifier.fillMaxSize().background(androidx.compose.ui.graphics.Color.Black)) {
        Column(Modifier.fillMaxSize().padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                TermTextKey("[back]", onClick = onClose)
                Spacer(Modifier.weight(1f))
                Text("stats", color = Accent, fontFamily = TermFont, fontSize = 18.sp)
                Spacer(Modifier.weight(1f))
                TermTextKey("[clear]", tone = Warn, onClick = {
                    UsageStats.clear(ctx)
                    refreshTick++
                })
            }
            Spacer(Modifier.height(10.dp))

            Text(
                "$weekTotal things asked this week · $allTime all time. Purely local — never uploaded.",
                color = Dim, fontFamily = TermFont, fontSize = 12.sp
            )
            Spacer(Modifier.height(14.dp))

            if (topWeek.isEmpty()) {
                Text("Nothing logged yet this week. Ask Novochron a few things and check back.", color = Dim, fontFamily = TermFont, fontSize = 13.sp)
            } else {
                Text("Most asked about this week", color = Ink, fontFamily = TermFont, fontSize = 14.sp)
                Spacer(Modifier.height(8.dp))
                val maxCount = topWeek.first().second.coerceAtLeast(1)
                LazyColumn {
                    items(topWeek.size) { i ->
                        val (cat, count) = topWeek[i]
                        Column(Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = androidx.compose.foundation.layout.Arrangement.SpaceBetween) {
                                Text(cat, color = Ink, fontFamily = TermFont, fontSize = 14.sp)
                                Text("$count", color = Accent, fontFamily = TermFont, fontSize = 14.sp)
                            }
                            Spacer(Modifier.height(4.dp))
                            val frac = (count.toFloat() / maxCount).coerceIn(0.02f, 1f)
                            Box(
                                Modifier
                                    .fillMaxWidth(frac)
                                    .height(6.dp)
                                    .background(Accent)
                            )
                            Box(Modifier.fillMaxWidth().height(1.dp).border(0.dp, Line))
                        }
                    }
                }
            }
        }
    }
}
