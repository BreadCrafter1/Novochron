package com.atlas.assistant

import android.content.Intent
import android.provider.Settings
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.width
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * "[stats]": a purely local, offline readout of (1) how much battery Novochron costs while it works in the
 * background - see [BatteryTracker] - and (2) what's been asked most: "you've asked me about X most this
 * week", built straight from the rolling log [UsageStats] keeps in Atlas/Adaptive/usage.json. No telemetry:
 * this never leaves the phone, there's no server, and [clear] wipes both logs on request.
 */
@Composable
fun UsageStatsScreen(onClose: () -> Unit) {
    val ctx = LocalContext.current
    var refreshTick by remember { mutableStateOf(0) }
    var rangeDays by remember { mutableStateOf(1) }   // battery range: 1 = last 24 h, 7 = last 7 days
    val weekTotal = remember(refreshTick) { UsageStats.totalCount(ctx, 7) }
    val allTime = remember(refreshTick) { UsageStats.allTimeCount(ctx) }
    val topWeek = remember(refreshTick) { UsageStats.topCategories(ctx, 7, 10) }

    // The live battery line refreshes itself while the screen is open.
    var battNow by remember { mutableStateOf(BatteryTracker.now(ctx)) }
    LaunchedEffect(Unit) {
        var n = 0
        while (true) {
            kotlinx.coroutines.delay(5000)
            battNow = BatteryTracker.now(ctx)
            if (++n % 12 == 0) refreshTick++      // re-read the totals about once a minute
        }
    }
    val summary = remember(refreshTick, rangeDays) { BatteryTracker.summary(ctx, rangeDays * 24L * 3_600_000L) }

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        Column(Modifier.fillMaxSize().padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                TermTextKey("[back]", onClick = onClose)
                Spacer(Modifier.weight(1f))
                Text("stats", color = Accent, fontFamily = TermFont, fontSize = 18.sp)
                Spacer(Modifier.weight(1f))
                TermTextKey("[clear]", tone = Warn, onClick = {
                    UsageStats.clear(ctx)
                    BatteryTracker.clear(ctx)
                    refreshTick++
                })
            }
            Spacer(Modifier.height(10.dp))

            LazyColumn(Modifier.fillMaxSize()) {
                item { BatterySection(battNow, summary, rangeDays, onRange = { rangeDays = it }) }
                item { Spacer(Modifier.height(22.dp)) }

                item {
                    Text(
                        "$weekTotal things asked this week · $allTime all time. Purely local — never uploaded.",
                        color = Dim, fontFamily = TermFont, fontSize = 12.sp
                    )
                    Spacer(Modifier.height(14.dp))
                }
                if (topWeek.isEmpty()) {
                    item {
                        Text("Nothing logged yet this week. Ask Novochron a few things and check back.", color = Dim, fontFamily = TermFont, fontSize = 13.sp)
                    }
                } else {
                    item {
                        Text("Most asked about this week", color = Ink, fontFamily = TermFont, fontSize = 14.sp)
                        Spacer(Modifier.height(8.dp))
                    }
                    val maxCount = topWeek.first().second.coerceAtLeast(1)
                    items(topWeek.size) { i ->
                        val (cat, count) = topWeek[i]
                        Column(Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text(cat, color = Ink, fontFamily = TermFont, fontSize = 14.sp)
                                Text("$count", color = Accent, fontFamily = TermFont, fontSize = 14.sp)
                            }
                            Spacer(Modifier.height(4.dp))
                            val frac = (count.toFloat() / maxCount).coerceIn(0.02f, 1f)
                            Box(
                                Modifier
                                    .fillMaxWidth(frac)
                                    .height(6.dp)
                                    .background(Accent)
                            )
                            Box(Modifier.fillMaxWidth().height(1.dp).border(0.dp, Line))
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun BatterySection(now: BatteryNow, sum: BatterySummary, rangeDays: Int, onRange: (Int) -> Unit) {
    val ctx = LocalContext.current
    Text("Battery", color = Ink, fontFamily = TermFont, fontSize = 14.sp, fontWeight = FontWeight.Bold)
    Spacer(Modifier.height(6.dp))

    // ---- right now ----
    val state = if (now.charging) "charging" else "on battery"
    val bits = buildList {
        add(if (now.pct >= 0) "${now.pct}%" else "?%")
        add(state)
        now.tempC?.let { add("%.1f°C".format(it)) }
        now.volts?.let { add("%.2f V".format(it)) }
        now.currentMa?.let { add("~$it mA") }
    }
    Text(bits.joinToString(" · "), color = if (now.pct in 0..15 && !now.charging) Warn else Accent, fontFamily = TermFont, fontSize = 15.sp)
    Spacer(Modifier.height(4.dp))
    Text(
        "Battery saver: ${if (now.powerSave) "on" else "off"} · Battery optimisation: " +
            if (now.ignoringOptimizations) "Novochron is exempt (good for background listening)" else "applies to Novochron - Android may stop it in the background",
        color = Dim, fontFamily = TermFont, fontSize = 11.sp
    )
    Spacer(Modifier.height(12.dp))

    // ---- range toggle ----
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
        Text("Background use:", color = Dim, fontFamily = TermFont, fontSize = 12.sp)
        StatsChip("24 h", rangeDays == 1) { onRange(1) }
        StatsChip("7 days", rangeDays == 7) { onRange(7) }
    }
    Spacer(Modifier.height(8.dp))

    if (sum.all.ms < 60_000L) {
        Text(
            "No background data yet. Turn on voice listening or message alerts and leave them running unplugged " +
                "for a while - readings are logged about once a minute, and time spent charging is ignored.",
            color = Dim, fontFamily = TermFont, fontSize = 12.sp
        )
    } else {
        val off = sum.screenOff
        StatLine("Tracked, unplugged", fmtDuration(sum.all.ms))
        StatLine(
            "Battery used while running",
            "${fmtNum(sum.all.pct)}%" + (if (sum.all.mahMs > 0) " (~${sum.all.mah.toInt()} mAh)" else "")
        )
        sum.all.pctPerHour?.let { r ->
            StatLine("Average rate", "%.1f %%/h".format(r) + (sum.all.mahPerHour?.let { " (~${it.toInt()} mAh/h)" } ?: ""))
        }
        if (off.ms >= 60_000L) {
            Spacer(Modifier.height(8.dp))
            Text("Screen off (closest to Novochron's own cost)", color = Ink, fontFamily = TermFont, fontSize = 12.sp)
            StatLine("Tracked", fmtDuration(off.ms))
            off.pctPerHour?.let { r ->
                StatLine("Rate", "%.2f %%/h".format(r) + (off.mahPerHour?.let { " (~${it.toInt()} mAh/h)" } ?: ""))
                if (r > 0.01) StatLine("A full charge would last", fmtDuration((100.0 / r * 3_600_000).toLong()))
            }
            if (off.cpuMs > 0) StatLine("CPU time used", "%.1f min per hour".format(off.cpuMs / 60_000.0 / off.hours))

            if (sum.byFeature.isNotEmpty()) {
                Spacer(Modifier.height(8.dp))
                Text("By feature (screen off)", color = Ink, fontFamily = TermFont, fontSize = 12.sp)
                sum.byFeature.entries.sortedByDescending { it.value.ms }.forEach { (tags, b) ->
                    val rate = b.pctPerHour
                    StatLine(
                        featureLabel(tags) + " · " + fmtDuration(b.ms),
                        if (rate != null) "%.2f %%/h".format(rate) else "too short"
                    )
                }
            }
        } else {
            Spacer(Modifier.height(6.dp))
            Text(
                "No screen-off stretches yet - leave the phone locked while Novochron runs to see its quiet-time cost.",
                color = Dim, fontFamily = TermFont, fontSize = 11.sp
            )
        }

        // ---- last 24 hours, one bar per hour ----
        Spacer(Modifier.height(12.dp))
        Text("Last 24 hours (drain %/h while running)", color = Ink, fontFamily = TermFont, fontSize = 12.sp)
        Spacer(Modifier.height(6.dp))
        val peak = (sum.hourly.filterNotNull().maxOrNull() ?: 0.0).coerceAtLeast(1.0)
        Row(Modifier.fillMaxWidth().height(56.dp), horizontalArrangement = Arrangement.spacedBy(2.dp), verticalAlignment = Alignment.Bottom) {
            sum.hourly.forEach { v ->
                Box(Modifier.weight(1f).fillMaxHeight(), contentAlignment = Alignment.BottomCenter) {
                    if (v == null) Box(Modifier.fillMaxWidth().height(1.dp).background(Line))
                    else Box(Modifier.fillMaxWidth().fillMaxHeight((v / peak).toFloat().coerceIn(0.04f, 1f)).background(Accent))
                }
            }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("24h ago", color = Dim, fontFamily = TermFont, fontSize = 10.sp)
            Text("peak %.1f %%/h".format(peak), color = Dim, fontFamily = TermFont, fontSize = 10.sp)
            Text("now", color = Dim, fontFamily = TermFont, fontSize = 10.sp)
        }
    }

    Spacer(Modifier.height(12.dp))
    Text(
        "Android doesn't tell apps their exact battery share, so these are whole-phone drain measured while " +
            "Novochron's background features run (voice listening, message alerts) - only unplugged time counts. " +
            "For Android's own per-app figure, open the system battery page.",
        color = Dim, fontFamily = TermFont, fontSize = 11.sp
    )
    Spacer(Modifier.height(4.dp))
    TermTextKey("[system battery]", tone = Accent, hpad = 0, onClick = {
        try {
            ctx.startActivity(Intent(Intent.ACTION_POWER_USAGE_SUMMARY).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e: Exception) {
            try { ctx.startActivity(Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Exception) { }
        }
    })
}

@Composable
private fun StatLine(label: String, value: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 2.dp), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, color = Dim, fontFamily = TermFont, fontSize = 12.sp, modifier = Modifier.weight(1f))
        Spacer(Modifier.width(8.dp))
        Text(value, color = Ink, fontFamily = TermFont, fontSize = 12.sp)
    }
}

@Composable
private fun StatsChip(label: String, selected: Boolean, onClick: () -> Unit) {
    Text(
        label,
        color = if (selected) Color.Black else Ink,
        fontFamily = TermFont, fontSize = 12.sp,
        fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
        modifier = Modifier
            .background(if (selected) Accent else Raised)
            .clickable(onClick = onClick)
            .padding(horizontal = 10.dp, vertical = 5.dp)
    )
}

private fun featureLabel(tags: String): String = when (tags) {
    BatteryTracker.TAG_VOICE -> "Voice listening"
    BatteryTracker.TAG_MSG -> "Message alerts"
    else -> tags.split(",").joinToString(" + ") { featureLabel(it) }
}

private fun fmtNum(v: Double): String = if (v >= 10) "%.0f".format(v) else "%.1f".format(v)

private fun fmtDuration(ms: Long): String {
    val totalMin = ms / 60_000L
    val d = totalMin / 1440
    val h = (totalMin % 1440) / 60
    val m = totalMin % 60
    return when {
        d > 0 -> "${d}d ${h}h"
        h > 0 -> "${h}h ${m}m"
        else -> "${m}m"
    }
}
