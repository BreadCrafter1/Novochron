package com.atlas.assistant

import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer

/**
 * Continuous hands-free listening: no press-to-talk. Restarts itself after every phrase and keeps
 * running while Novochron is thinking or speaking, so the user can talk over it (the engine filters out
 * Novochron's own voice). Uses the on-device recognizer when there is no internet.
 */
class Listener(
    private val ctx: Context,
    private val onText: (String) -> Unit,
    private val onPartial: (String) -> Unit,
    private val onFatal: (String) -> Unit,
    private val onSpeechEnd: () -> Unit = {}
) : RecognitionListener {

    private val main = Handler(Looper.getMainLooper())
    private val audio = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private val store = Store.get(ctx)
    private var rec: SpeechRecognizer? = null
    private var recOffline = false
    private var active = false
    private var running = false
    private var offlineUntil = 0L

    fun start() {
        if (!SpeechRecognizer.isRecognitionAvailable(ctx)) {
            onFatal("No speech recognition service found. Install or enable the Google app.")
            return
        }
        active = true
        setBeepMuted(true)
        begin()
    }

    fun stop() {
        active = false
        main.removeCallbacksAndMessages(null)
        destroy()
        setBeepMuted(false)
    }

    private fun begin() {
        if (!active || running) return
        val offline = store.forceOffline || System.currentTimeMillis() < offlineUntil || !Net.isOnline(ctx)
        if (rec == null || recOffline != offline) {
            destroy()
            rec = makeRecognizer(offline)
            recOffline = offline
            rec?.setRecognitionListener(this)
        }
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
            putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, offline)
            putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, ctx.packageName)
            // Snappy turn-taking: Novochron should start answering right after the user stops talking, not
            // after a long pause. A short, natural breath mid-sentence is still shorter than this, so it
            // doesn't cut people off, but the assistant no longer sits there waiting once they're done.
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 450L)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 300L)
        }
        running = true
        try {
            rec?.startListening(i)
        } catch (e: Exception) {
            running = false
            retry(1000)
        }
    }

    private fun makeRecognizer(offline: Boolean): SpeechRecognizer =
        if (offline && Build.VERSION.SDK_INT >= 31 && SpeechRecognizer.isOnDeviceRecognitionAvailable(ctx)) {
            SpeechRecognizer.createOnDeviceSpeechRecognizer(ctx)
        } else {
            SpeechRecognizer.createSpeechRecognizer(ctx)
        }

    private fun retry(ms: Long) {
        main.removeCallbacksAndMessages(null)
        main.postDelayed({ begin() }, ms)
    }

    private fun destroy() {
        try { rec?.destroy() } catch (e: Exception) { }
        rec = null
        running = false
    }

    private fun setBeepMuted(mute: Boolean) {
        val dir = if (mute) AudioManager.ADJUST_MUTE else AudioManager.ADJUST_UNMUTE
        for (s in intArrayOf(AudioManager.STREAM_NOTIFICATION, AudioManager.STREAM_SYSTEM)) {
            try { audio.adjustStreamVolume(s, dir, 0) } catch (e: Exception) { }
        }
    }

    // ---- RecognitionListener ----
    override fun onReadyForSpeech(params: Bundle?) {}
    override fun onBeginningOfSpeech() {}
    override fun onRmsChanged(rmsdB: Float) {}
    override fun onBufferReceived(buffer: ByteArray?) {}
    override fun onEndOfSpeech() { onSpeechEnd() }
    override fun onEvent(eventType: Int, params: Bundle?) {}

    override fun onPartialResults(partialResults: Bundle?) {
        val t = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
        if (!t.isNullOrBlank()) onPartial(t)
    }

    override fun onResults(results: Bundle?) {
        running = false
        val t = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
        if (!t.isNullOrBlank()) onText(t)
        // always go straight back to listening; the user may keep talking
        if (active) retry(10)
    }

    override fun onError(error: Int) {
        running = false
        if (!active) return
        when (error) {
            SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS ->
                onFatal("Microphone permission is off. Enable it in app settings.")
            12, 13 -> // language not supported / unavailable
                onFatal("Speech language pack missing. In the Google app: Settings > Voice > Offline speech recognition, download English.")
            SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> { destroy(); retry(600) }
            SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> retry(50)
            SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT, SpeechRecognizer.ERROR_SERVER -> {
                offlineUntil = System.currentTimeMillis() + 60_000
                destroy(); retry(500)
            }
            else -> { destroy(); retry(1000) }
        }
    }
}
