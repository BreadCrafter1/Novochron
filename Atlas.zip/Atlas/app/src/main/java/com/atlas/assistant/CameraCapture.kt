package com.atlas.assistant

import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import kotlinx.coroutines.delay
import java.util.concurrent.Executors

/**
 * Full-screen camera: front/back toggle, tap the shutter to ask about (or just identify) what the
 * camera sees, or turn on "Live scan" to have Novochron describe what's in frame every few seconds.
 * Runs online (Gemini vision) or offline (on-device vision model, if one is installed) — the same
 * routing Engine.submitPhoto already uses for typed/voice turns.
 */
@Composable
fun CameraScreen(engine: Engine, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val previewView = remember { PreviewView(ctx) }
    var lensFacing by remember { mutableStateOf(CameraSelector.LENS_FACING_BACK) }
    var imageCapture by remember { mutableStateOf<ImageCapture?>(null) }
    var scanning by remember { mutableStateOf(false) }
    var question by remember { mutableStateOf("") }
    var errorMsg by remember { mutableStateOf("") }
    val executor = remember { Executors.newSingleThreadExecutor() }

    DisposableEffect(Unit) { onDispose { executor.shutdown() } }

    // (Re)binds the camera whenever the lens facing changes.
    LaunchedEffect(lensFacing) {
        try {
            val provider = ProcessCameraProvider.getInstance(ctx).get()
            provider.unbindAll()
            val preview = Preview.Builder().build().also { it.setSurfaceProvider(previewView.surfaceProvider) }
            val capture = ImageCapture.Builder().build()
            val selector = CameraSelector.Builder().requireLensFacing(lensFacing).build()
            provider.bindToLifecycle(lifecycleOwner, selector, preview, capture)
            imageCapture = capture
            errorMsg = ""
        } catch (e: Exception) {
            errorMsg = "Couldn't start that camera."
        }
    }

    fun capture(askedQuestion: String) {
        val cap = imageCapture ?: return
        cap.takePicture(executor, object : ImageCapture.OnImageCapturedCallback() {
            override fun onCaptureSuccess(image: ImageProxy) {
                val bmp = Vision.fromImageProxy(image)
                image.close()
                if (bmp != null) engine.submitPhoto(bmp, askedQuestion)
            }
            override fun onError(exc: ImageCaptureException) {
                errorMsg = "Couldn't take that photo."
            }
        })
    }

    // Live scan: keeps asking "what am I looking at" every few seconds while the toggle is on.
    LaunchedEffect(scanning) {
        while (scanning) {
            capture("")
            delay(5000)
        }
    }

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        AndroidView(factory = { previewView }, modifier = Modifier.fillMaxSize())

        Row(
            Modifier.fillMaxWidth().align(Alignment.TopCenter).padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            RoundGlassButton("✕") { scanning = false; onClose() }
            RoundGlassButton("⟲") {
                lensFacing = if (lensFacing == CameraSelector.LENS_FACING_BACK)
                    CameraSelector.LENS_FACING_FRONT else CameraSelector.LENS_FACING_BACK
            }
        }

        Column(
            Modifier.align(Alignment.BottomCenter).fillMaxWidth().padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            if (errorMsg.isNotEmpty()) {
                Text(errorMsg, color = Color(0xFFFF6B6B), fontSize = 13.sp)
                Spacer(Modifier.height(6.dp))
            }
            if (scanning) {
                Text("Live scanning — describing what's in view every few seconds", color = Color.White, fontSize = 13.sp)
                Spacer(Modifier.height(8.dp))
            }
            OutlinedTextField(
                value = question,
                onValueChange = { question = it },
                placeholder = { Text("Ask about what you see (optional)", color = Color(0xFF999999)) },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
                colors = fieldColors(),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                keyboardActions = KeyboardActions(onSend = { capture(question); question = "" })
            )
            Spacer(Modifier.height(14.dp))
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(28.dp)) {
                TextButton(onClick = { scanning = !scanning }) {
                    Text(if (scanning) "Stop scanning" else "Live scan", color = if (scanning) Color(0xFFFF6B6B) else Color.White)
                }
                Box(
                    Modifier
                        .size(74.dp)
                        .clip(CircleShape)
                        .background(Color.White)
                        .clickable { capture(question); question = "" }
                )
                Spacer(Modifier.size(74.dp)) // balances the row so the shutter stays centered
            }
        }
    }
}

@Composable
private fun RoundGlassButton(label: String, onClick: () -> Unit) {
    Box(
        Modifier
            .size(44.dp)
            .clip(CircleShape)
            .background(Color(0x88000000))
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Text(label, color = Color.White, fontSize = 18.sp)
    }
}
