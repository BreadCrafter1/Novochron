package com.atlas.assistant

import android.content.Context
import android.util.Base64
import javax.crypto.Cipher
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec

/**
 * Encryption for the "Vault (locked photo)" section at the bottom of Settings.
 *
 * The photo itself is never shipped as a plain resource — it's baked into the APK as ciphertext
 * (`res/raw/vault_photo.enc`) and only exists decoded in memory for as long as the vault stays
 * unlocked. There is no stored password or password hash anywhere in the app: the password the
 * person types is fed straight into PBKDF2 to derive the AES key, and that key either opens the
 * file or it doesn't. A wrong password fails AES-GCM's built-in authentication check (the cipher
 * throws) rather than matching against any secret kept in the code, so there's nothing here for
 * someone to just read out of the decompiled app the way a hardcoded password used to allow.
 *
 * Caveat, stated plainly: this is password-based encryption baked into an APK, not a hardware-backed
 * secret. It stops the photo from being casually extracted (unzip the APK, open a drawable) and
 * forces an attacker into an actual offline brute-force of the password against the AES-GCM tag —
 * genuinely slower work, especially at [ITERATIONS] rounds of PBKDF2, but not literally uncrackable
 * against unlimited compute. For one personal photo behind a password only you know, this is a solid
 * upgrade over the previous plaintext-comparison version; it is not a substitute for full-disk
 * encryption or a hardware keystore if the threat model is a determined, resourced attacker.
 */
object VaultCrypto {
    // Not secret — a PBKDF2 salt's whole job is to be unique per-install-of-this-scheme, not hidden.
    private const val SALT_B64 = "7P8Baysz/jZ7a2fD/ALsAw=="
    private const val ITERATIONS = 150_000
    private const val KEY_LEN_BITS = 256
    private const val GCM_TAG_BITS = 128
    private const val IV_LEN_BYTES = 12

    private fun deriveKey(password: String): SecretKeySpec {
        val salt = Base64.decode(SALT_B64, Base64.NO_WRAP)
        val spec = PBEKeySpec(password.toCharArray(), salt, ITERATIONS, KEY_LEN_BITS)
        val keyBytes = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded
        return SecretKeySpec(keyBytes, "AES")
    }

    /**
     * Decrypts `res/raw/vault_photo.enc` with [password]. Returns the decoded photo bytes on
     * success, or null on a wrong password (or any other read/format problem) — deliberately not
     * distinguishing the two, so a bad guess can't be used to learn anything about why it failed.
     * Does real AES work (PBKDF2 at [ITERATIONS] rounds + AES-GCM), so call this off the main thread.
     */
    fun decryptVaultPhoto(ctx: Context, rawResId: Int, password: String): ByteArray? {
        return try {
            val raw = ctx.resources.openRawResource(rawResId).use { it.readBytes() }
            if (raw.size <= IV_LEN_BYTES) return null
            val iv = raw.copyOfRange(0, IV_LEN_BYTES)
            val ciphertext = raw.copyOfRange(IV_LEN_BYTES, raw.size)

            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.DECRYPT_MODE, deriveKey(password), GCMParameterSpec(GCM_TAG_BITS, iv))
            cipher.doFinal(ciphertext)
        } catch (e: Exception) {
            // Wrong password -> GCM's authentication tag check fails (AEADBadTagException) before any
            // plaintext is produced. Any other failure (corrupt resource, etc.) lands here too, on
            // purpose — see the doc comment above.
            null
        }
    }
}
