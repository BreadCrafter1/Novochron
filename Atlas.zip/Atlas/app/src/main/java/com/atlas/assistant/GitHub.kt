package com.atlas.assistant

import android.util.Base64
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

/** A device-code login in progress: shown to the user while [GitHub.pollForToken] waits. */
data class DeviceLogin(
    val userCode: String,
    val verificationUri: String,
    val deviceCode: String,
    val intervalSeconds: Int,
    val expiresInSeconds: Int
)

data class RepoRef(val owner: String, val name: String) {
    val full: String get() = "$owner/$name"
    companion object {
        /** Accepts "owner/name" or a full github.com URL. Returns null if it doesn't parse. */
        fun parse(text: String): RepoRef? {
            val cleaned = text.trim()
                .removePrefix("https://github.com/")
                .removePrefix("http://github.com/")
                .removePrefix("github.com/")
                .removeSuffix(".git")
                .removeSuffix("/")
            val parts = cleaned.split("/").filter { it.isNotBlank() }
            return if (parts.size >= 2) RepoRef(parts[0], parts[1]) else null
        }
    }
}

data class RepoFile(val path: String, val isDir: Boolean)
data class WorkflowRun(val status: String, val conclusion: String?, val htmlUrl: String, val name: String)

class GitHubApiException(val code: Int, val body: String) : IOException("GitHub API HTTP $code: $body")

/**
 * Thin GitHub REST client used so Novochron can log in with a GitHub account (OAuth device flow -
 * no password or client secret ever touches the phone) and then browse a repo, commit files, and
 * kick off / check GitHub Actions builds. All calls are suspend functions meant to be awaited from
 * a coroutine (they switch to Dispatchers.IO internally); none of this touches the main thread.
 *
 * Real compiling/building of an Android app happens on GitHub's own runners via Actions, not on the
 * phone - see README > "GitHub setup" for why, and for the one-time GITHUB_CLIENT_ID setup this needs.
 */
class GitHub(private val store: Store) {

    val isLinked: Boolean get() = store.githubToken.isNotBlank()
    val activeRepo: RepoRef? get() = RepoRef.parse(store.githubRepo)

    // ---------------- OAuth device flow (see https://docs.github.com/en/apps/oauth-apps/building-oauth-apps/authorizing-oauth-apps#device-flow) ----------------

    suspend fun requestDeviceLogin(clientId: String): DeviceLogin = withContext(Dispatchers.IO) {
        val res = postForm(
            "https://github.com/login/device/code",
            mapOf("client_id" to clientId, "scope" to "repo workflow read:user")
        )
        DeviceLogin(
            userCode = res.getString("user_code"),
            verificationUri = res.getString("verification_uri"),
            deviceCode = res.getString("device_code"),
            intervalSeconds = res.optInt("interval", 5),
            expiresInSeconds = res.optInt("expires_in", 900)
        )
    }

    /** Polls until the user finishes authorizing in the browser, or the code expires. Suspends the whole time. */
    suspend fun pollForToken(clientId: String, login: DeviceLogin): Result<String> = withContext(Dispatchers.IO) {
        var waited = 0
        var interval = login.intervalSeconds
        while (waited < login.expiresInSeconds) {
            delay(interval * 1000L)
            waited += interval
            val res = try {
                postForm(
                    "https://github.com/login/oauth/access_token",
                    mapOf(
                        "client_id" to clientId,
                        "device_code" to login.deviceCode,
                        "grant_type" to "urn:ietf:params:oauth:grant-type:device_code"
                    )
                )
            } catch (e: Exception) {
                return@withContext Result.failure(e)
            }
            val token = res.optString("access_token", "")
            if (token.isNotBlank()) {
                store.githubToken = token
                val who = try { fetchLogin(token) } catch (e: Exception) { "" }
                if (who.isNotBlank()) store.githubUser = who
                return@withContext Result.success(token)
            }
            when (res.optString("error", "")) {
                "authorization_pending" -> {} // keep polling
                "slow_down" -> interval += 5
                "expired_token" -> return@withContext Result.failure(IOException("The code expired. Try logging in again."))
                "access_denied" -> return@withContext Result.failure(IOException("Login was cancelled."))
                else -> if (res.has("error")) return@withContext Result.failure(IOException(res.optString("error_description", "Login failed.")))
            }
        }
        Result.failure(IOException("Login timed out."))
    }

    fun logout() {
        store.githubToken = ""
        store.githubUser = ""
    }

    private suspend fun fetchLogin(token: String): String = withContext(Dispatchers.IO) {
        get("https://api.github.com/user", token).getString("login")
    }

    // ---------------- repos ----------------

    /** Repos the logged-in user owns or collaborates on, most recently pushed first. */
    suspend fun listRepos(limit: Int = 15): List<String> = withContext(Dispatchers.IO) {
        val arr = getArray("https://api.github.com/user/repos?sort=pushed&per_page=$limit")
        (0 until arr.length()).map { arr.getJSONObject(it).getString("full_name") }
    }

    suspend fun listFiles(path: String, repo: RepoRef = requireRepo()): List<RepoFile> = withContext(Dispatchers.IO) {
        val clean = path.trim('/').let { Uri2.encodePath(it) }
        val url = "https://api.github.com/repos/${repo.full}/contents/$clean?ref=${store.githubBranch}"
        val body = getRaw(url)
        if (body.trimStart().startsWith("[")) {
            val arr = JSONArray(body)
            (0 until arr.length()).map {
                val o = arr.getJSONObject(it)
                RepoFile(o.getString("path"), o.getString("type") == "dir")
            }.sortedWith(compareBy({ !it.isDir }, { it.path.lowercase() }))
        } else {
            val o = JSONObject(body)
            listOf(RepoFile(o.getString("path"), false))
        }
    }

    /** Returns the decoded text content of a file, or null if it's not a text-decodable file. */
    suspend fun readFile(path: String, repo: RepoRef = requireRepo()): String? = withContext(Dispatchers.IO) {
        val o = getContents(path, repo) ?: return@withContext null
        if (o.optString("encoding") != "base64") return@withContext null
        val bytes = Base64.decode(o.getString("content").replace("\n", ""), Base64.DEFAULT)
        String(bytes, Charsets.UTF_8)
    }

    private suspend fun getContents(path: String, repo: RepoRef): JSONObject? {
        val clean = Uri2.encodePath(path.trim('/'))
        val url = "https://api.github.com/repos/${repo.full}/contents/$clean?ref=${store.githubBranch}"
        return try { get(url) } catch (e: GitHubApiException) { if (e.code == 404) null else throw e }
    }

    /** Creates or updates one file in one commit. Returns the commit's HTML URL. */
    suspend fun commitFile(path: String, content: String, message: String, repo: RepoRef = requireRepo()): String =
        withContext(Dispatchers.IO) {
            val existing = getContents(path, repo)
            val clean = Uri2.encodePath(path.trim('/'))
            val url = "https://api.github.com/repos/${repo.full}/contents/$clean"
            val body = JSONObject().apply {
                put("message", message)
                put("content", Base64.encodeToString(content.toByteArray(Charsets.UTF_8), Base64.NO_WRAP))
                put("branch", store.githubBranch)
                existing?.optString("sha")?.let { if (it.isNotBlank()) put("sha", it) }
            }
            val res = put(url, body)
            res.optJSONObject("commit")?.optString("html_url")
                ?: "https://github.com/${repo.full}/commits/${store.githubBranch}"
        }

    // ---------------- Actions (this is the real "build" - it runs on GitHub's servers, not the phone) ----------------

    suspend fun listWorkflows(repo: RepoRef = requireRepo()): List<Pair<String, String>> = withContext(Dispatchers.IO) {
        val o = get("https://api.github.com/repos/${repo.full}/actions/workflows")
        val arr = o.getJSONArray("workflows")
        (0 until arr.length()).map {
            val w = arr.getJSONObject(it)
            w.getString("name") to w.getString("path").substringAfterLast('/')
        }
    }

    /** Triggers a workflow_dispatch run. The workflow's YAML must have `on: workflow_dispatch:`. */
    suspend fun runWorkflow(workflowFile: String, repo: RepoRef = requireRepo()): Unit = withContext(Dispatchers.IO) {
        val url = "https://api.github.com/repos/${repo.full}/actions/workflows/$workflowFile/dispatches"
        post(url, JSONObject().put("ref", store.githubBranch))
    }

    suspend fun latestRun(repo: RepoRef = requireRepo(), workflowFile: String? = null): WorkflowRun? =
        withContext(Dispatchers.IO) {
            val path = if (workflowFile != null) "actions/workflows/$workflowFile/runs" else "actions/runs"
            val o = get("https://api.github.com/repos/${repo.full}/$path?per_page=1")
            val arr = o.getJSONArray("workflow_runs")
            if (arr.length() == 0) return@withContext null
            val r = arr.getJSONObject(0)
            WorkflowRun(
                status = r.getString("status"),
                conclusion = if (r.isNull("conclusion")) null else r.getString("conclusion"),
                htmlUrl = r.getString("html_url"),
                name = r.getString("name")
            )
        }

    // ---------------- HTTP plumbing ----------------

    private fun requireRepo(): RepoRef = activeRepo
        ?: throw IllegalStateException("No repo selected yet. Say \"use repo owner/name\" first.")

    private fun get(url: String, token: String = store.githubToken): JSONObject = JSONObject(getRaw(url, token))
    private fun getArray(url: String, token: String = store.githubToken): JSONArray = JSONArray(getRaw(url, token))

    private fun getRaw(url: String, token: String = store.githubToken): String = request(url, "GET", token, null)
    private fun post(url: String, body: JSONObject, token: String = store.githubToken): JSONObject {
        val res = request(url, "POST", token, body.toString())
        return if (res.isBlank()) JSONObject() else JSONObject(res)
    }
    private fun put(url: String, body: JSONObject, token: String = store.githubToken): JSONObject =
        JSONObject(request(url, "PUT", token, body.toString()))

    private fun postForm(url: String, params: Map<String, String>): JSONObject {
        val conn = URL(url).openConnection() as HttpURLConnection
        try {
            conn.requestMethod = "POST"
            conn.doOutput = true
            conn.connectTimeout = 15000
            conn.readTimeout = 20000
            conn.setRequestProperty("Accept", "application/json")
            conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded")
            val form = params.entries.joinToString("&") { (k, v) -> "$k=${java.net.URLEncoder.encode(v, "UTF-8")}" }
            conn.outputStream.use { it.write(form.toByteArray(Charsets.UTF_8)) }
            val code = conn.responseCode
            val text = readBody(conn, code)
            if (code !in 200..299) throw GitHubApiException(code, text)
            return JSONObject(text)
        } finally {
            conn.disconnect()
        }
    }

    private fun request(url: String, method: String, token: String, jsonBody: String?): String {
        val conn = URL(url).openConnection() as HttpURLConnection
        try {
            conn.requestMethod = method
            conn.connectTimeout = 15000
            conn.readTimeout = 20000
            conn.setRequestProperty("Accept", "application/vnd.github+json")
            conn.setRequestProperty("X-GitHub-Api-Version", "2022-11-28")
            if (token.isNotBlank()) conn.setRequestProperty("Authorization", "Bearer $token")
            if (jsonBody != null) {
                conn.doOutput = true
                conn.setRequestProperty("Content-Type", "application/json")
                conn.outputStream.use { it.write(jsonBody.toByteArray(Charsets.UTF_8)) }
            }
            val code = conn.responseCode
            val text = readBody(conn, code)
            if (code !in 200..299) throw GitHubApiException(code, text)
            return text
        } finally {
            conn.disconnect()
        }
    }

    private fun readBody(conn: HttpURLConnection, code: Int): String {
        val stream = if (code in 200..299) conn.inputStream else conn.errorStream
        return try { stream?.bufferedReader()?.use { it.readText() } ?: "" } catch (e: Exception) { "" }
    }
}

/** Tiny path-segment encoder (java.net.URLEncoder encodes "/" too, which we need to keep). */
private object Uri2 {
    fun encodePath(path: String): String =
        path.split("/").joinToString("/") { java.net.URLEncoder.encode(it, "UTF-8") }
}
