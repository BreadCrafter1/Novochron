package com.atlas.assistant

import android.Manifest
import android.app.AlarmManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import android.os.SystemClock
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.app.Person
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/**
 * Message alerts for "msg". The msg screen only polls the shared repo while it's open, so on its own you'd
 * never know someone wrote until you looked. This foreground service keeps checking in the background and
 * raises a normal notification for anything the *other* person sent.
 *
 * Two modes (Store.msgNotifyMode), because checking often costs battery - the [stats] screen shows how much:
 *  - "instant": a check every [INSTANT_MS] with a partial wake lock held, so alerts land within seconds.
 *  - "saver":   an alarm every [SAVER_MS] wakes the phone just long enough for one check. Much cheaper, slower.
 *
 * It remembers which message files it has already seen (per repo + branch), so turning alerts on never
 * floods you with old messages, and a message is announced exactly once.
 */
class MsgWatchService : Service() {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var loop: Job? = null
    private var wake: PowerManager.WakeLock? = null
    private lateinit var store: Store
    private lateinit var client: MsgClient
    private var tickRegistered = false
    private var tracking = false

    private val tickReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            if (store.msgNotifyMode != "saver") return
            val lock = grabWake(90_000L)
            scope.launch {
                try { checkOnce() } finally {
                    releaseWake(lock)
                    scheduleAlarm()
                }
            }
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        store = Store.get(this)
        client = MsgClient(tokenProvider = { store.githubToken }, branchProvider = { store.githubBranch })
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        // A service started with startForegroundService() must call startForeground() promptly, even if it
        // is about to stop again - so always do it first.
        try {
            val n = buildOngoing()
            if (Build.VERSION.SDK_INT >= 29) startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
            else startForeground(NOTIF_ID, n)
        } catch (e: Exception) {
            stopSelf(); return START_NOT_STICKY
        }

        if (intent?.action == ACTION_STOP) {
            store.msgNotify = false
            store.msgSpeak = false
            stopSelf(); return START_NOT_STICKY
        }
        if (!(store.msgNotify || store.msgSpeak) || store.githubToken.isBlank() || RepoRef.parse(store.msgRepo) == null) {
            stopSelf(); return START_NOT_STICKY
        }
        startWatching()
        return START_STICKY
    }

    /** (Re)starts the checking loop according to the current mode. Safe to call again after a mode change. */
    private fun startWatching() {
        loop?.cancel(); loop = null
        cancelAlarm()
        if (!tracking) { tracking = true; BatteryTracker.setActive(this, BatteryTracker.TAG_MSG, true) }

        if (store.msgNotifyMode == "saver") {
            releaseWake(wake); wake = null
            if (!tickRegistered) {
                ContextCompat.registerReceiver(this, tickReceiver, IntentFilter(ACTION_TICK), ContextCompat.RECEIVER_NOT_EXPORTED)
                tickRegistered = true
            }
            scope.launch { checkOnce(); scheduleAlarm() }
        } else {
            loop = scope.launch {
                while (isActive) {
                    armWake(10 * 60_000L)                  // re-armed every pass, so it can never be held forever
                    checkOnce()
                    delay(INSTANT_MS)
                }
            }
        }
    }

    private suspend fun checkOnce() {
        try {
            MsgWatcher.checkAndNotify(this, store, client)
            BatteryTracker.sample(this)
        } catch (e: Exception) { /* a failed check is simply retried next time */ }
    }

    // ---------------- wake lock + alarm ----------------

    private fun grabWake(timeoutMs: Long): PowerManager.WakeLock {
        val wl = getSystemService(PowerManager::class.java).newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "novochron:msgwatch")
        wl.setReferenceCounted(false)
        wl.acquire(timeoutMs)
        return wl
    }

    /** The instant-mode lock: one object, re-acquired (which resets its timeout) on every pass. */
    private fun armWake(timeoutMs: Long) {
        val wl = wake ?: getSystemService(PowerManager::class.java)
            .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "novochron:msgwatch-live")
            .also { it.setReferenceCounted(false); wake = it }
        wl.acquire(timeoutMs)
    }

    private fun releaseWake(wl: PowerManager.WakeLock?) {
        try { if (wl?.isHeld == true) wl.release() } catch (e: Exception) { }
    }

    private fun alarmIntent(): PendingIntent = PendingIntent.getBroadcast(
        this, 7, Intent(ACTION_TICK).setPackage(packageName), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
    )

    private fun scheduleAlarm() {
        try {
            getSystemService(AlarmManager::class.java)
                .setAndAllowWhileIdle(AlarmManager.ELAPSED_REALTIME_WAKEUP, SystemClock.elapsedRealtime() + SAVER_MS, alarmIntent())
        } catch (e: Exception) { }
    }

    private fun cancelAlarm() {
        try { getSystemService(AlarmManager::class.java).cancel(alarmIntent()) } catch (e: Exception) { }
    }

    override fun onDestroy() {
        loop?.cancel()
        scope.cancel()
        cancelAlarm()
        if (tickRegistered) { try { unregisterReceiver(tickReceiver) } catch (e: Exception) { }; tickRegistered = false }
        releaseWake(wake); wake = null
        if (tracking) { tracking = false; BatteryTracker.setActive(this, BatteryTracker.TAG_MSG, false) }
        super.onDestroy()
    }

    private fun buildOngoing(): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH_WATCH, "Message watcher", NotificationManager.IMPORTANCE_MIN))
        val open = PendingIntent.getActivity(this, 2, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val off = PendingIntent.getService(
            this, 3, Intent(this, MsgWatchService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CH_WATCH)
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle(if (store.msgSpeak) "Watching for messages (reads them aloud)" else "Watching for messages")
            .setContentText(if (store.msgNotifyMode == "saver") "Battery saver mode · checks every few minutes" else "Instant mode · checks every few seconds")
            .setContentIntent(open)
            .addAction(0, "Turn off", off)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_MIN)
            .build()
    }

    companion object {
        const val ACTION_STOP = "com.novochron.assistant.MSG_WATCH_STOP"
        private const val ACTION_TICK = "com.novochron.assistant.MSG_WATCH_TICK"
        const val CH_WATCH = "novochron_msg_watch"
        private const val NOTIF_ID = 43
        private const val INSTANT_MS = 15_000L
        private const val SAVER_MS = 5 * 60_000L

        /** Starts or stops the watcher so it matches the settings. Call after any change, and on app launch. */
        fun refresh(ctx: Context) {
            val store = Store.get(ctx)
            val wanted = (store.msgNotify || store.msgSpeak) && store.githubToken.isNotBlank() && RepoRef.parse(store.msgRepo) != null
            try {
                if (wanted) ContextCompat.startForegroundService(ctx, Intent(ctx, MsgWatchService::class.java))
                else ctx.stopService(Intent(ctx, MsgWatchService::class.java))
            } catch (e: Exception) {
                // Android refused to start a foreground service from the background; it'll start next time the app opens.
            }
        }
    }
}

/** What arrived, boiled down for a notification. */
internal data class Incoming(val from: String, val ts: Long, val line: String, val kind: String, val text: String)

/**
 * The actual "anything new?" logic, kept apart from the service so it has no lifecycle worries.
 * Remembers seen message files in msg_seen_<hash>.json; the very first check for a repo only records what's
 * already there (a baseline) and notifies nothing.
 */
object MsgWatcher {
    private const val MSG_DIR = "Msg"

    private fun seenFile(ctx: Context, repo: String, branch: String) =
        File(ctx.applicationContext.filesDir, "msg_seen_${"$repo@$branch".hashCode()}.json")

    suspend fun checkAndNotify(ctx: Context, store: Store, client: MsgClient) {
        val repo = RepoRef.parse(store.msgRepo) ?: return
        if (store.githubToken.isBlank()) return
        val files = client.listFiles(MSG_DIR, repo)
        val json = files.filter { !it.isDir && it.path.endsWith(".json") }
        val listed = json.mapTo(HashSet()) { it.path }

        val f = seenFile(ctx, store.msgRepo, store.githubBranch)
        val seen: MutableSet<String>? = try {
            if (!f.exists()) null else {
                val arr = JSONArray(f.readText())
                (0 until arr.length()).mapTo(HashSet()) { arr.getString(it) }
            }
        } catch (e: Exception) { null }

        if (seen == null) { saveSeen(f, listed); return }          // first run: baseline only

        val fresh = json.filter { it.path !in seen }.sortedBy { it.path }
        if (fresh.isEmpty()) return

        val me = store.msgUserName.ifBlank { "me" }
        val incoming = ArrayList<Incoming>()
        for (file in fresh) {
            val body = try { client.readFile(file.path, repo) } catch (e: Exception) { null } ?: continue   // retry next check
            seen += file.path
            val o = try { JSONObject(body) } catch (e: Exception) { continue }
            val from = o.optString("from", "them")
            if (from.equals(me, ignoreCase = true)) continue          // my own message, sent from another device
            val kind = o.optString("type", "TEXT").uppercase()
            val text = o.optString("text", "")
            val line = when (kind) {
                "PHOTO" -> "📷 Photo"
                "VIDEO" -> "🎥 Video"
                "VOICE" -> "🎤 Voice message"
                else -> text.ifBlank { "New message" }
            }
            incoming += Incoming(from, o.optLong("ts", System.currentTimeMillis()), line, kind, text)
        }
        saveSeen(f, seen.filterTo(HashSet()) { it in listed })       // forget files that were deleted

        if (incoming.isEmpty()) return

        // Read it out: who it's from and what they said.
        if (store.msgSpeak) {
            try { spokenLines(incoming).forEach { Engine.get(ctx).announce(it) } } catch (e: Exception) { }
        }
        // If the person is looking at msg right now they'll see it there - no need to buzz them too.
        val watching = AssistantState.appVisible && AssistantState.showMsg.value
        if (store.msgNotify && !watching) MsgNotifier.show(ctx, me, incoming)
    }

    /** Up to three messages are read individually; anything beyond that is summed up so a burst doesn't drone on. */
    private fun spokenLines(list: List<Incoming>): List<String> {
        val out = ArrayList<String>()
        for (m in list.take(3)) {
            out += when (m.kind) {
                "PHOTO" -> "${m.from} sent you a photo."
                "VIDEO" -> "${m.from} sent you a video."
                "VOICE" -> "${m.from} sent you a voice message."
                else -> {
                    val body = m.text.trim().let { if (it.length > 240) it.take(240).trimEnd() + "…" else it }
                    if (body.isBlank()) "New message from ${m.from}." else "Message from ${m.from}: $body"
                }
            }
        }
        if (list.size > 3) {
            val more = list.size - 3
            out += "…and $more more message${if (more == 1) "" else "s"}."
        }
        return out
    }

    /** Forget what's been seen, so the next check starts fresh instead of announcing everything missed while alerts were off. */
    fun resetBaseline(ctx: Context, store: Store) {
        try { seenFile(ctx, store.msgRepo, store.githubBranch).delete() } catch (e: Exception) { }
    }

    private fun saveSeen(f: File, paths: Set<String>) {
        try { f.writeText(JSONArray(paths.toList()).toString()) } catch (e: Exception) { }
    }
}

/** Posts (and clears) the "new message" notification. One notification, updated as more arrive. */
object MsgNotifier {
    private const val CH = "novochron_msg"
    private const val NOTIF_ID = 4300
    private const val KEEP = 8
    private val recent = ArrayList<Incoming>()

    @Synchronized
    internal fun show(ctx: Context, me: String, added: List<Incoming>) {
        val app = ctx.applicationContext
        if (Build.VERSION.SDK_INT >= 33 &&
            app.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) return

        recent += added
        while (recent.size > KEEP) recent.removeAt(0)

        val nm = app.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH, "Messages", NotificationManager.IMPORTANCE_HIGH))

        val meP = Person.Builder().setName(me).build()
        val style = NotificationCompat.MessagingStyle(meP)
        recent.forEach { style.addMessage(it.line, it.ts, Person.Builder().setName(it.from).build()) }
        val last = recent.last()

        val open = PendingIntent.getActivity(
            app, 4,
            Intent(app, MainActivity::class.java).putExtra(EXTRA_OPEN_MSG, true)
                .addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = NotificationCompat.Builder(app, CH)
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle(last.from)
            .setContentText(last.line)
            .setStyle(style)
            .setCategory(NotificationCompat.CATEGORY_MESSAGE)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setContentIntent(open)
            .setAutoCancel(true)
            .setNumber(recent.size)
            .build()
        try { NotificationManagerCompat.from(app).notify(NOTIF_ID, n) } catch (e: SecurityException) { }
    }

    /** Call when msg is opened, so the alert doesn't linger after you've read it. */
    @Synchronized
    fun clear(ctx: Context) {
        recent.clear()
        try { NotificationManagerCompat.from(ctx.applicationContext).cancel(NOTIF_ID) } catch (e: Exception) { }
    }

    const val EXTRA_OPEN_MSG = "open_msg"
}
