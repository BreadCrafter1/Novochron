package com.atlas.assistant

import android.content.Context
import com.rementia.openwakeword.lib.DetectionMode
import com.rementia.openwakeword.lib.WakeWordEngine
import com.rementia.openwakeword.lib.WakeWordModel
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

/**
 * A real dedicated low-power wake engine, the same shape as "Hey Google": a tiny always-on
 * keyword-spotting model (openWakeWord, running fully offline on-device via ONNX Runtime) listens
 * continuously on its own, using a small fraction of the CPU/battery a full speech recognizer needs,
 * and only wakes the rest of Novochron up once it actually hears the phrase. This replaces WakeWord's
 * old approach of gating the full SpeechRecognizer, which cost the same battery as Voice being on. See
 * AssistantService for how the two are switched between: openWakeWord runs while idle and waiting, the
 * full recognizer only runs for the follow-on command right after a wake is detected.
 *
 * Unlike Porcupine (the previous engine here), openWakeWord needs no account or AccessKey — it's fully
 * offline and free. The tradeoff: its three ONNX models (the fixed `melspectrogram.onnx` +
 * `embedding_model.onnx` preprocessing pair, and one classifier `.onnx` per wake word) are loaded by
 * the library from the app's bundled assets, not from a file a user can drop into shared storage at
 * runtime — so, unlike Porcupine's `Atlas/Models/wakeword.ppn`, changing the wake word here means
 * putting a new classifier `.onnx` in `app/src/main/assets/` and rebuilding, not dropping a file in and
 * relaunching. See README > "Wake word setup" for where to get all three files.
 *
 * [available] fails closed: if the required assets aren't present in this build, Novochron just falls
 * back to the old always-on-recognizer gating rather than silently not listening at all.
 */
class OpenWakeWordWake(private val ctx: Context) {
    private var engine: WakeWordEngine? = null
    private var scope: CoroutineScope? = null
    @Volatile private var running = false

    private fun hasAsset(path: String): Boolean = try {
        ctx.assets.open(path).close()
        true
    } catch (e: Exception) {
        false
    }

    fun available(): Boolean =
        hasAsset(MEL_ASSET) && hasAsset(EMBED_ASSET) && hasAsset(WAKEWORD_ASSET)

    /** Starts low-power listening. [onWake] fires on a background thread the instant the phrase is heard. */
    @Synchronized
    fun start(onWake: () -> Unit): Boolean {
        if (running) return true
        if (!available()) return false
        return try {
            val store = Store.get(ctx)
            val model = WakeWordModel(
                name = "atlas",
                modelPath = WAKEWORD_ASSET,
                threshold = store.wakeEngineThreshold
            )
            val newScope = CoroutineScope(Dispatchers.Default + SupervisorJob())
            val newEngine = WakeWordEngine(
                context = ctx,
                models = listOf(model),
                detectionMode = DetectionMode.SINGLE_BEST,
                scope = newScope
            )
            newScope.launch {
                newEngine.detections.collect { onWake() }
            }
            newEngine.start()
            engine = newEngine
            scope = newScope
            running = true
            true
        } catch (e: Exception) {
            try { engine?.release() } catch (e2: Exception) { }
            scope?.cancel()
            engine = null
            scope = null
            running = false
            false
        }
    }

    @Synchronized
    fun stop() {
        try { engine?.release() } catch (e: Exception) { }
        try { scope?.cancel() } catch (e: Exception) { }
        engine = null
        scope = null
        running = false
    }

    companion object {
        const val DEFAULT_THRESHOLD = 0.5f

        // Flat in assets root - matches the layout openwakeword-android-kt expects (see its README
        // "Required Files"). melspectrogram.onnx and embedding_model.onnx are openWakeWord's fixed,
        // word-independent preprocessing/embedding pair; wakeword.onnx is Novochron's classifier for
        // whichever word it was trained on.
        private const val MEL_ASSET = "melspectrogram.onnx"
        private const val EMBED_ASSET = "embedding_model.onnx"
        private const val WAKEWORD_ASSET = "wakeword.onnx"
    }
}
