package com.atlas.assistant

import android.annotation.SuppressLint
import android.app.DownloadManager
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.net.http.SslError
import android.os.Build
import android.os.Environment
import android.view.View
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.SslErrorHandler
import android.webkit.URLUtil
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebStorage
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView

/** Everything the page-loading callbacks report back to the UI. */
private class WebUi {
    var url by mutableStateOf("")
    var title by mutableStateOf("")
    var progress by mutableIntStateOf(0)
    var loading by mutableStateOf(false)
    var canBack by mutableStateOf(false)
    var canForward by mutableStateOf(false)
    var error by mutableStateOf<String?>(null)
    var note by mutableStateOf("")
    var customView by mutableStateOf<View?>(null)
    var customCallback: WebChromeClient.CustomViewCallback? = null
}

/**
 * "[web]": a small browser in the same terminal skin as everything else. Type an address to go there,
 * type anything else to search (DuckDuckGo by default; Google / Brave / Bing in `[opts]`).
 *
 * - Pages open over https only (plain http is upgraded, Android blocks cleartext anyway); file:, intent:,
 *   javascript: and other non-web links are refused. No JavaScript bridge, no file access.
 * - Follows the online/offline switch: with "offline" on, nothing is loaded.
 * - Dark pages, desktop site, private mode, bookmarks and history live in `[opts]` and on the start page.
 * - Hardware back walks back through pages, then to the start page, then closes the screen.
 */
@Composable
fun BrowserScreen(engine: Engine, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val store = engine.store
    val focusManager = LocalFocusManager.current
    val ui = remember { WebUi() }

    var engineKey by remember { mutableStateOf(store.webEngine) }
    var dark by remember { mutableStateOf(store.webDark) }
    var desktop by remember { mutableStateOf(store.webDesktop) }
    var priv by remember { mutableStateOf(store.webPrivate) }
    var bookmarks by remember { mutableStateOf(store.webBookmarks()) }
    var history by remember { mutableStateOf(store.webHistory()) }
    var home by remember { mutableStateOf(true) }
    var showOpts by remember { mutableStateOf(false) }
    var addr by remember { mutableStateOf(TextFieldValue("")) }
    var focused by remember { mutableStateOf(false) }

    val offline by AssistantState.forceOffline.collectAsState()
    val pending by AssistantState.webRequest.collectAsState()

    val defaultUa = remember { WebSettings.getDefaultUserAgent(ctx) }

    val recordVisit: (String, String) -> Unit = { url, title ->
        if (!store.webPrivate && url.startsWith("http")) {
            val next = (listOf(WebEntry(title.ifBlank { Web.hostOf(url) }, url)) +
                store.webHistory().filterNot { it.url == url }).take(60)
            store.saveWebHistory(next)
            history = next
        }
    }

    val web = remember {
        buildWebView(ctx, ui, recordVisit).also {
            applyDark(it, dark)
            applyDesktop(it, desktop, defaultUa)
        }
    }

    fun go(input: String) {
        if (AssistantState.forceOffline.value) {
            ui.note = "offline mode is on. switch to online to browse."
            return
        }
        val target = Web.resolve(input, engineKey)
        if (target == null) {
            ui.note = "can't open that: only web addresses and searches."
            return
        }
        ui.note = ""
        ui.error = null
        ui.url = target
        home = false
        web.loadUrl(target)
    }

    fun hideCustomView() {
        ui.customCallback?.onCustomViewHidden()
        ui.customCallback = null
        ui.customView = null
    }

    fun toggleBookmark() {
        val cur = ui.url
        if (home || cur.isBlank()) return
        val had = bookmarks.any { it.url == cur }
        val next = if (had) bookmarks.filterNot { it.url == cur }
        else listOf(WebEntry(ui.title.ifBlank { Web.hostOf(cur) }, cur)) + bookmarks
        bookmarks = next
        store.saveWebBookmarks(next)
        ui.note = if (had) "bookmark removed." else "bookmarked."
    }

    // "search the web for ..." from the voice / chat commands lands here
    LaunchedEffect(pending) {
        val r = pending
        if (r != null) {
            AssistantState.webRequest.value = null
            if (r.isNotBlank()) go(r)
        }
    }

    // keep the address bar in step with the page, unless the user is typing in it
    val shown = if (home) "" else ui.url
    LaunchedEffect(shown, focused) {
        if (!focused) addr = TextFieldValue(shown)
    }

    BackHandler {
        when {
            ui.customView != null -> hideCustomView()
            !home && web.canGoBack() -> web.goBack()
            !home -> home = true
            else -> onClose()
        }
    }

    DisposableEffect(Unit) {
        onDispose {
            ui.customCallback?.onCustomViewHidden()
            ui.customCallback = null
            ui.customView = null
            web.stopLoading()
            if (store.webPrivate) wipeWebData(web)
            (web.parent as? ViewGroup)?.removeView(web)
            web.destroy()
        }
    }

    val isMarked = !home && bookmarks.any { it.url == ui.url }
    val secure = ui.url.startsWith("https://")

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        Column(Modifier.fillMaxSize().padding(12.dp)) {
            // title row
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        "[ web ]",
                        color = Accent,
                        fontFamily = TermFont,
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp
                    )
                    if (priv) {
                        Text("  private", color = Warn, fontFamily = TermFont, fontSize = 12.sp)
                    }
                    if (offline) {
                        Text("  offline", color = Dim, fontFamily = TermFont, fontSize = 12.sp)
                    }
                }
                TermTextKey("[close]", onClick = onClose)
            }

            // address bar
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(
                    value = addr,
                    onValueChange = { addr = it },
                    singleLine = true,
                    placeholder = {
                        Text("search or type an address", color = Dim, fontFamily = TermFont, fontSize = 13.sp)
                    },
                    leadingIcon = {
                        Text(
                            if (home || ui.url.isBlank()) "$" else if (secure) "[s]" else "[!]",
                            color = if (!home && ui.url.isNotBlank() && !secure) Warn else Accent,
                            fontFamily = TermFont,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            modifier = Modifier.padding(start = 6.dp)
                        )
                    },
                    textStyle = TextStyle(fontFamily = TermFont, fontSize = 14.sp, color = Ink),
                    keyboardOptions = KeyboardOptions(
                        capitalization = KeyboardCapitalization.None,
                        keyboardType = KeyboardType.Uri,
                        imeAction = ImeAction.Go
                    ),
                    keyboardActions = KeyboardActions(onGo = {
                        focusManager.clearFocus()
                        go(addr.text)
                    }),
                    colors = fieldColors(),
                    modifier = Modifier
                        .weight(1f)
                        .onFocusChanged { st ->
                            focused = st.isFocused
                            if (st.isFocused) addr = addr.copy(selection = TextRange(0, addr.text.length))
                        }
                )
                TermTextKey("[go]", tone = Accent, bold = true) {
                    focusManager.clearFocus()
                    go(addr.text)
                }
            }

            // load progress: a 2 dp green line
            Spacer(Modifier.height(6.dp))
            Box(Modifier.fillMaxWidth().height(2.dp).background(Line)) {
                if (ui.loading) {
                    Box(
                        Modifier
                            .fillMaxWidth(ui.progress.coerceIn(3, 100) / 100f)
                            .fillMaxHeight()
                            .background(Accent)
                    )
                }
            }
            if (ui.note.isNotBlank()) {
                Text(ui.note, color = Dim, fontFamily = TermFont, fontSize = 11.sp, modifier = Modifier.padding(top = 4.dp))
            }
            Spacer(Modifier.height(6.dp))

            // page area: the WebView is always there (so a page survives a trip to the start page);
            // the start page or an error panel is drawn over it when needed
            Box(Modifier.weight(1f).fillMaxWidth().border(1.dp, Line)) {
                AndroidView(
                    modifier = Modifier.fillMaxSize(),
                    factory = { web },
                    update = { it.visibility = if (home || ui.error != null) View.INVISIBLE else View.VISIBLE }
                )
                if (home) {
                    WebHome(
                        engineKey = engineKey,
                        offline = offline,
                        priv = priv,
                        bookmarks = bookmarks,
                        history = history,
                        onEngine = { engineKey = it; store.webEngine = it },
                        onOpen = { go(it) },
                        onRemoveBookmark = { b ->
                            val next = bookmarks.filterNot { it.url == b.url }
                            bookmarks = next
                            store.saveWebBookmarks(next)
                        },
                        onClearHistory = {
                            store.clearWebHistory()
                            history = emptyList()
                        },
                        onGoOnline = { engine.setForceOffline(false) }
                    )
                } else {
                    val err = ui.error
                    if (err != null) {
                        Column(
                            Modifier
                                .fillMaxSize()
                                .background(Color.Black)
                                .pointerInput(Unit) { detectTapGestures { } }
                                .padding(18.dp)
                        ) {
                            Text("[ can't load page ]", color = Warn, fontFamily = TermFont, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                            Spacer(Modifier.height(10.dp))
                            Text(err, color = Ink, fontFamily = TermFont, fontSize = 13.sp)
                            Spacer(Modifier.height(6.dp))
                            Text(ui.url, color = Dim, fontFamily = TermFont, fontSize = 11.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                            Spacer(Modifier.height(10.dp))
                            Row {
                                TermTextKey("[retry]", tone = Accent, bold = true) {
                                    val u = ui.url
                                    ui.error = null
                                    if (u.isNotBlank() && !AssistantState.forceOffline.value) web.loadUrl(u)
                                }
                                TermTextKey("[start page]") { ui.error = null; home = true }
                            }
                        }
                    }
                }
            }

            // toolbar: scrolls sideways on narrow screens, like the main screen's key rows
            Row(
                Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                verticalAlignment = Alignment.CenterVertically
            ) {
                val canBackNow = if (home) ui.url.isNotBlank() else true
                TermTextKey("[<]", tone = if (canBackNow) Ink else Dim) {
                    if (home) {
                        if (ui.url.isNotBlank()) home = false
                    } else if (web.canGoBack()) {
                        web.goBack()
                    } else {
                        home = true
                    }
                }
                TermTextKey("[>]", tone = if (!home && ui.canForward) Ink else Dim) {
                    if (!home && web.canGoForward()) web.goForward()
                }
                TermTextKey(if (ui.loading) "[stop]" else "[reload]") {
                    if (ui.loading) web.stopLoading()
                    else if (!home && ui.url.isNotBlank() && !AssistantState.forceOffline.value) {
                        ui.error = null
                        web.reload()
                    }
                }
                TermTextKey("[home]", tone = if (home) Accent else Ink) { home = true }
                TermTextKey(
                    if (isMarked) "[marked]" else "[mark]",
                    tone = if (isMarked) Accent else Ink,
                    bold = isMarked
                ) { toggleBookmark() }
                TermTextKey("[share]", tone = if (!home && ui.url.isNotBlank()) Ink else Dim) {
                    if (!home && ui.url.isNotBlank()) shareUrl(ctx, ui.url, ui.title)
                }
                TermTextKey("[ext]", tone = if (!home && ui.url.isNotBlank()) Ink else Dim) {
                    if (!home && ui.url.isNotBlank() && !openExternal(ctx, ui.url)) ui.note = "no app can open that."
                }
                TermTextKey("[opts]") { showOpts = true }
            }
        }

        // a page's fullscreen video (a "custom view") takes over the whole screen
        ui.customView?.let { cv ->
            key(cv) {
                AndroidView(
                    modifier = Modifier.fillMaxSize().background(Color.Black),
                    factory = { c ->
                        FrameLayout(c).apply {
                            setBackgroundColor(android.graphics.Color.BLACK)
                            addView(
                                cv,
                                FrameLayout.LayoutParams(
                                    ViewGroup.LayoutParams.MATCH_PARENT,
                                    ViewGroup.LayoutParams.MATCH_PARENT
                                )
                            )
                        }
                    }
                )
            }
        }
    }

    if (showOpts) {
        AlertDialog(
            onDismissRequest = { showOpts = false },
            containerColor = Color(0xFF0B0B0B),
            title = { Text("[ web options ]", color = Accent, fontFamily = TermFont, fontWeight = FontWeight.Bold) },
            text = {
                Column {
                    OptRow("search engine", Web.engine(engineKey).label, hot = true) {
                        val n = Web.nextEngine(engineKey)
                        engineKey = n.key
                        store.webEngine = n.key
                    }
                    OptRow("dark pages", if (dark) "on" else "off", hot = dark) {
                        dark = !dark
                        store.webDark = dark
                        applyDark(web, dark)
                    }
                    OptRow("desktop site", if (desktop) "on" else "off", hot = desktop) {
                        desktop = !desktop
                        store.webDesktop = desktop
                        applyDesktop(web, desktop, defaultUa)
                        if (!home && ui.url.isNotBlank() && !AssistantState.forceOffline.value) web.reload()
                    }
                    OptRow("private mode", if (priv) "on" else "off", hot = priv) {
                        priv = !priv
                        store.webPrivate = priv
                    }
                    OptRow("clear history", "${history.size} saved") {
                        store.clearWebHistory()
                        history = emptyList()
                        ui.note = "history cleared."
                    }
                    OptRow("wipe cookies + cache", "now") {
                        wipeWebData(web)
                        ui.note = "cookies and cache wiped."
                        showOpts = false
                    }
                    Spacer(Modifier.height(8.dp))
                    Text(
                        "private mode keeps no history and wipes cookies when you leave [web]. " +
                            "pages open over https only, and third-party cookies are blocked.",
                        color = Dim,
                        fontFamily = TermFont,
                        fontSize = 11.sp
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = { showOpts = false }) { Text("Close", color = Accent, fontFamily = TermFont) }
            }
        )
    }
}

/** The page shown before anything is loaded (and when `[home]` is tapped): bookmarks and recent pages. */
@Composable
private fun WebHome(
    engineKey: String,
    offline: Boolean,
    priv: Boolean,
    bookmarks: List<WebEntry>,
    history: List<WebEntry>,
    onEngine: (String) -> Unit,
    onOpen: (String) -> Unit,
    onRemoveBookmark: (WebEntry) -> Unit,
    onClearHistory: () -> Unit,
    onGoOnline: () -> Unit
) {
    LazyColumn(
        Modifier
            .fillMaxSize()
            .background(Color.Black)
            .padding(horizontal = 12.dp)
    ) {
        item {
            Spacer(Modifier.height(14.dp))
            Row {
                Text("root@novochron:~$", color = Ink, fontFamily = TermFont, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                Text(" browse █", color = Accent, fontFamily = TermFont, fontWeight = FontWeight.Bold, fontSize = 15.sp)
            }
            Spacer(Modifier.height(6.dp))
            Text(
                "type an address to go there, or anything else to search.",
                color = Dim, fontFamily = TermFont, fontSize = 12.sp
            )
            Text(
                "or say: \"search the web for ...\"",
                color = Dim, fontFamily = TermFont, fontSize = 12.sp
            )
            if (offline) {
                Spacer(Modifier.height(10.dp))
                Text(
                    "offline mode is on: nothing leaves the phone, so pages won't load.",
                    color = Warn, fontFamily = TermFont, fontSize = 12.sp
                )
                TermTextKey("[go online]", tone = Accent, bold = true, hpad = 0, onClick = onGoOnline)
            }
            if (priv) {
                Spacer(Modifier.height(6.dp))
                Text("private mode: history off.", color = Warn, fontFamily = TermFont, fontSize = 12.sp)
            }
            Spacer(Modifier.height(10.dp))
            Row(Modifier.horizontalScroll(rememberScrollState()), verticalAlignment = Alignment.CenterVertically) {
                Text("engine:", color = Dim, fontFamily = TermFont, fontSize = 12.sp)
                Spacer(Modifier.width(4.dp))
                for (e in Web.engines) {
                    val on = e.key == engineKey
                    TermTextKey(
                        if (on) "[${e.short}]" else e.short,
                        tone = if (on) Accent else Dim,
                        bold = on,
                        hpad = 6
                    ) { onEngine(e.key) }
                }
            }
            Spacer(Modifier.height(12.dp))
            Text("bookmarks", color = Accent, fontFamily = TermFont, fontWeight = FontWeight.Bold, fontSize = 13.sp)
            if (bookmarks.isEmpty()) {
                Text(
                    "none yet. tap [mark] while on a page to keep it here.",
                    color = Dim, fontFamily = TermFont, fontSize = 12.sp,
                    modifier = Modifier.padding(vertical = 6.dp)
                )
            }
        }
        items(bookmarks) { b -> WebEntryRow(b, onOpen = { onOpen(b.url) }, onRemove = { onRemoveBookmark(b) }) }
        item {
            Spacer(Modifier.height(14.dp))
            Text("recent", color = Accent, fontFamily = TermFont, fontWeight = FontWeight.Bold, fontSize = 13.sp)
            if (history.isEmpty()) {
                Text(
                    "nothing yet.",
                    color = Dim, fontFamily = TermFont, fontSize = 12.sp,
                    modifier = Modifier.padding(vertical = 6.dp)
                )
            }
        }
        items(history.take(15)) { h -> WebEntryRow(h, onOpen = { onOpen(h.url) }, onRemove = null) }
        if (history.isNotEmpty()) {
            item { TermTextKey("[clear history]", tone = Dim, hpad = 0, onClick = onClearHistory) }
        }
        item { Spacer(Modifier.height(16.dp)) }
    }
}

@Composable
private fun WebEntryRow(entry: WebEntry, onOpen: () -> Unit, onRemove: (() -> Unit)?) {
    Row(
        Modifier
            .fillMaxWidth()
            .clickable(onClick = onOpen)
            .padding(vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(
                entry.title.ifBlank { Web.hostOf(entry.url) },
                color = Ink, fontFamily = TermFont, fontSize = 14.sp,
                maxLines = 1, overflow = TextOverflow.Ellipsis
            )
            Text(
                Web.hostOf(entry.url),
                color = Dim, fontFamily = TermFont, fontSize = 11.sp,
                maxLines = 1, overflow = TextOverflow.Ellipsis
            )
        }
        if (onRemove != null) TermTextKey("[x]", tone = Dim, onClick = onRemove)
    }
}

@Composable
private fun OptRow(label: String, value: String, hot: Boolean = false, onClick: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(vertical = 11.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, color = Ink, fontFamily = TermFont, fontSize = 13.sp, modifier = Modifier.weight(1f))
        Text(
            value,
            color = if (hot) Accent else Dim,
            fontFamily = TermFont,
            fontSize = 13.sp,
            fontWeight = if (hot) FontWeight.Bold else FontWeight.Normal
        )
    }
}

// ---------------------------------------------------------------------------------------------
// WebView plumbing
// ---------------------------------------------------------------------------------------------

/**
 * A locked-down WebView: JavaScript on (pages need it), but no file or content access, no JavaScript
 * bridge, no mixed content, no third-party cookies, and only https / a few "hand-off" links get through.
 */
@SuppressLint("SetJavaScriptEnabled")
private fun buildWebView(ctx: Context, ui: WebUi, onVisit: (String, String) -> Unit): WebView {
    val web = WebView(ctx)
    val s = web.settings
    s.javaScriptEnabled = true
    s.domStorageEnabled = true
    s.allowFileAccess = false
    s.allowContentAccess = false
    s.setSupportZoom(true)
    s.builtInZoomControls = true
    s.displayZoomControls = false
    s.useWideViewPort = true
    s.loadWithOverviewMode = true
    s.javaScriptCanOpenWindowsAutomatically = false
    s.mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
    CookieManager.getInstance().setAcceptThirdPartyCookies(web, false)

    web.webViewClient = object : WebViewClient() {
        override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
            val req = request ?: return true
            val u = req.url ?: return true
            val scheme = u.scheme?.lowercase() ?: return true
            if (scheme == "https") {
                if (AssistantState.forceOffline.value) {
                    ui.note = "offline mode is on. switch to online to browse."
                    return true
                }
                return false
            }
            if (scheme == "http") {
                // https-first: upgrade instead of loading in the clear
                if (req.isForMainFrame && !AssistantState.forceOffline.value) {
                    view?.loadUrl(u.buildUpon().scheme("https").build().toString())
                }
                return true
            }
            if ((scheme == "tel" || scheme == "mailto" || scheme == "sms" || scheme == "geo") && req.hasGesture()) {
                try {
                    ctx.startActivity(Intent(Intent.ACTION_VIEW, u).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                } catch (e: Exception) {
                    ui.note = "no app can open that link."
                }
            }
            return true // file:, content:, intent:, custom app schemes ... never followed
        }

        override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
            ui.loading = true
            ui.progress = 5
            ui.error = null
            if (!url.isNullOrBlank()) ui.url = url
        }

        override fun onPageFinished(view: WebView?, url: String?) {
            ui.loading = false
            ui.progress = 100
            if (ui.error == null && !url.isNullOrBlank()) onVisit(url, view?.title ?: "")
        }

        override fun doUpdateVisitedHistory(view: WebView?, url: String?, isReload: Boolean) {
            if (!url.isNullOrBlank()) ui.url = url
            ui.canBack = view?.canGoBack() == true
            ui.canForward = view?.canGoForward() == true
        }

        override fun onReceivedError(view: WebView?, request: WebResourceRequest?, error: WebResourceError?) {
            if (request?.isForMainFrame != true) return
            val desc = error?.description?.toString().orEmpty()
            val code = error?.errorCode
            ui.error = when {
                desc.contains("CLEARTEXT", ignoreCase = true) ->
                    "this site only offers plain http, which is blocked for your safety."
                code == WebViewClient.ERROR_HOST_LOOKUP ->
                    "can't find that site. check the address, or your connection."
                code == WebViewClient.ERROR_TIMEOUT || code == WebViewClient.ERROR_CONNECT ->
                    "the site didn't answer. check your connection and retry."
                else -> desc.ifBlank { "the page couldn't be loaded." }
            }
            ui.loading = false
        }

        override fun onReceivedSslError(view: WebView?, handler: SslErrorHandler?, error: SslError?) {
            handler?.cancel() // never click through a bad certificate
            ui.error = "the site's security certificate can't be trusted, so it was blocked."
            ui.loading = false
        }
    }

    web.webChromeClient = object : WebChromeClient() {
        override fun onProgressChanged(view: WebView?, newProgress: Int) {
            ui.progress = newProgress
            ui.loading = newProgress < 100
        }

        override fun onReceivedTitle(view: WebView?, title: String?) {
            ui.title = title ?: ""
        }

        override fun onShowCustomView(view: View?, callback: WebChromeClient.CustomViewCallback?) {
            if (view == null) {
                callback?.onCustomViewHidden()
                return
            }
            ui.customView = view
            ui.customCallback = callback
        }

        override fun onHideCustomView() {
            ui.customView = null
            ui.customCallback = null
        }
    }

    web.setDownloadListener { url, userAgent, contentDisposition, mimetype, _ ->
        startDownload(ctx, ui, url, userAgent, contentDisposition, mimetype)
    }
    return web
}

/** Dark pages: the WebView's own darkening, plus a matching backdrop so nothing flashes white. */
@Suppress("DEPRECATION")
private fun applyDark(web: WebView, on: Boolean) {
    web.setBackgroundColor(if (on) android.graphics.Color.BLACK else android.graphics.Color.WHITE)
    if (Build.VERSION.SDK_INT >= 33) {
        web.settings.isAlgorithmicDarkeningAllowed = on
    } else if (Build.VERSION.SDK_INT >= 29) {
        web.settings.forceDark = if (on) WebSettings.FORCE_DARK_ON else WebSettings.FORCE_DARK_OFF
    }
}

/** Desktop site = a desktop-style user agent. Takes effect on the next load. */
private fun applyDesktop(web: WebView, on: Boolean, defaultUa: String) {
    web.settings.userAgentString =
        if (on) defaultUa.replace(Regex("\\(Linux; Android[^)]*\\)"), "(X11; Linux x86_64)").replace(" Mobile", "")
        else defaultUa
}

/** Cookies, site storage and the HTTP cache. */
private fun wipeWebData(web: WebView?) {
    try {
        CookieManager.getInstance().removeAllCookies(null)
        CookieManager.getInstance().flush()
        WebStorage.getInstance().deleteAllData()
        web?.clearCache(true)
    } catch (e: Exception) {
        // nothing sensible to do; the next wipe will try again
    }
}

private fun startDownload(ctx: Context, ui: WebUi, url: String, userAgent: String?, contentDisposition: String?, mimetype: String?) {
    if (!url.startsWith("https://") && !url.startsWith("http://")) {
        ui.note = "can't download that kind of link."
        return
    }
    try {
        val name = URLUtil.guessFileName(url, contentDisposition, mimetype)
        val req = DownloadManager.Request(Uri.parse(url))
            .setTitle(name)
            .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
            .setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, name)
        if (!mimetype.isNullOrBlank()) req.setMimeType(mimetype)
        if (!userAgent.isNullOrBlank()) req.addRequestHeader("User-Agent", userAgent)
        CookieManager.getInstance().getCookie(url)?.let { req.addRequestHeader("Cookie", it) }
        (ctx.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager).enqueue(req)
        ui.note = "downloading $name to Downloads."
    } catch (e: Exception) {
        ui.note = "download failed: ${e.message ?: "unknown error"}"
    }
}

private fun shareUrl(ctx: Context, url: String, title: String) {
    val send = Intent(Intent.ACTION_SEND).apply {
        type = "text/plain"
        putExtra(Intent.EXTRA_TEXT, url)
        if (title.isNotBlank()) putExtra(Intent.EXTRA_SUBJECT, title)
    }
    try {
        ctx.startActivity(Intent.createChooser(send, "Share link").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    } catch (e: Exception) {
        // no share targets; nothing to do
    }
}

private fun openExternal(ctx: Context, url: String): Boolean = try {
    ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    true
} catch (e: Exception) {
    false
}
