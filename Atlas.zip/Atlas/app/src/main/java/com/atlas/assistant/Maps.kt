package com.atlas.assistant

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Bundle
import android.os.Looper
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

data class Place(val label: String, val lat: Double, val lon: Double, val ts: Long)

/**
 * Novochron's offline "map": it doesn't download street maps, it learns places the user tells it about
 * (GPS coordinates saved under a spoken label, e.g. "home", "the office") and keeps a rolling fix on
 * where the phone is right now. From those two things it can answer distance questions -
 * "how far to the office", "how many kilometres to home" - entirely offline, using the haversine
 * formula. Places are saved as plain JSON in Novochron's own folder (see [AtlasStorage]) so they survive
 * reinstalls and are easy to inspect or back up.
 */
class Maps(private val ctx: Context) : LocationListener {

    private val manager = ctx.getSystemService(Context.LOCATION_SERVICE) as? LocationManager

    @Volatile private var lastFix: Location? = null

    // ---------- live location ----------

    private fun hasPermission(): Boolean =
        ctx.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
            ctx.checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED

    /** Starts a low-power background fix so a location is ready the moment it's asked for. Call once, e.g. from the foreground service. */
    fun start() {
        if (!hasPermission()) return
        val mgr = manager ?: return
        for (p in listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER)) {
            try {
                if (mgr.isProviderEnabled(p)) {
                    lastFix = lastFix ?: mgr.getLastKnownLocation(p)
                    mgr.requestLocationUpdates(p, 60_000L, 30f, this, Looper.getMainLooper())
                }
            } catch (e: Exception) { /* provider unavailable on this device */ }
        }
    }

    fun stop() {
        try { manager?.removeUpdates(this) } catch (e: Exception) { }
    }

    /** Best known location right now, or null if Novochron has no fix yet (no permission, GPS off, indoors with no cache). */
    fun currentLocation(): Location? {
        lastFix?.let { return it }
        if (!hasPermission()) return null
        val mgr = manager ?: return null
        for (p in listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER, LocationManager.PASSIVE_PROVIDER)) {
            try {
                val l = mgr.getLastKnownLocation(p)
                if (l != null && (lastFix == null || l.time > lastFix!!.time)) lastFix = l
            } catch (e: Exception) { }
        }
        return lastFix
    }

    override fun onLocationChanged(location: Location) { lastFix = location }
    @Deprecated("Deprecated in Java") override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
    override fun onProviderEnabled(provider: String) {}
    override fun onProviderDisabled(provider: String) {}

    // ---------- learned places (Atlas/Maps/places.json) ----------

    private fun file(): File {
        AtlasStorage.ensureDirs()
        return AtlasStorage.placesFile()
    }

    @Synchronized
    fun places(): List<Place> {
        val f = file()
        if (!f.exists()) return emptyList()
        return try {
            val arr = JSONArray(f.readText())
            (0 until arr.length()).mapNotNull { i ->
                val o = arr.optJSONObject(i) ?: return@mapNotNull null
                Place(o.optString("label"), o.optDouble("lat"), o.optDouble("lon"), o.optLong("ts"))
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    @Synchronized
    private fun writePlaces(list: List<Place>) {
        val arr = JSONArray()
        for (p in list) {
            arr.put(JSONObject().put("label", p.label).put("lat", p.lat).put("lon", p.lon).put("ts", p.ts))
        }
        try { file().writeText(arr.toString(2)) } catch (e: Exception) { }
    }

    /** Saves (or updates) a place under a label, keyed case-insensitively so "Home" and "home" are the same place. */
    fun savePlace(label: String, lat: Double, lon: Double) {
        val clean = label.trim().ifBlank { return }
        val list = places().filterNot { it.label.equals(clean, ignoreCase = true) }.toMutableList()
        list.add(Place(clean, lat, lon, System.currentTimeMillis()))
        writePlaces(list)
    }

    fun forgetPlace(label: String): Boolean {
        val list = places()
        val kept = list.filterNot { it.label.contains(label.trim(), ignoreCase = true) }
        if (kept.size == list.size) return false
        writePlaces(kept)
        return true
    }

    /** Best (shortest, then most-recent) match for a spoken place name. */
    fun findPlace(query: String): Place? {
        val q = query.trim().lowercase()
        if (q.isEmpty()) return null
        val list = places()
        list.firstOrNull { it.label.equals(q, ignoreCase = true) }?.let { return it }
        return list.filter { it.label.lowercase().contains(q) || q.contains(it.label.lowercase()) }
            .minByOrNull { it.label.length }
    }

    companion object {
        /** Great-circle distance between two coordinates, in kilometres (haversine formula). */
        fun haversineKm(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Double {
            val r = 6371.0088 // mean Earth radius, km
            val dLat = Math.toRadians(lat2 - lat1)
            val dLon = Math.toRadians(lon2 - lon1)
            val a = sin(dLat / 2) * sin(dLat / 2) +
                cos(Math.toRadians(lat1)) * cos(Math.toRadians(lat2)) * sin(dLon / 2) * sin(dLon / 2)
            val c = 2 * atan2(sqrt(a), sqrt(1 - a))
            return r * c
        }

        @Volatile private var inst: Maps? = null
        fun get(ctx: Context): Maps =
            inst ?: synchronized(this) { inst ?: Maps(ctx.applicationContext).also { inst = it } }
    }
}
