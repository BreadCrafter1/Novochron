import java.util.Properties

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

// Google Maps needs an API key at build time (it's baked into the manifest, not something the app can
// read from Settings at runtime like the Gemini key). The easiest way to add it: open
// gradle.properties in the project root, put your key after MAPS_API_KEY=, and rebuild.
// The first non-blank value found wins, checked in this order:
//   1. MAPS_API_KEY in gradle.properties (project root, or ~/.gradle/gradle.properties), or -PMAPS_API_KEY=...
//   2. MAPS_API_KEY in local.properties
//   3. MAPS_API_KEY environment variable (handy for CI builds)
// See README > "Map setup".
val localProps = Properties().apply {
    val f = rootProject.file("local.properties")
    if (f.exists()) f.inputStream().use { load(it) }
}
val mapsApiKey: String = listOf(
    providers.gradleProperty("MAPS_API_KEY").orNull,
    localProps.getProperty("MAPS_API_KEY"),
    System.getenv("MAPS_API_KEY")
).firstOrNull { !it.isNullOrBlank() }?.trim() ?: ""

if (mapsApiKey.isBlank()) {
    logger.warn("Atlas: MAPS_API_KEY is not set - the [map] screen will show setup steps instead of a map. Add it to gradle.properties (see README > Map setup).")
} else if (!mapsApiKey.startsWith("AIza")) {
    logger.warn("Atlas: MAPS_API_KEY doesn't look like a Google API key (they usually start with AIza). Double-check it in gradle.properties.")
}

// GitHub login (device flow) needs the Client ID of a free OAuth App you register yourself - see
// README > "GitHub setup". No client secret is ever needed or stored: device flow is designed for
// exactly this (an app with no server to keep a secret in).
val githubClientId: String = listOf(
    providers.gradleProperty("GITHUB_CLIENT_ID").orNull,
    localProps.getProperty("GITHUB_CLIENT_ID"),
    System.getenv("GITHUB_CLIENT_ID")
).firstOrNull { !it.isNullOrBlank() }?.trim() ?: ""

if (githubClientId.isBlank()) {
    logger.warn("Atlas: GITHUB_CLIENT_ID is not set - \"gh login\" in the terminal will explain how to add one instead of logging in. See README > GitHub setup.")
}

// Gemini API key: baked into BuildConfig at build time - never typed into Settings, never stored in
// SharedPreferences (see Store.kt). Deliberately NOT put in this project's own gradle.properties: Google
// runs secret scanning on public GitHub repos and auto-revokes a Gemini/Generative Language key the
// moment it's pushed in plain text, so it must never be committed. Set it one of these ways instead -
// first non-blank value wins:
//   1. -PGEMINI_API_KEY=... on the command line, or GEMINI_API_KEY in ~/.gradle/gradle.properties
//      (outside the project, never committed) - for local builds.
//   2. GEMINI_API_KEY in local.properties (already git-ignored - see .gitignore) - for local builds.
//   3. GEMINI_API_KEY environment variable - for CI: add it as an encrypted repo secret
//      (Settings > Secrets and variables > Actions > "New repository secret") and the workflow
//      passes it through as this env var (see android-build.yml). It is never written to any file
//      in the repo at any point.
val geminiApiKey: String = listOf(
    providers.gradleProperty("GEMINI_API_KEY").orNull,
    localProps.getProperty("GEMINI_API_KEY"),
    System.getenv("GEMINI_API_KEY")
).firstOrNull { !it.isNullOrBlank() }?.trim() ?: ""

if (geminiApiKey.isBlank()) {
    logger.warn("Atlas: GEMINI_API_KEY is not set - the online brain/voice will stay offline-only in this build. See README > Gemini setup.")
}

android {
    namespace = "com.atlas.assistant"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.novochron.assistant"
        minSdk = 26
        targetSdk = 34
        versionCode = 14
        versionName = "3.2"
        manifestPlaceholders["MAPS_API_KEY"] = mapsApiKey
        buildConfigField("String", "GITHUB_CLIENT_ID", "\"$githubClientId\"")
        buildConfigField("String", "GEMINI_API_KEY", "\"$geminiApiKey\"")
    }

    // A fixed debug key: every build is signed the same way, so a new APK installs over the old one.
    signingConfigs {
        getByName("debug") {
            storeFile = file("debug.keystore")
            storePassword = "android"
            keyAlias = "androiddebugkey"
            keyPassword = "android"
        }
    }

    buildTypes {
        release { isMinifyEnabled = false }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    buildFeatures { compose = true; buildConfig = true }
    packaging { resources { excludes += "/META-INF/{AL2.0,LGPL2.1}" } }
}

dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.09.03"))
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.activity:activity-compose:1.9.2")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.material3:material3")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
    // Offline on-device LLM (optional model file, see README)
    implementation("com.google.mediapipe:tasks-genai:0.10.27")
    // Camera: send a photo, or point the camera and let Novochron scan what it sees, front or back lens
    implementation("androidx.camera:camera-core:1.3.4")
    implementation("androidx.camera:camera-camera2:1.3.4")
    implementation("androidx.camera:camera-lifecycle:1.3.4")
    implementation("androidx.camera:camera-view:1.3.4")
    // Silero VAD (voice activity detection), run on-device to spot the instant speech actually
    // ends so Novochron can respond right away instead of waiting on a fixed silence timer - see
    // SileroVad.kt / VadEndpointer.kt. Model ships bundled as assets/models/silero_vad.onnx (MIT).
    implementation("com.microsoft.onnxruntime:onnxruntime-android:1.19.2")
    // Real street map with roads/labels, styled dark to match the app theme - see MapScreen.kt
    implementation("com.google.android.gms:play-services-maps:19.0.0")
    implementation("com.google.maps.android:maps-compose:6.4.1")
    // Lets [web]'s "desktop site" option inject a script before a page's own scripts run - see
    // applyDesktop() in BrowserScreen.kt.
    implementation("androidx.webkit:webkit:1.12.1")
    // WebRTC for msg's [call]/[video call] (voice/video + STUN-assisted ICE) - see Calling.kt.
    // Stream's actively-maintained build of Google's WebRTC, published under the same org.webrtc
    // package names - Google stopped publishing google-webrtc itself. https://github.com/GetStream/webrtc-android
    implementation("io.getstream:stream-webrtc-android:1.3.9")
}
