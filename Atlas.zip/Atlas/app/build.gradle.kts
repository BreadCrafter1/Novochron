import java.util.Properties

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

// Google Maps needs an API key at build time (it's baked into the manifest, not something the app can
// read from Settings at runtime like the Gemini/Picovoice keys). The easiest way to add it: open
// gradle.properties in the project root, put your key after MAPS_API_KEY=, and rebuild.
// The first non-blank value found wins, checked in this order:
//   1. MAPS_API_KEY in gradle.properties (project root, or ~/.gradle/gradle.properties), or -PMAPS_API_KEY=...
//   2. MAPS_API_KEY in local.properties
//   3. MAPS_API_KEY environment variable (handy for CI builds)
// See README > "Map setup".
val localProps = Properties().apply {
    val f = rootProject.file("local.properties")
    if (f.exists()) f.inputStream().use { load(it) }
}
val mapsApiKey: String = listOf(
    providers.gradleProperty("MAPS_API_KEY").orNull,
    localProps.getProperty("MAPS_API_KEY"),
    System.getenv("MAPS_API_KEY")
).firstOrNull { !it.isNullOrBlank() }?.trim() ?: ""

if (mapsApiKey.isBlank()) {
    logger.warn("Atlas: MAPS_API_KEY is not set - the [map] screen will show setup steps instead of a map. Add it to gradle.properties (see README > Map setup).")
} else if (!mapsApiKey.startsWith("AIza")) {
    logger.warn("Atlas: MAPS_API_KEY doesn't look like a Google API key (they usually start with AIza). Double-check it in gradle.properties.")
}

// GitHub login (device flow) needs the Client ID of a free OAuth App you register yourself - see
// README > "GitHub setup". No client secret is ever needed or stored: device flow is designed for
// exactly this (an app with no server to keep a secret in).
val githubClientId: String = listOf(
    providers.gradleProperty("GITHUB_CLIENT_ID").orNull,
    localProps.getProperty("GITHUB_CLIENT_ID"),
    System.getenv("GITHUB_CLIENT_ID")
).firstOrNull { !it.isNullOrBlank() }?.trim() ?: ""

if (githubClientId.isBlank()) {
    logger.warn("Atlas: GITHUB_CLIENT_ID is not set - \"gh login\" in the terminal will explain how to add one instead of logging in. See README > GitHub setup.")
}

android {
    namespace = "com.atlas.assistant"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.novochron.assistant"
        minSdk = 26
        targetSdk = 34
        versionCode = 10
        versionName = "2.7"
        manifestPlaceholders["MAPS_API_KEY"] = mapsApiKey
        buildConfigField("String", "GITHUB_CLIENT_ID", "\"$githubClientId\"")
    }

    // A fixed debug key: every build is signed the same way, so a new APK installs over the old one.
    signingConfigs {
        getByName("debug") {
            storeFile = file("debug.keystore")
            storePassword = "android"
            keyAlias = "androiddebugkey"
            keyPassword = "android"
        }
    }

    buildTypes {
        release { isMinifyEnabled = false }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    buildFeatures { compose = true; buildConfig = true }
    packaging { resources { excludes += "/META-INF/{AL2.0,LGPL2.1}" } }
}

dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.09.03"))
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.activity:activity-compose:1.9.2")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.material3:material3")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
    // Offline on-device LLM (optional model file, see README)
    implementation("com.google.mediapipe:tasks-genai:0.10.27")
    // Camera: send a photo, or point the camera and let Novochron scan what it sees, front or back lens
    implementation("androidx.camera:camera-core:1.3.4")
    implementation("androidx.camera:camera-camera2:1.3.4")
    implementation("androidx.camera:camera-lifecycle:1.3.4")
    implementation("androidx.camera:camera-view:1.3.4")
    // Low-power dedicated wake-word engine (Picovoice Porcupine) - see PorcupineWake.kt
    implementation("ai.picovoice:porcupine-android:3.0.3")
    // Real street map with roads/labels, styled dark to match the app theme - see MapScreen.kt
    implementation("com.google.android.gms:play-services-maps:19.0.0")
    implementation("com.google.maps.android:maps-compose:6.4.1")
}
