# Novochron 3.0: hands-free voice assistant (native Android)

Built by Daniel for Aishadina.

## What's new in 3.0 — web browser
- **`[web]` button.** A small browser in the same terminal skin as the rest of the app (`Browser.kt` /
  `BrowserScreen.kt`). One address bar does both jobs: type an address (`example.com/page`) to go there, or
  anything else to search. DuckDuckGo is the default engine; pick Google, Brave Search or Bing with the chips on
  the start page or in `[opts]`. A green `[s]` in the bar means the page is https.
- **Start page.** Before anything is loaded (and whenever you tap `[home]`) you get your bookmarks and your 15
  most recent pages. `[mark]` bookmarks the page you're on (`[marked]` removes it), `[x]` deletes a bookmark,
  `[clear history]` wipes the recent list.
- **Toolbar.** `[<]` `[>]` `[reload]`/`[stop]` `[home]` `[mark]` `[share]` (share the link) `[ext]` (open in
  another browser app) `[opts]`. The Android back button walks back through pages, then to the start page, then
  closes `[web]`. Pages can go fullscreen video, and file downloads go to your Downloads folder.
- **`[opts]`.** Search engine, **dark pages** (on by default, so sites sit on the black theme instead of glaring
  white), **desktop site**, **private mode** (no history kept, cookies/cache wiped when you leave `[web]`),
  clear history, and wipe cookies + cache now.
- **Voice / chat.** "Open the browser", "search the web for sourdough starter", "google best hiking boots",
  "go to wikipedia.org". These open `[web]` and load the result.
- **Safety.** Pages open over https only (plain `http://` links are upgraded, and Android blocks cleartext
  traffic for the app anyway), bad certificates are blocked with no click-through, third-party cookies are
  blocked, and there is no file access or JavaScript bridge. `file:`, `intent:`, `javascript:` and other
  non-web links are refused (`tel:`, `mailto:`, `sms:` and `geo:` links hand off to the matching app).
- **Respects the online/offline switch.** With Novochron forced offline, `[web]` loads nothing and offers a
  `[go online]` button instead, so "nothing leaves the phone" stays true.
- No new permissions: it uses the internet permission the app already has. Tabs are not included (one page at
  a time).

## What's new in 2.9 — battery stats, message alerts, vault media
- **Battery in `[stats]`.** A new Battery section shows the live level / temperature / voltage / current, and
  how much battery Novochron costs while it works in the background. While voice listening or message
  alerts run, the app logs a battery reading about once a minute (unplugged time only, kept 14 days on the
  phone, wiped by `[clear]`), then shows the drain in %/h and mAh/h for the last 24 h or 7 days, the
  screen-off rate (the closest thing to Novochron's own cost), a split by feature (voice vs message
  alerts), CPU minutes per hour, an estimate of how long a full charge would last, and a 24-hour bar chart.
  Honest caveat, also printed on screen: Android doesn't give apps their exact share of battery use, so
  these are whole-phone numbers measured *while Novochron runs*. `[system battery]` opens Android's own page.
- **Message alerts.** In `[msg]`, tap `[alerts: off]` to turn them on (asks for notification permission on
  Android 13+). A small foreground service (`MsgWatchService`) then watches the shared repo and posts a
  notification for anything the *other* person sends - text, or "📷 Photo / 🎥 Video / 🎤 Voice message".
  Tapping it opens `[msg]`. Nothing is announced twice, turning alerts on never floods you with old
  messages, and you're not buzzed while `[msg]` is open on screen. Two modes (`[mode: …]`):
  **instant** checks every 15 s with a wake lock (near-instant, costs more battery - the stats screen will show
  how much) and **saver** wakes up every ~5 min (light on battery, slower).
- **Read aloud.** `[read aloud: off]` in `[msg]` makes Novochron speak incoming messages: who they're from and
  what they said ("Message from Sam: running late, start without me"). Photos, videos and voice messages are
  announced as "Sam sent you a photo" etc. Up to three messages in a burst are read individually, the rest
  are summed up ("…and 2 more messages"), and very long messages are cut at ~240 characters. It waits if
  Novochron is in the middle of a reply instead of talking over it, and the line also lands in the chat log.
  It shares the same background watcher as alerts, so it works with alerts off (and vice versa), and uses
  the same `[mode: instant/saver]`. It reads out loud even if the screen is locked - handy, but be aware of
  who's around.
- **Vault media viewer.** Tap a file in `[vault]` to open it in the app: photos (pinch / double-tap to zoom,
  swipe between them), audio (play/pause, seek bar, ±10 s) and video (built-in player). Filter chips
  (all / photos / audio / video / other) and a `[grid]` / `[list]` toggle show thumbnails. Files are
  downloaded once into the cache (capped at ~300 MB, oldest cleared first). `[open with…]` hands a file to
  another app and `[delete]` works from the viewer too. Thumbnails are only fetched for photos up to 8 MB.

## What's new in 2.8 — graph + sim
- **`[graph]` button.** A Desmos-style graphing calculator screen. Type one or more `y = ...`
  formulas (functions of `x` — `sin`, `cos`, `tan`, `sqrt`, `abs`, `ln`, `log`, `exp`, `floor`,
  `round`, `sign`, `^`, `pi`, `e` are all supported), each gets its own colour and is plotted live.
  Drag to pan, pinch to zoom, tap the colour dot to hide/show a line, `[+ add formula]` for more.
  Fully offline — its own small expression compiler (`GraphMath.kt`), no network call.
- **`[sim]` button.** A small Universe-Sandbox-style 3D orbit viewer (`OrbitMath.kt` /
  `SolarSystemScreen.kt`). Ships with two systems: the real Solar System, and the Proxima Centauri
  system (Proxima b, c, and the disputed inner candidate d), with real relative orbital periods and
  distances (circular-orbit approximation) — inner planets cluster tight near the star and outer ones
  sweep in huge arcs, the same true-to-scale read as Universe Sandbox, not a compressed cartoon.
  Every body's on-screen size is now directly proportional to the AU-to-pixel zoom ratio — zoom out
  and everything shrinks together at the same rate the orbits do, full stop; there's no separate
  curve that could ever make it grow the wrong way (an earlier build compared sizes against a fixed
  "default zoom" baseline, which decoupled them from the real zoom level and let the sun's fixed
  pixel size swallow the inner planets — fixed). A generated starfield + Milky Way dust band sits
  behind everything. Each planet is shaded procedurally per type — banded gas giants with a red-spot
  fleck, Earth with green continent blobs and a cloud swirl, rusty Mars with polar caps, a cratered
  Mercury, Saturn's rings drawn in front of and behind the sphere — plus its major moons (the Galilean
  four on Jupiter, Titan, our Moon, and so on) orbiting as small dots at their own real periods. One-
  finger drag orbits the camera, pinch zooms, `[solar]`/`[proxima]` swaps systems, tap a planet to zoom
  in and re-centre the camera on it (real numbers shown below the view), tap empty space or the star to
  back out, `[overview]` resets. Fully offline — just trig, gradients and a Canvas, no downloaded
  textures.

Kotlin + Jetpack Compose. Terminal-styled UI (monospace, green-on-black, portrait or landscape),
always-on listening with a real low-power wake engine, works online (Gemini API) and offline
(commands, memory, learned notes, a real offline calculator, optional on-device model), plus a
themed live street map with offline distance calculations.

## What's new in 2.7 — vault
- **`[vault]` button.** Upload any file or photo into a GitHub repo, pick which of your repos to use,
  and delete files - all through the same GitHub login the terminal's `gh` commands use. See "Vault"
  below. (The `[map]` screen's `street` chip is gone - see "What's new in 2.6" note below.)

## What's new in 2.6 — terminal + GitHub
- **`[term]` button.** A real terminal screen, next to `[lib]`/`[map]`/`[set]`. Local file commands
  (`ls`, `cd`, `cat`, `mkdir`, `rm`) run for real inside Novochron's own `Atlas/` folder with no setup.
- **`gh` / `repo` commands.** Log into a real GitHub account (`gh login` — OAuth device flow, no
  password or client secret ever stored on the phone), then browse a repo, commit files, and trigger
  or check GitHub Actions builds. See "GitHub setup" below for the one-time registration this needs.
- **`sh <command>`.** Bridges to the real Termux app, if installed, for genuine shell access (bash,
  git, python, whatever you have in Termux). See "Terminal setup" below.
- **Say it instead of typing it.** "Log into GitHub", "list my repos", "build the app", "check the
  build status" work as plain voice/chat commands too — Novochron routes them to the terminal engine
  and speaks back the result. See "Voice commands" for the full list.
- **Why builds don't happen "on the phone":** Android doesn't let one app compile or run another
  app's full build toolchain, and there's no Android SDK/Gradle on a phone to begin with. "Build the
  app" instead triggers a GitHub Actions workflow, which does the actual compiling on GitHub's own
  servers — which is also just how a real dev team would want it done.
- **Map layers.** *(Originally shipped with a `street` chip for Street View too; removed in 2.7 - see
  above - because Street View hit a quota block Google returns separately from ordinary map tiles.)* A chip row along the top of `[map]`: `dark` (the original themed map), `mono`
  (black-and-white), `sat` (satellite with labels) and `roads` (everything dimmed except roads and
  paths, drawn in bright colours by class — highways, main roads, streets & paths — with a legend).
  `3D` tilts the camera and extrudes buildings on top of whichever layer is active. The layer and 3D
  choice are remembered between visits. See "Map" below.
- **`[clear chat]` on the main screen.** Right under the button rows. Tap once, then tap `[confirm?]`
  within 3 seconds; the second tap clears the conversation. (The Settings button still works too.)
- **"Clear photos in directory" at the very top of Settings.** Deletes every photo in `Atlas/Photos/`
  (camera shots, gallery picks and screencast frames) after a confirmation, and shows how many photos and
  how much space they take. Only image files are removed; the folder and anything else in it stay.

## What's new in 2.5.3
- **Newer offline-model engine.** MediaPipe's LLM library is updated (0.10.21 to 0.10.27) so current Gemma
  builds load, including Gemma 3n with photo input. The library is in maintenance mode at Google, but this is
  the version their current docs use.
- **Context length is matched to the model.** Google's file names carry it (`..._ekv2048.task`); Gemma 3n is 4096;
  for other names a few common sizes are tried until one loads.
- **Which model to add:** Gemma 3 1B (int4 `.task`, about 0.6 GB, text) for most phones, or Gemma 3n E2B
  (`gemma-3n-E2B-it-int4.task`, about 3.1 GB) if you want offline photo/camera/screen understanding and the
  phone has around 8 GB RAM. Both are gated on Hugging Face: log in and accept the Gemma terms first.

## What's new in 2.5.2
- **The offline model is found by any file name.** Previously it only counted if the file was named exactly
  `model.task`. Now any `.task` file (e.g. `gemma3-1b-it-int4.task`) in `Atlas/Models/` works; if there are
  several, `model.task` wins, otherwise the newest.
- **Settings tells you what it sees.** It shows the model it found (name, size, folder), refreshes every couple
  of seconds while open, and says why when it finds nothing: no "All files access" yet, a `.tflite` /
  `.gguf` file this build can't load, a too-small or unfinished download, a stray `.txt` extension.
- **A model that's found but won't load says so** (in Settings and when you talk to it offline) instead of
  claiming no model is installed.

## What's new in 2.5.1
- **Adding the Maps key is now one line.** Open `gradle.properties` in the project root, put your key
  after `MAPS_API_KEY=`, rebuild. (`local.properties`, `-PMAPS_API_KEY=...` and a `MAPS_API_KEY`
  environment variable also work.) If a build has no key, the `[map]` screen shows the steps instead
  of a blank grey map, and Settings shows whether the key made it into the build.

## What's new in 2.5
- **Real street map.** The `[map]` screen now shows an actual Google Maps street map — real roads,
  road names, parks, neighbourhoods — recoloured dark to match the terminal theme, in place of 2.4's
  abstract offline radar plot. Needs a Google Maps API key baked in at build time and an internet
  connection for tiles; see "Map setup." Tapping to pin a point and getting the distance from your
  GPS fix still works exactly as before, offline, via the same haversine math.
- **One map layout.** The map now uses a single compact layout (map on top, a slim scrolling control
  strip underneath) instead of separate portrait/landscape arrangements.

## What's new in 2.4
- **A real dedicated low-power wake engine.** Wake-word can now use Picovoice Porcupine — a tiny
  always-on keyword-spotting model, the same shape as "Hey Google" — instead of reusing the full
  speech recognizer. Get a free AccessKey at console.picovoice.ai, paste it into Settings, and either
  pick one of Porcupine's built-in words there or train your own for free and drop the resulting
  `.ppn` file in as `Atlas/Models/wakeword.ppn`. No key installed? Novochron falls back to the old
  always-on-recognizer gating automatically, so wake-word still works either way.
- **Learned knowledge now lives in a folder.** "Learn X" notes are kept as plain, human-editable
  `.txt` files in `Atlas/Knowledge/` (one per topic) instead of hidden inside the database — open,
  read, or hand-edit them with any file manager. Existing learned topics are migrated automatically
  on first launch after updating.
- **Offline model folder actually wired up.** `Atlas/Models/model.task` is now genuinely checked
  first (previously documented but not actually read); the private-storage fallback still works too.
- **Turn off, computer.** A `POWER` key in the top bar, and the voice command "turn off,
  computer" (also "computer, turn off", "shut down, computer", "exit the app"), cleanly stop voice
  and close Novochron entirely — not just mute it.
- **Map (superseded in 2.5 — see above).** 2.4 introduced a themed, fully offline "radar" map with no
  tiles or API key; 2.5 replaces it with the real street map described above.

## What's new in 2.3
- **"Learn X" while online, use it offline.** Say "learn mathematics" (or any topic) while online
  with an API key set: Novochron fetches compact reference notes from Gemini and keeps them on the phone.
  Later, offline, it looks up the closest learned topic for what you're asking and either feeds it to
  the local model (if one's installed) or reads back the most relevant lines directly. Manage what's
  been learned, and remove individual topics, from Settings.
- **Real offline math**, no AI needed at all: arithmetic ("what's 45 times 12", "20% of 85"),
  parenthesised expressions, and simple linear equations ("solve 2x + 3 = 7") are solved with a small
  built-in calculator that runs before anything else, online or off. "Learning" mathematics adds
  reference notes on top of this for things a calculator can't do (concepts, word problems) — those
  still need either the online brain or a local LLM to reason over the notes.
- **Wake word.** Turn on "wake-word" (main screen or Settings, where you can also change the phrase
  from the default "novochron") and Novochron waits for you to say it before reacting to anything, the same
  shape as "Hey Google" — it re-arms after each reply. Worth knowing: this reuses the same continuous
  speech recognizer as always-on listening rather than a dedicated low-power keyword spotter, so it
  costs the same battery as Voice being on; it just won't act on anything until it hears the phrase.
- **Termux-style terminal UI.** White-on-black monospace with a green `~ $` prompt. Every button lives in a
  two-row key bar at the very top (`LIB MAP CAM IMG CAST` / `VOICE ONLINE WAKE SET POWER`; switches show
  inverted while on), so the conversation gets the whole screen. The log is plain prompt-and-output lines
  instead of chat bubbles, with one dim status line and the `~ $` prompt at the bottom (the keyboard's
  enter key sends).
- **A character in the background.** A monochrome half-body line drawing of a girl holding up a sketch of
  her own face. Her drawn mouth moves while Novochron speaks, she spirals her eyes while it thinks, perks
  up while you talk or type, does silly things when idle (paper flips, hops, dances, ahoge boings, ...)
  and dozes off after about 40 s of nothing. Turn her off in Settings if you like. Code: `Mascot.kt`
  (drawing), `MascotAnimator.kt` (behaviour), `MascotArt.kt` (the line art).
- **Portrait or landscape.** In landscape the key bar becomes a single row of ten.

## What's new in 2.2 — vision
- **Send a photo.** Tap **Photo** to pick one from your gallery, type a question (or leave it blank),
  and Novochron looks at it and answers or asks a clarifying question if something's unclear.
- **Camera, front or back.** Tap **Camera** for a full-screen viewfinder with a lens-flip button.
  Tap the shutter to ask about whatever's in frame, or turn on **Live scan** to have Novochron describe
  what it sees again every few seconds without you tapping anything.
- **Screencast.** Tap **Screencast** to let Novochron watch your screen (Android's normal "start
  recording your screen?" prompt appears once). While it's on, whatever you say or type — voice or
  typed — goes along with the freshest screenshot, so "what does this button do" or "why is this
  page blank" works while it watches you use the phone. Tap **Stop** (in-app or in the system
  notification) to end it.
- **Online and offline.** Online with an API key, all three use Gemini's vision. Offline, they only
  work if the installed model is a genuinely multimodal build — see "Offline vision" below — otherwise
  Novochron says so plainly rather than guessing at an image it can't actually see.

## What's new in 2.1
- **Phone controls.** Say (or type) "turn off Wi-Fi", "turn on Bluetooth", "turn off location", "turn on mobile data",
  "airplane mode on", "turn up the volume", "do not disturb on", "set brightness to 40 percent" and more. It also
  answers "is Bluetooth on". See "Phone controls" below for exactly what Novochron flips itself and what Android only lets
  it open.

## What's new in 2.0
- **Live conversation.** The mic stays open while Novochron thinks and speaks. Talk over it and it stops and
  listens. Replies stream in and are spoken sentence by sentence, so it starts talking almost immediately.
- **Background.** Runs as a foreground service: keeps listening with the screen off or while you use other
  apps, and asks Android to exempt it from battery saving.
- **Artifacts.** Ask it to build things: "make me a sudoku puzzle", "build a tip calculator", "make a
  snake game". It writes a self-contained HTML app and opens it full screen. Say "make the buttons bigger"
  and it updates it. Everything it builds is saved in **Library**. Artifacts run in a sandbox with no
  network access.
- **Its own folder.** Once granted, Novochron keeps its chat history, memory, artifacts and learned places in
  a plain, visible folder at `/storage/emulated/0/Atlas`, instead of hidden app-private storage. See
  "Novochron's own folder" below.
- **Offline maps.** Novochron can learn places by name ("remember this place as home") and later answer "how
  far is home" or "how many kilometres to the office" entirely offline, using GPS and simple distance
  math — no map downloads, no internet needed. See "Offline maps" below.
- **Faster turn-taking.** Novochron now reacts the instant you stop talking instead of waiting on a long
  pause, so replies start noticeably sooner. See "Talking over Novochron" below.
- **Black theme** and the new name, Novochron.

## Build
1. Install Android Studio (Koala or newer).
2. File > Open > select this folder. Let Gradle sync (needs internet once).
3. Plug in a phone (USB debugging on) and press Run, or Build > Build APK(s).
   APK: `app/build/outputs/apk/debug/app-debug.apk`

The debug APK is signed with the fixed key in `app/debug.keystore`, so new builds install over old ones.

## First run
- Tap VOICE in the top bar. Grant the permissions (mic, contacts, phone, SMS, location, notifications, nearby devices).
- Say yes to the battery prompt so Android does not stop Novochron in the background.
- Settings > "Give Novochron its own folder on this phone" so its data lives at `/storage/emulated/0/Atlas`
  instead of hidden app storage (Android 11+: this opens the "All files access" screen — turn it on for
  Novochron and go back).
- Settings > paste your Gemini API key (aistudio.google.com/apikey) for online chat, artifacts and the online voice.
- Settings > "Allow opening apps from the background" so commands and new artifacts can come to the front
  when Novochron is not on screen.

## Phone controls
Android decides which switches a normal app may flip. Novochron uses the strongest thing Android allows for each one:

| Setting | What Novochron does |
|---|---|
| Volume (up, down, a number, max, mute, unmute), silent / vibrate / normal | Changes it directly (silent mode needs the Do Not Disturb permission below) |
| Brightness (up, down, a number, max, min), auto brightness, auto-rotate | Changes it directly, after one-time "Modify system settings" permission |
| Do Not Disturb (also "alarms only", "total silence") | Changes it directly, after one-time Do Not Disturb permission |
| Flashlight | Changes it directly (already in 2.0) |
| Bluetooth | Android 12 and older: directly. Android 13+: turning **on** shows Android's own "Allow" dialog, turning **off** opens the Bluetooth switch |
| Wi-Fi | Android 9 and older: directly. Android 10+: opens the Wi-Fi panel and you tap the switch |
| Mobile data, location, airplane mode, hotspot, NFC, battery saver | Opens the right switch or panel and tells you to tap it. Android gives apps no way to flip these |

Grant the two one-time permissions in Settings > Phone controls. Bluetooth asks for "Nearby devices" the next time
you turn Voice on. If Novochron is not on screen it opens the switch over your current app, which uses the same
"Allow opening apps from the background" permission as timers and new artifacts.

Example phrases: "turn on Wi-Fi", "Bluetooth off", "is location on", "turn off mobile data", "airplane mode on",
"turn on do not disturb", "put the phone on vibrate", "mute the phone", "turn the volume up", "set volume to 40",
"turn down the brightness", "turn on auto brightness", "turn off auto rotate", "turn on battery saver".
Only sentences shaped like a command are acted on, so "how do I turn off Wi-Fi on a laptop" is still just a question.

## Novochron's own folder
Once "All files access" is granted (Settings > the storage button, or Android Settings directly), Novochron
stores everything in a folder it owns on shared storage:
```
/storage/emulated/0/Atlas/
├── atlas.db        chat history, memory, artifacts (SQLite — open with any SQLite viewer)
├── Maps/
│   └── places.json places Novochron has learned, with GPS coordinates (plain JSON, editable by hand)
├── Photos/         pictures from the camera, gallery picker and screencast (Settings > "Clear photos in directory")
├── Models/
│   ├── *.task        optional offline LLM, any file name (see "Offline setup" below)
│   └── wakeword.ppn  optional custom low-power wake word (see "Wake word" below)
└── Knowledge/
    └── <topic>.txt one plain-text file per "learn X" topic, editable by hand
```
You can browse, back up, or copy this folder like any other folder on the phone (file manager, USB, cloud
backup app). Until access is granted, Novochron still works normally; its data just stays in the app's private
storage instead (`novochron.db`), same as before.

## Wake word
Turn on wake-word (main screen or Settings) and Novochron waits for you to say the phrase before reacting to
anything, re-arming after each reply — the same shape as "Hey Google." There are two engines behind it:
- **Dedicated low-power engine (recommended).** Get a free AccessKey at console.picovoice.ai, paste it into
  Settings, and pick one of Porcupine's built-in words there (Computer, Jarvis, Porcupine, and others).
  Novochron then listens with a tiny always-on keyword-spotting model that barely touches the battery while
  waiting — full speech recognition only spins up for the few seconds right after the word is heard. Trained
  a custom word instead? Drop the `.ppn` file it gives you in as `Atlas/Models/wakeword.ppn` and it's used
  automatically in place of the built-in picker.
- **Fallback.** With no AccessKey installed (or if the dedicated engine can't start), Novochron falls back to
  reusing the full continuous speech recognizer to gate what it reacts to — it still works, just at the same
  battery cost as Voice being on.

## Turn off, computer
The `POWER` key in the top bar closes Novochron completely (not just the voice) after a confirmation.
The same thing happens hands-free: say "turn off, computer" (or "computer, turn off", "shut down, computer",
"exit the app"). Either way, voice and background listening stop and the app process ends.

## Map
The `[map]` button opens a real street map — actual roads, road names, parks, neighbourhoods — via the
Google Maps SDK, recoloured dark to match Novochron's terminal theme (see `res/raw/map_style_dark.json`).
Tap anywhere to drop a pin; Novochron reports the straight-line distance from your current GPS fix using
the same haversine math as "how far is home." Save a pinned point as a new place, or remove a saved one,
right from the map. One compact layout (a big map with a slim scrolling control strip underneath) is used
regardless of device orientation. Needs an internet connection for map tiles and a Google Maps API key —
see "Map setup" below; the offline distance-to-a-place voice commands below don't need either.

**Layers.** Chips along the top of the map switch the look:
- `dark` — the default terminal-themed map (`res/raw/map_style_dark.json`).
- `mono` — a black-and-white map (`res/raw/map_style_mono.json`).
- `sat` — satellite imagery with road and place labels (Google's *hybrid* map type; JSON styles don't apply to it).
- `roads` — land, water and labels muted, with every road and path lit up: orange highways, yellow main
  roads, cyan streets and footpaths (`res/raw/map_style_roads.json`). Google doesn't publish separate
  data for footpaths, so paths show up in the same cyan class as local streets, and only once you're
  zoomed in far enough for Google to draw them.
- `3D` — a toggle, combinable with any layer above. Tilts the camera to 60° and zooms in to street level so
  buildings extrude (they only appear at roughly zoom 16 and closer, and only in cities Google has building
  data for). Turning it off levels the camera and points north again. You can also tilt by hand with a
  two-finger drag and rotate with a twist.
Google's own zoom/compass/my-location buttons are stock widgets that can't be recoloured to match the
theme, so they're switched off in favour of small themed `+` / `–` / `◎` buttons in the corner instead.

## Map setup
The map needs a Google Maps API key. Unlike the Gemini/Picovoice keys, Google reads this one from the app's
manifest at build time, so it can't be pasted into Settings - but it's one line:
1. Create a Google Cloud project and enable the **Maps SDK for Android** at
   console.cloud.google.com - free tier covers ordinary personal use, but a billing account must be
   attached to the project.
2. Create an API key (APIs & Services > Credentials). To restrict it (recommended), choose
   *Android apps* and add:
   - package name: `com.novochron.assistant`
   - SHA-1 fingerprint: `2D:66:10:F4:3F:AF:9B:D0:66:FE:68:54:E1:6E:1E:DB:48:25:6A:CD`
     (from the fixed `app/debug.keystore` this project signs with). A key restricted by package name
     but with no matching SHA-1 gives a blank map.
3. Open `gradle.properties` in the project's root folder and put the key after `MAPS_API_KEY=`
   (no quotes, no spaces): `MAPS_API_KEY=AIza...`
4. Rebuild and reinstall. Settings will say "Google Maps key: included in this build".

Other places the build looks, in this order, if `gradle.properties` is blank: `local.properties` in the
project root, then a `MAPS_API_KEY` environment variable (useful for CI). Putting the line in
`~/.gradle/gradle.properties` instead keeps the key out of the project folder entirely, which is handy if
you share or upload the project.

Without a key the `[map]` screen still opens but shows these steps instead of a map.

## Vault
The `[vault]` button stores files — photos, documents, anything — in a `Vault/` folder inside one of
your own GitHub repos, using the same account the terminal's `gh login` sets up (see "GitHub setup"
below); there's nothing extra to configure.

- **Pick a repo.** A chip row lists repos on your account; tap one to make it active. This is the same
  "active repo" the terminal's `repo use owner/name` command sets — switching it in one place switches
  it in the other, since they both mean the one repo Novochron is currently pointed at.
- **Upload.** `[upload]` opens the system file/photo picker; pick one or more files of any type. Each
  becomes its own commit to `Vault/<filename>` in the active repo and branch. Files are capped at 25 MB
  each on the way up (GitHub's Contents API itself allows up to 100 MB, but that's a lot of a phone's
  data plan for one file).
- **Delete.** `[delete]` next to a file asks for confirmation, then commits its removal.
- Only the `Vault/` folder is shown and touched here — the rest of the repo (code, workflows, whatever
  else is in it) is left alone; browsing the full repo tree is still what the terminal's `repo ls`/`repo
  cat` commands are for.
- **View & play.** Tap a file to open it: photos zoom and swipe, audio and video play in the app. Use the
  filter chips and `[grid]` view to browse photos as thumbnails.
- Not logged in yet? The vault says so and offers to open the terminal, where `gh login` handles it.

## Terminal
The `[term]` button opens a real terminal. Type `help` inside it for the full command list. Three
different things answer a command, and it matters which:
- **Local files** (`ls`, `cd`, `cat`, `mkdir`, `rm`, `echo`, `clear`) work immediately, no setup —
  they operate on Novochron's own `Atlas/` folder using real file I/O. This is *not* a real shell:
  it can't run arbitrary programs, because Android doesn't let one app execute another app's
  binaries (or a system shell with real privileges) without root.
- **`gh` and `repo` commands** talk to GitHub's real API — log in, list/browse repos, commit files,
  and trigger/check Actions builds. Needs the one-time setup in "GitHub setup" below.
- **`sh <command>`** hands the command line to the real Termux app for genuine shell access. Needs
  Termux installed and one line of config — see "Terminal setup" below. Without Termux, `sh` just
  explains what's missing instead of pretending to run something.

Everything here is also reachable by voice/chat — see "Voice commands" below — and both share the
same login/terminal state, so a command you say out loud shows up in the terminal's own transcript.

## GitHub setup
Logging in uses GitHub's OAuth **device flow**: Novochron shows a short code, you type it into
github.com/login/device on any browser, and GitHub hands back a token — your GitHub password never
touches the phone or this app, and (unlike most OAuth setups) no client *secret* needs to be stored
anywhere either, which is exactly what device flow is designed for.

To turn this on, you register a free "OAuth App" once (this identifies *this build of the app* to
GitHub, not you — every user of your build shares it, and it holds no secret):
1. Go to **github.com/settings/developers** → "New OAuth App".
2. Application name: anything (e.g. "Atlas Terminal"). Homepage URL and Authorization callback URL
   can both just be `https://github.com` — device flow doesn't use the callback.
3. Check **"Enable Device Flow"**, then create the app.
4. Copy its **Client ID** (not the secret — device flow doesn't need one).
5. Open `gradle.properties` in the project root and put it after `GITHUB_CLIENT_ID=`.
6. Rebuild. `gh login` in the terminal (or saying "log into GitHub") will now work.

**Don't want to register an OAuth App at all, or just want the fastest way for two people to both
get "msg" working?** Skip device flow entirely and log in with a **Personal Access Token** instead:
1. Go to **github.com/settings/tokens** → generate a token (a fine-grained token with Contents
   read/write on the shared repo is enough; a classic token needs the `repo` scope).
2. Paste it in: `gh token <the-token>` in the terminal, or - inside `[msg]` itself, if you're not
   linked yet - right in the box it shows there.
3. That's it — no `GITHUB_CLIENT_ID`, no build step, no waiting on a browser. Each person does this
   once with their own token, both pointing at the same shared repo, and messages will start
   flowing.

Once logged in:
- `gh repos` — list your repos
- `repo use owner/name [branch]` — pick which repo (and branch, default `main`) commands act on
- `repo ls [path]`, `repo cat <path>` — browse it
- `repo commit <path> -m "message"` — paste new content for a file, end with a line containing only
  `.`, and it commits straight to GitHub (creating or updating the file)
- `repo workflows`, `repo run [workflow.yml]`, `repo status [workflow.yml]` — trigger and check
  GitHub Actions. The target workflow's YAML needs `on: workflow_dispatch:` in it, or there's nothing
  for `repo run` to trigger — most CI templates (including Android build templates) support this by
  default or with one added line.

The token is stored in this app's normal private settings storage on the phone (same place the
Gemini API key lives) — not encrypted at rest, so treat it like you would any other saved
credential on a personal device, and `gh logout` clears it.

## The `[msg]` screen
A tiny two-person chat that uses a shared GitHub repo as the mailbox (`Msg/` folder). Text, photos,
videos and **voice messages**:
- **Voice.** Tap `[mic]` to record (the button becomes a running timer and `[stop]`); tap it again to
  send, or `[cancel]` to discard. First tap asks for microphone permission. The recipient taps `[▶ play]`.
  Tip: turn the main screen's voice (LIVE) off while recording, so the always-on listener doesn't also hear it.
- **Size.** Photos, videos and voice clips can be up to **100 MB** each (GitHub's hard per-file limit).
  Big files are streamed to/from disk and the status line shows upload progress.
- **Save photos.** Tap any photo to open it full-screen, then `[save]` puts the original in
  Pictures/Atlas. Android 9 and older ask for storage permission the first time.
- **Speed.** New messages are checked every second (cheap `304` replies when nothing changed), fetched
  several at a time, and the chat is cached on the phone so it opens instantly. Your own messages appear
  immediately and send in the background.
- **Alerts.** `[alerts: on]` keeps a background watcher running (see "What's new in 2.9") so you get a
  notification when the other person writes. It's off until you turn it on.
- Msg uses its own small client (`MsgClient.kt`); the vault, terminal and share-link features still use
  `GitHub.kt` unchanged.
- Known limit: GitHub only lists the first 1,000 files of a folder, so a chat is capped at roughly
  1,000 messages.

## Terminal setup
`sh <command>` in the terminal needs the real [Termux app](https://termux.dev) — Android doesn't
give any app, including this one, a real Linux userland on its own.
1. Install Termux from **F-Droid** (recommended — the Play Store build is outdated and unsupported)
   or Termux's GitHub releases.
2. Open Termux once so it finishes its first-run setup.
3. In Termux, run: `echo "allow-external-apps=true" >> ~/.termux/termux.properties`
4. Restart Termux (swipe it away from Recents, reopen).
5. Back in Novochron's terminal, `sh git status` (or any command) should now return real output.

This uses Termux's own documented `RUN_COMMAND` intent — Novochron never reads or modifies anything
inside Termux beyond running the one command line you gave it and reading back its output.

## Offline maps
Novochron doesn't download street maps — it learns places you tell it about and remembers roughly where the
phone is, so it can work out straight-line distance with no internet at all:
- "Remember this place as home" (or "office", "the gym", anything) saves your current GPS position under
  that name to `Atlas/Maps/places.json`.
- "How far is home" / "how many kilometres to the office" / "distance to the gym" answers with the
  straight-line distance from where you are now.
- "What places do you know" lists everything learned so far.
- "Forget the place home" removes one.

This needs location permission (granted on first run) and a GPS or network fix; Novochron keeps a fix cached
in the background while listening is on, so answers are instant once you've been outside or connected at
least once. Distances are straight-line ("as the crow flies"), not driving distance, since there's no
offline road network involved.

## Online / offline toggle
There's a switch under the Voice toggle on the main screen (and in Settings) that forces Novochron offline
even when the internet is available — useful for testing offline behaviour, saving data, or just knowing
for sure nothing is leaving the phone. With it on: no Gemini chat, no online voice, no artifacts; you
still get phone commands, memory, offline maps and the offline brain (if installed). Turn it back to
"Online" and Novochron goes back to deciding for itself based on whatever connection is actually available.

## Talking over Novochron
While Novochron speaks, the mic also hears Novochron's own voice. Novochron compares what it hears with what it is
saying and ignores its own echo. **Headphones make this reliable.** On the phone speaker it can occasionally
mishear itself; if that happens repeatedly it turns interrupting off for 90 seconds. You can also switch
interrupting off in Settings.

Novochron treats a short pause (under half a second) as "done talking" and starts answering right away, rather
than waiting on a long silence — the UI shows "Thinking…" the instant it detects you've stopped. A quick
breath mid-sentence is shorter than that pause and won't cut you off, but if you tend to speak in short
bursts with long gaps, Novochron may occasionally answer before you meant to finish; just keep talking and it
will pick the rest up as a follow-up.

## Models
Settings > Model: **Auto** uses Gemini 3.5 Flash when you ask Novochron to build something and Gemini 3.1
Flash Lite for everything else. **Fast** is always 3.1 Flash Lite, **Smart** is always 3.5 Flash. Building
an app uses many more tokens than chatting, so it costs more.

## Voice
Online with a Gemini API key, Novochron's voice is synthesized by Gemini's TTS model (voice "Leda") with a
style instruction asking for a bright, high-pitched, cheerful anime-girl delivery.

## Offline vision
Photos, the camera and screencast frames can be understood with no internet at all, but only if the
installed `model.task` is a genuinely **multimodal** model — a text-only Gemma build cannot accept
images no matter how it's installed. A converted Gemma 3n E2B or E4B `.task` build is the model to
look for; install it exactly like the offline chat brain below (same file, same folder). If the
installed model turns out to be text-only, Novochron detects that automatically the first time you send
it an image and falls back to "I don't have an offline vision model installed" instead of guessing —
text chat, commands, memory and maps keep working offline regardless.

## Offline setup
- Speech: Google app > Settings > Voice > Offline speech recognition > download English.
- Offline fallback voice: Android Settings > Text-to-speech (Google) > Install voice data > English (US/UK).
  Novochron picks the brightest female voice installed automatically. This is only used when there is no
  internet or no API key; tune its pitch in Settings > offline voice slider.
- Offline chat brain (optional): download a MediaPipe LLM `.task` model (e.g. Gemma 3 1B int4). Any file
  name ending in `.task` works - no renaming needed. First give Novochron its own folder (Settings > "Give
  Novochron its own folder", grant "All files access"), then copy the file into
  `/storage/emulated/0/Atlas/Models/` with any file manager. Settings > "Offline AI model" shows what it
  found within a couple of seconds, or why it didn't. Alternatively, from a computer:
  `adb push your-model.task /sdcard/Android/data/com.novochron.assistant/files/`
  (Android 11+ hides that folder from phone file managers, so Atlas/Models is the easier route.)
  Use `.task` files. `.litertlm` files are picked up too but only work for models MediaPipe supports, and
  `.gguf` / `.tflite` files won't load. Skip anything named `-web.task` (browser-only builds). The chat
  prompt is written in Gemma's format, so stick to Gemma models.
  Without it, offline mode still runs every phone command, memory, distance-to-place, time/date and simple replies.
  Building artifacts needs the internet and an API key.

## Playing a song in another app
"Open <music app> and play <song> by <artist>" (or "play <song> on <music app>") opens the app and sends it a
standard "play from search" request, the same one Google Assistant and Android Auto use. Android has no way to
force another app to play something, so it works only if that app supports the request:
- Apps that handle `MEDIA_PLAY_FROM_SEARCH` (Spotify, YouTube Music and most big players) open and start playing.
- Apps that expose a media browser service (what Android Auto talks to) are sent the request in the background.
  Whether they then find the right track is up to the app.
- Apps that offer neither are just opened, and Novochron says so instead of pretending it played something.
Speech tip: the app name is matched with spaces ignored, so "simp music" finds SimpMusic.

## Voice commands
- "Open Spotify" / "launch WhatsApp"
- "Open SimpMusic and play Multo by Cup of Joe" / "play Multo by Cup of Joe on Spotify" — opens the app and
  asks it to play that song (see "Playing a song in another app")
- "Set an alarm for 6:30 AM" / "wake me in 20 minutes" / "set a timer for 10 minutes"
- "Call Mom" / "call 555 0134"
- "Text John saying I'm running late" (Novochron reads it back and asks; say "yes" to send)
- "Remember my locker code is 4021" / "what do you remember" / "forget the locker code"
- "Remember this place as home" / "how far is home" / "what places do you know" / "forget the place home"
- "Open that again" (reopens the last thing it built) / "open my library"
- "Open the browser" / "search the web for sourdough starter" / "google best hiking boots" / "go to wikipedia.org"
  — opens `[web]` and loads it (see "What's new in 3.0")
- "Open the terminal" / "log into GitHub" / "list my repos" / "use repo owner/name" /
  "build the app" / "check the build status" (see "Terminal" and "GitHub setup")
- "Flashlight on" / "what time is it" / "stop listening"
- "Activate mode 1" — turns wake-word mode on (same as the `wake` switch). "Deactivate mode 2" — turns it
  off again; this one works even while wake-word mode is waiting, no wake phrase needed first (unless the
  low-power Porcupine engine is holding the mic, in which case say the wake word, then "deactivate mode 2").
- "Turn off, computer" (also "computer, turn off", "shut down, computer", "exit the app") — closes
  Novochron entirely
- "Turn off Wi-Fi" / "turn on Bluetooth" / "turn off location" / "airplane mode on" / "turn up the volume" /
  "do not disturb on" / "set brightness to 40 percent" (see "Phone controls")
- While it is talking: "stop" or "wait" silences it.

## Data
Chat history, memory, artifacts and learned places live in Novochron's own folder at
`/storage/emulated/0/Atlas` once granted (otherwise a local SQLite database, `novochron.db`, in app-private
storage); the Gemini API key is in app-private storage either way. Backups are disabled. Note: Novochron 2.0
is a separate app from Atlas 1.x (`com.novochron.assistant`), so it starts with empty history and memory.
