# Novochron 2.3: hands-free voice assistant (native Android)

Built by Daniel for Aishadina.

Kotlin + Jetpack Compose. Terminal-styled UI (monospace, green-on-black, portrait or landscape),
always-on listening with an optional wake word, works online (Gemini API) and offline (commands,
memory, learned notes, a real offline calculator, optional on-device model).

## What's new in 2.3
- **"Learn X" while online, use it offline.** Say "learn mathematics" (or any topic) while online
  with an API key set: Novochron fetches compact reference notes from Gemini and keeps them on the phone.
  Later, offline, it looks up the closest learned topic for what you're asking and either feeds it to
  the local model (if one's installed) or reads back the most relevant lines directly. Manage what's
  been learned, and remove individual topics, from Settings.
- **Real offline math**, no AI needed at all: arithmetic ("what's 45 times 12", "20% of 85"),
  parenthesised expressions, and simple linear equations ("solve 2x + 3 = 7") are solved with a small
  built-in calculator that runs before anything else, online or off. "Learning" mathematics adds
  reference notes on top of this for things a calculator can't do (concepts, word problems) — those
  still need either the online brain or a local LLM to reason over the notes.
- **Wake word.** Turn on "wake-word" (main screen or Settings, where you can also change the phrase
  from the default "novochron") and Novochron waits for you to say it before reacting to anything, the same
  shape as "Hey Google" — it re-arms after each reply. Worth knowing: this reuses the same continuous
  speech recognizer as always-on listening rather than a dedicated low-power keyword spotter, so it
  costs the same battery as Voice being on; it just won't act on anything until it hears the phrase.
- **Terminal UI.** Green-on-black, monospace throughout, bracket-style buttons, a scrolling
  `you $` / `novochron >` log instead of chat bubbles, and a blinking status box instead of the old orb.
- **Portrait or landscape.** The layout adapts: portrait stacks status → chat → input; landscape moves
  status and quick actions into a left-hand column next to a wider chat log.

## What's new in 2.2 — vision
- **Send a photo.** Tap **Photo** to pick one from your gallery, type a question (or leave it blank),
  and Novochron looks at it and answers or asks a clarifying question if something's unclear.
- **Camera, front or back.** Tap **Camera** for a full-screen viewfinder with a lens-flip button.
  Tap the shutter to ask about whatever's in frame, or turn on **Live scan** to have Novochron describe
  what it sees again every few seconds without you tapping anything.
- **Screencast.** Tap **Screencast** to let Novochron watch your screen (Android's normal "start
  recording your screen?" prompt appears once). While it's on, whatever you say or type — voice or
  typed — goes along with the freshest screenshot, so "what does this button do" or "why is this
  page blank" works while it watches you use the phone. Tap **Stop** (in-app or in the system
  notification) to end it.
- **Online and offline.** Online with an API key, all three use Gemini's vision. Offline, they only
  work if the installed model is a genuinely multimodal build — see "Offline vision" below — otherwise
  Novochron says so plainly rather than guessing at an image it can't actually see.

## What's new in 2.1
- **Phone controls.** Say (or type) "turn off Wi-Fi", "turn on Bluetooth", "turn off location", "turn on mobile data",
  "airplane mode on", "turn up the volume", "do not disturb on", "set brightness to 40 percent" and more. It also
  answers "is Bluetooth on". See "Phone controls" below for exactly what Novochron flips itself and what Android only lets
  it open.

## What's new in 2.0
- **Live conversation.** The mic stays open while Novochron thinks and speaks. Talk over it and it stops and
  listens. Replies stream in and are spoken sentence by sentence, so it starts talking almost immediately.
- **Background.** Runs as a foreground service: keeps listening with the screen off or while you use other
  apps, and asks Android to exempt it from battery saving.
- **Artifacts.** Ask it to build things: "make me a sudoku puzzle", "build a tip calculator", "make a
  snake game". It writes a self-contained HTML app and opens it full screen. Say "make the buttons bigger"
  and it updates it. Everything it builds is saved in **Library**. Artifacts run in a sandbox with no
  network access.
- **Its own folder.** Once granted, Novochron keeps its chat history, memory, artifacts and learned places in
  a plain, visible folder at `/storage/emulated/0/Atlas`, instead of hidden app-private storage. See
  "Novochron's own folder" below.
- **Offline maps.** Novochron can learn places by name ("remember this place as home") and later answer "how
  far is home" or "how many kilometres to the office" entirely offline, using GPS and simple distance
  math — no map downloads, no internet needed. See "Offline maps" below.
- **Faster turn-taking.** Novochron now reacts the instant you stop talking instead of waiting on a long
  pause, so replies start noticeably sooner. See "Talking over Novochron" below.
- **Black theme** and the new name, Novochron.

## Build
1. Install Android Studio (Koala or newer).
2. File > Open > select this folder. Let Gradle sync (needs internet once).
3. Plug in a phone (USB debugging on) and press Run, or Build > Build APK(s).
   APK: `app/build/outputs/apk/debug/app-debug.apk`

The debug APK is signed with the fixed key in `app/debug.keystore`, so new builds install over old ones.

## First run
- Tap the orb / Voice switch. Grant the permissions (mic, contacts, phone, SMS, location, notifications, nearby devices).
- Say yes to the battery prompt so Android does not stop Novochron in the background.
- Settings > "Give Novochron its own folder on this phone" so its data lives at `/storage/emulated/0/Atlas`
  instead of hidden app storage (Android 11+: this opens the "All files access" screen — turn it on for
  Novochron and go back).
- Settings > paste your Gemini API key (aistudio.google.com/apikey) for online chat, artifacts and the online voice.
- Settings > "Allow opening apps from the background" so commands and new artifacts can come to the front
  when Novochron is not on screen.

## Phone controls
Android decides which switches a normal app may flip. Novochron uses the strongest thing Android allows for each one:

| Setting | What Novochron does |
|---|---|
| Volume (up, down, a number, max, mute, unmute), silent / vibrate / normal | Changes it directly (silent mode needs the Do Not Disturb permission below) |
| Brightness (up, down, a number, max, min), auto brightness, auto-rotate | Changes it directly, after one-time "Modify system settings" permission |
| Do Not Disturb (also "alarms only", "total silence") | Changes it directly, after one-time Do Not Disturb permission |
| Flashlight | Changes it directly (already in 2.0) |
| Bluetooth | Android 12 and older: directly. Android 13+: turning **on** shows Android's own "Allow" dialog, turning **off** opens the Bluetooth switch |
| Wi-Fi | Android 9 and older: directly. Android 10+: opens the Wi-Fi panel and you tap the switch |
| Mobile data, location, airplane mode, hotspot, NFC, battery saver | Opens the right switch or panel and tells you to tap it. Android gives apps no way to flip these |

Grant the two one-time permissions in Settings > Phone controls. Bluetooth asks for "Nearby devices" the next time
you turn Voice on. If Novochron is not on screen it opens the switch over your current app, which uses the same
"Allow opening apps from the background" permission as timers and new artifacts.

Example phrases: "turn on Wi-Fi", "Bluetooth off", "is location on", "turn off mobile data", "airplane mode on",
"turn on do not disturb", "put the phone on vibrate", "mute the phone", "turn the volume up", "set volume to 40",
"turn down the brightness", "turn on auto brightness", "turn off auto rotate", "turn on battery saver".
Only sentences shaped like a command are acted on, so "how do I turn off Wi-Fi on a laptop" is still just a question.

## Novochron's own folder
Once "All files access" is granted (Settings > the storage button, or Android Settings directly), Novochron
stores everything in a folder it owns on shared storage:
```
/storage/emulated/0/Atlas/
├── atlas.db        chat history, memory, artifacts (SQLite — open with any SQLite viewer)
├── Maps/
│   └── places.json places Novochron has learned, with GPS coordinates (plain JSON, editable by hand)
└── Models/
    └── model.task  optional offline LLM (see "Offline setup" below)
```
You can browse, back up, or copy this folder like any other folder on the phone (file manager, USB, cloud
backup app). Until access is granted, Novochron still works normally; its data just stays in the app's private
storage instead (`novochron.db`), same as before.

## Offline maps
Novochron doesn't download street maps — it learns places you tell it about and remembers roughly where the
phone is, so it can work out straight-line distance with no internet at all:
- "Remember this place as home" (or "office", "the gym", anything) saves your current GPS position under
  that name to `Atlas/Maps/places.json`.
- "How far is home" / "how many kilometres to the office" / "distance to the gym" answers with the
  straight-line distance from where you are now.
- "What places do you know" lists everything learned so far.
- "Forget the place home" removes one.

This needs location permission (granted on first run) and a GPS or network fix; Novochron keeps a fix cached
in the background while listening is on, so answers are instant once you've been outside or connected at
least once. Distances are straight-line ("as the crow flies"), not driving distance, since there's no
offline road network involved.

## Online / offline toggle
There's a switch under the Voice toggle on the main screen (and in Settings) that forces Novochron offline
even when the internet is available — useful for testing offline behaviour, saving data, or just knowing
for sure nothing is leaving the phone. With it on: no Gemini chat, no online voice, no artifacts; you
still get phone commands, memory, offline maps and the offline brain (if installed). Turn it back to
"Online" and Novochron goes back to deciding for itself based on whatever connection is actually available.

## Talking over Novochron
While Novochron speaks, the mic also hears Novochron's own voice. Novochron compares what it hears with what it is
saying and ignores its own echo. **Headphones make this reliable.** On the phone speaker it can occasionally
mishear itself; if that happens repeatedly it turns interrupting off for 90 seconds. You can also switch
interrupting off in Settings.

Novochron treats a short pause (under half a second) as "done talking" and starts answering right away, rather
than waiting on a long silence — the UI shows "Thinking…" the instant it detects you've stopped. A quick
breath mid-sentence is shorter than that pause and won't cut you off, but if you tend to speak in short
bursts with long gaps, Novochron may occasionally answer before you meant to finish; just keep talking and it
will pick the rest up as a follow-up.

## Models
Settings > Model: **Auto** uses Gemini 3.5 Flash when you ask Novochron to build something and Gemini 3.1
Flash Lite for everything else. **Fast** is always 3.1 Flash Lite, **Smart** is always 3.5 Flash. Building
an app uses many more tokens than chatting, so it costs more.

## Voice
Online with a Gemini API key, Novochron's voice is synthesized by Gemini's TTS model (voice "Leda") with a
style instruction asking for a bright, high-pitched, cheerful anime-girl delivery.

## Offline vision
Photos, the camera and screencast frames can be understood with no internet at all, but only if the
installed `model.task` is a genuinely **multimodal** model — a text-only Gemma build cannot accept
images no matter how it's installed. A converted Gemma 3n E2B or E4B `.task` build is the model to
look for; install it exactly like the offline chat brain below (same file, same folder). If the
installed model turns out to be text-only, Novochron detects that automatically the first time you send
it an image and falls back to "I don't have an offline vision model installed" instead of guessing —
text chat, commands, memory and maps keep working offline regardless.

## Offline setup
- Speech: Google app > Settings > Voice > Offline speech recognition > download English.
- Offline fallback voice: Android Settings > Text-to-speech (Google) > Install voice data > English (US/UK).
  Novochron picks the brightest female voice installed automatically. This is only used when there is no
  internet or no API key; tune its pitch in Settings > offline voice slider.
- Offline chat brain (optional): download a MediaPipe LLM `.task` model (e.g. Gemma 3 1B int4), rename it
  `model.task`, and either copy it to `/storage/emulated/0/Atlas/Models/model.task` (once Novochron has its
  own folder — easiest, just drag it in with a file manager) or:
  `adb push model.task /sdcard/Android/data/com.novochron.assistant/files/model.task`
  Without it, offline mode still runs every phone command, memory, distance-to-place, time/date and simple replies.
  Building artifacts needs the internet and an API key.

## Voice commands
- "Open Spotify" / "launch WhatsApp"
- "Set an alarm for 6:30 AM" / "wake me in 20 minutes" / "set a timer for 10 minutes"
- "Call Mom" / "call 555 0134"
- "Text John saying I'm running late" (Novochron reads it back and asks; say "yes" to send)
- "Remember my locker code is 4021" / "what do you remember" / "forget the locker code"
- "Remember this place as home" / "how far is home" / "what places do you know" / "forget the place home"
- "Open that again" (reopens the last thing it built) / "open my library"
- "Flashlight on" / "what time is it" / "stop listening"
- "Turn off Wi-Fi" / "turn on Bluetooth" / "turn off location" / "airplane mode on" / "turn up the volume" /
  "do not disturb on" / "set brightness to 40 percent" (see "Phone controls")
- While it is talking: "stop" or "wait" silences it.

## Data
Chat history, memory, artifacts and learned places live in Novochron's own folder at
`/storage/emulated/0/Atlas` once granted (otherwise a local SQLite database, `novochron.db`, in app-private
storage); the Gemini API key is in app-private storage either way. Backups are disabled. Note: Novochron 2.0
is a separate app from Atlas 1.x (`com.novochron.assistant`), so it starts with empty history and memory.
