package com.atlas.assistant

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.net.Uri
import android.util.Base64
import androidx.camera.core.ImageProxy
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream

/**
 * Everything to do with turning a photo, a camera frame or a screen frame into (a) a JPEG saved on
 * disk so it can be shown again in the chat bubble, and (b) a small base64 blob to send to Gemini.
 */
object Vision {
    private const val MAX_SIDE = 1024 // keep uploads small and fast; plenty for identification
    private const val JPEG_QUALITY = 80

    /** Shrinks a bitmap so its longest side is at most [MAX_SIDE], keeping aspect ratio. */
    fun downscale(bmp: Bitmap): Bitmap {
        val w = bmp.width; val h = bmp.height
        val longest = maxOf(w, h)
        if (longest <= MAX_SIDE) return bmp
        val scale = MAX_SIDE.toFloat() / longest
        val m = Matrix().apply { postScale(scale, scale) }
        return Bitmap.createBitmap(bmp, 0, 0, w, h, m, true)
    }

    /** Saves a bitmap as a JPEG into Novochron's photo folder (or app-private storage) and returns its path. */
    fun save(ctx: Context, bmp: Bitmap): String {
        val dir = if (NovochronStorage.hasAccess() && NovochronStorage.ensureDirs()) NovochronStorage.photosDir()
        else NovochronStorage.privatePhotosDir(ctx).apply { mkdirs() }
        val file = File(dir, "img_${System.currentTimeMillis()}.jpg")
        val small = downscale(bmp)
        FileOutputStream(file).use { out -> small.compress(Bitmap.CompressFormat.JPEG, JPEG_QUALITY, out) }
        return file.absolutePath
    }

    fun loadBitmap(path: String): Bitmap? = try {
        BitmapFactory.decodeFile(path)
    } catch (e: Exception) {
        null
    }

    /** Reads an already-saved image back out as base64 JPEG, for sending to Gemini. */
    fun base64Of(path: String): String? {
        val bmp = loadBitmap(path) ?: return null
        val out = ByteArrayOutputStream()
        bmp.compress(Bitmap.CompressFormat.JPEG, JPEG_QUALITY, out)
        return Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)
    }

    /** Loads a picked gallery Uri into a bitmap, respecting EXIF-free simple decode. */
    fun fromUri(ctx: Context, uri: Uri): Bitmap? = try {
        ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) }
    } catch (e: Exception) {
        null
    }

    /**
     * CameraX's in-memory capture callback hands back a JPEG-encoded frame by default, so this just
     * decodes it and corrects the rotation the sensor recorded for it.
     */
    fun fromImageProxy(image: ImageProxy): Bitmap? = try {
        val buffer = image.planes[0].buffer
        val bytes = ByteArray(buffer.remaining())
        buffer.get(bytes)
        val raw = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
        val rotation = image.imageInfo.rotationDegrees
        if (raw != null && rotation != 0) {
            val m = Matrix().apply { postRotate(rotation.toFloat()) }
            Bitmap.createBitmap(raw, 0, 0, raw.width, raw.height, m, true)
        } else raw
    } catch (e: Exception) {
        null
    }
}
