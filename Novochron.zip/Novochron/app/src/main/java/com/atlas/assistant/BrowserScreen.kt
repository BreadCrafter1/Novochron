package com.atlas.assistant

import android.annotation.SuppressLint
import android.app.DownloadManager
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.net.http.SslError
import android.os.Build
import android.os.Environment
import android.view.View
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.SslErrorHandler
import android.webkit.URLUtil
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebStorage
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.webkit.ScriptHandler
import androidx.webkit.WebViewCompat
import androidx.webkit.WebViewFeature
import java.util.concurrent.atomic.AtomicLong

/** Everything the page-loading callbacks report back to the UI. */
private class WebUi {
    var url by mutableStateOf("")
    var title by mutableStateOf("")
    var progress by mutableIntStateOf(0)
    var loading by mutableStateOf(false)
    var canBack by mutableStateOf(false)
    var canForward by mutableStateOf(false)
    var error by mutableStateOf<String?>(null)
    var note by mutableStateOf("")
    var customView by mutableStateOf<View?>(null)
    var customCallback: WebChromeClient.CustomViewCallback? = null
    // whether *this* WebView is currently in desktop-site mode, and the injected script that
    // enforces it - see applyDesktop().
    var desktop: Boolean = false
    var viewportScript: ScriptHandler? = null
}

/** One open browser tab: its own WebView (so a page keeps its state while another tab is shown),
 *  its own address/loading state, and an optional tab-group name. */
private class WebTab(val id: Long, group: String? = null) {
    val ui = WebUi()
    var home by mutableStateOf(true)
    var group by mutableStateOf(group)
    var webView: WebView? = null
}

private val GroupPalette = listOf(
    Color(0xFF3DFF5C), Color(0xFF5CC8FF), Color(0xFFFFC65C),
    Color(0xFFFF5C9E), Color(0xFFB98CFF), Color(0xFF5CFFE0)
)

/** A stable colour dot for a tab-group name, so the same group always reads the same colour. */
private fun groupColor(name: String): Color = GroupPalette[(name.hashCode() and 0x7fffffff) % GroupPalette.size]

/**
 * "[web]": a small browser in the same terminal skin as everything else. Type an address to go there,
 * type anything else to search (DuckDuckGo by default; Google / Brave / Bing in `[opts]`).
 *
 * - Pages open over https only (plain http is upgraded, Android blocks cleartext anyway); file:, intent:,
 *   javascript: and other non-web links are refused. No JavaScript bridge, no file access.
 * - Follows the online/offline switch: with "offline" on, nothing is loaded.
 * - Dark pages, desktop site, private mode, bookmarks and history live in `[opts]` and on the start page.
 * - Multiple tabs can be open at once, each with its own WebView, and can be organized into named
 *   groups via `[tabs]`. The open tabs (their address, title and group - not full page/session
 *   state) are saved as they change and restored the next time `[web]` is opened, so closing and
 *   reopening the app brings tabs and groups back. Private mode saves none of this.
 * - Hardware back walks back through pages, then to the start page, then closes the current tab
 *   (if others are open), then closes the screen.
 */
@Composable
fun BrowserScreen(engine: Engine, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val store = engine.store
    val focusManager = LocalFocusManager.current

    var engineKey by remember { mutableStateOf(store.webEngine) }
    var dark by remember { mutableStateOf(store.webDark) }
    var desktop by remember { mutableStateOf(store.webDesktop) }
    var priv by remember { mutableStateOf(store.webPrivate) }
    var bookmarks by remember { mutableStateOf(store.webBookmarks()) }
    var history by remember { mutableStateOf(store.webHistory()) }
    var showOpts by remember { mutableStateOf(false) }
    var showTabs by remember { mutableStateOf(false) }
    var addr by remember { mutableStateOf(TextFieldValue("")) }
    var focused by remember { mutableStateOf(false) }

    val offline by AssistantState.forceOffline.collectAsState()
    val pending by AssistantState.webRequest.collectAsState()

    val defaultUa = remember { WebSettings.getDefaultUserAgent(ctx) }

    val recordVisit: (String, String) -> Unit = { url, title ->
        if (!store.webPrivate && url.startsWith("http")) {
            val next = (listOf(WebEntry(title.ifBlank { Web.hostOf(url) }, url)) +
                store.webHistory().filterNot { it.url == url }).take(60)
            store.saveWebHistory(next)
            history = next
        }
    }

    // tabs (and their groups) saved from a previous visit to [web], restored below unless the
    // browser was left in private mode last time it was closed.
    val savedTabs = remember { Web.decodeTabs(store.webTabsJson) }
    val tabIdGen = remember { AtomicLong(0) }
    fun newTab(
        group: String? = null,
        initialUrl: String? = null,
        initialTitle: String = "",
        startHome: Boolean = true
    ): WebTab {
        val t = WebTab(tabIdGen.getAndIncrement(), group)
        t.webView = buildWebView(ctx, t.ui, recordVisit)
        applyDark(t.webView!!, dark)
        applyDesktop(t.webView!!, t.ui, desktop, defaultUa)
        t.home = startHome
        if (initialTitle.isNotBlank()) t.ui.title = initialTitle
        if (!startHome && !initialUrl.isNullOrBlank()) {
            t.ui.url = initialUrl
            if (!AssistantState.forceOffline.value) t.webView?.loadUrl(initialUrl)
            else t.ui.note = "offline mode is on. reload once you're back online to load this tab."
        }
        return t
    }

    // every open tab, each with its own WebView so a page keeps its scroll/state while another tab
    // is on screen; restored from the last save (see persistTabs()) if there is one, so tabs and
    // tab groups survive closing [web] and reopening it, or restarting the app.
    val tabs = remember {
        mutableStateListOf<WebTab>().apply {
            if (savedTabs.isNotEmpty()) {
                for (s in savedTabs) add(newTab(s.group, s.url, s.title, s.home))
            } else {
                add(newTab())
            }
        }
    }
    var activeTabId by remember {
        mutableStateOf(tabs.getOrNull(store.webActiveTab.toInt())?.id ?: tabs.first().id)
    }
    val activeTab = tabs.firstOrNull { it.id == activeTabId } ?: tabs.first()
    val ui = activeTab.ui

    // saves the open tabs (address, title, group, whether each is on its start page) and which one
    // is active, so [web] reopens the way it was left. Private mode never writes anything here, and
    // clears whatever was last saved, matching how it already keeps no history.
    fun persistTabs() {
        if (store.webPrivate) {
            store.webTabsJson = ""
            store.webActiveTab = 0L
            return
        }
        val list = tabs.map { t ->
            TabState(url = if (t.home) "" else t.ui.url, title = t.ui.title, group = t.group, home = t.home)
        }
        store.webTabsJson = Web.encodeTabs(list)
        store.webActiveTab = tabs.indexOfFirst { it.id == activeTabId }.coerceAtLeast(0).toLong()
    }

    fun closeTab(t: WebTab) {
        t.ui.customCallback?.onCustomViewHidden()
        t.ui.customCallback = null
        t.ui.customView = null
        t.webView?.stopLoading()
        (t.webView?.parent as? ViewGroup)?.removeView(t.webView)
        t.webView?.destroy()
        val idx = tabs.indexOf(t)
        if (idx < 0) return
        tabs.removeAt(idx)
        if (tabs.isEmpty()) {
            store.webTabsJson = ""
            store.webActiveTab = 0L
            onClose()
            return
        }
        if (activeTabId == t.id) activeTabId = tabs[idx.coerceAtMost(tabs.size - 1)].id
        persistTabs()
    }

    fun go(input: String) {
        if (AssistantState.forceOffline.value) {
            activeTab.ui.note = "offline mode is on. switch to online to browse."
            return
        }
        val target = Web.resolve(input, engineKey)
        if (target == null) {
            activeTab.ui.note = "can't open that: only web addresses and searches."
            return
        }
        val t = activeTab
        t.ui.note = ""
        t.ui.error = null
        t.ui.url = target
        t.home = false
        t.webView?.loadUrl(target)
        persistTabs()
    }

    fun hideCustomView() {
        val t = activeTab
        t.ui.customCallback?.onCustomViewHidden()
        t.ui.customCallback = null
        t.ui.customView = null
    }

    fun toggleBookmark() {
        val cur = activeTab.ui.url
        if (activeTab.home || cur.isBlank()) return
        val had = bookmarks.any { it.url == cur }
        val next = if (had) bookmarks.filterNot { it.url == cur }
        else listOf(WebEntry(activeTab.ui.title.ifBlank { Web.hostOf(cur) }, cur)) + bookmarks
        bookmarks = next
        store.saveWebBookmarks(next)
        activeTab.ui.note = if (had) "bookmark removed." else "bookmarked."
    }

    // "search the web for ..." from the voice / chat commands lands here
    LaunchedEffect(pending) {
        val r = pending
        if (r != null) {
            AssistantState.webRequest.value = null
            if (r.isNotBlank()) go(r)
        }
    }

    // keep the address bar in step with the page, unless the user is typing in it
    val shown = if (activeTab.home) "" else activeTab.ui.url
    LaunchedEffect(activeTabId, shown, focused) {
        if (!focused) addr = TextFieldValue(shown)
    }

    // save the open tabs and groups whenever a page's address or title settles (this also catches
    // the explicit persistTabs() calls above landing on the same values, which is harmless).
    val tabsSignature = tabs.joinToString("|") { "${it.id}:${it.home}:${it.ui.url}:${it.ui.title}:${it.group}" }
    LaunchedEffect(tabsSignature, activeTabId, priv) { persistTabs() }

    BackHandler {
        when {
            activeTab.ui.customView != null -> hideCustomView()
            !activeTab.home && activeTab.webView?.canGoBack() == true -> activeTab.webView?.goBack()
            !activeTab.home -> { activeTab.home = true; persistTabs() }
            tabs.size > 1 -> closeTab(activeTab)
            else -> onClose()
        }
    }

    DisposableEffect(Unit) {
        onDispose {
            persistTabs()
            for (t in tabs) {
                t.ui.customCallback?.onCustomViewHidden()
                t.ui.customCallback = null
                t.ui.customView = null
                t.webView?.stopLoading()
                if (store.webPrivate) wipeWebData(t.webView)
                (t.webView?.parent as? ViewGroup)?.removeView(t.webView)
                t.webView?.destroy()
            }
        }
    }

    val home = activeTab.home
    val isMarked = !home && bookmarks.any { it.url == ui.url }
    val secure = ui.url.startsWith("https://")

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        Column(Modifier.fillMaxSize().padding(12.dp)) {
            // title row
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        "[ web ]",
                        color = Accent,
                        fontFamily = TermFont,
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp
                    )
                    if (priv) {
                        Text("  private", color = Warn, fontFamily = TermFont, fontSize = 12.sp)
                    }
                    if (offline) {
                        Text("  offline", color = Dim, fontFamily = TermFont, fontSize = 12.sp)
                    }
                }
                TermTextKey("[close]", onClick = onClose)
            }

            // tab strip
            Row(
                Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                verticalAlignment = Alignment.CenterVertically
            ) {
                for (t in tabs) {
                    key(t.id) {
                        TabChip(
                            tab = t,
                            active = t.id == activeTabId,
                            onSelect = { activeTabId = t.id; persistTabs() },
                            onClose = { closeTab(t) }
                        )
                    }
                }
                TermTextKey("[+]", tone = Accent, bold = true, hpad = 6) {
                    val t = newTab()
                    tabs.add(t)
                    activeTabId = t.id
                    persistTabs()
                }
                if (tabs.size > 1) {
                    TermTextKey("[tabs: ${tabs.size}]", tone = Ink, hpad = 6) { showTabs = true }
                }
            }

            // address bar
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(
                    value = addr,
                    onValueChange = { addr = it },
                    singleLine = true,
                    placeholder = {
                        Text("search or type an address", color = Dim, fontFamily = TermFont, fontSize = 13.sp)
                    },
                    leadingIcon = {
                        Text(
                            if (home || ui.url.isBlank()) "$" else if (secure) "[s]" else "[!]",
                            color = if (!home && ui.url.isNotBlank() && !secure) Warn else Accent,
                            fontFamily = TermFont,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            modifier = Modifier.padding(start = 6.dp)
                        )
                    },
                    textStyle = TextStyle(fontFamily = TermFont, fontSize = 14.sp, color = Ink),
                    keyboardOptions = KeyboardOptions(
                        capitalization = KeyboardCapitalization.None,
                        keyboardType = KeyboardType.Uri,
                        imeAction = ImeAction.Go
                    ),
                    keyboardActions = KeyboardActions(onGo = {
                        focusManager.clearFocus()
                        go(addr.text)
                    }),
                    colors = fieldColors(),
                    modifier = Modifier
                        .weight(1f)
                        .onFocusChanged { st ->
                            focused = st.isFocused
                            if (st.isFocused) addr = addr.copy(selection = TextRange(0, addr.text.length))
                        }
                )
                TermTextKey("[go]", tone = Accent, bold = true) {
                    focusManager.clearFocus()
                    go(addr.text)
                }
            }

            // load progress: a 2 dp green line
            Spacer(Modifier.height(6.dp))
            Box(Modifier.fillMaxWidth().height(2.dp).background(Line)) {
                if (ui.loading) {
                    Box(
                        Modifier
                            .fillMaxWidth(ui.progress.coerceIn(3, 100) / 100f)
                            .fillMaxHeight()
                            .background(Accent)
                    )
                }
            }
            if (ui.note.isNotBlank()) {
                Text(ui.note, color = Dim, fontFamily = TermFont, fontSize = 11.sp, modifier = Modifier.padding(top = 4.dp))
            }
            Spacer(Modifier.height(6.dp))

            // page area: each tab's WebView is always there (so a page survives a trip to the start
            // page, and switching tabs doesn't reload them); the start page or an error panel is
            // drawn over the active tab's WebView when needed
            Box(Modifier.weight(1f).fillMaxWidth().border(1.dp, Line)) {
                key(activeTabId) {
                    AndroidView(
                        modifier = Modifier.fillMaxSize(),
                        factory = { activeTab.webView!! },
                        update = { it.visibility = if (home || ui.error != null) View.INVISIBLE else View.VISIBLE }
                    )
                }
                if (home) {
                    WebHome(
                        engineKey = engineKey,
                        offline = offline,
                        priv = priv,
                        bookmarks = bookmarks,
                        history = history,
                        onEngine = { engineKey = it; store.webEngine = it },
                        onOpen = { go(it) },
                        onRemoveBookmark = { b ->
                            val next = bookmarks.filterNot { it.url == b.url }
                            bookmarks = next
                            store.saveWebBookmarks(next)
                        },
                        onClearHistory = {
                            store.clearWebHistory()
                            history = emptyList()
                        },
                        onGoOnline = { engine.setForceOffline(false) }
                    )
                } else {
                    val err = ui.error
                    if (err != null) {
                        Column(
                            Modifier
                                .fillMaxSize()
                                .background(Color.Black)
                                .pointerInput(Unit) { detectTapGestures { } }
                                .padding(18.dp)
                        ) {
                            Text("[ can't load page ]", color = Warn, fontFamily = TermFont, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                            Spacer(Modifier.height(10.dp))
                            Text(err, color = Ink, fontFamily = TermFont, fontSize = 13.sp)
                            Spacer(Modifier.height(6.dp))
                            Text(ui.url, color = Dim, fontFamily = TermFont, fontSize = 11.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                            Spacer(Modifier.height(10.dp))
                            Row {
                                TermTextKey("[retry]", tone = Accent, bold = true) {
                                    val u = ui.url
                                    ui.error = null
                                    if (u.isNotBlank() && !AssistantState.forceOffline.value) activeTab.webView?.loadUrl(u)
                                }
                                TermTextKey("[start page]") { ui.error = null; activeTab.home = true; persistTabs() }
                            }
                        }
                    }
                }
            }

            // toolbar: scrolls sideways on narrow screens, like the main screen's key rows
            Row(
                Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                verticalAlignment = Alignment.CenterVertically
            ) {
                val canBackNow = if (home) ui.url.isNotBlank() else true
                TermTextKey("[<]", tone = if (canBackNow) Ink else Dim) {
                    if (activeTab.home) {
                        if (ui.url.isNotBlank()) activeTab.home = false
                    } else if (activeTab.webView?.canGoBack() == true) {
                        activeTab.webView?.goBack()
                    } else {
                        activeTab.home = true
                    }
                }
                TermTextKey("[>]", tone = if (!home && ui.canForward) Ink else Dim) {
                    if (!activeTab.home && activeTab.webView?.canGoForward() == true) activeTab.webView?.goForward()
                }
                TermTextKey(if (ui.loading) "[stop]" else "[reload]") {
                    if (ui.loading) activeTab.webView?.stopLoading()
                    else if (!activeTab.home && ui.url.isNotBlank() && !AssistantState.forceOffline.value) {
                        ui.error = null
                        activeTab.webView?.reload()
                    }
                }
                TermTextKey("[home]", tone = if (home) Accent else Ink) { activeTab.home = true; persistTabs() }
                TermTextKey(
                    if (isMarked) "[marked]" else "[mark]",
                    tone = if (isMarked) Accent else Ink,
                    bold = isMarked
                ) { toggleBookmark() }
                TermTextKey("[share]", tone = if (!home && ui.url.isNotBlank()) Ink else Dim) {
                    if (!home && ui.url.isNotBlank()) shareUrl(ctx, ui.url, ui.title)
                }
                TermTextKey("[ext]", tone = if (!home && ui.url.isNotBlank()) Ink else Dim) {
                    if (!home && ui.url.isNotBlank() && !openExternal(ctx, ui.url)) ui.note = "no app can open that."
                }
                TermTextKey("[tabs]") { showTabs = true }
                TermTextKey("[opts]") { showOpts = true }
            }
        }

        // a page's fullscreen video (a "custom view") takes over the whole screen
        ui.customView?.let { cv ->
            key(cv) {
                AndroidView(
                    modifier = Modifier.fillMaxSize().background(Color.Black),
                    factory = { c ->
                        FrameLayout(c).apply {
                            setBackgroundColor(android.graphics.Color.BLACK)
                            addView(
                                cv,
                                FrameLayout.LayoutParams(
                                    ViewGroup.LayoutParams.MATCH_PARENT,
                                    ViewGroup.LayoutParams.MATCH_PARENT
                                )
                            )
                        }
                    }
                )
            }
        }
    }

    if (showOpts) {
        AlertDialog(
            onDismissRequest = { showOpts = false },
            containerColor = Color(0xFF0B0B0B),
            title = { Text("[ web options ]", color = Accent, fontFamily = TermFont, fontWeight = FontWeight.Bold) },
            text = {
                Column {
                    OptRow("search engine", Web.engine(engineKey).label, hot = true) {
                        val n = Web.nextEngine(engineKey)
                        engineKey = n.key
                        store.webEngine = n.key
                    }
                    OptRow("dark pages", if (dark) "on" else "off", hot = dark) {
                        dark = !dark
                        store.webDark = dark
                        for (t in tabs) t.webView?.let { applyDark(it, dark) }
                    }
                    OptRow("desktop site", if (desktop) "on" else "off", hot = desktop) {
                        desktop = !desktop
                        store.webDesktop = desktop
                        for (t in tabs) t.webView?.let { applyDesktop(it, t.ui, desktop, defaultUa) }
                        if (!home && ui.url.isNotBlank() && !AssistantState.forceOffline.value) activeTab.webView?.reload()
                    }
                    OptRow("private mode", if (priv) "on" else "off", hot = priv) {
                        priv = !priv
                        store.webPrivate = priv
                    }
                    OptRow("clear history", "${history.size} saved") {
                        store.clearWebHistory()
                        history = emptyList()
                        ui.note = "history cleared."
                    }
                    OptRow("wipe cookies + cache", "now") {
                        for (t in tabs) wipeWebData(t.webView)
                        ui.note = "cookies and cache wiped."
                        showOpts = false
                    }
                    Spacer(Modifier.height(8.dp))
                    Text(
                        "private mode keeps no history and wipes cookies when you leave [web]. " +
                            "pages open over https only, and third-party cookies are blocked.",
                        color = Dim,
                        fontFamily = TermFont,
                        fontSize = 11.sp
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = { showOpts = false }) { Text("Close", color = Accent, fontFamily = TermFont) }
            }
        )
    }

    if (showTabs) {
        TabSwitcherOverlay(
            tabs = tabs,
            activeTabId = activeTabId,
            onSelect = { activeTabId = it; showTabs = false; persistTabs() },
            onCloseTab = { closeTab(it) },
            onNewTab = { g -> val t = newTab(g); tabs.add(t); activeTabId = t.id; showTabs = false; persistTabs() },
            onAssignGroup = { t, g -> t.group = g?.trim()?.ifBlank { null }; persistTabs() },
            onCloseGroup = { g -> tabs.filter { it.group == g }.toList().forEach { closeTab(it) } },
            onDismiss = { showTabs = false }
        )
    }
}

/** A single tab in the strip below the title row: a group dot (if any), its title, and a close [x]. */
@Composable
private fun TabChip(tab: WebTab, active: Boolean, onSelect: () -> Unit, onClose: () -> Unit) {
    val title = tab.ui.title.ifBlank { if (tab.home) "new tab" else Web.hostOf(tab.ui.url) }
    Row(
        Modifier
            .padding(end = 6.dp)
            .border(1.dp, if (active) Accent else Line)
            .clickable(onClick = onSelect)
            .padding(horizontal = 8.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        tab.group?.let { g ->
            Text("● ", color = groupColor(g), fontFamily = TermFont, fontSize = 11.sp)
        }
        Text(
            title.take(16),
            color = if (active) Accent else Ink,
            fontFamily = TermFont,
            fontSize = 12.sp,
            fontWeight = if (active) FontWeight.Bold else FontWeight.Normal,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
        Spacer(Modifier.width(8.dp))
        Text(
            "x",
            color = Dim,
            fontFamily = TermFont,
            fontSize = 12.sp,
            modifier = Modifier.clickable(onClick = onClose)
        )
    }
}

/**
 * Full-screen tab manager opened from `[tabs]`: every open tab, grouped by tab-group, with buttons
 * to switch to a tab, close it, put it in a group, open a new tab (in a group or not), or close a
 * whole group at once.
 */
@Composable
private fun TabSwitcherOverlay(
    tabs: List<WebTab>,
    activeTabId: Long,
    onSelect: (Long) -> Unit,
    onCloseTab: (WebTab) -> Unit,
    onNewTab: (String?) -> Unit,
    onAssignGroup: (WebTab, String?) -> Unit,
    onCloseGroup: (String) -> Unit,
    onDismiss: () -> Unit
) {
    var groupTarget by remember { mutableStateOf<WebTab?>(null) }
    val groupNames = tabs.mapNotNull { it.group }.distinct().sorted()
    val grouped = tabs.filter { it.group != null }.groupBy { it.group!! }
    val ungrouped = tabs.filter { it.group == null }

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        Column(Modifier.fillMaxSize().padding(12.dp)) {
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("[ tabs ]", color = Accent, fontFamily = TermFont, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                TermTextKey("[close]", onClick = onDismiss)
            }
            Spacer(Modifier.height(8.dp))
            TermTextKey("[+ new tab]", tone = Accent, bold = true, hpad = 0) { onNewTab(null) }
            Spacer(Modifier.height(10.dp))

            LazyColumn(Modifier.weight(1f)) {
                if (ungrouped.isNotEmpty()) {
                    item {
                        Text("no group", color = Dim, fontFamily = TermFont, fontSize = 12.sp, modifier = Modifier.padding(bottom = 4.dp))
                    }
                    items(ungrouped, key = { it.id }) { t ->
                        TabSwitchRow(t, t.id == activeTabId, onSelect = { onSelect(t.id) }, onClose = { onCloseTab(t) }, onGroup = { groupTarget = t })
                    }
                }
                for (g in groupNames) {
                    item {
                        Spacer(Modifier.height(12.dp))
                        Row(
                            Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text("● ", color = groupColor(g), fontFamily = TermFont, fontSize = 12.sp)
                                Text(g, color = Ink, fontFamily = TermFont, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            }
                            Row {
                                TermTextKey("[+ tab]", hpad = 6) { onNewTab(g) }
                                TermTextKey("[close group]", tone = Warn, hpad = 6) { onCloseGroup(g) }
                            }
                        }
                    }
                    items(grouped[g].orEmpty(), key = { it.id }) { t ->
                        TabSwitchRow(t, t.id == activeTabId, onSelect = { onSelect(t.id) }, onClose = { onCloseTab(t) }, onGroup = { groupTarget = t })
                    }
                }
                item { Spacer(Modifier.height(16.dp)) }
            }
        }
    }

    val gt = groupTarget
    if (gt != null) {
        AssignGroupDialog(
            tab = gt,
            existingGroups = groupNames,
            onAssign = { name -> onAssignGroup(gt, name); groupTarget = null },
            onDismiss = { groupTarget = null }
        )
    }
}

@Composable
private fun TabSwitchRow(tab: WebTab, active: Boolean, onSelect: () -> Unit, onClose: () -> Unit, onGroup: () -> Unit) {
    val title = tab.ui.title.ifBlank { if (tab.home) "new tab" else Web.hostOf(tab.ui.url) }
    Column(Modifier.fillMaxWidth().padding(bottom = 4.dp)) {
        Row(
            Modifier
                .fillMaxWidth()
                .border(1.dp, if (active) Accent else Line)
                .clickable(onClick = onSelect)
                .padding(horizontal = 10.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Text(
                    title, color = if (active) Accent else Ink, fontFamily = TermFont, fontSize = 14.sp,
                    maxLines = 1, overflow = TextOverflow.Ellipsis
                )
                if (!tab.home) {
                    Text(
                        Web.hostOf(tab.ui.url), color = Dim, fontFamily = TermFont, fontSize = 11.sp,
                        maxLines = 1, overflow = TextOverflow.Ellipsis
                    )
                }
            }
            TermTextKey("[group]", tone = Dim, hpad = 6, onClick = onGroup)
            TermTextKey("[x]", tone = Warn, hpad = 6, onClick = onClose)
        }
    }
}

@Composable
private fun AssignGroupDialog(tab: WebTab, existingGroups: List<String>, onAssign: (String?) -> Unit, onDismiss: () -> Unit) {
    var text by remember { mutableStateOf(tab.group ?: "") }
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Color(0xFF0B0B0B),
        title = { Text("[ group ]", color = Accent, fontFamily = TermFont, fontWeight = FontWeight.Bold) },
        text = {
            Column {
                OutlinedTextField(
                    value = text,
                    onValueChange = { text = it },
                    singleLine = true,
                    placeholder = { Text("group name", color = Dim, fontFamily = TermFont, fontSize = 13.sp) },
                    textStyle = TextStyle(fontFamily = TermFont, fontSize = 14.sp, color = Ink),
                    colors = fieldColors()
                )
                if (existingGroups.isNotEmpty()) {
                    Spacer(Modifier.height(10.dp))
                    Text("existing:", color = Dim, fontFamily = TermFont, fontSize = 11.sp)
                    Row(Modifier.horizontalScroll(rememberScrollState())) {
                        for (g in existingGroups) {
                            TermTextKey(g, tone = groupColor(g), hpad = 6) { text = g }
                        }
                    }
                }
                if (tab.group != null) {
                    Spacer(Modifier.height(6.dp))
                    TermTextKey("[remove from group]", tone = Warn, hpad = 0) { onAssign(null) }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = { onAssign(text) }) { Text("Save", color = Accent, fontFamily = TermFont) }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel", color = Dim, fontFamily = TermFont) }
        }
    )
}

/** The page shown before anything is loaded (and when `[home]` is tapped): bookmarks and recent pages. */
@Composable
private fun WebHome(
    engineKey: String,
    offline: Boolean,
    priv: Boolean,
    bookmarks: List<WebEntry>,
    history: List<WebEntry>,
    onEngine: (String) -> Unit,
    onOpen: (String) -> Unit,
    onRemoveBookmark: (WebEntry) -> Unit,
    onClearHistory: () -> Unit,
    onGoOnline: () -> Unit
) {
    LazyColumn(
        Modifier
            .fillMaxSize()
            .background(Color.Black)
            .padding(horizontal = 12.dp)
    ) {
        item {
            Spacer(Modifier.height(14.dp))
            Row {
                Text("root@novochron:~$", color = Ink, fontFamily = TermFont, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                Text(" browse █", color = Accent, fontFamily = TermFont, fontWeight = FontWeight.Bold, fontSize = 15.sp)
            }
            Spacer(Modifier.height(6.dp))
            Text(
                "type an address to go there, or anything else to search.",
                color = Dim, fontFamily = TermFont, fontSize = 12.sp
            )
            Text(
                "or say: \"search the web for ...\"",
                color = Dim, fontFamily = TermFont, fontSize = 12.sp
            )
            if (offline) {
                Spacer(Modifier.height(10.dp))
                Text(
                    "offline mode is on: nothing leaves the phone, so pages won't load.",
                    color = Warn, fontFamily = TermFont, fontSize = 12.sp
                )
                TermTextKey("[go online]", tone = Accent, bold = true, hpad = 0, onClick = onGoOnline)
            }
            if (priv) {
                Spacer(Modifier.height(6.dp))
                Text("private mode: history off.", color = Warn, fontFamily = TermFont, fontSize = 12.sp)
            }
            Spacer(Modifier.height(10.dp))
            Row(Modifier.horizontalScroll(rememberScrollState()), verticalAlignment = Alignment.CenterVertically) {
                Text("engine:", color = Dim, fontFamily = TermFont, fontSize = 12.sp)
                Spacer(Modifier.width(4.dp))
                for (e in Web.engines) {
                    val on = e.key == engineKey
                    TermTextKey(
                        if (on) "[${e.short}]" else e.short,
                        tone = if (on) Accent else Dim,
                        bold = on,
                        hpad = 6
                    ) { onEngine(e.key) }
                }
            }
            Spacer(Modifier.height(12.dp))
            Text("bookmarks", color = Accent, fontFamily = TermFont, fontWeight = FontWeight.Bold, fontSize = 13.sp)
            if (bookmarks.isEmpty()) {
                Text(
                    "none yet. tap [mark] while on a page to keep it here.",
                    color = Dim, fontFamily = TermFont, fontSize = 12.sp,
                    modifier = Modifier.padding(vertical = 6.dp)
                )
            }
        }
        items(bookmarks) { b -> WebEntryRow(b, onOpen = { onOpen(b.url) }, onRemove = { onRemoveBookmark(b) }) }
        item {
            Spacer(Modifier.height(14.dp))
            Text("recent", color = Accent, fontFamily = TermFont, fontWeight = FontWeight.Bold, fontSize = 13.sp)
            if (history.isEmpty()) {
                Text(
                    "nothing yet.",
                    color = Dim, fontFamily = TermFont, fontSize = 12.sp,
                    modifier = Modifier.padding(vertical = 6.dp)
                )
            }
        }
        items(history.take(15)) { h -> WebEntryRow(h, onOpen = { onOpen(h.url) }, onRemove = null) }
        if (history.isNotEmpty()) {
            item { TermTextKey("[clear history]", tone = Dim, hpad = 0, onClick = onClearHistory) }
        }
        item { Spacer(Modifier.height(16.dp)) }
    }
}

@Composable
private fun WebEntryRow(entry: WebEntry, onOpen: () -> Unit, onRemove: (() -> Unit)?) {
    Row(
        Modifier
            .fillMaxWidth()
            .clickable(onClick = onOpen)
            .padding(vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(
                entry.title.ifBlank { Web.hostOf(entry.url) },
                color = Ink, fontFamily = TermFont, fontSize = 14.sp,
                maxLines = 1, overflow = TextOverflow.Ellipsis
            )
            Text(
                Web.hostOf(entry.url),
                color = Dim, fontFamily = TermFont, fontSize = 11.sp,
                maxLines = 1, overflow = TextOverflow.Ellipsis
            )
        }
        if (onRemove != null) TermTextKey("[x]", tone = Dim, onClick = onRemove)
    }
}

@Composable
private fun OptRow(label: String, value: String, hot: Boolean = false, onClick: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(vertical = 11.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, color = Ink, fontFamily = TermFont, fontSize = 13.sp, modifier = Modifier.weight(1f))
        Text(
            value,
            color = if (hot) Accent else Dim,
            fontFamily = TermFont,
            fontSize = 13.sp,
            fontWeight = if (hot) FontWeight.Bold else FontWeight.Normal
        )
    }
}

// ---------------------------------------------------------------------------------------------
// WebView plumbing
// ---------------------------------------------------------------------------------------------

/**
 * A locked-down WebView: JavaScript on (pages need it), but no file or content access, no JavaScript
 * bridge, no mixed content, no third-party cookies, and only https / a few "hand-off" links get through.
 */
@SuppressLint("SetJavaScriptEnabled")
private fun buildWebView(ctx: Context, ui: WebUi, onVisit: (String, String) -> Unit): WebView {
    val web = WebView(ctx)
    val s = web.settings
    s.javaScriptEnabled = true
    s.domStorageEnabled = true
    s.allowFileAccess = false
    s.allowContentAccess = false
    s.setSupportZoom(true)
    s.builtInZoomControls = true
    s.displayZoomControls = false
    s.useWideViewPort = true
    s.loadWithOverviewMode = true
    s.javaScriptCanOpenWindowsAutomatically = false
    s.mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
    CookieManager.getInstance().setAcceptThirdPartyCookies(web, false)

    web.webViewClient = object : WebViewClient() {
        override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
            val req = request ?: return true
            val u = req.url ?: return true
            val scheme = u.scheme?.lowercase() ?: return true
            if (scheme == "https") {
                if (AssistantState.forceOffline.value) {
                    ui.note = "offline mode is on. switch to online to browse."
                    return true
                }
                return false
            }
            if (scheme == "http") {
                // https-first: upgrade instead of loading in the clear
                if (req.isForMainFrame && !AssistantState.forceOffline.value) {
                    view?.loadUrl(u.buildUpon().scheme("https").build().toString())
                }
                return true
            }
            if ((scheme == "tel" || scheme == "mailto" || scheme == "sms" || scheme == "geo") && req.hasGesture()) {
                try {
                    ctx.startActivity(Intent(Intent.ACTION_VIEW, u).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                } catch (e: Exception) {
                    ui.note = "no app can open that link."
                }
            }
            return true // file:, content:, intent:, custom app schemes ... never followed
        }

        override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
            ui.loading = true
            ui.progress = 5
            ui.error = null
            if (!url.isNullOrBlank()) ui.url = url
        }

        override fun onPageFinished(view: WebView?, url: String?) {
            ui.loading = false
            ui.progress = 100
            // belt-and-braces: also apply here in case document-start scripts aren't supported on
            // this device, or a site rewrites its own viewport tag after load.
            if (ui.desktop) view?.evaluateJavascript(DESKTOP_VIEWPORT_JS, null)
            if (ui.error == null && !url.isNullOrBlank()) onVisit(url, view?.title ?: "")
        }

        override fun doUpdateVisitedHistory(view: WebView?, url: String?, isReload: Boolean) {
            if (!url.isNullOrBlank()) ui.url = url
            ui.canBack = view?.canGoBack() == true
            ui.canForward = view?.canGoForward() == true
        }

        override fun onReceivedError(view: WebView?, request: WebResourceRequest?, error: WebResourceError?) {
            if (request?.isForMainFrame != true) return
            val desc = error?.description?.toString().orEmpty()
            val code = error?.errorCode
            ui.error = when {
                desc.contains("CLEARTEXT", ignoreCase = true) ->
                    "this site only offers plain http, which is blocked for your safety."
                code == WebViewClient.ERROR_HOST_LOOKUP ->
                    "can't find that site. check the address, or your connection."
                code == WebViewClient.ERROR_TIMEOUT || code == WebViewClient.ERROR_CONNECT ->
                    "the site didn't answer. check your connection and retry."
                else -> desc.ifBlank { "the page couldn't be loaded." }
            }
            ui.loading = false
        }

        override fun onReceivedSslError(view: WebView?, handler: SslErrorHandler?, error: SslError?) {
            handler?.cancel() // never click through a bad certificate
            ui.error = "the site's security certificate can't be trusted, so it was blocked."
            ui.loading = false
        }
    }

    web.webChromeClient = object : WebChromeClient() {
        override fun onProgressChanged(view: WebView?, newProgress: Int) {
            ui.progress = newProgress
            ui.loading = newProgress < 100
        }

        override fun onReceivedTitle(view: WebView?, title: String?) {
            ui.title = title ?: ""
        }

        override fun onShowCustomView(view: View?, callback: WebChromeClient.CustomViewCallback?) {
            if (view == null) {
                callback?.onCustomViewHidden()
                return
            }
            ui.customView = view
            ui.customCallback = callback
        }

        override fun onHideCustomView() {
            ui.customView = null
            ui.customCallback = null
        }
    }

    web.setDownloadListener { url, userAgent, contentDisposition, mimetype, _ ->
        startDownload(ctx, ui, url, userAgent, contentDisposition, mimetype)
    }
    return web
}

/** Dark pages: the WebView's own darkening, plus a matching backdrop so nothing flashes white. */
@Suppress("DEPRECATION")
private fun applyDark(web: WebView, on: Boolean) {
    web.setBackgroundColor(if (on) android.graphics.Color.BLACK else android.graphics.Color.WHITE)
    if (Build.VERSION.SDK_INT >= 33) {
        web.settings.isAlgorithmicDarkeningAllowed = on
    } else if (Build.VERSION.SDK_INT >= 29) {
        web.settings.forceDark = if (on) WebSettings.FORCE_DARK_ON else WebSettings.FORCE_DARK_OFF
    }
}

// Forces a desktop-width layout regardless of what the page's own <meta name="viewport"> tag says.
// A desktop user agent alone rarely changes anything on real sites: almost all responsive sites pick
// mobile vs. desktop layout from the *viewport width* (usually "width=device-width" in their own meta
// tag), not from sniffing the UA string. This is what "request desktop site" does in real browsers.
private const val DESKTOP_VIEWPORT_JS = """
(function() {
    var vp = document.querySelector('meta[name="viewport"]');
    if (!vp) {
        vp = document.createElement('meta');
        vp.setAttribute('name', 'viewport');
        (document.head || document.documentElement).appendChild(vp);
    }
    vp.setAttribute('content', 'width=1024, initial-scale=' + (screen.width / 1024) + ', user-scalable=yes');
})();
"""

/**
 * Desktop site: a desktop-style user agent, plus a forced desktop-width viewport (see
 * [DESKTOP_VIEWPORT_JS]). The viewport script is injected before the page's own scripts run
 * (so a site can't reset it back to mobile), where the installed WebView build supports that;
 * [WebViewClient.onPageFinished] above re-applies it as a fallback either way. Takes effect on
 * the next load, or immediately if the caller reloads afterwards.
 */
private fun applyDesktop(web: WebView, ui: WebUi, on: Boolean, defaultUa: String) {
    ui.desktop = on
    web.settings.userAgentString =
        if (on) defaultUa.replace(Regex("\\(Linux; Android[^)]*\\)"), "(X11; Linux x86_64)").replace(" Mobile", "")
        else defaultUa
    web.settings.useWideViewPort = true
    web.settings.loadWithOverviewMode = true

    ui.viewportScript?.remove()
    ui.viewportScript = null
    if (on && WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT)) {
        ui.viewportScript = WebViewCompat.addDocumentStartJavaScript(web, DESKTOP_VIEWPORT_JS, setOf("*"))
    }
}

/** Cookies, site storage and the HTTP cache. */
private fun wipeWebData(web: WebView?) {
    try {
        CookieManager.getInstance().removeAllCookies(null)
        CookieManager.getInstance().flush()
        WebStorage.getInstance().deleteAllData()
        web?.clearCache(true)
    } catch (e: Exception) {
        // nothing sensible to do; the next wipe will try again
    }
}

private fun startDownload(ctx: Context, ui: WebUi, url: String, userAgent: String?, contentDisposition: String?, mimetype: String?) {
    if (!url.startsWith("https://") && !url.startsWith("http://")) {
        ui.note = "can't download that kind of link."
        return
    }
    try {
        val name = URLUtil.guessFileName(url, contentDisposition, mimetype)
        val req = DownloadManager.Request(Uri.parse(url))
            .setTitle(name)
            .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
            .setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, name)
        if (!mimetype.isNullOrBlank()) req.setMimeType(mimetype)
        if (!userAgent.isNullOrBlank()) req.addRequestHeader("User-Agent", userAgent)
        CookieManager.getInstance().getCookie(url)?.let { req.addRequestHeader("Cookie", it) }
        (ctx.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager).enqueue(req)
        ui.note = "downloading $name to Downloads."
    } catch (e: Exception) {
        ui.note = "download failed: ${e.message ?: "unknown error"}"
    }
}

private fun shareUrl(ctx: Context, url: String, title: String) {
    val send = Intent(Intent.ACTION_SEND).apply {
        type = "text/plain"
        putExtra(Intent.EXTRA_TEXT, url)
        if (title.isNotBlank()) putExtra(Intent.EXTRA_SUBJECT, title)
    }
    try {
        ctx.startActivity(Intent.createChooser(send, "Share link").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    } catch (e: Exception) {
        // no share targets; nothing to do
    }
}

private fun openExternal(ctx: Context, url: String): Boolean = try {
    ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    true
} catch (e: Exception) {
    false
}
