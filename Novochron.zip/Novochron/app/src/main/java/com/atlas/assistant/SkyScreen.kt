package com.atlas.assistant

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.hardware.GeomagneticField
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.location.LocationManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableDoubleStateOf
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.math.tan

/** One thing you can see (or not) in the sky right now: a direction in local East/North/Up plus how to draw it. */
private class SkyObj(
    val name: String,
    val dir: DoubleArray,   // unit vector (East, North, Up)
    val kind: Int,          // 0 star, 1 planet, 2 sun, 3 moon
    val color: Color,
    val mag: Double,
    val note: String
)

/** Camera basis in local (East, North, Up) space: where "right", "up on the screen" and "forward" point. */
private class SkyBasis(val right: DoubleArray, val up: DoubleArray, val fwd: DoubleArray)

private val PLANET_MAG = mapOf(
    "Mercury" to 0.0, "Venus" to -4.0, "Mars" to 0.8, "Jupiter" to -2.2,
    "Saturn" to 0.6, "Uranus" to 5.7, "Neptune" to 7.8
)

private fun dot(a: DoubleArray, b: DoubleArray) = a[0] * b[0] + a[1] * b[1] + a[2] * b[2]

private fun project(b: SkyBasis, d: DoubleArray, focalPx: Double, cx: Double, cy: Double): Offset? {
    val fw = dot(d, b.fwd)
    if (fw <= 0.05) return null
    val x = dot(d, b.right) / fw
    val y = dot(d, b.up) / fw
    return Offset((cx + focalPx * x).toFloat(), (cy - focalPx * y).toFloat())
}

/** Basis for "looking toward [headingDeg] (0 = north, 90 = east) tilted up by [pitchDeg]". */
private fun manualBasis(headingDeg: Double, pitchDeg: Double): SkyBasis {
    val h = Math.toRadians(headingDeg)
    val p = Math.toRadians(pitchDeg)
    return SkyBasis(
        right = doubleArrayOf(cos(h), -sin(h), 0.0),
        up = doubleArrayOf(-sin(h) * sin(p), -cos(h) * sin(p), cos(p)),
        fwd = doubleArrayOf(sin(h) * cos(p), cos(h) * cos(p), sin(p))
    )
}

/**
 * Basis from the phone's rotation matrix ([r] is row-major, device -> world East/North/Up). The back
 * camera looks along the device's -Z axis; screen-right is device +X and screen-up is device +Y.
 * [declDeg] turns magnetic north into true north.
 */
private fun sensorBasis(r: FloatArray, declDeg: Double): SkyBasis {
    fun rot(e: Double, n: Double, u: Double): DoubleArray {
        val d = Math.toRadians(declDeg)
        return doubleArrayOf(e * cos(d) + n * sin(d), n * cos(d) - e * sin(d), u)
    }
    return SkyBasis(
        right = rot(r[0].toDouble(), r[3].toDouble(), r[6].toDouble()),
        up = rot(r[1].toDouble(), r[4].toDouble(), r[7].toDouble()),
        fwd = rot(-r[2].toDouble(), -r[5].toDouble(), -r[8].toDouble())
    )
}

private fun buildObjects(t: Double, lat: Double, lon: Double): List<SkyObj> {
    val lst = SkyMath.lstDeg(t, lon)
    val out = ArrayList<SkyObj>()
    SkyMath.STARS.forEach { s ->
        out.add(SkyObj(s.name, SkyMath.enu(s.raH * 15.0, s.decDeg, lst, lat), 0, Color.White, s.mag, "star, magnitude ${"%.1f".format(s.mag)}"))
    }
    val earth = OrbitMath.SOLAR_SYSTEM.first { it.name == "Earth" }
    val ep = OrbitMath.position(earth, t)
    val (sunRa, sunDec) = SkyMath.eclToEq(-ep.x, -ep.y, -ep.z)
    out.add(SkyObj("Sun", SkyMath.enu(sunRa, sunDec, lst, lat), 2, Color(0xFFFFD84A), -26.7, "the Sun — never look at it directly"))
    val sunLon = (Math.toDegrees(atan2(-ep.y, -ep.x)) + 360.0) % 360.0
    for (name in listOf("Mercury", "Venus", "Mars", "Jupiter", "Saturn", "Uranus", "Neptune")) {
        val b = OrbitMath.SOLAR_SYSTEM.first { it.name == name }
        val p = OrbitMath.position(b, t)
        val gx = p.x - ep.x; val gy = p.y - ep.y; val gz = p.z - ep.z
        val dist = sqrt(gx * gx + gy * gy + gz * gz)
        val (ra, dec) = SkyMath.eclToEq(gx, gy, gz)
        val mag = PLANET_MAG[name] ?: 5.0
        val note = "planet, ${"%.2f".format(dist)} AU from Earth" + if (mag > 5.0) " — needs binoculars or a telescope" else ""
        out.add(SkyObj(name, SkyMath.enu(ra, dec, lst, lat), 1, Color(b.color), mag, note))
    }
    val (mRa, mDec) = SkyMath.moonEquatorial(t)
    val lit = SkyMath.moonIllumination(t, sunLon)
    out.add(SkyObj("Moon", SkyMath.enu(mRa, mDec, lst, lat), 3, Color(0xFFE6E6E6), -10.0, "the Moon, ${(lit * 100).toInt()}% lit"))
    return out
}

@Composable
internal fun SkyTab() {
    val ctx = LocalContext.current

    // ---- observer
    var lat by remember { mutableDoubleStateOf(0.0) }
    var lon by remember { mutableDoubleStateOf(0.0) }
    var locNote by remember { mutableStateOf("no location yet — using 0°, 0°. Tap [use my location].") }
    fun readLocation() {
        val fine = ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        val coarse = ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
        if (!fine && !coarse) { locNote = "location permission not granted — using ${"%.1f".format(lat)}°, ${"%.1f".format(lon)}°."; return }
        try {
            val lm = ctx.getSystemService(Context.LOCATION_SERVICE) as LocationManager
            var best: android.location.Location? = null
            for (prov in listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER, LocationManager.PASSIVE_PROVIDER)) {
                val l = try { lm.getLastKnownLocation(prov) } catch (e: IllegalArgumentException) { null }
                if (l != null && (best == null || l.time > best.time)) best = l
            }
            val b = best
            if (b != null) {
                lat = b.latitude; lon = b.longitude
                locNote = "at ${"%.2f".format(lat)}°, ${"%.2f".format(lon)}° (last known location)"
            } else locNote = "no last-known location on this phone yet — open [map] once, then try again."
        } catch (e: SecurityException) {
            locNote = "location permission not granted."
        }
    }
    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { readLocation() }
    LaunchedEffect(Unit) { readLocation() }

    // ---- time
    var useSimTime by remember { mutableStateOf(false) }
    var hourShift by remember { mutableFloatStateOf(0f) }
    var clockTick by remember { mutableIntStateOf(0) }
    LaunchedEffect(Unit) { while (true) { delay(5000); clockTick++ } }
    val t: Double = (if (useSimTime) (LabState.simT ?: OrbitMath.todayDays().toFloat()).toDouble() else OrbitMath.todayDays()) + hourShift / 24.0

    // ---- look direction: phone sensor, or heading/tilt by hand
    val sm = remember { ctx.getSystemService(Context.SENSOR_SERVICE) as SensorManager }
    val hasSensor = remember { sm.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR) != null }
    var useSensor by remember { mutableStateOf(hasSensor) }
    var rot by remember { mutableStateOf<FloatArray?>(null) }
    var heading by remember { mutableFloatStateOf(180f) }
    var tilt by remember { mutableFloatStateOf(35f) }
    var fovDeg by remember { mutableFloatStateOf(65f) }
    var pick by remember { mutableStateOf("") }

    DisposableEffect(useSensor) {
        if (!useSensor || !hasSensor) return@DisposableEffect onDispose { }
        val sensor = sm.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR)
        val listener = object : SensorEventListener {
            private val m = FloatArray(9)
            override fun onSensorChanged(event: SensorEvent) {
                SensorManager.getRotationMatrixFromVector(m, event.values)
                val prev = rot
                rot = if (prev == null) m.copyOf() else FloatArray(9) { i -> prev[i] + 0.4f * (m[i] - prev[i]) }
            }
            override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
        }
        sm.registerListener(listener, sensor, SensorManager.SENSOR_DELAY_GAME)
        onDispose { sm.unregisterListener(listener) }
    }

    val declination = remember(lat, lon) {
        try { GeomagneticField(lat.toFloat(), lon.toFloat(), 0f, System.currentTimeMillis()).declination.toDouble() } catch (e: Exception) { 0.0 }
    }
    val rotNow = rot
    val basis: SkyBasis = if (useSensor && rotNow != null) sensorBasis(rotNow, declination) else manualBasis(heading.toDouble(), tilt.toDouble())

    @Suppress("UNUSED_VARIABLE") val tickRead = clockTick
    val tq = Math.floor(t * 1440.0) / 1440.0 // whole minutes, so the object list isn't rebuilt on every frame
    val objects = remember(tq, lat, lon) { buildObjects(tq, lat, lon) }
    val lst = SkyMath.lstDeg(tq, lon)
    val basisNow = androidx.compose.runtime.rememberUpdatedState(basis)
    val objectsNow = androidx.compose.runtime.rememberUpdatedState(objects)
    val fovNow = androidx.compose.runtime.rememberUpdatedState(fovDeg)
    val byName = remember(objects) { objects.associateBy { it.name } }

    val screenH = LocalConfiguration.current.screenHeightDp
    val canvasH = (screenH * 0.52f).coerceIn(260f, 470f).dp

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        Box(
            Modifier
                .fillMaxWidth()
                .height(canvasH)
                .border(1.dp, Line)
                .pointerInput(useSensor) {
                    detectTransformGestures { _, pan, zoom, _ ->
                        fovDeg = (fovDeg / zoom).coerceIn(15f, 110f)
                        if (!useSensor || !hasSensor) {
                            val degPerPx = fovDeg / size.width
                            heading = (((heading - pan.x * degPerPx) % 360f) + 360f) % 360f
                            tilt = (tilt + pan.y * degPerPx).coerceIn(-20f, 90f)
                        }
                    }
                }
                .pointerInput(Unit) {
                    detectTapGestures { tap ->
                        val w = size.width.toDouble(); val h = size.height.toDouble()
                        val focal = (w / 2.0) / tan(Math.toRadians(fovNow.value / 2.0))
                        var best: SkyObj? = null
                        var bestD = 48f
                        objectsNow.value.forEach { o ->
                            val p = project(basisNow.value, o.dir, focal, w / 2, h / 2) ?: return@forEach
                            val d = sqrt((p.x - tap.x) * (p.x - tap.x) + (p.y - tap.y) * (p.y - tap.y))
                            if (d < bestD) { bestD = d; best = o }
                        }
                        val b = best
                        pick = if (b == null) "" else {
                            val alt = SkyMath.altDeg(b.dir)
                            "${b.name} — ${b.note}. Altitude ${alt.toInt()}°, azimuth ${SkyMath.azDeg(b.dir).toInt()}°" +
                                if (alt < 0) " (below the horizon)" else ""
                        }
                    }
                }
        ) {
            SkyCanvas(objects, byName, basis, fovDeg, lst, lat, clockTick, rotNow?.let { it[0] } ?: 0f, heading, tilt)
        }

        // readout: what the view centre points at
        val cAlt = Math.toDegrees(kotlin.math.asin(basis.fwd[2].coerceIn(-1.0, 1.0)))
        val cAz = (Math.toDegrees(atan2(basis.fwd[0], basis.fwd[1])) + 360.0) % 360.0
        Text(
            "facing ${cAz.toInt()}° ${compass(cAz)}, ${cAlt.toInt()}° up  ·  fov ${fovDeg.toInt()}°  ·  ${OrbitMath.dateFromDays(tq)}",
            color = Dim, fontFamily = TermFont, fontSize = 11.sp
        )
        if (pick.isNotBlank()) Text(pick, color = Accent, fontFamily = TermFont, fontSize = 12.sp)

        val up = objects.filter { it.kind != 0 && it.name != "Sun" && SkyMath.altDeg(it.dir) > 0 && (PLANET_MAG[it.name] ?: 0.0) < 6.0 }
            .sortedByDescending { SkyMath.altDeg(it.dir) }
        Text(
            if (up.isEmpty()) "Nothing bright above the horizon right now."
            else "Above the horizon: " + up.joinToString(", ") { "${it.name} ${SkyMath.altDeg(it.dir).toInt()}°" },
            color = Ink, fontFamily = TermFont, fontSize = 12.sp
        )
        Spacer(Modifier.height(6.dp))

        // ---- controls
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("look", color = Dim, fontFamily = TermFont, fontSize = 11.sp)
            if (hasSensor) {
                TermTextKey("Sensor", tone = if (useSensor) Accent else Ink, bold = useSensor, onClick = { useSensor = true })
                TermTextKey("Manual", tone = if (!useSensor) Accent else Ink, bold = !useSensor, onClick = { useSensor = false })
            } else Text("  no rotation sensor — drag to look around", color = Dim, fontFamily = TermFont, fontSize = 11.sp)
        }
        if (!useSensor || !hasSensor) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("heading", color = Dim, fontFamily = TermFont, fontSize = 11.sp)
                Slider(
                    value = heading, onValueChange = { heading = it }, valueRange = 0f..360f,
                    colors = SliderDefaults.colors(thumbColor = Accent, activeTrackColor = Accent, inactiveTrackColor = Line),
                    modifier = Modifier.weight(1f).padding(horizontal = 8.dp)
                )
                Text("${heading.toInt()}°", color = Ink, fontFamily = TermFont, fontSize = 11.sp)
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("tilt", color = Dim, fontFamily = TermFont, fontSize = 11.sp)
                Spacer(Modifier.width(20.dp))
                Slider(
                    value = tilt, onValueChange = { tilt = it }, valueRange = -20f..90f,
                    colors = SliderDefaults.colors(thumbColor = Accent, activeTrackColor = Accent, inactiveTrackColor = Line),
                    modifier = Modifier.weight(1f).padding(horizontal = 8.dp)
                )
                Text("${tilt.toInt()}°", color = Ink, fontFamily = TermFont, fontSize = 11.sp)
            }
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("time", color = Dim, fontFamily = TermFont, fontSize = 11.sp)
            TermTextKey("Now", tone = if (!useSimTime) Accent else Ink, bold = !useSimTime, onClick = { useSimTime = false })
            TermTextKey("Sim date", tone = if (useSimTime) Accent else Ink, bold = useSimTime, onClick = { useSimTime = true })
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("shift", color = Dim, fontFamily = TermFont, fontSize = 11.sp)
            Slider(
                value = hourShift, onValueChange = { hourShift = it }, valueRange = -12f..12f,
                colors = SliderDefaults.colors(thumbColor = Accent, activeTrackColor = Accent, inactiveTrackColor = Line),
                modifier = Modifier.weight(1f).padding(horizontal = 8.dp)
            )
            Text("${if (hourShift >= 0) "+" else ""}${"%.1f".format(hourShift)}h", color = Ink, fontFamily = TermFont, fontSize = 11.sp)
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            TermTextKey("[use my location]", tone = Accent, onClick = {
                permLauncher.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION))
            })
            TermTextKey("[N]", onClick = { heading = 0f })
            TermTextKey("[S]", onClick = { heading = 180f })
            TermTextKey("[zenith]", onClick = { tilt = 90f })
        }
        Text(locNote, color = Dim, fontFamily = TermFont, fontSize = 10.sp)
        Text(
            "Positions are computed from real orbital elements for your date and place (planets to a fraction of a degree, Moon to about half a degree). " +
                "Tap an object to identify it. Pinch to zoom.",
            color = Dim, fontFamily = TermFont, fontSize = 10.sp
        )
        Spacer(Modifier.height(24.dp))
    }
}

private fun compass(az: Double): String {
    val names = listOf("N", "NE", "E", "SE", "S", "SW", "W", "NW")
    return names[(((az + 22.5) / 45.0).toInt()) % 8]
}

private val skyPaint = android.graphics.Paint().apply { isAntiAlias = true; textSize = 26f }

@Composable
private fun SkyCanvas(
    objects: List<SkyObj>,
    byName: Map<String, SkyObj>,
    basis: SkyBasis,
    fovDeg: Float,
    lst: Double,
    lat: Double,
    clockTick: Int,
    sensorTick: Float,
    heading: Float,
    tilt: Float
) {
    Canvas(Modifier.fillMaxSize()) {
        @Suppress("UNUSED_VARIABLE") val reads = clockTick + sensorTick + heading + tilt
        val w = size.width.toDouble(); val h = size.height.toDouble()
        val cx = w / 2; val cy = h / 2
        val focal = cx / tan(Math.toRadians(fovDeg / 2.0))

        drawRect(Color(0xFF02030A))

        // Milky Way: the galactic plane as a chain of soft glows, brightest toward the Galactic Centre
        SkyMath.GALACTIC_BAND.forEach { bp ->
            val v = SkyMath.enu(bp.raDeg, bp.decDeg, lst, lat)
            val p = project(basis, v, focal, cx, cy) ?: return@forEach
            if (p.x < -200f || p.x > w + 200f || p.y < -200f || p.y > h + 200f) return@forEach
            val alt = SkyMath.altDeg(v)
            val a = (0.055f + 0.10f * bp.weight.toFloat()) * (if (alt < 0) 0.35f else 1f)
            drawGlow(p, (focal * 0.16).toFloat(), Color(0xFFB8B4D8), a)
        }

        // faint background stars
        SkyMath.FAINT.forEach { s ->
            val p = project(basis, SkyMath.enu(s.raDeg, s.decDeg, lst, lat), focal, cx, cy) ?: return@forEach
            if (p.x < 0f || p.x > w || p.y < 0f || p.y > h) return@forEach
            drawCircle(Color.White.copy(alpha = (0.55f - (s.mag.toFloat() - 3.6f) * 0.18f).coerceIn(0.12f, 0.55f)), radius = 0.9f, center = p)
        }

        // horizon
        var prev: Offset? = null
        for (i in 0..120) {
            val az = Math.toRadians(i * 3.0)
            val p = project(basis, doubleArrayOf(sin(az), cos(az), 0.0), focal, cx, cy)
            if (p != null && prev != null && abs(p.x - prev.x) < w && abs(p.y - prev.y) < h) {
                drawLine(Color(0xAA3DFF5C), prev, p, strokeWidth = 2f)
            }
            prev = p
        }
        for ((label, azd) in listOf("N" to 0.0, "E" to 90.0, "S" to 180.0, "W" to 270.0)) {
            val az = Math.toRadians(azd)
            val p = project(basis, doubleArrayOf(sin(az), cos(az), 0.0), focal, cx, cy) ?: continue
            skyPaint.color = android.graphics.Color.argb(230, 61, 255, 92)
            skyPaint.textSize = 34f
            drawContext.canvas.nativeCanvas.drawText(label, p.x - 10f, p.y - 10f, skyPaint)
        }

        // constellation lines
        SkyMath.LINES.forEach { (a, b) ->
            val oa = byName[a]?.dir ?: return@forEach
            val ob = byName[b]?.dir ?: return@forEach
            val pa = project(basis, oa, focal, cx, cy) ?: return@forEach
            val pb = project(basis, ob, focal, cx, cy) ?: return@forEach
            if (abs(pa.x - pb.x) > w || abs(pa.y - pb.y) > h) return@forEach
            drawLine(Color(0x555CC8FF), pa, pb, strokeWidth = 1.2f)
        }

        // stars, planets, Sun, Moon
        skyPaint.textSize = 24f
        objects.forEach { o ->
            val p = project(basis, o.dir, focal, cx, cy) ?: return@forEach
            if (p.x < -40f || p.x > w + 40f || p.y < -40f || p.y > h + 40f) return@forEach
            val below = SkyMath.altDeg(o.dir) < 0
            val fade = if (below) 0.35f else 1f
            when (o.kind) {
                2 -> { // Sun
                    drawGlow(p, 70f, o.color, fade)
                    drawCircle(Color(0xFFFFF2B0).copy(alpha = fade), radius = 11f, center = p)
                }
                3 -> { // Moon
                    drawGlow(p, 44f, Color(0xFFDDE4FF), 0.35f * fade)
                    drawCircle(o.color.copy(alpha = 0.92f * fade), radius = 12f, center = p)
                }
                1 -> { // planets
                    val r = (2.6 + (1.5 - o.mag) * 0.9).coerceIn(1.6, 7.5).toFloat()
                    drawGlow(p, r * 4f, o.color, 0.5f * fade)
                    drawCircle(o.color.copy(alpha = fade), radius = r, center = p)
                }
                else -> {
                    val r = (1.2 + (2.6 - o.mag) * 0.75).coerceIn(1.1, 5.0).toFloat()
                    drawCircle(Color.White.copy(alpha = fade), radius = r, center = p)
                }
            }
            val named = o.kind != 0 || o.mag < 1.3
            if (named && !(o.kind == 1 && o.mag > 5.0 && fovDeg > 50f)) {
                skyPaint.color = android.graphics.Color.argb((210 * fade).toInt(), 232, 232, 232)
                drawContext.canvas.nativeCanvas.drawText(o.name, p.x + 12f, p.y - 8f, skyPaint)
            }
        }

        // centre crosshair
        drawCircle(Color(0x663DFF5C), radius = 14f, center = Offset(cx.toFloat(), cy.toFloat()), style = Stroke(width = 1.2f))
    }
}
