package com.atlas.assistant

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

/**
 * One-shot downloader for the offline model offered on first setup (see [SetupWizard]). Fetches a
 * MediaPipe ".task" build of Gemma 3 1B IT straight into [NovochronStorage.modelsDir], the same
 * folder [LocalLlm] already scans - so once this finishes, offline chat "just works" with nothing
 * else to configure.
 *
 * Google's official Gemma builds are gated behind an HF account that has accepted the Gemma license,
 * even for a plain HTTP download - [accessToken] is [BuildConfig.HF_TOKEN], baked in at build time
 * exactly like [Store.githubToken]'s GITHUB_PAT default (see app/build.gradle.kts), so the person
 * using the app never has to paste in a token themselves.
 */
object ModelDownloader {

    /** Google's official Gemma-3-1B-IT MediaPipe build. Gated: requires an HF account that has
     *  accepted the Gemma license, hence [BuildConfig.HF_TOKEN] below. */
    const val MODEL_URL = "https://huggingface.co/litert-community/Gemma3-1B-IT/resolve/main/gemma3-1b-it-int4.task"
    const val MODEL_FILE_NAME = "gemma-3-1b-it.task"

    /** Baked in at build time (see app/build.gradle.kts > "Hugging Face access token"). Blank in a
     *  build where no HF_TOKEN was set - [download] fails fast with a clear message in that case
     *  rather than silently trying an unauthenticated request that HF will just 401/403. */
    private val accessToken: String get() = BuildConfig.HF_TOKEN

    sealed class Progress {
        data class InProgress(val bytesDone: Long, val bytesTotal: Long) : Progress()
        data class Done(val file: File) : Progress()
        data class Failed(val message: String) : Progress()
    }

    /**
     * Streams the model into [NovochronStorage.modelsDir]/[MODEL_FILE_NAME], reporting progress via
     * [onProgress] as it goes. Downloads to a ".part" file first and only renames to the final name on
     * a clean finish, so a killed app or a dropped connection never leaves [LocalLlm] mistaking a
     * half-written file for a real model (LocalLlm's own MIN_BYTES check is a second line of defense,
     * but a stray "model.task.part" is never even considered).
     */
    suspend fun download(onProgress: (Progress) -> Unit) = withContext(Dispatchers.IO) {
        if (accessToken.isBlank()) {
            onProgress(Progress.Failed(
                "No Hugging Face token baked into this build - see README > Offline model setup, " +
                    "or drop a .task file into Novochron/Models/ yourself."
            ))
            return@withContext
        }
        val dir = NovochronStorage.modelsDir()
        dir.mkdirs()
        val dest = File(dir, MODEL_FILE_NAME)
        val partial = File(dir, "$MODEL_FILE_NAME.part")
        var conn: HttpURLConnection? = null
        try {
            conn = (URL(MODEL_URL).openConnection() as HttpURLConnection).apply {
                connectTimeout = 20_000
                readTimeout = 30_000
                requestMethod = "GET"
                if (accessToken.isNotBlank()) setRequestProperty("Authorization", "Bearer $accessToken")
                instanceFollowRedirects = true
            }
            val code = conn.responseCode
            if (code !in 200..299) {
                onProgress(Progress.Failed(describeHttpError(code)))
                return@withContext
            }
            val total = conn.contentLengthLong // -1 if the server doesn't send it; UI just shows bytes-so-far then
            var done = 0L
            conn.inputStream.use { input ->
                partial.outputStream().use { output ->
                    val buf = ByteArray(64 * 1024)
                    while (true) {
                        val n = input.read(buf)
                        if (n < 0) break
                        output.write(buf, 0, n)
                        done += n
                        onProgress(Progress.InProgress(done, total))
                    }
                }
            }
            if (!partial.renameTo(dest)) {
                // rename can fail across some FS boundaries - fall back to a copy+delete
                partial.copyTo(dest, overwrite = true)
                partial.delete()
            }
            onProgress(Progress.Done(dest))
        } catch (e: Exception) {
            partial.delete()
            onProgress(Progress.Failed(e.message ?: e.javaClass.simpleName))
        } finally {
            conn?.disconnect()
        }
    }

    private fun describeHttpError(code: Int): String = when (code) {
        401, 403 -> "Hugging Face rejected this build's token (HTTP $code) - it may be missing, revoked, or " +
            "the Gemma license hasn't been accepted by the account it belongs to."
        404 -> "Model not found at the configured URL (HTTP 404)."
        else -> "Download failed (HTTP $code)."
    }
}
