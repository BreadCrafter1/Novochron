package com.atlas.assistant

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlin.math.atan2
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/** One body in the sandbox: SI-ish units scaled so numbers stay friendly (see [NBodySim.G]). */
private class NBody(
    var x: Double, var y: Double, var vx: Double, var vy: Double,
    val mass: Double, val radiusPx: Float, val color: Color, val name: String, val fixed: Boolean = false
) {
    val trail = ArrayDeque<Offset>()
}

/** Simple pairwise-gravity integrator (leapfrog / velocity-Verlet, softened so close passes don't blow up). */
private object NBodySim {
    const val G = 3200.0        // tuned constant, not SI — chosen so a "Small" body makes a sensible orbit on a phone screen
    const val SOFTEN2 = 14.0 * 14.0

    fun accel(bodies: List<NBody>, of: NBody): Pair<Double, Double> {
        var ax = 0.0; var ay = 0.0
        bodies.forEach { other ->
            if (other === of) return@forEach
            val dx = other.x - of.x; val dy = other.y - of.y
            val d2 = dx * dx + dy * dy + SOFTEN2
            val d = sqrt(d2)
            val f = G * other.mass / (d2 * d)
            ax += f * dx; ay += f * dy
        }
        return ax to ay
    }

    fun step(bodies: List<NBody>, dt: Double) {
        val acc = bodies.map { if (it.fixed) 0.0 to 0.0 else accel(bodies, it) }
        bodies.forEachIndexed { i, b ->
            if (b.fixed) return@forEachIndexed
            b.vx += acc[i].first * dt * 0.5
            b.vy += acc[i].second * dt * 0.5
            b.x += b.vx * dt
            b.y += b.vy * dt
        }
        val acc2 = bodies.map { if (it.fixed) 0.0 to 0.0 else accel(bodies, it) }
        bodies.forEachIndexed { i, b ->
            if (b.fixed) return@forEachIndexed
            b.vx += acc2[i].first * dt * 0.5
            b.vy += acc2[i].second * dt * 0.5
        }
    }
}

private enum class DropKind(val label: String, val mass: Double, val radius: Float, val color: Color) {
    SMALL("Small", 4.0, 4f, Color(0xFF9E9E9E)),
    JUPITER("Jupiter", 300.0, 11f, Color(0xFFE0B27A)),
    STAR("Star", 3000.0, 16f, Color(0xFFFFD84A))
}

/**
 * `[nbody]`: tap to drop a body, drag to set its launch velocity, watch real pairwise gravity (not
 * pre-baked Keplerian orbits) act on everything at once — bodies can capture each other, sling past,
 * collide, or fly out of frame. Center starts with one fixed "star" so a first tap gives an orbit.
 */
@Composable
internal fun NBodyTab() {
    val ctx = LocalContext.current
    val bodies = remember { mutableStateListOf<NBody>() }
    var drop by remember { mutableStateOf(DropKind.SMALL) }
    var speedMult by remember { mutableFloatStateOf(1f) }
    var running by remember { mutableStateOf(true) }
    var dragStart by remember { mutableStateOf<Offset?>(null) }
    var dragNow by remember { mutableStateOf<Offset?>(null) }
    var canvasSize by remember { mutableStateOf(Offset(1f, 1f)) }
    var texReady by remember { mutableStateOf(false) }
    var collideNote by remember { mutableStateOf("") }
    LaunchedEffect(Unit) { withContext(Dispatchers.Default) { Textures.preload(ctx) }; texReady = true }

    fun reset() {
        bodies.clear()
        val cx = canvasSize.x / 2; val cy = canvasSize.y / 2
        bodies.add(NBody(cx.toDouble(), cy.toDouble(), 0.0, 0.0, 4000.0, 16f, Color(0xFFFFD84A), "Star", fixed = true))
    }
    LaunchedEffect(canvasSize) { if (bodies.isEmpty()) reset() }

    LaunchedEffect(running, speedMult) {
        while (running) {
            delay(16)
            val steps = max(1, (speedMult * 3).toInt())
            repeat(steps) { NBodySim.step(bodies, 0.6) }
            bodies.forEach { b ->
                b.trail.addLast(Offset(b.x.toFloat(), b.y.toFloat()))
                if (b.trail.size > 260) b.trail.removeFirst()
            }
            // drop anything that wandered far off-canvas so old flings don't pile up forever
            val margin = 400f
            bodies.removeAll { !it.fixed && (it.x < -margin || it.y < -margin || it.x > canvasSize.x + margin || it.y > canvasSize.y + margin) }
            // merge collisions (distance under the sum of radii): heavier absorbs lighter, momentum conserved
            var i = 0
            while (i < bodies.size) {
                var j = i + 1
                var merged = false
                while (j < bodies.size) {
                    val a = bodies[i]; val b = bodies[j]
                    val d = hypot(a.x - b.x, a.y - b.y)
                    if (d < (a.radiusPx + b.radiusPx) * 0.65) {
                        val heavy = if (a.mass >= b.mass) a else b
                        val light = if (a.mass >= b.mass) b else a
                        if (!heavy.fixed) {
                            val totalM = heavy.mass + light.mass
                            heavy.vx = (heavy.vx * heavy.mass + light.vx * light.mass) / totalM
                            heavy.vy = (heavy.vy * heavy.mass + light.vy * light.mass) / totalM
                        }
                        bodies.remove(light)
                        collideNote = "${light.name} merged into ${heavy.name}."
                        merged = true
                        break
                    }
                    j++
                }
                if (!merged) i++
            }
        }
    }

    val screenH = LocalConfiguration.current.screenHeightDp
    val canvasH = (screenH * 0.5f).coerceIn(260f, 460f).dp

    Column(Modifier.fillMaxSize()) {
        Text("${bodies.size} bodies", color = Dim, fontFamily = TermFont, fontSize = 11.sp)
        Box(
            Modifier
                .fillMaxWidth()
                .height(canvasH)
                .border(1.dp, Line)
                .onGloballyPositioned { coords -> canvasSize = Offset(coords.size.width.toFloat(), coords.size.height.toFloat()) }
                .pointerInput(drop) {
                    awaitEachGesture {
                        val down = awaitFirstDown()
                        val start = down.position
                        dragStart = start; dragNow = start
                        var end = start
                        while (true) {
                            val event = awaitPointerEvent()
                            val change = event.changes.firstOrNull { it.id == down.id } ?: break
                            if (!change.pressed) { end = change.position; break }
                            end = change.position
                            dragNow = end
                            change.consume()
                        }
                        val vx = (start.x - end.x) * 0.05
                        val vy = (start.y - end.y) * 0.05
                        bodies.add(
                            NBody(
                                start.x.toDouble(), start.y.toDouble(), vx, vy,
                                drop.mass, drop.radius, drop.color,
                                "${drop.label} ${bodies.size}"
                            )
                        )
                        dragStart = null; dragNow = null
                    }
                }
        ) {
            NBodyCanvas(ctx, bodies, dragStart, dragNow, texReady)
        }
        Row(Modifier.horizontalScroll(rememberScrollState()), verticalAlignment = Alignment.CenterVertically) {
            Text("drop", color = Dim, fontFamily = TermFont, fontSize = 11.sp)
            DropKind.values().forEach { k ->
                TermTextKey(k.label, tone = if (k == drop) Accent else Ink, bold = k == drop, onClick = { drop = k })
            }
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("speed", color = Dim, fontFamily = TermFont, fontSize = 11.sp)
            Slider(
                value = speedMult, onValueChange = { speedMult = it }, valueRange = 0f..3f,
                colors = SliderDefaults.colors(thumbColor = Accent, activeTrackColor = Accent, inactiveTrackColor = Line),
                modifier = Modifier.weight(1f).padding(horizontal = 8.dp)
            )
            Text("x${"%.2f".format(speedMult)}", color = Ink, fontFamily = TermFont, fontSize = 11.sp)
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            TermTextKey(if (running) "Pause" else "Play", onClick = { running = !running })
            TermTextKey("Clear", onClick = { bodies.removeAll { !it.fixed } })
            TermTextKey("Reset", onClick = { reset(); collideNote = "" })
        }
        Text(
            "tap the canvas and drag before releasing to launch a body — the pull-back sets its speed and direction",
            color = Dim, fontFamily = TermFont, fontSize = 10.sp
        )
        if (collideNote.isNotBlank()) Text(collideNote, color = Accent, fontFamily = TermFont, fontSize = 11.sp)
    }
}

@Composable
private fun NBodyCanvas(
    ctx: android.content.Context,
    bodies: List<NBody>,
    dragStart: Offset?,
    dragNow: Offset?,
    texReady: Boolean
) {
    Canvas(Modifier.fillMaxSize()) {
        @Suppress("UNUSED_VARIABLE") val ready = texReady
        drawRect(Color(0xFF04050C))
        // faint fixed starfield dots (no parallax needed here — it's a sandbox, not a real sky)
        val rnd = kotlin.random.Random(7)
        repeat(140) {
            drawCircle(Color.White.copy(alpha = 0.12f + rnd.nextFloat() * 0.2f), radius = 0.8f, center = Offset(rnd.nextFloat() * size.width, rnd.nextFloat() * size.height))
        }

        bodies.forEach { b ->
            if (b.trail.size > 1) {
                var prev: Offset? = null
                b.trail.forEachIndexed { i, p ->
                    if (prev != null) drawLine(b.color.copy(alpha = 0.06f + 0.3f * i / b.trail.size), prev!!, p, strokeWidth = 1.5f)
                    prev = p
                }
            }
        }
        bodies.forEach { b ->
            val center = Offset(b.x.toFloat(), b.y.toFloat())
            if (b.name == "Star" || b.mass > 1500) drawGlow(center, b.radiusPx * 3.5f, Color(0xFFFFD84A), 0.7f)
            drawCircle(b.color, radius = b.radiusPx, center = center)
            drawCircle(Color.Black.copy(alpha = 0.5f), radius = b.radiusPx, center = center, style = Stroke(width = 1f))
        }

        if (dragStart != null && dragNow != null) {
            drawLine(Color(0xFF3DFF5C), dragStart, dragNow, strokeWidth = 2f)
            val dx = dragStart.x - dragNow.x; val dy = dragStart.y - dragNow.y
            val speed = hypot(dx, dy)
            if (speed > 4f) {
                val ang = atan2(dy, dx)
                val tip = Offset(dragStart.x + kotlin.math.cos(ang) * min(speed, 160f), dragStart.y + kotlin.math.sin(ang) * min(speed, 160f))
                drawCircle(Color(0xFF3DFF5C), radius = 3f, center = tip)
            }
        }
    }
}
