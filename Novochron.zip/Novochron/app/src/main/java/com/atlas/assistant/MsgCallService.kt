package com.atlas.assistant

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder

/**
 * Foreground-service "slot" kept alive for the whole duration of a msg [call]/[video call].
 *
 * Ported from N's CallService (see N/app/src/main/java/com/novochron/n/CallService.kt) - Novochron
 * never had an equivalent, so a call's mic (and camera, for video calls) were only ever kept alive
 * by the Activity being visible, with nothing telling Android this process is doing real-time
 * call work. Without this, Android can mute mic/camera input or deprioritize/kill the process once
 * it decides the app isn't doing anything "foreground-service-worthy" - and, worse for the bug this
 * was added to fix, can starve a *newly started* encode pipeline (like a screenshare added mid-call)
 * of CPU/scheduling priority even while the Activity is visible, especially on OEM battery
 * managers. Screen sharing during an already-running video call rides along on video priority that
 * was already granted at call start; screen sharing during an audio-only call is the first video
 * work in that call, with nothing marking it as important - exactly the "[video call] shows the
 * share, [call] doesn't" split reported. CallManager starts this right before opening the mic (in
 * startCall/accept) and stops it in endLocally()/dispose() - it does no work of its own beyond
 * satisfying that OS requirement and showing the (mandatory) "call in progress" notification.
 */
class MsgCallService : Service() {
    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val video = intent?.getBooleanExtra("video", false) == true
        val channelId = "msg_call"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = getSystemService(NotificationManager::class.java)
            nm?.createNotificationChannel(
                NotificationChannel(channelId, "Calls", NotificationManager.IMPORTANCE_LOW)
            )
        }
        val openApp = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val notification = Notification.Builder(this, channelId)
            .setContentTitle("Novochron")
            .setContentText(if (video) "Video call in progress" else "Call in progress")
            .setSmallIcon(android.R.drawable.presence_audio_online)
            .setContentIntent(openApp)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val type = if (video) {
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE or ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA
            } else {
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
            }
            startForeground(2001, notification, type)
        } else {
            @Suppress("DEPRECATION")
            startForeground(2001, notification)
        }
        return START_NOT_STICKY
    }
}
