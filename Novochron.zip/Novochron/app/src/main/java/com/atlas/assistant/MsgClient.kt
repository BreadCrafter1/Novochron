package com.atlas.assistant

import android.util.Base64
import android.util.Base64OutputStream
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.ConcurrentHashMap

data class MsgFile(val path: String, val isDir: Boolean, val sha: String = "")

private const val MSG_JSON_ACCEPT = "application/vnd.github+json"
// Raw media type: the response body IS the file (no JSON/base64 wrapper), and it works for files
// up to 100 MB - the default JSON response can't carry anything over 1 MB.
private const val MSG_RAW_ACCEPT = "application/vnd.github.raw+json"

/**
 * GitHub client used ONLY by the msg screen (MsgScreen.kt), so the faster paths below don't change how
 * the vault, terminal or share-link features talk to GitHub (they keep using GitHub.kt untouched).
 * It reads the same token and branch the rest of the app stores, live, on every request.
 *
 * Speed notes:
 *  - Folder listings use ETags. When nothing changed GitHub answers "304 Not Modified" with no body
 *    (and 304s don't count against the API rate limit), so polling is cheap enough to do every second.
 *  - Files are read with the raw media type (no base64 decode, no 1 MB cap) and media is streamed to
 *    disk instead of held in memory.
 *  - Uploads are streamed from disk (base64-encoded on the fly) so even very large files don't need
 *    to fit in RAM, and new files skip the "does it already exist?" lookup.
 *  - Writes are retried on 409 conflicts (two commits racing for the same branch).
 */
class MsgClient(private val tokenProvider: () -> String, private val branchProvider: () -> String) {

    private class CachedListing(val etag: String, val files: List<MsgFile>)
    private val listingCache = ConcurrentHashMap<String, CachedListing>()

    private class Response(val code: Int, val body: String, val etag: String?)

    suspend fun listFiles(path: String, repo: RepoRef): List<MsgFile> = withContext(Dispatchers.IO) {
        val url = contentsUrl(path, repo)
        val cached = listingCache[url]
        val res = try {
            request("GET", url, MSG_JSON_ACCEPT, etag = cached?.etag)
        } catch (e: GitHubApiException) {
            if (e.code == 404) { listingCache.remove(url); return@withContext emptyList() } else throw e
        }
        if (res.code == 304 && cached != null) return@withContext cached.files

        val body = res.body
        val files = if (body.trimStart().startsWith("[")) {
            val arr = JSONArray(body)
            (0 until arr.length()).map {
                val o = arr.getJSONObject(it)
                MsgFile(o.getString("path"), o.getString("type") == "dir", o.optString("sha", ""))
            }
        } else {
            val o = JSONObject(body)
            listOf(MsgFile(o.getString("path"), false, o.optString("sha", "")))
        }
        res.etag?.let { listingCache[url] = CachedListing(it, files) }
        files
    }

    /** Decoded text content, or null if the file doesn't exist. */
    suspend fun readFile(path: String, repo: RepoRef): String? = withContext(Dispatchers.IO) {
        try {
            request("GET", contentsUrl(path, repo), MSG_RAW_ACCEPT).body
        } catch (e: GitHubApiException) {
            if (e.code == 404) null else throw e
        }
    }

    /** Streams a file (photo/video/voice, up to 100 MB) straight to [dest]. False if it doesn't exist. */
    suspend fun downloadFile(path: String, repo: RepoRef, dest: File): Boolean = withContext(Dispatchers.IO) {
        val conn = open("GET", contentsUrl(path, repo), MSG_RAW_ACCEPT)
        conn.readTimeout = 60_000
        val code = conn.responseCode
        if (code == 404) { readBody(conn, code); return@withContext false }
        if (code !in 200..299) throw GitHubApiException(code, readBody(conn, code))
        dest.parentFile?.mkdirs()
        val tmp = File(dest.path + ".part")
        try {
            conn.inputStream.use { input -> tmp.outputStream().use { out -> input.copyTo(out, 64 * 1024) } }
            if (!tmp.renameTo(dest)) { tmp.copyTo(dest, overwrite = true); tmp.delete() }
        } catch (e: Exception) {
            tmp.delete(); throw e
        }
        true
    }

    /** Creates a new small text file (message JSON). Path must not already exist. */
    suspend fun commitFile(path: String, content: String, message: String, repo: RepoRef): Unit =
        withContext(Dispatchers.IO) {
            val body = JSONObject().apply {
                put("message", message)
                put("content", Base64.encodeToString(content.toByteArray(Charsets.UTF_8), Base64.NO_WRAP))
                put("branch", branchProvider())
            }
            retryOnConflict { request("PUT", contentsUrl(path, repo, withRef = false), MSG_JSON_ACCEPT, body = body) }
            Unit
        }

    /**
     * Creates or overwrites a small text file (looks up the current sha first, so it works either
     * way). Used for call signaling (Call/offer.json, answer.json, hangup.json), where the same
     * path gets reused call after call, unlike ordinary messages which always get a fresh path.
     */
    suspend fun writeFile(path: String, content: String, message: String, repo: RepoRef): Unit =
        withContext(Dispatchers.IO) {
            retryOnConflict {
                val sha = try {
                    JSONObject(request("GET", contentsUrl(path, repo), MSG_JSON_ACCEPT).body).optString("sha", "")
                } catch (e: GitHubApiException) {
                    if (e.code == 404) "" else throw e
                }
                val body = JSONObject().apply {
                    put("message", message)
                    put("content", Base64.encodeToString(content.toByteArray(Charsets.UTF_8), Base64.NO_WRAP))
                    put("branch", branchProvider())
                    if (sha.isNotEmpty()) put("sha", sha)
                }
                request("PUT", contentsUrl(path, repo, withRef = false), MSG_JSON_ACCEPT, body = body)
            }
            Unit
        }

    /**
     * Creates a new file from [source], streaming it from disk and base64-encoding on the fly, so the
     * whole file (and its ~33% larger base64 form) never sits in memory. [onProgress] gets 0..100.
     */
    suspend fun commitFileStream(
        path: String, source: File, message: String, repo: RepoRef, onProgress: ((Int) -> Unit)? = null
    ): Unit = withContext(Dispatchers.IO) {
        retryOnConflict { uploadOnce(path, source, message, repo, onProgress) }
    }

    private fun uploadOnce(path: String, source: File, message: String, repo: RepoRef, onProgress: ((Int) -> Unit)?) {
        val prefix = ("{\"message\":" + JSONObject.quote(message) + ",\"branch\":" + JSONObject.quote(branchProvider()) + ",\"content\":\"")
            .toByteArray(Charsets.UTF_8)
        val suffix = "\"}".toByteArray(Charsets.UTF_8)
        val len = source.length()
        val total = prefix.size + ((len + 2) / 3) * 4 + suffix.size   // exact size of the base64 body

        val conn = open("PUT", contentsUrl(path, repo, withRef = false), MSG_JSON_ACCEPT)
        conn.readTimeout = 180_000
        conn.doOutput = true
        conn.setRequestProperty("Content-Type", "application/json")
        conn.setFixedLengthStreamingMode(total)

        val out = conn.outputStream
        out.write(prefix)
        val b64 = Base64OutputStream(out, Base64.NO_WRAP or Base64.NO_CLOSE)
        source.inputStream().use { input ->
            val buf = ByteArray(64 * 1024)
            var sent = 0L
            var lastPct = -1
            while (true) {
                val n = input.read(buf)
                if (n < 0) break
                b64.write(buf, 0, n)
                sent += n
                if (onProgress != null && len > 0) {
                    val pct = (sent * 100 / len).toInt()
                    if (pct != lastPct) { lastPct = pct; onProgress(pct) }
                }
            }
        }
        b64.close()          // flushes the final base64 padding; NO_CLOSE keeps `out` open
        out.write(suffix)
        out.flush()

        val code = conn.responseCode
        val text = readBody(conn, code)
        if (code !in 200..299) throw GitHubApiException(code, text)
    }

    // ---------------- plain HTTP helpers ----------------

    private suspend fun <T> retryOnConflict(block: () -> T): T {
        var attempt = 0
        while (true) {
            try { return block() } catch (e: GitHubApiException) {
                if (e.code != 409 || ++attempt >= 4) throw e
                delay(300L * attempt)
            }
        }
    }

    private fun contentsUrl(path: String, repo: RepoRef, withRef: Boolean = true): String {
        val clean = encodePath(path.trim('/'))
        val base = "https://api.github.com/repos/${repo.full}/contents/$clean"
        return if (withRef) "$base?ref=${branchProvider()}" else base
    }

    private fun open(method: String, url: String, accept: String): HttpURLConnection {
        val conn = URL(url).openConnection() as HttpURLConnection
        conn.requestMethod = method
        conn.connectTimeout = 10_000
        conn.readTimeout = 30_000
        val token = tokenProvider()
        if (token.isNotBlank()) conn.setRequestProperty("Authorization", "Bearer $token")
        conn.setRequestProperty("Accept", accept)
        conn.setRequestProperty("X-GitHub-Api-Version", "2022-11-28")
        return conn
    }

    private fun request(method: String, url: String, accept: String, etag: String? = null, body: JSONObject? = null): Response {
        val conn = open(method, url, accept)
        if (etag != null) conn.setRequestProperty("If-None-Match", etag)
        if (body != null) {
            conn.doOutput = true
            conn.setRequestProperty("Content-Type", "application/json")
            conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
        }
        val code = conn.responseCode
        val text = readBody(conn, code)
        if (code !in 200..299 && code != 304) throw GitHubApiException(code, text)
        return Response(code, text, conn.getHeaderField("ETag"))
    }

    private fun readBody(conn: HttpURLConnection, code: Int): String {
        val stream = if (code in 200..299) conn.inputStream else conn.errorStream
        return try { stream?.bufferedReader()?.use { it.readText() } ?: "" } catch (e: Exception) { "" }
    }

    private fun encodePath(path: String): String =
        path.split("/").joinToString("/") { java.net.URLEncoder.encode(it, "UTF-8").replace("+", "%20") }
}
