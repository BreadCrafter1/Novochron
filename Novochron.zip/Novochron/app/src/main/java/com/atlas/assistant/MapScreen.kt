package com.atlas.assistant

import android.Manifest
import android.content.pm.PackageManager
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.model.BitmapDescriptorFactory
import com.google.android.gms.maps.model.CameraPosition
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.MapStyleOptions
import com.google.maps.android.compose.GoogleMap
import com.google.maps.android.compose.MapProperties
import com.google.maps.android.compose.MapType
import com.google.maps.android.compose.MapUiSettings
import com.google.maps.android.compose.Marker
import com.google.maps.android.compose.MarkerState
import com.google.maps.android.compose.rememberCameraPositionState
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.util.Locale
import kotlin.math.roundToInt

/**
 * A real street map — actual roads, labels, parks, the works — via the Google Maps SDK, recoloured
 * dark to match Novochron's terminal theme (see res/raw/map_style_dark.json). Needs a Google Maps API
 * key baked in at build time; see README > "Map setup". Tap anywhere to drop a pin; Novochron reports
 * the straight-line distance from your current fix using the same haversine math as "how far is home"
 * (see [Maps]). One compact landscape-style layout — a big map with a slim scrolling control strip
 * underneath — is used regardless of device orientation, rather than separate portrait/landscape
 * arrangements.
 *
 * Layers (chip row along the top of the map, remembered between visits):
 *   dark   - the default terminal-themed street map (res/raw/map_style_dark.json)
 *   mono   - black-and-white street map (res/raw/map_style_mono.json)
 *   sat    - satellite imagery with road and place labels (Google's HYBRID type)
 *   roads  - everything dark except roads and paths, drawn in bright colours by class with a legend
 *            (res/raw/map_style_roads.json)
 *   3D     - toggle that works on top of any layer: tilts the camera and extrudes buildings
 *
 * (There used to be a "street" chip for Street View. It's gone — Street View is billed and quota'd
 * separately from ordinary map tiles, and it hit a "Quota status is BLOCKED" wall on first use here.)
 *
 * Google's own map chrome (the tile colours, road lines, water, parks) follows the JSON style above,
 * but the zoom/compass/my-location *buttons* are Google's stock widgets and can't be recoloured to
 * match the theme — they're switched off here in favour of small themed zoom/recenter buttons instead.
 */
@Composable
fun MapScreen(engine: Engine, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val maps = remember { Maps.get(ctx) }
    var places by remember { mutableStateOf(maps.places()) }
    var here by remember { mutableStateOf(maps.currentLocation()) }
    var pin by remember { mutableStateOf<LatLng?>(null) }
    var pinLabel by remember { mutableStateOf("") }
    var savedFlash by remember { mutableStateOf(false) }
    var centeredOnce by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val mapKeyOk = remember { MapsKey.isConfigured(ctx) }

    val hasLocationPerm = ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_FINE_LOCATION) ==
        PackageManager.PERMISSION_GRANTED ||
        ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED

    val darkStyle = remember { MapStyleOptions.loadRawResourceStyle(ctx, R.raw.map_style_dark) }
    val monoStyle = remember { MapStyleOptions.loadRawResourceStyle(ctx, R.raw.map_style_mono) }
    val roadsStyle = remember { MapStyleOptions.loadRawResourceStyle(ctx, R.raw.map_style_roads) }

    // Layer + 3D are remembered between visits (Store.mapLayer / Store.map3d)
    var layer by remember { mutableStateOf(MapLayer.from(engine.store.mapLayer)) }
    var threeD by remember { mutableStateOf(engine.store.map3d) }

    val cameraPositionState = rememberCameraPositionState {
        position = if (here != null) {
            CameraPosition(
                LatLng(here!!.latitude, here!!.longitude),
                if (threeD) THREE_D_ZOOM else FLAT_ZOOM,
                if (threeD) THREE_D_TILT else 0f,
                0f
            )
        } else {
            CameraPosition.fromLatLngZoom(LatLng(0.0, 0.0), 2f)
        }
    }

    /** A camera at [target] that respects the 3D toggle (tilted and closer in when on, flat and north-up when off). */
    fun cameraAt(target: LatLng): CameraPosition = CameraPosition(
        target,
        if (threeD) THREE_D_ZOOM else FLAT_ZOOM,
        if (threeD) THREE_D_TILT else 0f,
        if (threeD) cameraPositionState.position.bearing else 0f
    )

    LaunchedEffect(Unit) {
        maps.start()
        while (true) {
            here = maps.currentLocation()
            delay(5000)
        }
    }
    // recenters once, the first time a fix arrives, without fighting the user's own panning afterward
    LaunchedEffect(here) {
        val h = here
        if (h != null && !centeredOnce) {
            centeredOnce = true
            cameraPositionState.animate(CameraUpdateFactory.newCameraPosition(cameraAt(LatLng(h.latitude, h.longitude))))
        }
    }
    LaunchedEffect(savedFlash) {
        if (savedFlash) { delay(1200); savedFlash = false }
    }

    Column(
        Modifier
            .fillMaxSize()
            .background(Color.Black)
            .padding(horizontal = 12.dp, vertical = 10.dp)
    ) {
        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("[ map ]", color = Accent, fontFamily = TermFont, fontWeight = FontWeight.Bold, fontSize = 18.sp)
            TextButton(onClick = onClose) { Text("[close]", color = Ink, fontFamily = TermFont, fontSize = 13.sp) }
        }
        Spacer(Modifier.height(8.dp))

        Box(
            Modifier
                .weight(1f)
                .fillMaxWidth()
                .clip(RoundedCornerShape(8.dp))
                .border(1.dp, Line, RoundedCornerShape(8.dp))
        ) {
            if (!mapKeyOk) {
                MapKeyMissing(Modifier.align(Alignment.Center))
            } else {
                GoogleMap(
                    modifier = Modifier.fillMaxSize(),
                    cameraPositionState = cameraPositionState,
                    properties = MapProperties(
                        // styles only apply to NORMAL maps; satellite (HYBRID) has none
                        mapStyleOptions = when (layer) {
                            MapLayer.DARK -> darkStyle
                            MapLayer.MONO -> monoStyle
                            MapLayer.ROADS -> roadsStyle
                            MapLayer.SAT -> null
                        },
                        isMyLocationEnabled = hasLocationPerm,
                        mapType = if (layer == MapLayer.SAT) MapType.HYBRID else MapType.NORMAL,
                        isBuildingEnabled = threeD
                    ),
                    uiSettings = MapUiSettings(
                        zoomControlsEnabled = false,
                        myLocationButtonEnabled = false,
                        mapToolbarEnabled = false,
                        compassEnabled = false
                    ),
                    onMapClick = { latLng -> pin = latLng }
                ) {
                    places.forEach { p ->
                        Marker(
                            state = MarkerState(LatLng(p.lat, p.lon)),
                            title = p.label,
                            icon = BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_GREEN)
                        )
                    }
                    pin?.let {
                        Marker(
                            state = MarkerState(it),
                            title = pinLabel.ifBlank { "Pinned point" },
                            icon = BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_RED)
                        )
                    }
                }

                if (!hasLocationPerm) {
                    Text(
                        "No location permission — grant it in Settings to see yourself on the map.",
                        color = Warn,
                        fontFamily = TermFont,
                        fontSize = 12.sp,
                        modifier = Modifier
                            .align(Alignment.TopCenter)
                            .padding(top = 52.dp) // sits below the layer chips
                            .background(CardBg, RoundedCornerShape(4.dp))
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }

                if (layer == MapLayer.ROADS) {
                    RoadsLegend(Modifier.align(Alignment.BottomStart).padding(10.dp))
                }

                // Google's own zoom/compass/my-location widgets are stock and can't be recoloured, so they're
                // switched off above in favour of these small themed buttons instead.
                Column(
                    Modifier.align(Alignment.BottomEnd).padding(10.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    MapChip("+") { scope.launch { cameraPositionState.animate(CameraUpdateFactory.zoomIn()) } }
                    MapChip("–") { scope.launch { cameraPositionState.animate(CameraUpdateFactory.zoomOut()) } }
                    MapChip("◎") {
                        here?.let { h ->
                            scope.launch {
                                cameraPositionState.animate(
                                    CameraUpdateFactory.newCameraPosition(cameraAt(LatLng(h.latitude, h.longitude)))
                                )
                            }
                        }
                    }
                }

                // Layer picker: pick one base layer, then optionally add 3D on top of it.
                Row(
                    Modifier
                        .align(Alignment.TopStart)
                        .padding(8.dp)
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    MapLayer.values().forEach { l ->
                        MapModeChip(l.label, selected = layer == l) {
                            layer = l
                            engine.store.mapLayer = l.key
                        }
                    }
                    Text("|", color = Dim, fontFamily = TermFont, fontSize = 12.sp)
                    MapModeChip("3D", selected = threeD) {
                        threeD = !threeD
                        engine.store.map3d = threeD
                        val cur = cameraPositionState.position
                        val next = CameraPosition(
                            cur.target,
                            if (threeD) maxOf(cur.zoom, THREE_D_ZOOM) else cur.zoom,
                            if (threeD) THREE_D_TILT else 0f,
                            if (threeD) cur.bearing else 0f
                        )
                        scope.launch { cameraPositionState.animate(CameraUpdateFactory.newCameraPosition(next)) }
                    }
                }
            }
        }

        Spacer(Modifier.height(8.dp))

        // one slim, horizontally-scrolling control strip under the map, landscape-style
        Row(
            Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                if (here != null) String.format(Locale.US, "Here: %.5f, %.5f", here!!.latitude, here!!.longitude)
                else "No location fix yet",
                color = Dim,
                fontFamily = TermFont,
                fontSize = 12.sp
            )

            if (pin == null) {
                Text("Tap the map to drop a pin.", color = Dim, fontFamily = TermFont, fontSize = 13.sp)
            } else {
                val p = pin!!
                if (here != null) {
                    val km = Maps.haversineKm(here!!.latitude, here!!.longitude, p.latitude, p.longitude)
                    val distText = if (km < 1.0) "${(km * 1000).roundToInt()} m away" else "${String.format(Locale.US, "%.2f", km)} km away"
                    Text(distText, color = Accent, fontFamily = TermFont, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                }
                OutlinedTextField(
                    value = pinLabel,
                    onValueChange = { pinLabel = it },
                    singleLine = true,
                    label = { Text("Save as…", color = Dim, fontSize = 11.sp) },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Text),
                    colors = fieldColors(),
                    modifier = Modifier.width(160.dp)
                )
                TextButton(onClick = {
                    maps.savePlace(pinLabel.ifBlank { "pinned point" }, p.latitude, p.longitude)
                    places = maps.places()
                    savedFlash = true
                    CloudSync.notifyDirty(ctx)
                }) { Text("[save]", color = Accent, fontFamily = TermFont, fontSize = 13.sp) }
                TextButton(onClick = { pin = null; pinLabel = "" }) {
                    Text("[clear pin]", color = Warn, fontFamily = TermFont, fontSize = 13.sp)
                }
                if (savedFlash) Text("Saved.", color = Accent, fontFamily = TermFont, fontSize = 12.sp)
            }

            if (places.isNotEmpty()) {
                Text("|", color = Line, fontFamily = TermFont, fontSize = 13.sp)
                places.forEach { p ->
                    val dist = here?.let { " (${String.format(Locale.US, "%.1f", Maps.haversineKm(it.latitude, it.longitude, p.lat, p.lon))} km)" } ?: ""
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("• ${p.label}$dist", color = Ink, fontFamily = TermFont, fontSize = 13.sp)
                        TextButton(onClick = { maps.forgetPlace(p.label); places = maps.places() }) {
                            Text("×", color = Warn, fontFamily = TermFont, fontSize = 14.sp)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun MapChip(label: String, onClick: () -> Unit) {
    Box(
        Modifier
            .clip(RoundedCornerShape(6.dp))
            .background(CardBg)
            .border(1.dp, Line, RoundedCornerShape(6.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 10.dp, vertical = 6.dp)
    ) {
        Text(label, color = Accent, fontFamily = TermFont, fontWeight = FontWeight.Bold, fontSize = 15.sp)
    }
}

@Composable
private fun MapKeyMissing(modifier: Modifier = Modifier) {
    Column(
        modifier
            .fillMaxWidth()
            .padding(16.dp)
            .background(CardBg, RoundedCornerShape(8.dp))
            .border(1.dp, Line, RoundedCornerShape(8.dp))
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Text("Map needs a Google Maps key", color = Warn, fontFamily = TermFont, fontWeight = FontWeight.Bold, fontSize = 14.sp)
        Text(MapsKey.SETUP_STEPS, color = Ink, fontFamily = TermFont, fontSize = 12.sp)
    }
}

private const val FLAT_ZOOM = 15f
private const val THREE_D_ZOOM = 17f // buildings only extrude once you're zoomed in this far
private const val THREE_D_TILT = 60f

/** The base layers in the chip row. [key] is what gets saved in Store.mapLayer. */
private enum class MapLayer(val key: String, val label: String) {
    DARK("dark", "dark"),
    MONO("mono", "mono"),
    SAT("sat", "sat"),
    ROADS("roads", "roads");

    companion object {
        fun from(key: String): MapLayer = values().firstOrNull { it.key == key } ?: DARK
    }
}

@Composable
private fun MapModeChip(label: String, selected: Boolean, onClick: () -> Unit) {
    val shape = RoundedCornerShape(6.dp)
    Box(
        Modifier
            .clip(shape)
            .background(if (selected) Accent else CardBg.copy(alpha = 0.88f))
            .border(1.dp, if (selected) Accent else Line, shape)
            .clickable(onClick = onClick)
            .padding(horizontal = 8.dp, vertical = 6.dp)
    ) {
        Text(
            label,
            color = if (selected) Color.Black else Ink,
            fontFamily = TermFont,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
            fontSize = 11.sp,
            maxLines = 1
        )
    }
}

/** Colour key for the "roads" layer; the colours match res/raw/map_style_roads.json. */
@Composable
private fun RoadsLegend(modifier: Modifier = Modifier) {
    val shape = RoundedCornerShape(6.dp)
    Column(
        modifier
            .clip(shape)
            .background(CardBg.copy(alpha = 0.88f))
            .border(1.dp, Line, shape)
            .padding(horizontal = 8.dp, vertical = 6.dp),
        verticalArrangement = Arrangement.spacedBy(3.dp)
    ) {
        LegendRow(Color(0xFFFF6B3D), "highways")
        LegendRow(Color(0xFFFFD23F), "main roads")
        LegendRow(Color(0xFF00E5FF), "streets & paths")
    }
}

@Composable
private fun LegendRow(color: Color, label: String) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        Box(Modifier.width(18.dp).height(3.dp).background(color))
        Text(label, color = Ink, fontFamily = TermFont, fontSize = 10.sp)
    }
}
