package com.atlas.assistant

import kotlin.math.PI
import kotlin.math.asin
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * Astronomy for the `[sky]` tab: sidereal time, RA/Dec -> local East/North/Up, a low-precision Moon,
 * a small bright-star catalogue with constellation lines, and the galactic plane. Sun and planets come
 * from [OrbitMath]'s Keplerian elements, so `[sky]` and `[sim]` always agree about where things are.
 */
object SkyMath {

    class Star(val name: String, val raH: Double, val decDeg: Double, val mag: Double)

    /** Brightest / best-known stars: name, RA (hours), Dec (degrees), apparent magnitude. */
    val STARS: List<Star> = listOf(
        Star("Sirius", 6.7525, -16.7161, -1.46), Star("Canopus", 6.3992, -52.6957, -0.74),
        Star("Arcturus", 14.2610, 19.1824, -0.05), Star("Rigil Kent", 14.6600, -60.8350, -0.01),
        Star("Vega", 18.6156, 38.7837, 0.03), Star("Capella", 5.2782, 45.9980, 0.08),
        Star("Rigel", 5.2423, -8.2016, 0.13), Star("Procyon", 7.6550, 5.2250, 0.34),
        Star("Betelgeuse", 5.9195, 7.4071, 0.42), Star("Achernar", 1.6286, -57.2367, 0.46),
        Star("Hadar", 14.0637, -60.3730, 0.61), Star("Altair", 19.8464, 8.8683, 0.77),
        Star("Acrux", 12.4433, -63.0991, 0.76), Star("Aldebaran", 4.5987, 16.5093, 0.85),
        Star("Antares", 16.4901, -26.4320, 0.96), Star("Spica", 13.4199, -11.1613, 0.97),
        Star("Pollux", 7.7553, 28.0262, 1.14), Star("Fomalhaut", 22.9608, -29.6222, 1.16),
        Star("Deneb", 20.6905, 45.2803, 1.25), Star("Mimosa", 12.7953, -59.6888, 1.25),
        Star("Regulus", 10.1395, 11.9672, 1.35), Star("Castor", 7.5767, 31.8883, 1.58),
        Star("Bellatrix", 5.4189, 6.3497, 1.64), Star("Alnilam", 5.6036, -1.2019, 1.69),
        Star("Alnitak", 5.6793, -1.9426, 1.74), Star("Mintaka", 5.5334, -0.2991, 2.25),
        Star("Saiph", 5.7959, -9.6696, 2.07), Star("Alioth", 12.9005, 55.9598, 1.76),
        Star("Dubhe", 11.0621, 61.7510, 1.79), Star("Mizar", 13.3988, 54.9254, 2.23),
        Star("Alkaid", 13.7923, 49.3132, 1.86), Star("Merak", 11.0307, 56.3824, 2.37),
        Star("Phecda", 11.8972, 53.6948, 2.44), Star("Megrez", 12.2571, 57.0326, 3.31),
        Star("Polaris", 2.5303, 89.2641, 1.98), Star("Gacrux", 12.5194, -57.1132, 1.64),
        Star("Delta Cru", 12.2524, -58.7489, 2.80), Star("Schedar", 0.6751, 56.5373, 2.24),
        Star("Caph", 0.1530, 59.1498, 2.27), Star("Gamma Cas", 0.9451, 60.7167, 2.47),
        Star("Ruchbah", 1.4303, 60.2353, 2.68), Star("Segin", 1.9067, 63.6700, 3.38),
        Star("Dschubba", 16.0056, -22.6217, 2.29), Star("Acrab", 16.0906, -19.8054, 2.62),
        Star("Eps Sco", 16.8361, -34.2932, 2.29), Star("Sargas", 17.6220, -42.9978, 1.87),
        Star("Shaula", 17.5601, -37.1038, 1.63)
    )

    val STAR_BY_NAME: Map<String, Star> = STARS.associateBy { it.name }

    /** Constellation stick figures as pairs of star names. */
    val LINES: List<Pair<String, String>> = listOf(
        // Orion
        "Betelgeuse" to "Bellatrix", "Betelgeuse" to "Alnitak", "Bellatrix" to "Mintaka",
        "Mintaka" to "Alnilam", "Alnilam" to "Alnitak", "Alnitak" to "Saiph", "Mintaka" to "Rigel",
        // Big Dipper
        "Dubhe" to "Merak", "Merak" to "Phecda", "Phecda" to "Megrez", "Megrez" to "Dubhe",
        "Megrez" to "Alioth", "Alioth" to "Mizar", "Mizar" to "Alkaid",
        // Cassiopeia
        "Caph" to "Schedar", "Schedar" to "Gamma Cas", "Gamma Cas" to "Ruchbah", "Ruchbah" to "Segin",
        // Southern Cross
        "Acrux" to "Gacrux", "Mimosa" to "Delta Cru",
        // Scorpius
        "Acrab" to "Dschubba", "Dschubba" to "Antares", "Antares" to "Eps Sco", "Eps Sco" to "Sargas", "Sargas" to "Shaula",
        // Summer Triangle
        "Vega" to "Deneb", "Deneb" to "Altair", "Altair" to "Vega"
    )

    private const val OBLIQUITY = 23.4392911

    /** Ecliptic (J2000) vector -> equatorial (RA deg 0..360, Dec deg). */
    fun eclToEq(x: Double, y: Double, z: Double): Pair<Double, Double> {
        val e = Math.toRadians(OBLIQUITY)
        val xe = x
        val ye = y * cos(e) - z * sin(e)
        val ze = y * sin(e) + z * cos(e)
        val r = sqrt(xe * xe + ye * ye + ze * ze).coerceAtLeast(1e-12)
        val ra = (Math.toDegrees(atan2(ye, xe)) + 360.0) % 360.0
        val dec = Math.toDegrees(asin(ze / r))
        return ra to dec
    }

    /** Local sidereal time in degrees; [tDays] is days since J2000.0 (fractional, UT), [lonDeg] east positive. */
    fun lstDeg(tDays: Double, lonDeg: Double): Double {
        val gmst = 280.46061837 + 360.98564736629 * tDays
        return ((gmst + lonDeg) % 360.0 + 360.0) % 360.0
    }

    /** Unit vector (East, North, Up) toward a point at [raDeg]/[decDeg] for an observer at [latDeg] with sidereal time [lst]. */
    fun enu(raDeg: Double, decDeg: Double, lst: Double, latDeg: Double): DoubleArray {
        val h = Math.toRadians(lst - raDeg)
        val d = Math.toRadians(decDeg)
        val p = Math.toRadians(latDeg)
        val east = -cos(d) * sin(h)
        val north = cos(p) * sin(d) - sin(p) * cos(d) * cos(h)
        val up = sin(p) * sin(d) + cos(p) * cos(d) * cos(h)
        return doubleArrayOf(east, north, up)
    }

    fun altDeg(v: DoubleArray): Double = Math.toDegrees(asin(v[2].coerceIn(-1.0, 1.0)))
    fun azDeg(v: DoubleArray): Double = (Math.toDegrees(atan2(v[0], v[1])) + 360.0) % 360.0

    /** Low-precision Moon (about half a degree): ecliptic longitude and latitude in degrees. */
    fun moonEcliptic(tDays: Double): Pair<Double, Double> {
        val l = 218.316 + 13.176396 * tDays
        val m = Math.toRadians(134.963 + 13.064993 * tDays)
        val f = Math.toRadians(93.272 + 13.229350 * tDays)
        val lon = l + 6.289 * sin(m)
        val lat = 5.128 * sin(f)
        return ((lon % 360.0 + 360.0) % 360.0) to lat
    }

    /** RA/Dec of the Moon. */
    fun moonEquatorial(tDays: Double): Pair<Double, Double> {
        val (lon, lat) = moonEcliptic(tDays)
        val lr = Math.toRadians(lon); val br = Math.toRadians(lat)
        return eclToEq(cos(br) * cos(lr), cos(br) * sin(lr), sin(br))
    }

    /** Fraction of the Moon's disc that is lit (0..1), from its elongation from the Sun. */
    fun moonIllumination(tDays: Double, sunLonDeg: Double): Double {
        val (lon, lat) = moonEcliptic(tDays)
        val cosElong = cos(Math.toRadians(lat)) * cos(Math.toRadians(lon - sunLonDeg))
        return (1.0 - cosElong) / 2.0
    }

    /** Points along the galactic plane in RA/Dec with a brightness weight (brightest toward the Galactic Centre). */
    class BandPoint(val raDeg: Double, val decDeg: Double, val weight: Double)

    val GALACTIC_BAND: List<BandPoint> by lazy {
        val raNgp = Math.toRadians(192.85948)
        val decNgp = Math.toRadians(27.12825)
        val lNcp = Math.toRadians(122.93192)
        (0 until 120).map { i ->
            val lDeg = i * 3.0
            val l = Math.toRadians(lDeg)
            val b = 0.0
            val sinDec = sin(decNgp) * sin(b) + cos(decNgp) * cos(b) * cos(lNcp - l)
            val dec = asin(sinDec)
            val ra = raNgp + atan2(cos(b) * sin(lNcp - l), cos(decNgp) * sin(b) - sin(decNgp) * cos(b) * cos(lNcp - l))
            val lw = if (lDeg > 180.0) lDeg - 360.0 else lDeg
            BandPoint(((Math.toDegrees(ra) % 360.0) + 360.0) % 360.0, Math.toDegrees(dec), 0.30 + 0.70 * exp(-(lw / 55.0) * (lw / 55.0)))
        }
    }

    /** Faint background stars scattered evenly over the sphere (fixed seed), so the sky isn't empty between the named ones. */
    class FaintStar(val raDeg: Double, val decDeg: Double, val mag: Double)

    val FAINT: List<FaintStar> by lazy {
        val rnd = java.util.Random(4242L)
        List(900) {
            val ra = rnd.nextDouble() * 360.0
            val dec = Math.toDegrees(asin(rnd.nextDouble() * 2.0 - 1.0))
            FaintStar(ra, dec, 3.6 + rnd.nextDouble() * 2.2)
        }
    }

    @Suppress("unused")
    private val twoPi = 2 * PI
}
