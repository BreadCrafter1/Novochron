package com.atlas.assistant

import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Build
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import kotlinx.coroutines.flow.MutableStateFlow
import java.io.File
import kotlin.coroutines.resume

/**
 * A small, real terminal for Novochron.
 *
 * Two very different things live here, and it matters which one answers a given command:
 *  - Plain file commands (ls/cd/pwd/cat/mkdir/rm/echo) run directly against Novochron's own folder
 *    (Novochron/, see NovochronStorage) using java.io.File. This always works, no setup needed, but it is NOT
 *    a real shell - it can't run arbitrary binaries, because Android doesn't let one app execute
 *    another app's programs or a system shell with real privileges without root.
 *  - `sh <command>` hands the command line to the real Termux app (if installed) via its documented
 *    RUN_COMMAND intent, and returns its actual stdout/stderr. That's a genuine Linux userland
 *    (bash, git, python, gcc, etc.) - see README > "Terminal setup" for the one-time Termux setup.
 *  - `gh` / `repo` commands talk to GitHub's API (see GitHub.kt) to log in, browse a repo, commit
 *    files, and trigger/check GitHub Actions builds - the real place an Android build should run.
 */
class Terminal(private val ctx: Context, private val store: Store) {

    val github = GitHub(store)
    val lines = MutableStateFlow(listOf(BOOT_BANNER))
    var pendingDeviceLogin: DeviceLogin? = null

    private var cwd: File = NovochronStorage.root().apply { mkdirs() }

    fun prompt(): String {
        val root = NovochronStorage.root()
        val rel = if (cwd == root) "" else "/" + cwd.toRelativeString(root)
        return "novochron:$rel$ "
    }

    private fun print(text: String) {
        lines.value = lines.value + text
    }

    /** Runs one command line typed into the terminal. Always safe to call from a coroutine. */
    suspend fun run(raw: String) {
        val cmdLine = raw.trim()
        print("${prompt()}$cmdLine")
        if (cmdLine.isBlank()) return
        val parts = cmdLine.split(Regex("\\s+"), limit = 2)
        val cmd = parts[0].lowercase()
        val rest = parts.getOrElse(1) { "" }
        try {
            when {
                cmd == "help" -> printHelp()
                cmd == "clear" -> lines.value = listOf(BOOT_BANNER)
                cmd == "pwd" -> print(cwd.absolutePath)
                cmd == "ls" -> localLs(rest)
                cmd == "cd" -> localCd(rest)
                cmd == "cat" -> localCat(rest)
                cmd == "mkdir" -> localMkdir(rest)
                cmd == "rm" -> localRm(rest)
                cmd == "echo" -> print(rest)
                cmd == "sh" || cmd == "bash" -> runInTermux(rest)
                cmd == "gh" -> ghCommand(rest)
                cmd == "repo" -> repoCommand(rest)
                cmd == "sync" -> syncCommand(rest)
                else -> print("Unknown command: $cmd (try \"help\")")
            }
        } catch (e: IllegalStateException) {
            print("! ${e.message}")
        } catch (e: GitHubApiException) {
            print("! GitHub error ${e.code}: ${friendlyGhError(e)}")
        } catch (e: Exception) {
            print("! ${e.message ?: e.toString()}")
        }
    }

    private fun printHelp() {
        print(
            """
            |Local files (inside Novochron/, always works):
            |  ls [path]           list files
            |  cd <path>           change directory ( .. goes up, / goes to Novochron/ root)
            |  cat <file>          print a text file
            |  mkdir <dir>         make a folder
            |  rm <file>           delete a file
            |  echo <text>         print text
            |  clear               clear the screen
            |
            |Real shell (needs Termux installed - see README > Terminal setup):
            |  sh <command>        run a command line for real, e.g. sh git status
            |
            |GitHub (needs "gh login" or "gh token" first):
            |  gh login            log in with your GitHub account (device code, no password stored)
            |  gh token <PAT>      log in by pasting a Personal Access Token instead (no client ID needed)
            |  gh logout           forget the saved GitHub login
            |  gh whoami           show who you're logged in as
            |  gh repos            list your repos
            |
            |Once logged in:
            |  repo use <owner/name> [branch]   pick the repo (and branch, default main) to work on
            |  repo ls [path]                   list files in the repo
            |  repo cat <path>                  show a file from the repo
            |  repo commit <path> -m "message"  paste new content, end with a line containing only .
            |  repo workflows                   list GitHub Actions workflows
            |  repo run [workflow.yml]           trigger a build (needs on: workflow_dispatch in the yaml)
            |  repo status [workflow.yml]        latest run's status
            |  repo open                        show the repo's Actions page link
            |
            |Cloud sync (mirrors Novochron/, except Models/, to ${store.cloudSyncRepo} - see Settings):
            |  sync status          show whether it's synced, syncing, or queued
            |  sync now             sync right away instead of waiting for the next change
            |  sync repo <owner/name>   change which repo it mirrors to
            """.trimMargin()
        )
    }

    // ---------------- local sandboxed file commands ----------------

    private fun resolve(path: String): File {
        if (path.isBlank()) return cwd
        val f = if (path.startsWith("/")) File(NovochronStorage.root(), path.removePrefix("/")) else File(cwd, path)
        return f.canonicalFile
    }

    private fun insideSandbox(f: File): Boolean =
        f.canonicalPath.startsWith(NovochronStorage.root().canonicalPath)

    private fun localLs(arg: String) {
        val dir = resolve(arg)
        if (!insideSandbox(dir)) { print("! Can only browse inside Novochron/"); return }
        if (!dir.exists()) { print("No such file or directory"); return }
        if (dir.isFile) { print(dir.name); return }
        val names = dir.listFiles()?.sortedBy { it.name } ?: emptyList()
        if (names.isEmpty()) print("(empty)") else print(names.joinToString("  ") { if (it.isDirectory) "${it.name}/" else it.name })
    }

    private fun localCd(arg: String) {
        val target = if (arg.isBlank() || arg == "~" || arg == "/") NovochronStorage.root() else resolve(arg)
        if (!insideSandbox(target)) { print("! Can only move around inside Novochron/"); return }
        if (!target.exists() || !target.isDirectory) { print("No such directory"); return }
        cwd = target
    }

    private fun localCat(arg: String) {
        if (arg.isBlank()) { print("usage: cat <file>"); return }
        val f = resolve(arg)
        if (!insideSandbox(f)) { print("! Can only read inside Novochron/"); return }
        if (!f.exists() || !f.isFile) { print("No such file"); return }
        if (f.length() > 200_000) { print("File is too large to show here (${f.length()} bytes)."); return }
        print(f.readText())
    }

    private fun localMkdir(arg: String) {
        if (arg.isBlank()) { print("usage: mkdir <dir>"); return }
        val f = resolve(arg)
        if (!insideSandbox(f)) { print("! Can only create folders inside Novochron/"); return }
        print(if (f.mkdirs()) "Created ${f.name}" else "Could not create that folder")
    }

    private fun localRm(arg: String) {
        if (arg.isBlank()) { print("usage: rm <file>"); return }
        val f = resolve(arg)
        if (!insideSandbox(f) || f == NovochronStorage.root()) { print("! Won't delete that"); return }
        if (!f.exists()) { print("No such file"); return }
        print(if (f.deleteRecursively()) "Deleted" else "Could not delete that")
    }

    // ---------------- real shell, via the Termux app ----------------

    fun termuxInstalled(): Boolean = try {
        ctx.packageManager.getPackageInfo("com.termux", 0); true
    } catch (e: Exception) { false }

    private suspend fun runInTermux(command: String) {
        if (command.isBlank()) { print("usage: sh <command>"); return }
        if (!termuxInstalled()) {
            print(
                "Termux isn't installed, so there's no real Linux shell to run that in. Install Termux " +
                    "from F-Droid (recommended) or GitHub releases, open it once, then in Termux run:\n" +
                    "  echo \"allow-external-apps=true\" >> ~/.termux/termux.properties\n" +
                    "and restart Termux. See README > Terminal setup."
            )
            return
        }
        print("$ $command")
        val result = withTimeoutOrNull(60_000) { TermuxBridge.run(ctx, command) }
        if (result == null) {
            print("(no response from Termux after 60s - is \"allow-external-apps=true\" set in ~/.termux/termux.properties? See README > Terminal setup.)")
            return
        }
        if (result.stdout.isNotBlank()) print(result.stdout.trimEnd())
        if (result.stderr.isNotBlank()) print(result.stderr.trimEnd())
        print("[exit ${result.exitCode}]")
    }

    // ---------------- gh (login) commands ----------------

    private suspend fun ghCommand(rest: String) {
        val (sub, arg) = rest.split(Regex("\\s+"), limit = 2).let { it[0] to it.getOrElse(1) { "" } }
        when (sub.lowercase()) {
            "login" -> ghLogin()
            "token" -> ghLoginWithToken(arg)
            "logout" -> { github.logout(); print("Logged out.") }
            "whoami" -> print(if (github.isLinked) "Logged in as ${store.githubUser.ifBlank { "(unknown)" }}" else "Not logged in. Try \"gh login\".")
            "repos" -> {
                if (!github.isLinked) { print("Not logged in. Try \"gh login\" first."); return }
                print("Loading your repos…")
                val repos = withContext(Dispatchers.IO) { github.listRepos() }
                print(if (repos.isEmpty()) "No repos found." else repos.joinToString("\n"))
            }
            "" -> print("usage: gh login | gh token <personal-access-token> | gh logout | gh whoami | gh repos")
            else -> print("Unknown gh command: $sub")
        }
    }

    private suspend fun ghLogin() {
        if (BuildConfig.GITHUB_CLIENT_ID.isBlank()) {
            print(
                "This build has no GITHUB_CLIENT_ID baked in, so it can't start a GitHub login. Register a " +
                    "free OAuth App at github.com/settings/developers with \"Enable Device Flow\" checked, " +
                    "put its Client ID in gradle.properties as GITHUB_CLIENT_ID=…, and rebuild. See README > GitHub setup."
            )
            return
        }
        print("Contacting GitHub…")
        val login = try {
            github.requestDeviceLogin(BuildConfig.GITHUB_CLIENT_ID)
        } catch (e: Exception) {
            print("! Couldn't start login: ${e.message}")
            return
        }
        pendingDeviceLogin = login
        print(
            "Go to ${login.verificationUri} on any device and enter this code:\n" +
                "  ${login.userCode}\n" +
                "Waiting for you to finish in the browser (up to ${login.expiresInSeconds / 60} min)…"
        )
        val result = github.pollForToken(BuildConfig.GITHUB_CLIENT_ID, login)
        pendingDeviceLogin = null
        result.onSuccess { print("Logged in as ${store.githubUser}. ✓") }
            .onFailure { print("! Login didn't finish: ${it.message}") }
    }

    /**
     * Alternative to the device-code "gh login": paste a Personal Access Token straight from
     * github.com/settings/tokens. No OAuth app / GITHUB_CLIENT_ID needed, so this is the quickest way
     * for two people to both get linked when they just want "msg" to work.
     */
    private suspend fun ghLoginWithToken(token: String) {
        if (token.isBlank()) {
            print("usage: gh token <personal-access-token>\nCreate one at github.com/settings/tokens - a fine-grained token with Contents read/write on the shared repo, or a classic token with the \"repo\" scope.")
            return
        }
        print("Verifying token…")
        val result = github.loginWithToken(token)
        result.onSuccess { print("Logged in as $it. ✓") }
            .onFailure { print("! ${it.message}") }
    }

    // ---------------- repo commands ----------------

    private var pendingCommitPath: String? = null
    private var pendingCommitMessage: String = ""
    private val pendingCommitBuffer = StringBuilder()

    /** True while `repo commit` is mid-flow and the next lines typed are file content, not commands. */
    val awaitingCommitBody: Boolean get() = pendingCommitPath != null

    /** Feeds one more line of pasted content while a `repo commit` is in progress. A lone "." finishes it. */
    suspend fun feedCommitLine(line: String) {
        print(line)
        if (line.trim() == ".") {
            val path = pendingCommitPath!!
            pendingCommitPath = null
            print("Committing $path…")
            try {
                val url = withContext(Dispatchers.IO) {
                    github.commitFile(path, pendingCommitBuffer.toString(), pendingCommitMessage)
                }
                print("Committed. $url")
            } catch (e: Exception) {
                print("! Commit failed: ${e.message}")
            }
            pendingCommitBuffer.setLength(0)
            return
        }
        pendingCommitBuffer.append(line).append('\n')
    }

    private suspend fun repoCommand(rest: String) {
        if (!github.isLinked) { print("Not logged in. Try \"gh login\" first."); return }
        val parts = rest.split(Regex("\\s+"), limit = 2)
        val sub = parts.getOrElse(0) { "" }.lowercase()
        val arg = parts.getOrElse(1) { "" }
        when (sub) {
            "use" -> {
                val (repoText, branch) = arg.split(Regex("\\s+"), limit = 2).let { it[0] to it.getOrElse(1) { "main" } }
                val ref = RepoRef.parse(repoText)
                if (ref == null) { print("usage: repo use owner/name [branch]"); return }
                store.githubRepo = ref.full
                store.githubBranch = branch.ifBlank { "main" }
                print("Using ${ref.full} @ ${store.githubBranch}")
            }
            "ls" -> {
                print("Loading…")
                val files = withContext(Dispatchers.IO) { github.listFiles(arg) }
                print(if (files.isEmpty()) "(empty)" else files.joinToString("\n") { if (it.isDir) "${it.path}/" else it.path })
            }
            "cat" -> {
                if (arg.isBlank()) { print("usage: repo cat <path>"); return }
                print("Loading…")
                val text = withContext(Dispatchers.IO) { github.readFile(arg) }
                print(text ?: "Couldn't read that as text (missing, binary, or too large).")
            }
            "commit" -> {
                val m = Regex("^(.+?)\\s+-m\\s+\"?(.+?)\"?$").find(arg)
                val path = m?.groupValues?.get(1)?.trim() ?: ""
                val message = m?.groupValues?.get(2)?.trim() ?: ""
                if (path.isBlank() || message.isBlank()) { print("usage: repo commit <path> -m \"message\""); return }
                pendingCommitPath = path
                pendingCommitMessage = message
                pendingCommitBuffer.setLength(0)
                print("Paste the new content for $path, then a line with just . to commit it.")
            }
            "workflows" -> {
                print("Loading…")
                val wf = withContext(Dispatchers.IO) { github.listWorkflows() }
                print(if (wf.isEmpty()) "No workflows found." else wf.joinToString("\n") { (name, file) -> "$name  ($file)" })
            }
            "run" -> {
                val file = arg.ifBlank {
                    val wf = withContext(Dispatchers.IO) { github.listWorkflows() }
                    wf.firstOrNull()?.second ?: ""
                }
                if (file.isBlank()) { print("No workflow found. Add a .yml under .github/workflows with \"on: workflow_dispatch\"."); return }
                print("Triggering $file on ${store.githubBranch}…")
                try {
                    withContext(Dispatchers.IO) { github.runWorkflow(file) }
                    print("Build triggered. Say \"repo status\" in a bit to check on it.")
                } catch (e: GitHubApiException) {
                    print("! Couldn't trigger it: ${friendlyGhError(e)}")
                }
            }
            "status" -> {
                print("Checking…")
                val run = withContext(Dispatchers.IO) { github.latestRun(workflowFile = arg.ifBlank { null }) }
                print(
                    if (run == null) "No runs found yet."
                    else "${run.name}: ${run.status}${run.conclusion?.let { " ($it)" } ?: ""}\n${run.htmlUrl}"
                )
            }
            "open" -> {
                val repo = github.activeRepo
                if (repo == null) { print("No repo selected."); return }
                print("https://github.com/${repo.full}/actions")
            }
            "" -> print("usage: repo use|ls|cat|commit|workflows|run|status|open")
            else -> print("Unknown repo command: $sub")
        }
    }

    private fun syncCommand(rest: String) {
        val parts = rest.split(Regex("\\s+"), limit = 2)
        val sub = parts.getOrElse(0) { "" }.lowercase()
        val arg = parts.getOrElse(1) { "" }
        when (sub) {
            "", "status" -> {
                print("Repo: ${store.cloudSyncRepo}  (${if (store.cloudSyncEnabled) "on" else "off"})")
                print(store.cloudSyncStatus + if (store.cloudSyncPending) " — pending" else "")
            }
            "now" -> {
                if (!store.cloudSyncEnabled) { print("Cloud sync is off - turn it on in Settings first."); return }
                print("Syncing…")
                CloudSync.syncNow(ctx)
            }
            "repo" -> {
                val ref = RepoRef.parse(arg)
                if (ref == null) { print("usage: sync repo <owner/name>"); return }
                store.cloudSyncRepo = ref.full
                store.cloudSyncManifest = "" // switching repos - start this one's manifest fresh
                print("Now mirroring to ${ref.full}. Run \"sync now\" to kick off the first sync.")
            }
            "on" -> { store.cloudSyncEnabled = true; print("Cloud sync on."); CloudSync.syncNow(ctx) }
            "off" -> { store.cloudSyncEnabled = false; print("Cloud sync off.") }
            else -> print("Unknown sync command: $sub (try \"sync status\", \"sync now\", \"sync repo owner/name\", \"sync on\", \"sync off\")")
        }
    }

    private fun friendlyGhError(e: GitHubApiException): String = when (e.code) {
        401 -> "your login was rejected - try \"gh login\" again"
        403 -> "forbidden (check the repo name and that your token has access)"
        404 -> "not found (check the repo/path/workflow name)"
        422 -> "GitHub rejected the request - double check the workflow file has \"on: workflow_dispatch\""
        else -> e.message ?: "unknown error"
    }

    companion object {
        private const val BOOT_BANNER = "Novochron terminal. Type \"help\" to see what's available."
    }
}

private data class TermuxResult(val stdout: String, val stderr: String, val exitCode: Int)

/**
 * Bridges to the real Termux app using its documented RUN_COMMAND intent
 * (https://github.com/termux/termux-app/wiki/RUN_COMMAND-Intent). Termux must have
 * "allow-external-apps=true" set in ~/.termux/termux.properties, and this app must hold the
 * com.termux.permission.RUN_COMMAND permission (declared in AndroidManifest.xml).
 */
private object TermuxBridge {
    suspend fun run(ctx: Context, command: String): TermuxResult = suspendCancellableCoroutine { cont ->
        val resultAction = "com.atlas.assistant.TERMUX_RESULT.${System.nanoTime()}"
        val receiver = object : BroadcastReceiver() {
            override fun onReceive(c: Context, intent: Intent) {
                try { ctx.unregisterReceiver(this) } catch (e: Exception) {}
                val bundle = intent.getBundleExtra("result")
                val out = bundle?.getString("stdout") ?: ""
                val err = bundle?.getString("stderr") ?: ""
                val code = bundle?.getInt("exitCode") ?: -1
                if (cont.isActive) cont.resume(TermuxResult(out, err, code))
            }
        }
        val filter = IntentFilter(resultAction)
        if (Build.VERSION.SDK_INT >= 33) {
            ctx.registerReceiver(receiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            @Suppress("UnspecifiedRegisterReceiverFlag")
            ctx.registerReceiver(receiver, filter)
        }
        cont.invokeOnCancellation { try { ctx.unregisterReceiver(receiver) } catch (e: Exception) {} }

        val pendingIntent = PendingIntent.getBroadcast(
            ctx, 0, Intent(resultAction).setPackage(ctx.packageName),
            PendingIntent.FLAG_MUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val runIntent = Intent().apply {
            setClassName("com.termux", "com.termux.app.RunCommandService")
            action = "com.termux.RUN_COMMAND"
            putExtra("com.termux.RUN_COMMAND_PATH", "/data/data/com.termux/files/usr/bin/bash")
            putExtra("com.termux.RUN_COMMAND_ARGUMENTS", arrayOf("-c", command))
            putExtra("com.termux.RUN_COMMAND_WORKDIR", "/data/data/com.termux/files/home")
            putExtra("com.termux.RUN_COMMAND_BACKGROUND", true)
            putExtra("com.termux.RUN_COMMAND_PENDING_INTENT", pendingIntent)
        }
        try {
            if (Build.VERSION.SDK_INT >= 26) ctx.startForegroundService(runIntent) else ctx.startService(runIntent)
        } catch (e: Exception) {
            try { ctx.unregisterReceiver(receiver) } catch (e2: Exception) {}
            if (cont.isActive) cont.resume(TermuxResult("", "Couldn't reach Termux: ${e.message}", -1))
        }
    }
}
