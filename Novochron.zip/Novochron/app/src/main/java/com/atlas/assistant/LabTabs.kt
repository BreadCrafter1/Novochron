package com.atlas.assistant

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.rememberScrollState
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier

/** Tab names shared by the sim/graph lab: sim, sky, sat, plan, nbody, graph. */
val LabTabNames = listOf("sim", "sky", "sat", "plan", "nbody", "graph")

/** The `[sim] [sky] [plan] [nbody] [graph]` row shown at the top of every lab screen. */
@Composable
fun LabTabs(active: String, onSelect: (String) -> Unit) {
    Row(
        Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
        verticalAlignment = Alignment.CenterVertically
    ) {
        LabTabNames.forEach { t ->
            TermTextKey(
                "[$t]",
                tone = if (t == active) Accent else Ink,
                bold = t == active,
                size = 13,
                hpad = 6,
                onClick = { onSelect(t) }
            )
        }
    }
}

/** Switches between the lab's screens from anywhere: [graph] is its own screen, the rest are tabs of `[sim]`. */
fun openLabTab(tab: String) {
    if (tab == "graph") {
        AssistantState.showSolar.value = false
        AssistantState.showGraph.value = true
    } else {
        AssistantState.labTab.value = tab
        AssistantState.showGraph.value = false
        AssistantState.showSolar.value = true
    }
}

/** Remembers a few things across tab switches (a tab's own state is dropped when you leave it). */
object LabState {
    /** Simulation time, days since J2000.0 (Solar System only). Null until [sim] has been opened once. */
    var simT: Float? = null
    var circular: Boolean = false
}
