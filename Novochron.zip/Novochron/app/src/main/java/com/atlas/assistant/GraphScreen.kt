package com.atlas.assistant

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch

/** One plotted formula: its raw text, an assigned colour, whether it's shown, and its last error (if any). */
private class PlotLine(text: String, val color: Color) {
    var text by mutableStateOf(text)
    var visible by mutableStateOf(true)
    var showDerivative by mutableStateOf(false)
    var showIntegral by mutableStateOf(false)
    var error: String? = null
}

private val PlotPalette = listOf(
    Color(0xFF3DFF5C), Color(0xFF5CC8FF), Color(0xFFFF9A3D),
    Color(0xFFFF5CD8), Color(0xFFFFE85C), Color(0xFFB35CFF)
)

/** What `[save session]` remembers — kept in memory only (see the object below), lost when the app process dies. */
private class GraphSession(
    val lines: List<Pair<String, Boolean>>, // text, visible
    val centerX: Float, val centerY: Float, val unitsPerPx: Float, val savedAt: Long
)

private object GraphSessionStore {
    var saved: GraphSession? = null
}

/**
 * "[graph]": a Desmos-style calculator, now sharing the `[sim]/[sky]/[plan]/[nbody]` tab row (tapping
 * any other tab swaps to the SolarSystemScreen host). Type one or more `y = ...` formulas (functions of
 * `x`); each is compiled by [GraphMath] and sampled per pixel column. New in this pass: derivative (f')
 * and integral (∫f) overlays per curve, a data [Table] view, polynomial curve-[Fit] with R², and
 * [Save session] (kept in memory for this app session — [Share] shows what a real share action would do,
 * since actually posting anywhere needs the vault/GitHub link already wired up below).
 */
@Composable
fun GraphScreen(onClose: () -> Unit) {
    val ctx = LocalContext.current
    val lines = remember {
        mutableStateListOf(PlotLine("y = sin(x)", PlotPalette[0]))
    }
    var centerX by remember { mutableFloatStateOf(0f) }
    var centerY by remember { mutableFloatStateOf(0f) }
    var unitsPerPx by remember { mutableFloatStateOf(0.02f) }

    var derivativeMode by remember { mutableStateOf(false) }
    var derivativeNote by remember { mutableStateOf("") }
    var derivativePoint by remember { mutableStateOf<Offset?>(null) }
    var intersections by remember { mutableStateOf<List<Pair<Double, Double>>>(emptyList()) }
    var intersectNote by remember { mutableStateOf("") }
    val github = remember { GitHub(Store.get(ctx)) }
    val scope = rememberCoroutineScope()
    var shareBusy by remember { mutableStateOf(false) }
    var shareNote by remember { mutableStateOf("") }

    // ---- new: table / fit
    var mode by remember { mutableStateOf("plot") } // "plot" | "table" | "fit"
    var fitDegree by remember { mutableStateOf(2) }
    var fitNote by remember { mutableStateOf("") }
    var fitCurve by remember { mutableStateOf<GraphMath.PolyFit?>(null) }
    var sessionNote by remember { mutableStateOf("") }

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        Column(Modifier.fillMaxSize().padding(16.dp)) {
            Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                TermTextKey("[back]", onClick = onClose)
                Spacer(Modifier.weight(1f))
                Text("graph", color = Accent, fontFamily = TermFont, fontSize = 18.sp)
                Spacer(Modifier.weight(1f))
                TermTextKey("[reset]", onClick = {
                    centerX = 0f; centerY = 0f; unitsPerPx = 0.02f
                    derivativeNote = ""; derivativePoint = null; intersections = emptyList(); intersectNote = ""
                })
            }
            LabTabs(active = "graph") { t -> openLabTab(t) }
            Spacer(Modifier.height(8.dp))

            val firstVisible = lines.firstOrNull { it.visible && it.text.isNotBlank() }
            val compiledFirst = remember(firstVisible?.text) {
                firstVisible?.let { try { GraphMath.compile(it.text) } catch (e: Exception) { null } }
            }

            when (mode) {
                "table" -> {
                    Box(Modifier.fillMaxWidth().weight(1f).border(1.dp, Line)) {
                        TableView(firstVisible?.text, compiledFirst, centerX, unitsPerPx)
                    }
                }
                "fit" -> {
                    Box(Modifier.fillMaxWidth().weight(1f).border(1.dp, Line)) {
                        FitCanvas(firstVisible?.text, compiledFirst, centerX, centerY, unitsPerPx, fitCurve)
                    }
                }
                else -> {
                    Box(
                        Modifier
                            .fillMaxWidth()
                            .weight(1f)
                            .border(1.dp, Line)
                            .clip(androidx.compose.ui.graphics.RectangleShape)
                            .pointerInput(Unit) {
                                detectTransformGestures { _, pan, zoom, _ ->
                                    if (zoom != 1f) unitsPerPx = (unitsPerPx / zoom).coerceIn(0.0002f, 500f)
                                    centerX -= pan.x * unitsPerPx
                                    centerY += pan.y * unitsPerPx
                                }
                            }
                            .pointerInput(derivativeMode, firstVisible?.text) {
                                if (!derivativeMode) return@pointerInput
                                detectTapGestures { tap ->
                                    val first = lines.firstOrNull { it.visible && it.text.isNotBlank() } ?: return@detectTapGestures
                                    val f = try { GraphMath.compile(first.text) } catch (e: Exception) { null } ?: return@detectTapGestures
                                    val w = size.width; val upp = unitsPerPx.toDouble()
                                    val wx = centerX + (tap.x - w / 2) * upp
                                    val y = try { f(wx) } catch (e: Exception) { Double.NaN }
                                    val slope = try { GraphMath.derivative(f, wx) } catch (e: Exception) { Double.NaN }
                                    derivativePoint = tap
                                    derivativeNote = if (y.isNaN() || slope.isNaN()) "Undefined there."
                                    else "At x ≈ ${fmtG(wx)}: ${first.text.substringBefore("=").trim().ifBlank { "y" }} ≈ ${fmtG(y)}, slope f'(x) ≈ ${fmtG(slope)}"
                                }
                            }
                    ) {
                        GraphCanvas(lines, centerX, centerY, unitsPerPx, intersections)
                    }
                }
            }

            Spacer(Modifier.height(8.dp))
            Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                TermTextKey("Plot", tone = if (mode == "plot") Accent else Ink, bold = mode == "plot", onClick = { mode = "plot" })
                TermTextKey("Table", tone = if (mode == "table") Accent else Ink, bold = mode == "table", onClick = { mode = "table" })
                TermTextKey("Fit", tone = if (mode == "fit") Accent else Ink, bold = mode == "fit", onClick = {
                    mode = "fit"
                    val f = compiledFirst
                    if (f == null) { fitNote = "Fix the formula error above first." }
                    else {
                        val minX = centerX - 400 * unitsPerPx; val maxX = centerX + 400 * unitsPerPx
                        val pts = (0..160).map { i -> val x = minX + (maxX - minX) * i / 160.0; x.toDouble() to (try { f(x.toDouble()) } catch (e: Exception) { Double.NaN }) }
                        val fit = GraphMath.polyFit(pts, fitDegree)
                        fitCurve = fit
                        fitNote = if (fit == null) "Not enough points to fit." else "y ≈ ${fit.formula()}   R² = ${fmtG(fit.r2)}"
                    }
                })
            }

            if (mode == "plot") {
                Text(
                    "Drag to pan · pinch to zoom · functions of x (sin, cos, sqrt, abs, ln, exp, pi, e, ^)",
                    color = Dim, fontFamily = TermFont, fontSize = 11.sp
                )
                Spacer(Modifier.height(6.dp))
                Row(Modifier.horizontalScroll(rememberScrollState()), verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                    TermTextKey(
                        if (derivativeMode) "[f' on]" else "[f']",
                        tone = if (derivativeMode) Accent else Ink,
                        onClick = { derivativeMode = !derivativeMode; if (!derivativeMode) { derivativeNote = ""; derivativePoint = null } }
                    )
                    TermTextKey(
                        "[intersect]",
                        onClick = {
                            val visible = lines.filter { it.visible && it.text.isNotBlank() }
                            if (visible.size < 2) {
                                intersectNote = "Need at least two visible curves to find where they cross."
                                intersections = emptyList()
                            } else {
                                val fa = try { GraphMath.compile(visible[0].text) } catch (e: Exception) { null }
                                val fb = try { GraphMath.compile(visible[1].text) } catch (e: Exception) { null }
                                if (fa == null || fb == null) {
                                    intersectNote = "Fix the formula errors above first."
                                    intersections = emptyList()
                                } else {
                                    val w = 1000.0
                                    val minX = centerX - w / 2 * unitsPerPx
                                    val maxX = centerX + w / 2 * unitsPerPx
                                    val xs = GraphMath.findIntersections(fa, fb, minX.toDouble(), maxX.toDouble())
                                    intersections = xs.mapNotNull { x -> try { x to fa(x) } catch (e: Exception) { null } }
                                    intersectNote = if (intersections.isEmpty()) "No crossings in the visible range — pan/zoom out and try again."
                                    else "Crossings: " + intersections.joinToString(", ") { (x, y) -> "(${fmtG(x)}, ${fmtG(y)})" }
                                }
                            }
                        }
                    )
                    TermTextKey(
                        "[export]",
                        onClick = {
                            val curves = lines.filter { it.visible && it.text.isNotBlank() }.map { it.text to it.color.toArgb() }
                            val bmp = Sharing.renderGraphSnapshot(curves, centerX, centerY, unitsPerPx, 1000, 1400)
                            Sharing.shareBitmap(ctx, bmp, "graph")
                        }
                    )
                    TermTextKey(
                        if (shareBusy) "[linking…]" else "[link]",
                        tone = if (shareBusy) Dim else Ink,
                        onClick = {
                            if (!shareBusy) {
                                shareBusy = true; shareNote = ""
                                scope.launch {
                                    try {
                                        val curves = lines.filter { it.visible && it.text.isNotBlank() }.map { it.text to it.color.toArgb() }
                                        val bmp = Sharing.renderGraphSnapshot(curves, centerX, centerY, unitsPerPx, 1000, 1400)
                                        shareNote = Sharing.uploadAndLink(github, bmp, "graph")
                                    } catch (e: Exception) {
                                        shareNote = "Couldn't upload — check the vault is set up in [vault]."
                                    } finally {
                                        shareBusy = false
                                    }
                                }
                            }
                        }
                    )
                    TermTextKey("[save session]", onClick = {
                        GraphSessionStore.saved = GraphSession(lines.map { it.text to it.visible }, centerX, centerY, unitsPerPx, System.currentTimeMillis())
                        sessionNote = "Saved ${lines.size} formula(s) — in memory for this app session (closing the app clears it)."
                    })
                    TermTextKey("[load session]", tone = if (GraphSessionStore.saved != null) Ink else Dim, onClick = {
                        val s = GraphSessionStore.saved
                        if (s == null) sessionNote = "No saved session yet." else {
                            lines.clear()
                            s.lines.forEachIndexed { i, pair -> lines.add(PlotLine(pair.first, PlotPalette[i % PlotPalette.size]).also { it.visible = pair.second }) }
                            centerX = s.centerX; centerY = s.centerY; unitsPerPx = s.unitsPerPx
                            sessionNote = "Loaded the session saved earlier."
                        }
                    })
                    TermTextKey("[share]", onClick = {
                        sessionNote = "Share would post a snapshot PNG to Messages/Mail/etc. via the Android share sheet — same image [export] saves, " +
                            "just handed straight to the share sheet instead of your Downloads folder. (Preview only here — use [export] or [link] to actually send one.)"
                    })
                }
                if (derivativeMode) Text("Tap the graph to sample the first visible curve's slope there.", color = Dim, fontFamily = TermFont, fontSize = 10.sp)
                if (derivativeNote.isNotBlank()) Text(derivativeNote, color = Ink, fontFamily = TermFont, fontSize = 12.sp)
                if (intersectNote.isNotBlank()) Text(intersectNote, color = Ink, fontFamily = TermFont, fontSize = 12.sp)
                if (shareNote.isNotBlank()) Text(shareNote, color = Accent, fontFamily = TermFont, fontSize = 11.sp)
                if (sessionNote.isNotBlank()) Text(sessionNote, color = Accent, fontFamily = TermFont, fontSize = 11.sp)
                Spacer(Modifier.height(6.dp))

                LazyColumn(Modifier.fillMaxWidth().height(if (lines.size > 3) 190.dp else (lines.size * 86).dp)) {
                    items(lines.size) { idx ->
                        val line = lines[idx]
                        Column(Modifier.fillMaxWidth().padding(vertical = 2.dp)) {
                            Row(Modifier.fillMaxWidth(), verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                                Box(
                                    Modifier.size(14.dp).clip(CircleShape).background(line.color)
                                        .clickable { line.visible = !line.visible }
                                        .then(if (!line.visible) Modifier.border(1.dp, Dim, CircleShape) else Modifier)
                                )
                                Spacer(Modifier.width(8.dp))
                                OutlinedTextField(
                                    value = line.text,
                                    onValueChange = { line.text = it },
                                    singleLine = true,
                                    textStyle = TextStyle(fontFamily = TermFont, fontSize = 14.sp, color = Ink),
                                    colors = fieldColors(),
                                    modifier = Modifier.weight(1f)
                                )
                                Spacer(Modifier.width(8.dp))
                                TermTextKey("[x]", onClick = { if (lines.size > 1) lines.removeAt(idx) })
                            }
                            Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                                Spacer(Modifier.width(22.dp))
                                TermTextKey(
                                    if (line.showDerivative) "[f' shown]" else "[+ f']",
                                    tone = if (line.showDerivative) line.color else Dim, size = 11, hpad = 6,
                                    onClick = { line.showDerivative = !line.showDerivative }
                                )
                                TermTextKey(
                                    if (line.showIntegral) "[∫f shown]" else "[+ ∫f]",
                                    tone = if (line.showIntegral) line.color else Dim, size = 11, hpad = 6,
                                    onClick = { line.showIntegral = !line.showIntegral }
                                )
                            }
                            line.error?.let { Text("  $it", color = Warn, fontFamily = TermFont, fontSize = 11.sp) }
                        }
                    }
                    item {
                        TermTextKey(
                            "[+ add formula]",
                            onClick = {
                                val color = PlotPalette[lines.size % PlotPalette.size]
                                lines.add(PlotLine("", color))
                            }
                        )
                    }
                }
            } else if (mode == "fit") {
                Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                    Text("fit degree", color = Dim, fontFamily = TermFont, fontSize = 11.sp)
                    (1..4).forEach { d ->
                        TermTextKey(
                            "$d", tone = if (fitDegree == d) Accent else Ink, bold = fitDegree == d,
                            onClick = {
                                fitDegree = d
                                val f = compiledFirst
                                if (f != null) {
                                    val minX = centerX - 400 * unitsPerPx; val maxX = centerX + 400 * unitsPerPx
                                    val pts = (0..160).map { i -> val x = minX + (maxX - minX) * i / 160.0; x.toDouble() to (try { f(x.toDouble()) } catch (e: Exception) { Double.NaN }) }
                                    val fit = GraphMath.polyFit(pts, d)
                                    fitCurve = fit
                                    fitNote = if (fit == null) "Not enough points to fit." else "y ≈ ${fit.formula()}   R² = ${fmtG(fit.r2)}"
                                }
                            }
                        )
                    }
                }
                Text(
                    if (firstVisible == null) "Type a formula in [Plot] first, then come back to Fit."
                    else fitNote.ifBlank { "Fitting the visible range of \"${firstVisible.text}\" to a degree-$fitDegree polynomial." },
                    color = Ink, fontFamily = TermFont, fontSize = 12.sp
                )
                Text("Least-squares fit over the x-range currently in view — pan/zoom the Plot tab first to change it.", color = Dim, fontFamily = TermFont, fontSize = 10.sp)
            } else {
                Text("Table of \"${firstVisible?.text ?: "—"}\" over the visible x-range.", color = Dim, fontFamily = TermFont, fontSize = 11.sp)
            }
        }
    }
}

private fun fmtG(v: Double): String {
    if (v.isNaN() || v.isInfinite()) return "—"
    val r = Math.round(v * 1000.0) / 1000.0
    return if (r == r.toLong().toDouble()) r.toLong().toString() else r.toString()
}

@Composable
private fun TableView(formula: String?, f: ((Double) -> Double)?, centerX: Float, unitsPerPx: Float) {
    if (formula == null || f == null) {
        Text("No valid formula to tabulate.", color = Dim, fontFamily = TermFont, fontSize = 12.sp, modifier = Modifier.padding(12.dp))
        return
    }
    val step = GraphMath.niceStep(unitsPerPx * 80.0)
    val rows = remember(formula, centerX, step) {
        (-10..10).map { i -> val x = centerX + i * step.toFloat(); x.toDouble() to (try { f(x.toDouble()) } catch (e: Exception) { Double.NaN }) }
    }
    Column(Modifier.fillMaxSize().padding(10.dp)) {
        Row(Modifier.fillMaxWidth()) {
            Text("x", color = Accent, fontFamily = TermFont, fontSize = 13.sp, modifier = Modifier.weight(1f), textAlign = TextAlign.Center)
            Text("f(x)", color = Accent, fontFamily = TermFont, fontSize = 13.sp, modifier = Modifier.weight(1f), textAlign = TextAlign.Center)
        }
        LazyColumn(Modifier.fillMaxSize()) {
            items(rows.size) { i ->
                val pair = rows[i]
                Row(Modifier.fillMaxWidth().padding(vertical = 3.dp)) {
                    Text(fmtG(pair.first), color = Ink, fontFamily = TermFont, fontSize = 13.sp, modifier = Modifier.weight(1f), textAlign = TextAlign.Center)
                    Text(fmtG(pair.second), color = Ink, fontFamily = TermFont, fontSize = 13.sp, modifier = Modifier.weight(1f), textAlign = TextAlign.Center)
                }
            }
        }
    }
}

@Composable
private fun FitCanvas(formula: String?, f: ((Double) -> Double)?, centerX: Float, centerY: Float, unitsPerPx: Float, fit: GraphMath.PolyFit?) {
    Canvas(Modifier.fillMaxSize()) {
        val w = size.width; val h = size.height
        val upp = unitsPerPx.toDouble()
        fun sx(wx: Double) = ((wx - centerX) / upp + w / 2).toFloat()
        fun sy(wy: Double) = (h / 2 - (wy - centerY) / upp).toFloat()

        val step = GraphMath.niceStep(upp * 80.0)
        var gx = Math.floor((centerX - w / 2 * upp) / step) * step
        while (gx <= centerX + w / 2 * upp) { drawLine(Line, Offset(sx(gx), 0f), Offset(sx(gx), h), 1f); gx += step }
        var gy = Math.floor((centerY - h / 2 * upp) / step) * step
        while (gy <= centerY + h / 2 * upp) { drawLine(Line, Offset(0f, sy(gy)), Offset(w, sy(gy)), 1f); gy += step }

        if (f != null) {
            var prev: Offset? = null
            var px = 0
            while (px <= w.toInt()) {
                val wx = centerX + (px - w / 2) * upp
                val y = try { f(wx.toDouble()) } catch (e: Exception) { Double.NaN }
                if (!y.isNaN() && !y.isInfinite()) {
                    val cur = Offset(px.toFloat(), sy(y))
                    if (prev != null) drawLine(PlotPalette[0].copy(alpha = 0.55f), prev!!, cur, strokeWidth = 3f, cap = StrokeCap.Round)
                    prev = cur
                } else prev = null
                px += 2
            }
        }
        if (fit != null) {
            var prev: Offset? = null
            var px = 0
            while (px <= w.toInt()) {
                val wx = centerX + (px - w / 2) * upp
                val y = fit.eval(wx.toDouble())
                val cur = Offset(px.toFloat(), sy(y))
                if (prev != null) drawLine(Color(0xFFFFE85C), prev!!, cur, strokeWidth = 3f, cap = StrokeCap.Round)
                prev = cur
                px += 2
            }
        }
    }
}

@Composable
private fun GraphCanvas(
    lines: List<PlotLine>,
    centerX: Float,
    centerY: Float,
    unitsPerPx: Float,
    intersections: List<Pair<Double, Double>> = emptyList()
) {
    Canvas(Modifier.fillMaxSize()) {
        val w = size.width
        val h = size.height
        val upp = unitsPerPx.toDouble()

        fun worldToScreenX(wx: Double) = ((wx - centerX) / upp + w / 2).toFloat()
        fun worldToScreenY(wy: Double) = (h / 2 - (wy - centerY) / upp).toFloat()

        val step = GraphMath.niceStep(upp * 80.0)
        val minX = centerX - w / 2 * upp
        val maxX = centerX + w / 2 * upp
        val minY = centerY - h / 2 * upp
        val maxY = centerY + h / 2 * upp

        var gx = Math.floor(minX / step) * step
        while (gx <= maxX) {
            val sx = worldToScreenX(gx)
            val bold = Math.abs(gx) < step / 1000.0
            drawLine(color = if (bold) Dim else Line, start = Offset(sx, 0f), end = Offset(sx, h), strokeWidth = if (bold) 2f else 1f)
            gx += step
        }
        var gy = Math.floor(minY / step) * step
        while (gy <= maxY) {
            val sy = worldToScreenY(gy)
            val bold = Math.abs(gy) < step / 1000.0
            drawLine(color = if (bold) Dim else Line, start = Offset(0f, sy), end = Offset(w, sy), strokeWidth = if (bold) 2f else 1f)
            gy += step
        }

        lines.forEach { line ->
            if (!line.visible || line.text.isBlank()) { line.error = null; return@forEach }
            val f = try {
                GraphMath.compile(line.text)
            } catch (e: Exception) {
                line.error = e.message ?: "can't parse this formula"
                return@forEach
            }
            line.error = null

            var prev: Offset? = null
            var px = 0
            val maxJumpPx = h * 4
            while (px <= w.toInt()) {
                val wx = centerX + (px - w / 2) * upp
                val y = try { f(wx) } catch (e: Exception) { Double.NaN }
                if (y.isNaN() || y.isInfinite()) {
                    prev = null
                } else {
                    val cur = Offset(px.toFloat(), worldToScreenY(y))
                    val p = prev
                    if (p != null && Math.abs(cur.y - p.y) < maxJumpPx) {
                        drawLine(color = line.color, start = p, end = cur, strokeWidth = 3f, cap = StrokeCap.Round)
                    }
                    prev = cur
                }
                px += 2
            }

            if (line.showDerivative) {
                var pv: Offset? = null
                var qx = 0
                while (qx <= w.toInt()) {
                    val wx = centerX + (qx - w / 2) * upp
                    val d = try { GraphMath.derivative(f, wx) } catch (e: Exception) { Double.NaN }
                    if (!d.isNaN() && !d.isInfinite()) {
                        val cur = Offset(qx.toFloat(), worldToScreenY(d))
                        if (pv != null && Math.abs(cur.y - pv.y) < maxJumpPx) {
                            drawLine(color = line.color.copy(alpha = 0.65f), start = pv!!, end = cur, strokeWidth = 2f, cap = StrokeCap.Round)
                        }
                        pv = cur
                    } else pv = null
                    qx += 3
                }
            }
            if (line.showIntegral) {
                val curve = GraphMath.integralCurve(f, minX.toDouble(), maxX.toDouble(), 160)
                var pv: Offset? = null
                curve.forEach { pair ->
                    val cur = Offset(worldToScreenX(pair.first), worldToScreenY(pair.second))
                    if (pv != null) drawLine(color = line.color.copy(alpha = 0.9f), start = pv!!, end = cur, strokeWidth = 2f, cap = StrokeCap.Round)
                    pv = cur
                }
            }
        }

        intersections.forEach { pair ->
            val sx = worldToScreenX(pair.first); val sy = worldToScreenY(pair.second)
            drawCircle(color = Color.White, radius = 7f, center = Offset(sx, sy), style = Stroke(width = 2f))
            drawCircle(color = Color(0xFFFFE85C), radius = 3f, center = Offset(sx, sy))
        }
    }
}
