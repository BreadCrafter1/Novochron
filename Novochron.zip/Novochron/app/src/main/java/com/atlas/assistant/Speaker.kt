package com.atlas.assistant

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.Base64
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale

/**
 * Text-to-speech with a bright, youthful, anime-styled voice.
 *
 * Online with a Gemini API key, speech is synthesized by Gemini's TTS model using a youthful voice
 * plus a style instruction asking for a cheerful, high-pitched anime-girl delivery, and played back
 * with AudioTrack. Offline (or with no key), it falls back to the device's own text-to-speech engine
 * with the brightest female voice available, so Novochron can still talk with no internet.
 *
 * Usage for a streamed reply: begin(), enqueue(sentence) for each sentence as it arrives, then end().
 * [finished] fires once, after end() has been called and everything queued has been spoken.
 * stop() cuts speech immediately (used when the user interrupts) and does not fire [finished].
 */
class Speaker(
    context: Context,
    private val store: Store,
    private val finished: () -> Unit
) : TextToSpeech.OnInitListener {

    private val appCtx = context.applicationContext
    private val main = Handler(Looper.getMainLooper())
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    // ---- device (offline fallback) engine ----
    private var tts: TextToSpeech? = null
    private var ready = false
    private var failed = false
    private val backlog = ArrayList<String>()   // text queued before the engine finished starting

    private var gen = 0            // bumped on every begin()/stop() so late callbacks from old speech are ignored
    private var active = false     // a turn is in progress
    private var open = false       // more text may still be added
    private var pending = 0        // chunks handed off (device TTS or cloud) that have not finished yet
    private var pendingChars = 0
    private var counter = 0
    private val lengths = HashMap<String, Int>()

    // ---- cloud (Gemini TTS) playback ----
    private val cloudQueue = ArrayDeque<Pair<String, String>>() // piece to id, kept in order
    private var cloudBusy = false
    private var fetchJob: Job? = null
    private var track: AudioTrack? = null
    private var playbackRunnable: Runnable? = null

    private val watchdog = Runnable {
        // nothing reported back in time: do not leave the assistant stuck "speaking"
        pending = 0
        pendingChars = 0
        checkDone()
    }

    init {
        tts = TextToSpeech(appCtx, this)
    }

    override fun onInit(status: Int) {
        val t = tts
        if (status != TextToSpeech.SUCCESS || t == null) {
            failed = true
            backlog.clear()
            pending = 0
            pendingChars = 0
            checkDone()
            return
        }
        t.setLanguage(Locale.US)
        pickFallbackVoice(t)
        t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {}
            override fun onDone(utteranceId: String?) { chunkDone(utteranceId) }
            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) { chunkDone(utteranceId) }
        })
        ready = true
        val queued = ArrayList(backlog)
        backlog.clear()
        queued.forEach { piece ->
            val id = "g${gen}u${++counter}"
            lengths[id] = piece.length
            speakLocalPiece(piece, id)
        }
    }

    /** Offline fallback voice: the brightest female voice installed, closest to the anime-girl style without network. */
    private fun pickFallbackVoice(t: TextToSpeech) {
        try {
            val voices = t.voices?.filter { it.locale.language == "en" } ?: return
            val v = voices.firstOrNull { !it.isNetworkConnectionRequired && it.name.lowercase(Locale.US).contains("female") }
                ?: voices.firstOrNull { it.name.lowercase(Locale.US).contains("female") }
            if (v != null) t.setVoice(v)
        } catch (e: Exception) {
            // keep default voice; the raised pitch still makes it brighter
        }
    }

    /** Start a new spoken turn. Anything still being said is cut off. */
    fun begin() {
        halt()
        gen++
        active = true
        open = true
    }

    /** Add text to the current turn. It is spoken right after whatever is already queued. */
    fun enqueue(text: String) {
        if (!active) return
        // By default Novochron only talks out loud while its own screen is the one in front; with
        // the setting off and the app backgrounded, the reply still lands in chat, it's just silent.
        if (!AssistantState.appVisible && !store.speakInBackgroundEnabled) return
        val clean = text.replace(Regex("[*_#`>]"), "").trim()
        if (clean.isEmpty()) return
        var rest = clean
        while (rest.isNotEmpty()) {
            val piece = if (rest.length <= MAX_CHUNK) rest else rest.substring(0, rest.lastIndexOf(' ', MAX_CHUNK).let { if (it > 0) it else MAX_CHUNK })
            rest = rest.substring(piece.length).trim()
            pending++
            pendingChars += piece.length
            speakNow(piece)
        }
        if (failed && cloudQueue.isEmpty() && !cloudBusy) { pending = 0; pendingChars = 0 }
    }

    /** No more text is coming for this turn. */
    fun end() {
        open = false
        checkDone()
    }

    /** Speak one line by itself. */
    fun speak(text: String) {
        begin()
        enqueue(text)
        end()
    }

    /** Cut speech right now. [finished] is not called. */
    fun stop() {
        halt()
        gen++
    }

    private fun halt() {
        main.removeCallbacks(watchdog)
        tts?.stop()
        backlog.clear()
        lengths.clear()
        pending = 0
        pendingChars = 0
        active = false
        open = false
        fetchJob?.cancel()
        fetchJob = null
        cloudQueue.clear()
        cloudBusy = false
        releaseTrack()
    }

    private fun speakNow(piece: String) {
        if (!store.forceOffline && store.apiKey.isNotBlank() && Net.isOnline(appCtx)) {
            val id = "g${gen}u${++counter}"
            lengths[id] = piece.length
            cloudQueue.addLast(piece to id)
            pumpCloud()
        } else if (ready) {
            val id = "g${gen}u${++counter}"
            lengths[id] = piece.length
            speakLocalPiece(piece, id)
        } else if (!failed) {
            backlog.add(piece)
        }
    }

    // ---------- device (offline) playback ----------

    private fun speakLocalPiece(piece: String, id: String) {
        val t = tts
        if (t == null) { chunkDone(id); return }
        t.setPitch(store.pitch)
        t.setSpeechRate(1.05f)
        t.speak(piece, TextToSpeech.QUEUE_ADD, null, id)
        arm()
    }

    // ---------- cloud (Gemini TTS) playback ----------

    /** Runs at most one Gemini TTS request/playback at a time, in the order pieces were queued. */
    private fun pumpCloud() {
        if (cloudBusy) return
        val (piece, id) = cloudQueue.removeFirstOrNull() ?: return
        cloudBusy = true
        arm()
        val myGen = genOf(id)
        fetchJob = scope.launch {
            val result = try { fetchTts(piece) } catch (e: Exception) { null }
            main.post {
                if (myGen != gen) { cloudBusy = false; pumpCloud(); return@post }
                if (result == null) {
                    // network hiccup: fall back to the device voice for this piece rather than going silent
                    cloudBusy = false
                    if (ready) speakLocalPiece(piece, id) else chunkDone(id)
                    pumpCloud()
                } else {
                    playPcm(result.first, result.second, id)
                }
            }
        }
    }

    private fun playPcm(pcm: ByteArray, sampleRate: Int, id: String) {
        try {
            val minBuf = AudioTrack.getMinBufferSize(sampleRate, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
            val at = AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_ASSISTANT)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .build()
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(sampleRate)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                        .build()
                )
                .setBufferSizeInBytes(maxOf(minBuf, pcm.size))
                .setTransferMode(AudioTrack.MODE_STATIC)
                .build()
            at.write(pcm, 0, pcm.size)
            track = at
            at.play()
            // 16-bit mono PCM: 2 bytes per sample.
            val durationMs = pcm.size * 1000L / 2 / sampleRate + 200L
            val r = Runnable {
                cloudBusy = false
                releaseTrack()
                chunkDone(id)
                pumpCloud()
            }
            playbackRunnable = r
            main.postDelayed(r, durationMs)
        } catch (e: Exception) {
            cloudBusy = false
            releaseTrack()
            chunkDone(id)
            pumpCloud()
        }
    }

    private fun releaseTrack() {
        playbackRunnable?.let { main.removeCallbacks(it) }
        playbackRunnable = null
        track?.let {
            try { it.stop() } catch (e: Exception) { }
            try { it.release() } catch (e: Exception) { }
        }
        track = null
    }

    /** Calls Gemini's TTS model and returns raw 16-bit PCM audio plus its sample rate. */
    private fun fetchTts(text: String): Pair<ByteArray, Int> {
        val styled = "Say the following in a bright, cheerful, high-pitched young anime-girl voice, " +
            "playful and energetic, like a character from Japanese animation: $text"
        val body = JSONObject()
            .put("contents", JSONArray().put(JSONObject().put("parts", JSONArray().put(JSONObject().put("text", styled)))))
            .put(
                "generationConfig",
                JSONObject()
                    .put("responseModalities", JSONArray().put("AUDIO"))
                    .put(
                        "speechConfig",
                        JSONObject().put(
                            "voiceConfig",
                            JSONObject().put("prebuiltVoiceConfig", JSONObject().put("voiceName", VOICE_NAME))
                        )
                    )
            )
        val conn = URL(TTS_URL).openConnection() as HttpURLConnection
        try {
            conn.requestMethod = "POST"
            conn.connectTimeout = 6000
            conn.readTimeout = 15000
            conn.doOutput = true
            conn.setRequestProperty("x-goog-api-key", store.apiKey)
            conn.setRequestProperty("content-type", "application/json")
            conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            val code = conn.responseCode
            if (code !in 200..299) throw IOException("tts http $code")
            val respText = conn.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
            val part = JSONObject(respText)
                .optJSONArray("candidates")?.optJSONObject(0)
                ?.optJSONObject("content")?.optJSONArray("parts")?.optJSONObject(0)
                ?: throw IOException("no audio in tts response")
            val inline = part.optJSONObject("inlineData") ?: throw IOException("no inlineData in tts response")
            val mime = inline.optString("mimeType", "audio/L16;rate=24000")
            val rate = Regex("rate=(\\d+)").find(mime)?.groupValues?.get(1)?.toIntOrNull() ?: 24000
            val data = Base64.decode(inline.optString("data"), Base64.DEFAULT)
            return data to rate
        } finally {
            conn.disconnect()
        }
    }

    // ---------- shared bookkeeping ----------

    private fun genOf(id: String): Int = id.removePrefix("g").substringBefore('u').toIntOrNull() ?: -1

    private fun chunkDone(id: String?) {
        main.post {
            if (id == null) return@post
            if (genOf(id) != gen) return@post
            pending = (pending - 1).coerceAtLeast(0)
            pendingChars = (pendingChars - (lengths.remove(id) ?: 0)).coerceAtLeast(0)
            arm()
            checkDone()
        }
    }

    private fun arm() {
        main.removeCallbacks(watchdog)
        if (pending > 0) main.postDelayed(watchdog, 8000L + pendingChars * 90L)
    }

    private fun checkDone() {
        if (active && !open && pending <= 0) {
            active = false
            main.removeCallbacks(watchdog)
            finished()
        }
    }

    companion object {
        private const val MAX_CHUNK = 500
        private const val TTS_URL = "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash-preview-tts:generateContent"
        // "Leda" is Gemini's youthful female preset voice; the style instruction pushes it toward an anime-girl delivery.
        private const val VOICE_NAME = "Leda"
    }
}
