package com.atlas.assistant

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder

/**
 * Holds a foreground-service "slot" of type mediaProjection while a msg screenshare is active.
 * Separate from ScreenCastService (Novochron's own screen-understanding feature) - this one is
 * only used by Calling.kt's [share] button. No work happens here; CallManager does the actual
 * capturing in-process, this just satisfies Android 14+'s requirement and shows the (mandatory)
 * "your screen is being shared" notification.
 */
class MsgScreenShareService : Service() {
    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val channelId = "msg_screenshare"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = getSystemService(NotificationManager::class.java)
            nm?.createNotificationChannel(
                NotificationChannel(channelId, "msg screen sharing", NotificationManager.IMPORTANCE_LOW)
            )
        }
        val notification = Notification.Builder(this, channelId)
            .setContentTitle("Novochron")
            .setContentText("Your screen is being shared in the call")
            .setSmallIcon(R.drawable.ic_stat)
            .build()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(1, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else {
            @Suppress("DEPRECATION")
            startForeground(1, notification)
        }
        return START_NOT_STICKY
    }
}
