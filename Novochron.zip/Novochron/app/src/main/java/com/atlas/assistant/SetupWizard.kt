package com.atlas.assistant

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.background
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.DisposableEffect
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import kotlinx.coroutines.launch

/**
 * First-run wizard, shown once (until [Store.setupComplete] is true) before [MainScreen]. Steps:
 * grant every permission Novochron actually uses, then fetch the offline model. Both PERMISSIONS
 * and MODEL are mandatory - PERMISSIONS can't be continued past until every item
 * [RequiredPermission.all] returns is granted, since features across the app (voice, msg, calls,
 * camera, maps, the visible storage folder) silently misbehave without them, and MODEL can't be
 * continued past without a successful download, since it's the only offline brain Novochron has.
 *
 * There is no separate GitHub-login step: a Personal Access Token is baked into this build at
 * compile time (see [Store.githubToken] / app/build.gradle.kts), so the vault and cloud sync are
 * already linked to GitHub the moment the app opens, with nothing to type in or authorize here.
 */
private enum class SetupStep { WELCOME, PERMISSIONS, MODEL, DONE }

@Composable
fun SetupWizard(
    store: Store,
    onStorage: () -> Unit,
    onFinish: () -> Unit
) {
    var step by rememberSaveable { mutableStateOf(SetupStep.WELCOME) }

    Box(Modifier.fillMaxSize().background(CardBg), contentAlignment = Alignment.Center) {
        Column(
            Modifier
                .widthIn(max = 480.dp)
                .padding(28.dp)
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            StepDots(step)
            Spacer(Modifier.height(20.dp))
            when (step) {
                SetupStep.WELCOME -> WelcomeStep { step = SetupStep.PERMISSIONS }
                SetupStep.PERMISSIONS -> PermissionsStep(
                    onStorage = onStorage,
                    onNext = { step = SetupStep.MODEL }
                )
                SetupStep.MODEL -> ModelStep(onNext = { step = SetupStep.DONE })
                SetupStep.DONE -> DoneStep {
                    store.setupComplete = true
                    onFinish()
                }
            }
        }
    }
}

/** The steps a person actually walks through - DONE is the finish line, not counted as one of them. */
private val ORDERED_STEPS = listOf(SetupStep.WELCOME, SetupStep.PERMISSIONS, SetupStep.MODEL)

/** Small "step 2 of 4" dot row plus label, so it's obvious how much of setup is left and when it's finished. */
@Composable
private fun StepDots(step: SetupStep) {
    if (step == SetupStep.DONE) {
        Text("Setup complete", color = Accent, fontSize = 13.sp, fontWeight = FontWeight.Bold)
        return
    }
    val index = ORDERED_STEPS.indexOf(step).coerceAtLeast(0)
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        ORDERED_STEPS.forEachIndexed { i, _ ->
            Box(
                Modifier
                    .height(6.dp)
                    .width(if (i == index) 22.dp else 6.dp)
                    .clip(CircleShape)
                    .background(if (i <= index) Accent else Raised)
            )
        }
    }
    Spacer(Modifier.height(8.dp))
    Text("Step ${index + 1} of ${ORDERED_STEPS.size}", color = Dim, fontSize = 12.sp)
}

@Composable
private fun StepTitle(text: String) = Text(
    text, color = Ink, fontSize = 22.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center
)

@Composable
private fun StepBody(text: String) = Text(
    text, color = Dim, fontSize = 15.sp, textAlign = TextAlign.Center,
    modifier = Modifier.padding(top = 10.dp, bottom = 24.dp)
)

@Composable
private fun PrimaryButton(text: String, onClick: () -> Unit) = Button(
    onClick = onClick,
    colors = ButtonDefaults.buttonColors(containerColor = Accent, contentColor = androidx.compose.ui.graphics.Color.Black),
    modifier = Modifier.fillMaxWidth().height(52.dp)
) { Text(text, fontWeight = FontWeight.Bold) }

@Composable
private fun WelcomeStep(onNext: () -> Unit) {
    StepTitle("Welcome to Novochron")
    StepBody("A quick one-time setup: grant the permissions Novochron needs, then download the offline model. GitHub, the vault and cloud sync are already linked - nothing to log into.")
    PrimaryButton("Get started", onNext)
}

/** One row in the mandatory permissions checklist. [permissions] is the set of runtime permission
 *  strings that must ALL be granted for this item to count (e.g. fine+coarse location together);
 *  empty means it's a "special" permission ([isGranted] does the check itself, e.g. all-files access,
 *  which has no entry in the standard runtime-permission dialog). */
private class RequiredPermission(
    val label: String,
    val description: String,
    val permissions: List<String>,
    val isSpecial: Boolean = false,
    val isGranted: (Context) -> Boolean
) {
    companion object {
        fun all(): List<RequiredPermission> = buildList {
            add(RequiredPermission(
                "Microphone", "Voice commands and the wake word",
                listOf(Manifest.permission.RECORD_AUDIO)
            ) { ctx -> granted(ctx, Manifest.permission.RECORD_AUDIO) })
            add(RequiredPermission(
                "Camera", "Photo capture, scanning what's in view, and msg's video call",
                listOf(Manifest.permission.CAMERA)
            ) { ctx -> granted(ctx, Manifest.permission.CAMERA) })
            add(RequiredPermission(
                "Phone", "Placing calls",
                listOf(Manifest.permission.CALL_PHONE)
            ) { ctx -> granted(ctx, Manifest.permission.CALL_PHONE) })
            add(RequiredPermission(
                "Contacts", "Calling or messaging someone by name",
                listOf(Manifest.permission.READ_CONTACTS)
            ) { ctx -> granted(ctx, Manifest.permission.READ_CONTACTS) })
            add(RequiredPermission(
                "SMS", "Sending texts",
                listOf(Manifest.permission.SEND_SMS)
            ) { ctx -> granted(ctx, Manifest.permission.SEND_SMS) })
            add(RequiredPermission(
                "Location", "Learning places and offline distance lookups",
                listOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)
            ) { ctx -> granted(ctx, Manifest.permission.ACCESS_FINE_LOCATION) || granted(ctx, Manifest.permission.ACCESS_COARSE_LOCATION) })
            if (Build.VERSION.SDK_INT >= 33) add(RequiredPermission(
                "Notifications", "Message alerts and the listening/call status bar",
                listOf(Manifest.permission.POST_NOTIFICATIONS)
            ) { ctx -> granted(ctx, Manifest.permission.POST_NOTIFICATIONS) })
            if (Build.VERSION.SDK_INT >= 31) add(RequiredPermission(
                "Bluetooth", "Voice control of connected devices",
                listOf(Manifest.permission.BLUETOOTH_CONNECT)
            ) { ctx -> granted(ctx, Manifest.permission.BLUETOOTH_CONNECT) })
            if (Build.VERSION.SDK_INT < 30) add(RequiredPermission(
                "Storage", "Reading and writing the Novochron/ folder",
                listOf(Manifest.permission.WRITE_EXTERNAL_STORAGE)
            ) { ctx -> granted(ctx, Manifest.permission.WRITE_EXTERNAL_STORAGE) })
            add(RequiredPermission(
                "All files access", "Keeps chats, memory, photos and the offline model in a visible Novochron/ folder instead of a private sandbox",
                emptyList(), isSpecial = true
            ) { NovochronStorage.hasAccess() })
        }
        private fun granted(ctx: Context, perm: String) =
            ctx.checkSelfPermission(perm) == PackageManager.PERMISSION_GRANTED
    }
}

/**
 * Mandatory checklist step - unlike every other step in the wizard, this one has no "skip"; Novochron's
 * core features (voice, msg, calls, camera, maps, the visible storage folder) don't work right without
 * these, so onNext only becomes reachable once every [RequiredPermission] reports granted. Re-checks on
 * every resume (covers both the runtime-permission dialog and the "All files access" Settings screen,
 * which reports back via onResume rather than an activity result).
 */
@Composable
private fun PermissionsStep(onStorage: () -> Unit, onNext: () -> Unit) {
    val ctx = LocalContext.current
    val items = remember { RequiredPermission.all() }
    var tick by remember { mutableStateOf(0) } // bumped to force re-evaluating isGranted() below
    val missing = remember(tick) { items.filter { !it.isGranted(ctx) } }
    val allGranted = missing.isEmpty()

    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        tick++
    }

    // Re-check when coming back from the runtime-permission dialog or the "All files access" Settings screen.
    val lifecycleOwner = LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) tick++
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    StepTitle("Permissions")
    StepBody(
        if (allGranted)
            "Everything Novochron needs is granted."
        else
            "Novochron needs all of these to work properly - grant each one to continue."
    )

    Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(2.dp)) {
        items.forEach { item -> PermissionRow(item, item.isGranted(ctx)) }
    }
    Spacer(Modifier.height(16.dp))

    if (!allGranted) {
        PrimaryButton("Grant permissions") {
            val runtimeMissing = missing.filter { !it.isSpecial }.flatMap { it.permissions }.distinct()
            if (runtimeMissing.isNotEmpty()) launcher.launch(runtimeMissing.toTypedArray())
            if (missing.any { it.isSpecial }) onStorage()
        }
        Spacer(Modifier.height(10.dp))
        Text(
            "Continue unlocks once everything above is granted.",
            color = Dim, fontSize = 12.sp, textAlign = TextAlign.Center
        )
    } else {
        PrimaryButton("Continue", onNext)
    }
}

@Composable
private fun PermissionRow(item: RequiredPermission, granted: Boolean) {
    Row(
        Modifier.fillMaxWidth().padding(vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier
                .height(20.dp).width(20.dp)
                .clip(CircleShape)
                .background(if (granted) Accent else Raised),
            contentAlignment = Alignment.Center
        ) {
            if (granted) Text("✓", color = androidx.compose.ui.graphics.Color.Black, fontSize = 12.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.width(12.dp))
        Column {
            Text(item.label, color = Ink, fontSize = 14.sp, fontWeight = FontWeight.Bold)
            Text(item.description, color = Dim, fontSize = 12.sp)
        }
    }
}

/** True only when the active network is Wi-Fi (not just "online" - [CloudSync.isOnline] covers that
 *  case already). Used to warn before pulling down a ~1GB model on mobile data. */
private fun isOnWifi(ctx: Context): Boolean = try {
    val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
    val caps = cm.getNetworkCapabilities(cm.activeNetwork)
    caps != null && caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)
} catch (e: Exception) {
    false
}

/** Mandatory, like PERMISSIONS: there is no "skip" here - Gemma-3-1B-IT is the only brain Novochron
 *  has with no internet connection, so setup can't finish without it landing in Novochron/Models/. */
@Composable
private fun ModelStep(onNext: () -> Unit) {
    var state by remember { mutableStateOf<ModelDownloader.Progress?>(null) }
    val scope = rememberCoroutineScope()
    val ctx = LocalContext.current
    var onWifi by remember { mutableStateOf(isOnWifi(ctx)) }

    StepTitle("Offline model")
    StepBody("Downloading Gemma-3-1B-IT so Novochron can still chat with no internet connection. It's about 1 GB, saved straight into Novochron/Models/. This is required - you can swap in a different model there later, but setup needs one now.")

    when (val s = state) {
        is ModelDownloader.Progress.InProgress -> {
            val fraction = if (s.bytesTotal > 0) (s.bytesDone.toFloat() / s.bytesTotal.toFloat()).coerceIn(0f, 1f) else 0f
            Column(Modifier.fillMaxWidth()) {
                LinearProgressIndicator(
                    progress = { fraction },
                    modifier = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp)),
                    color = Accent, trackColor = Raised
                )
                Spacer(Modifier.height(8.dp))
                Text(downloadLabel(s), color = Dim, fontSize = 13.sp)
                Text("Keep the app open and stay connected until this finishes.", color = Dim, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp))
            }
        }
        is ModelDownloader.Progress.Done -> {
            Text("Downloaded — ready to use offline.", color = Accent, fontSize = 14.sp)
            Spacer(Modifier.height(16.dp))
            PrimaryButton("Continue", onNext)
        }
        is ModelDownloader.Progress.Failed -> {
            Text(s.message, color = Warn, fontSize = 13.sp, textAlign = TextAlign.Center)
            Spacer(Modifier.height(16.dp))
            PrimaryButton("Retry") { onWifi = isOnWifi(ctx); state = null }
        }
        null -> {
            if (!onWifi) {
                Text(
                    "You're not on Wi-Fi right now. This download is large (about 1 GB) and may use a lot of your mobile data plan.",
                    color = Warn, fontSize = 13.sp, textAlign = TextAlign.Center,
                    modifier = Modifier.padding(bottom = 14.dp)
                )
            }
            PrimaryButton(if (onWifi) "Download" else "Download anyway") {
                state = ModelDownloader.Progress.InProgress(0, -1)
                scope.launch {
                    ModelDownloader.download { p -> state = p }
                }
            }
            if (!onWifi) {
                Spacer(Modifier.height(12.dp))
                TextButton(onClick = { onWifi = isOnWifi(ctx) }) { Text("I've connected to Wi-Fi — check again", color = Dim) }
            }
        }
    }
}

private fun downloadLabel(p: ModelDownloader.Progress.InProgress): String {
    val doneMb = p.bytesDone / (1024 * 1024)
    return if (p.bytesTotal > 0) {
        val totalMb = p.bytesTotal / (1024 * 1024)
        "Downloading… ${doneMb} MB / ${totalMb} MB"
    } else {
        "Downloading… ${doneMb} MB"
    }
}

@Composable
private fun DoneStep(onFinish: () -> Unit) {
    StepTitle("All set")
    StepBody("Novochron is ready to go - GitHub, the vault and cloud sync are already linked, so your chats, artifacts and notes start mirroring automatically.")
    PrimaryButton("Enter Novochron", onFinish)
}
