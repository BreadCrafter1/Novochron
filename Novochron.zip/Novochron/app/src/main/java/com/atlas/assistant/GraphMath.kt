package com.atlas.assistant

import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.acos
import kotlin.math.asin
import kotlin.math.atan
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.floor
import kotlin.math.ln
import kotlin.math.log10
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.round
import kotlin.math.sign
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.math.tan

/**
 * Tiny self-contained expression compiler for the `[graph]` screen (see GraphScreen.kt).
 * Deliberately separate from [MathEval]'s parser: that one only does bare arithmetic for the offline
 * calculator (no variables, no functions) and is private to that file. Graphing formulas need a
 * variable (`x`) and named functions (`sin`, `sqrt`, ...), so this is its own small recursive-descent
 * parser producing a reusable closure — `compile()` parses once per formula edit, not once per pixel
 * column, so panning/zooming stays smooth.
 */
object GraphMath {

    class GraphMathException(message: String) : Exception(message)

    private val CONSTANTS = mapOf("pi" to PI, "e" to Math.E, "tau" to (2 * PI))

    private val FUNCTIONS: Map<String, (Double) -> Double> = mapOf(
        "sin" to { x: Double -> sin(x) },
        "cos" to { x: Double -> cos(x) },
        "tan" to { x: Double -> tan(x) },
        "asin" to { x: Double -> asin(x) },
        "acos" to { x: Double -> acos(x) },
        "atan" to { x: Double -> atan(x) },
        "sqrt" to { x: Double -> sqrt(x) },
        "abs" to { x: Double -> abs(x) },
        "ln" to { x: Double -> ln(x) },
        "log" to { x: Double -> log10(x) },
        "exp" to { x: Double -> exp(x) },
        "floor" to { x: Double -> floor(x) },
        "round" to { x: Double -> round(x) },
        "sign" to { x: Double -> sign(x) }
    )

    /** Compiles `formula` (RHS only, e.g. "sin(x) + 1", "x^2 - 3") to `f(x)`. Throws on bad syntax. */
    fun compile(formula: String): (Double) -> Double {
        // Accept "y = ..." / "f(x) = ..." prefixes by dropping anything up to and including the first '='
        val rhs = formula.substringAfter('=', formula).ifBlank { throw GraphMathException("empty") }
        val tokens = Lexer(rhs).lex()
        val ast = Parser(tokens).parseExpr()
        return { x: Double -> ast.eval(x) }
    }

    private sealed class Node {
        abstract fun eval(x: Double): Double
    }
    private class Num(val v: Double) : Node() { override fun eval(x: Double) = v }
    private class Var(val name: String) : Node() {
        override fun eval(x: Double) = if (name == "x") x else CONSTANTS[name]
            ?: throw GraphMathException("unknown name '$name'")
    }
    private class Neg(val a: Node) : Node() { override fun eval(x: Double) = -a.eval(x) }
    private class Bin(val op: Char, val a: Node, val b: Node) : Node() {
        override fun eval(x: Double): Double {
            val l = a.eval(x); val r = b.eval(x)
            return when (op) {
                '+' -> l + r
                '-' -> l - r
                '*' -> l * r
                '/' -> l / r
                '^' -> l.pow(r)
                else -> throw GraphMathException("bad op")
            }
        }
    }
    private class Call(val name: String, val arg: Node) : Node() {
        override fun eval(x: Double): Double {
            val fn = FUNCTIONS[name] ?: throw GraphMathException("unknown function '$name'")
            return fn(arg.eval(x))
        }
    }

    private sealed class Tok {
        data class NumT(val v: Double) : Tok()
        data class Ident(val s: String) : Tok()
        data class Op(val c: Char) : Tok()
    }

    private class Lexer(private val s: String) {
        fun lex(): List<Tok> {
            val out = mutableListOf<Tok>()
            var i = 0
            while (i < s.length) {
                val c = s[i]
                when {
                    c.isWhitespace() -> i++
                    c.isDigit() || c == '.' -> {
                        val start = i
                        while (i < s.length && (s[i].isDigit() || s[i] == '.')) i++
                        out += Tok.NumT(s.substring(start, i).toDouble())
                    }
                    c.isLetter() -> {
                        val start = i
                        while (i < s.length && s[i].isLetterOrDigit()) i++
                        out += Tok.Ident(s.substring(start, i).lowercase())
                    }
                    c in "+-*/^()," -> { out += Tok.Op(c); i++ }
                    else -> throw GraphMathException("unexpected character '$c'")
                }
            }
            return out
        }
    }

    /** + - * / ^ with normal precedence, unary minus, parens, and single-argument function calls. */
    private class Parser(private val toks: List<Tok>) {
        private var i = 0
        private fun peek(): Tok? = toks.getOrNull(i)

        fun parseExpr(): Node {
            val n = expr()
            if (i != toks.size) throw GraphMathException("unexpected trailing input")
            return n
        }

        private fun expr(): Node {
            var v = term()
            while (true) {
                val t = peek()
                if (t is Tok.Op && (t.c == '+' || t.c == '-')) {
                    i++
                    v = Bin(t.c, v, term())
                } else break
            }
            return v
        }

        private fun term(): Node {
            var v = factor()
            while (true) {
                val t = peek()
                if (t is Tok.Op && (t.c == '*' || t.c == '/')) {
                    i++
                    v = Bin(t.c, v, factor())
                } else if (t is Tok.Ident || (t is Tok.Op && t.c == '(')) {
                    // implicit multiplication: "2x", "3sin(x)", "2(x+1)"
                    v = Bin('*', v, factor())
                } else break
            }
            return v
        }

        private fun factor(): Node {
            val base = unary()
            val t = peek()
            return if (t is Tok.Op && t.c == '^') { i++; Bin('^', base, factor()) } else base
        }

        private fun unary(): Node {
            val t = peek()
            if (t is Tok.Op && t.c == '-') { i++; return Neg(unary()) }
            if (t is Tok.Op && t.c == '+') { i++; return unary() }
            return primary()
        }

        private fun primary(): Node {
            val t = peek() ?: throw GraphMathException("unexpected end of formula")
            return when {
                t is Tok.NumT -> { i++; Num(t.v) }
                t is Tok.Op && t.c == '(' -> {
                    i++
                    val n = expr()
                    val close = peek()
                    if (close is Tok.Op && close.c == ')') i++ else throw GraphMathException("missing ')'")
                    n
                }
                t is Tok.Ident -> {
                    i++
                    val next = peek()
                    if (next is Tok.Op && next.c == '(') {
                        i++
                        val arg = expr()
                        val close = peek()
                        if (close is Tok.Op && close.c == ')') i++ else throw GraphMathException("missing ')'")
                        Call(t.s, arg)
                    } else {
                        Var(t.s)
                    }
                }
                else -> throw GraphMathException("unexpected token")
            }
        }
    }

    /** "Nice" gridline spacing (1/2/5 * power of ten) closest to `targetUnitsPerGridline`. */
    fun niceStep(targetUnitsPerGridline: Double): Double {
        val t = max(targetUnitsPerGridline, 1e-9)
        val mag = 10.0.pow(floor(log10(t)))
        val residual = t / mag
        val step = when {
            residual < 1.5 -> 1.0
            residual < 3.5 -> 2.0
            residual < 7.5 -> 5.0
            else -> 10.0
        }
        return step * mag
    }

    fun clamp(v: Double, lo: Double, hi: Double) = min(max(v, lo), hi)

    /** Numeric derivative of a compiled formula at [x] via central difference — no symbolic differentiation
     *  needed since [compile] only ever hands back an opaque `(Double) -> Double` closure. */
    fun derivative(f: (Double) -> Double, x: Double, h: Double = 1e-4): Double {
        val hh = h.coerceAtLeast(1e-6)
        return (f(x + hh) - f(x - hh)) / (2 * hh)
    }

    /**
     * x-values in [xMin, xMax] where two compiled curves cross, found by sampling for sign changes in
     * (f - g) across [samples] steps and bisecting each crossing down to a tight tolerance. Skips NaN/
     * infinite samples (asymptotes) rather than treating them as a crossing.
     */
    fun findIntersections(f: (Double) -> Double, g: (Double) -> Double, xMin: Double, xMax: Double, samples: Int = 800): List<Double> {
        if (xMax <= xMin) return emptyList()
        fun diff(x: Double): Double = try {
            val d = f(x) - g(x)
            if (d.isNaN() || d.isInfinite()) Double.NaN else d
        } catch (e: Exception) { Double.NaN }

        val step = (xMax - xMin) / samples
        val out = mutableListOf<Double>()
        var xPrev = xMin
        var dPrev = diff(xPrev)
        for (i in 1..samples) {
            val x = xMin + step * i
            val d = diff(x)
            if (!dPrev.isNaN() && !d.isNaN()) {
                if (dPrev == 0.0) {
                    out += xPrev
                } else if ((dPrev > 0) != (d > 0)) {
                    var lo = xPrev; var hi = x; var loVal = dPrev
                    repeat(40) {
                        val mid = (lo + hi) / 2.0
                        val midVal = diff(mid)
                        if (!midVal.isNaN() && (midVal > 0) == (loVal > 0)) { lo = mid; loVal = midVal } else hi = mid
                    }
                    out += (lo + hi) / 2.0
                }
            }
            xPrev = x; dPrev = d
        }
        // de-dupe crossings that landed within the same tiny bucket (e.g. a tangency the sampler saw twice)
        return out.distinctBy { Math.round(it * 1_000.0) }
    }

    /** Numeric definite integral of [f] from [a] to [b] via Simpson's rule. NaN samples count as 0 (skip the gap). */
    fun integral(f: (Double) -> Double, a: Double, b: Double, steps: Int = 400): Double {
        if (b == a) return 0.0
        val n = if (steps % 2 == 0) steps else steps + 1
        val h = (b - a) / n
        fun s(x: Double): Double { val y = try { f(x) } catch (e: Exception) { Double.NaN }; return if (y.isNaN() || y.isInfinite()) 0.0 else y }
        var sum = s(a) + s(b)
        for (i in 1 until n) sum += (if (i % 2 == 0) 2.0 else 4.0) * s(a + i * h)
        return sum * h / 3.0
    }

    /** Running integral values sampled at [n] evenly spaced x's from [a] to [b] (for drawing an integral curve). */
    fun integralCurve(f: (Double) -> Double, a: Double, b: Double, n: Int): List<Pair<Double, Double>> {
        if (n < 2 || b <= a) return emptyList()
        val h = (b - a) / (n - 1)
        val out = ArrayList<Pair<Double, Double>>(n)
        var acc = 0.0
        var prevX = a
        fun s(x: Double): Double { val y = try { f(x) } catch (e: Exception) { Double.NaN }; return if (y.isNaN() || y.isInfinite()) 0.0 else y }
        var prevY = s(a)
        out.add(a to 0.0)
        for (i in 1 until n) {
            val x = a + i * h
            val y = s(x)
            acc += (prevY + y) / 2.0 * (x - prevX)
            out.add(x to acc)
            prevX = x; prevY = y
        }
        return out
    }

    /** Least-squares polynomial fit of [xs]/[ys] to the given [degree] (normal equations via Gaussian elimination). */
    data class PolyFit(val coeffs: List<Double>, val r2: Double) {
        fun eval(x: Double): Double {
            var acc = 0.0; var p = 1.0
            coeffs.forEach { c -> acc += c * p; p *= x }
            return acc
        }
        /** Formula string, highest power first, e.g. "1.2x^2 + 0.5x - 3". */
        fun formula(): String {
            val n = coeffs.size - 1
            val terms = (n downTo 0).mapNotNull { p ->
                val c = coeffs[p]
                if (kotlin.math.abs(c) < 1e-9 && n > 0) return@mapNotNull null
                val mag = "%.4g".format(kotlin.math.abs(c)).trimEnd('0').trimEnd('.')
                val varPart = when (p) { 0 -> ""; 1 -> "x"; else -> "x^$p" }
                (if (c < 0) "-" else "+") to (if (varPart.isEmpty()) mag else "$mag$varPart")
            }
            if (terms.isEmpty()) return "0"
            val sb = StringBuilder()
            terms.forEachIndexed { i, (sign, mag) ->
                if (i == 0) { if (sign == "-") sb.append("-"); sb.append(mag) }
                else sb.append(" $sign ").append(mag)
            }
            return sb.toString()
        }
    }

    fun polyFit(points: List<Pair<Double, Double>>, degree: Int): PolyFit? {
        val pts = points.filter { !it.first.isNaN() && !it.second.isNaN() && it.first.isFinite() && it.second.isFinite() }
        val d = degree.coerceAtMost(pts.size - 1).coerceAtLeast(0)
        if (pts.size < d + 1) return null
        val n = d + 1
        // normal equations: A^T A c = A^T y, A's columns are x^0..x^d
        val ata = Array(n) { DoubleArray(n) }
        val aty = DoubleArray(n)
        pts.forEach { (x, y) ->
            val powers = DoubleArray(n).also { var p = 1.0; for (i in 0 until n) { it[i] = p; p *= x } }
            for (i in 0 until n) {
                aty[i] += powers[i] * y
                for (j in 0 until n) ata[i][j] += powers[i] * powers[j]
            }
        }
        // Gaussian elimination with partial pivoting
        for (col in 0 until n) {
            var piv = col
            for (r in col + 1 until n) if (abs(ata[r][col]) > abs(ata[piv][col])) piv = r
            if (abs(ata[piv][col]) < 1e-12) return null
            val tmp = ata[col]; ata[col] = ata[piv]; ata[piv] = tmp
            val tv = aty[col]; aty[col] = aty[piv]; aty[piv] = tv
            val pv = ata[col][col]
            for (j in col until n) ata[col][j] /= pv
            aty[col] /= pv
            for (r in 0 until n) {
                if (r == col) continue
                val f = ata[r][col]
                if (f == 0.0) continue
                for (j in col until n) ata[r][j] -= f * ata[col][j]
                aty[r] -= f * aty[col]
            }
        }
        val coeffs = aty.toList()
        val meanY = pts.sumOf { it.second } / pts.size
        var ssRes = 0.0; var ssTot = 0.0
        pts.forEach { (x, y) ->
            var pred = 0.0; var p = 1.0
            for (i in 0 until n) { pred += coeffs[i] * p; p *= x }
            ssRes += (y - pred) * (y - pred)
            ssTot += (y - meanY) * (y - meanY)
        }
        val r2 = if (ssTot < 1e-12) 1.0 else (1.0 - ssRes / ssTot).coerceIn(-1.0, 1.0)
        return PolyFit(coeffs, r2)
    }
}
