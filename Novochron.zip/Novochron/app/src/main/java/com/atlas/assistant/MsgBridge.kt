package com.atlas.assistant

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import org.json.JSONArray
import java.io.File

/**
 * Everything [MsgScreen] owns (sendText, the live message list, the call manager) is local Compose
 * state, so a voice command handled in [Commands] - which may run before msg has ever been opened -
 * can't call into it directly. Instead a request is dropped here; [MsgScreen] watches these flows
 * whenever it's on screen and clears each one once it's handled.
 *
 * Reading recent messages is the exception: it doesn't need the screen open at all, since it just
 * reads the same on-disk cache MsgScreen keeps for instant startup (see msgSaveCache/msgLoadCache
 * in MsgScreen.kt). This is a separate, minimal reader so those `private` functions stay untouched.
 */
object MsgBridge {
    /** Text a voice command wants sent through [msg]; MsgScreen sends it and resets this to null. */
    val sendRequest = MutableStateFlow<String?>(null)
    /** "Initiate call" (false) / "Initiate video call" (true); MsgScreen starts it and resets this to null. */
    val callRequest = MutableStateFlow<Boolean?>(null)
    /** "Answer"/"decline" while a call is ringing (true = answer, false = decline), paired with when it
     *  was asked so a stale request can't be applied to a later, unrelated call. MsgScreen actions it
     *  once the ringing screen is confirmed up, and resets this to null either way. */
    val callAnswerRequest = MutableStateFlow<Pair<Boolean, Long>?>(null)

    data class RecentMsg(val sender: String, val ts: Long, val type: String, val text: String)

    /** Last [count] messages from the on-disk chat cache, oldest first. Empty if msg was never opened yet. */
    fun recent(ctx: Context, store: Store, count: Int): List<RecentMsg> {
        val repo = store.msgRepo
        if (repo.isBlank()) return emptyList()
        val f = File(ctx.filesDir, "msg_chat_${"$repo@${store.githubBranch}".hashCode()}.json")
        if (!f.exists()) return emptyList()
        return try {
            val arr = JSONArray(f.readText())
            (0 until arr.length()).map {
                val o = arr.getJSONObject(it)
                RecentMsg(o.optString("from", "them"), o.optLong("ts", 0L), o.optString("type", "TEXT"), o.optString("text", ""))
            }.sortedBy { it.ts }.takeLast(count)
        } catch (e: Exception) { emptyList() }
    }
}
