package com.atlas.assistant

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import kotlinx.coroutines.flow.MutableStateFlow

/** Observable state shared between the service, the engine and the UI. */
object AssistantState {
    val messages = MutableStateFlow<List<Msg>>(emptyList())
    val status = MutableStateFlow("Voice off")
    val voiceOn = MutableStateFlow(false)
    val heard = MutableStateFlow("")
    /** Manual online/offline toggle, mirrors Store.forceOffline so every screen sees the same live state. */
    val forceOffline = MutableStateFlow(false)
    /** Mirrors Store.wakeWordEnabled: while true, Novochron waits for the wake phrase before reacting. */
    val wakeWordOn = MutableStateFlow(false)
    /** True from Novochron's first spoken sentence until speech ends or is cut off (drives the on-screen character's mouth). */
    val speaking = MutableStateFlow(false)
    /** Mirrors Store.mascotOn: show the line-art character behind the conversation. */
    val mascotOn = MutableStateFlow(true)

    /** Id of the artifact currently open full screen (0 = none). */
    val openArtifact = MutableStateFlow(0L)
    val showLibrary = MutableStateFlow(false)
    /** True while the full-screen offline map (pinpoint + distance) is open. */
    val showMap = MutableStateFlow(false)
    /** True while the terminal (local sandbox shell + GitHub login/repo/build commands) is open. */
    val showTerminal = MutableStateFlow(false)
    /** True while the vault (upload/delete files in a GitHub repo, once logged in) is open. */
    val showVault = MutableStateFlow(false)
    val showMsg = MutableStateFlow(false)
    /** True while the "[chats]" screen (switch/rename/delete saved conversations) is open. */
    val showChats = MutableStateFlow(false)

    // [graph]: Desmos-style plotting calculator (see GraphScreen.kt)
    val showGraph = MutableStateFlow(false)

    // [sim]: 3D solar system / Proxima Centauri / TRAPPIST-1 orbit viewer (see SolarSystemScreen.kt)
    val showSolar = MutableStateFlow(false)

    // Which tab of the sim/graph lab was last open: "sim", "sky", "plan", "nbody" (the [graph] tab is its own screen)
    val labTab = MutableStateFlow("sim")

    // [stats]: local, offline usage-stats screen (see UsageStatsScreen.kt)
    val showStats = MutableStateFlow(false)

    // [web]: themed browser / web search (see Browser.kt and BrowserScreen.kt)
    val showWeb = MutableStateFlow(false)
    /** Something for [web] to open or search as soon as it shows ("search the web for ..."); the screen clears it once used. */
    val webRequest = MutableStateFlow<String?>(null)
    /** Flips true when Novochron is closing itself (exit button or "turn off, computer"), so the
     *  Activity can remove itself from Recents right before the process is ended. */
    val exitRequested = MutableStateFlow(false)

    /** True from the moment a msg call connects (or starts connecting) until it ends. Lets the
     *  Activity offer to shrink into Picture-in-Picture the instant the person leaves the app -
     *  see MainActivity.onUserLeaveHint(). Deliberately excludes RINGING_IN/RINGING_OUT: those
     *  still need [accept]/[decline] on a full-size screen. */
    val callActive = MutableStateFlow(false)
    /** Mirrors the active call's [CallUiState.video], so PiP can pick a sensible aspect ratio (tall for video, square for voice). */
    val callHasVideo = MutableStateFlow(false)
    /** True only while an incoming msg call is actually up on screen and ringing (CallPhase.RINGING_IN),
     *  i.e. msg is open and CallManager has confirmed it. Lets "answer"/"decline" voice commands know
     *  there's something to act on right now - see Commands.kt and MsgScreen's callManager.ui effect. */
    val incomingCallRinging = MutableStateFlow(false)
    /** Set the moment CallWatcher's background check announces an incoming call - before msg has even
     *  been opened. Lets "answer"/"decline" work right after the spoken announcement, not only once
     *  msg is already open. Cleared once msg opens and settles the real state (incomingCallRinging
     *  takes over), or once the ring window passes with nothing happening. */
    val pendingIncomingCall = MutableStateFlow<IncomingCall?>(null)
    /** Mirrors the system's onPictureInPictureModeChanged callback, so the call UI can swap to a stripped-down layout. */
    val inPictureInPicture = MutableStateFlow(false)

    /** True while the full-screen camera (photo / live scan) is open. */
    val cameraOpen = MutableStateFlow(false)
    /** True while Novochron is watching the screen: every spoken/typed question gets the latest frame attached. */
    val screencastOn = MutableStateFlow(false)

    /** True while the app screen is in front (used to decide whether to pull it forward). */
    @Volatile var appVisible = false
}

/** Who's calling and whether it's video, as announced by [CallWatcher] before msg is even open. */
data class IncomingCall(val from: String, val video: Boolean, val ts: Long)

object Net {
    fun isOnline(ctx: Context): Boolean {
        val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val n = cm.activeNetwork ?: return false
        val c = cm.getNetworkCapabilities(n) ?: return false
        return c.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
            c.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
    }
}
