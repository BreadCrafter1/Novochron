package com.atlas.assistant

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import androidx.core.content.FileProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

/**
 * Social/sharing: turns whatever's on the `[graph]` or `[sim]` screen right now into a PNG, then either
 * (a) hands it to the normal Android share sheet ("share as an image" - any app: Messages, mail, etc.),
 * or (b) commits it into the logged-in GitHub vault repo and hands back a plain raw.githubusercontent.com
 * link (see [GitHub.commitBytesWithLink]) - "share as a link" for pasting somewhere a file can't go.
 *
 * The snapshots are drawn independently with plain android.graphics (not a screenshot of the live Compose
 * canvas), reusing the same pure-math model classes ([OrbitMath], [GraphMath]) the on-screen view uses,
 * so the exported image is a faithful, resolution-independent redraw rather than a fragile pixel-capture
 * of whatever happened to be on screen.
 */
object Sharing {

    private fun cacheDir(ctx: Context): File = File(ctx.cacheDir, "shared").apply { mkdirs() }

    /** Saves [bitmap] to cache and opens the normal Android share sheet for it as a PNG image. */
    fun shareBitmap(ctx: Context, bitmap: Bitmap, baseName: String) {
        val file = File(cacheDir(ctx), "${baseName}_${System.currentTimeMillis()}.png")
        try {
            FileOutputStream(file).use { bitmap.compress(Bitmap.CompressFormat.PNG, 100, it) }
        } catch (e: Exception) {
            return
        }
        val uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.fileprovider", file)
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "image/png"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        ctx.startActivity(Intent.createChooser(intent, "Share").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    /**
     * Commits [bitmap] into the active GitHub repo's Vault/Shared/ folder (same vault the `[vault]`
     * screen uses) and returns a stable, no-auth-needed raw link to it. Throws whatever [GitHub] throws
     * (not logged in, no repo picked, network error) - caller shows that as an error message.
     */
    suspend fun uploadAndLink(github: GitHub, bitmap: Bitmap, baseName: String): String = withContext(Dispatchers.IO) {
        val baos = ByteArrayOutputStream()
        bitmap.compress(Bitmap.CompressFormat.PNG, 100, baos)
        val safe = baseName.replace(Regex("[^a-zA-Z0-9-_]"), "_").ifBlank { "shared" }
        val path = "Vault/Shared/${safe}_${System.currentTimeMillis()}.png"
        val (_, raw) = github.commitBytesWithLink(path, baos.toByteArray(), "Share $safe via Novochron")
        raw
    }

    // ---------------------------------------------------------------- orbit-view snapshot

    /** Redraws the current `[sim]` view (bodies + orbit rings, no starfield/labels clutter) to a PNG-ready bitmap. */
    fun renderOrbitSnapshot(
        bodies: List<OrbitMath.Body>,
        tDays: Double,
        camera: OrbitMath.Camera,
        focusBody: OrbitMath.Body?,
        width: Int,
        height: Int,
        circular: Boolean = false
    ): Bitmap {
        val w = width.coerceAtLeast(1); val h = height.coerceAtLeast(1)
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bmp)
        canvas.drawColor(Color.BLACK)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        val wf = w.toFloat(); val hf = h.toFloat()
        val focusPos = focusBody?.let { OrbitMath.position(it, tDays, circular) } ?: OrbitMath.Vec3(0.0, 0.0, 0.0)
        fun rel(p: OrbitMath.Vec3) = OrbitMath.Vec3(p.x - focusPos.x, p.y - focusPos.y, p.z - focusPos.z)

        // orbit rings
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 1.5f
        bodies.forEach { b ->
            if (b.isStar || b.orbitAu <= 0.0) return@forEach
            paint.color = if (b.isComet) 0x60BFE8FF else 0x40DCC88C
            var prevX = 0f; var prevY = 0f; var has = false
            OrbitMath.orbitPoints(b, circular, if (b.isComet) 200 else 120).forEach { p3 ->
                val (sx, sy, _) = camera.project(rel(p3), wf, hf)
                if (has) canvas.drawLine(prevX, prevY, sx, sy, paint)
                prevX = sx; prevY = sy; has = true
            }
        }

        // bodies, back-to-front by depth
        paint.style = Paint.Style.FILL
        val withDepth = bodies.mapNotNull { b ->
            val p3 = OrbitMath.position(b, tDays, circular)
            if ((b.comet?.e ?: 0.0) >= 1.0 && OrbitMath.distFromStar(p3) > 45.0) return@mapNotNull null
            val (sx, sy, depth) = camera.project(rel(p3), wf, hf)
            Triple(b, sx to sy, depth)
        }.sortedBy { it.third }

        withDepth.forEach { (b, pos, _) ->
            val (sx, sy) = pos
            val r = OrbitMath.bodyPixelRadius(b, camera.pxPerAu(wf, hf), min(wf, hf))
            paint.color = 0xFF000000.toInt() or (b.color.toInt() and 0xFFFFFF)
            canvas.drawCircle(sx, sy, r, paint)
            paint.color = Color.WHITE
            paint.textSize = 22f
            canvas.drawText(b.name, sx + r + 6f, sy + 8f, paint)
        }

        // watermark
        paint.color = Color.argb(160, 200, 200, 200)
        paint.textSize = 20f
        canvas.drawText("Novochron · sim", 12f, hf - 14f, paint)
        return bmp
    }

    // ---------------------------------------------------------------- graph snapshot

    /** Redraws the current `[graph]` view (grid + curves) to a PNG-ready bitmap. [curves] is (formula text, ARGB color). */
    fun renderGraphSnapshot(
        curves: List<Pair<String, Int>>,
        centerX: Float,
        centerY: Float,
        unitsPerPx: Float,
        width: Int,
        height: Int
    ): Bitmap {
        val w = width.coerceAtLeast(1); val h = height.coerceAtLeast(1)
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bmp)
        canvas.drawColor(Color.BLACK)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        val upp = unitsPerPx.toDouble()
        fun toSx(wx: Double) = ((wx - centerX) / upp + w / 2.0).toFloat()
        fun toSy(wy: Double) = (h / 2.0 - (wy - centerY) / upp).toFloat()

        // grid
        val step = GraphMath.niceStep(upp * 80.0)
        val minX = centerX - w / 2 * upp; val maxX = centerX + w / 2 * upp
        val minY = centerY - h / 2 * upp; val maxY = centerY + h / 2 * upp
        paint.strokeWidth = 1f
        var gx = Math.floor(minX / step) * step
        while (gx <= maxX) {
            val bold = Math.abs(gx) < step / 1000.0
            paint.color = if (bold) 0xFF6E6E6E.toInt() else 0xFF2A2A2A.toInt()
            val sx = toSx(gx)
            canvas.drawLine(sx, 0f, sx, h.toFloat(), paint)
            gx += step
        }
        var gy = Math.floor(minY / step) * step
        while (gy <= maxY) {
            val bold = Math.abs(gy) < step / 1000.0
            paint.color = if (bold) 0xFF6E6E6E.toInt() else 0xFF2A2A2A.toInt()
            val sy = toSy(gy)
            canvas.drawLine(0f, sy, w.toFloat(), sy, paint)
            gy += step
        }

        // curves
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 4f
        paint.strokeCap = Paint.Cap.ROUND
        curves.forEach { (formula, colorArgb) ->
            val f = try { GraphMath.compile(formula) } catch (e: Exception) { return@forEach }
            paint.color = colorArgb
            var prevX = 0f; var prevY = 0f; var has = false
            var px = 0
            val maxJump = h * 4
            while (px <= w) {
                val wx = centerX + (px - w / 2) * upp
                val y = try { f(wx) } catch (e: Exception) { Double.NaN }
                if (y.isNaN() || y.isInfinite()) {
                    has = false
                } else {
                    val sy = toSy(y)
                    if (has && Math.abs(sy - prevY) < maxJump) canvas.drawLine(prevX, prevY, px.toFloat(), sy, paint)
                    prevX = px.toFloat(); prevY = sy; has = true
                }
                px += 2
            }
        }

        paint.style = Paint.Style.FILL
        paint.color = Color.argb(160, 200, 200, 200)
        paint.textSize = 20f
        canvas.drawText("Novochron · graph", 12f, h - 14f, paint)
        return bmp
    }
}
