package com.atlas.assistant

import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.cosh
import kotlin.math.ln
import kotlin.math.sinh
import kotlin.math.asinh
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.random.Random

/**
 * Real orbital mechanics + a small 3D->2D camera for the `[sim]` screen (see SolarSystemScreen.kt).
 *
 * 3.1: the eight planets now use the JPL "approximate positions of the major planets" Keplerian
 * elements (Standish; valid 1800-2050, still fine to 2100 for a visualiser), so they sit where they
 * really are on a given date and their orbits are true ellipses. `circular = true` flattens every
 * eccentricity to zero so the two can be compared. Halley's Comet and 'Oumuamua use their own
 * orbit (an eccentric ellipse and a hyperbola). Bodies with no elements (Proxima, TRAPPIST-1) still
 * use the older circular model. Simulation time [tDays] is days since J2000.0 for the Solar System.
 */
object OrbitMath {

    data class Vec3(val x: Double, val y: Double, val z: Double)

    /**
     * A decorative moon, drawn in screen-space around its planet (see [Body.moons] doc below).
     *
     * [eccentricity] and [inclinationDeg]/[nodeDeg] make the drawn orbit a real tilted ellipse instead
     * of a flat circle — [orbitFactor] is then the semi-major axis of that ellipse. Real regular moons
     * mostly hug their planet's equator (inclination near 0°), which would barely read on screen at
     * this decorative scale, so where a moon's true value isn't hand-set below, [tiltedMoons] fills in
     * a modest deterministic tilt — the same spirit as [proceduralIrregulars]'s seeded scatter: not the
     * real angle, but never reshuffled, and retrograde moons still lean into their real near-polar tilt.
     */
    data class Moon(
        val name: String,
        val color: Long,
        val radiusUnits: Double,  // relative to its own planet's drawn radius
        val orbitFactor: Double,  // orbit semi-major axis, in units of the planet's drawn radius
        val periodDays: Double,
        val eccentricity: Double = 0.0,
        val inclinationDeg: Double = 0.0, // tilt of this moon's orbital plane vs the planet's equator
        val nodeDeg: Double = 0.0,        // rotation of that tilt direction, so moons don't all lean the same way
        // Only the biggest moons are pulled round by their own gravity (hydrostatic equilibrium, roughly
        // >=200km radius); everything smaller — shepherd moons, captured asteroids/KBOs — is a lumpy,
        // irregular potato in reality (Phobos, Hyperion and Amalthea are the textbook examples), so it's
        // drawn as one instead of a perfect disc. See [drawMoons] in SolarSystemScreen.kt.
        val irregularShape: Boolean = false
    )

    /**
     * Fills in [Moon.eccentricity]/[Moon.inclinationDeg]/[Moon.nodeDeg] for any moon that doesn't
     * already carry hand-set real values (left at their 0.0 defaults above), so every moon in the app
     * ends up on a distinct tilted ellipse rather than a flat circle. Deterministic per moon name, so
     * it's stable across recompositions and app runs — never reshuffled.
     */
    private fun tiltedMoons(moons: List<Moon>): List<Moon> = moons.map { m ->
        val rnd = Random(m.name.hashCode().toLong())
        val retro = m.periodDays < 0
        // Each field falls back independently, so a moon can carry a real hand-set eccentricity (say,
        // Nereid's dramatic 0.75) while still getting a deterministic fallback inclination, or vice
        // versa. Retrograde moons really do sit at steep, often near-polar/retrograde inclinations;
        // prograde regular moons get a modest exaggerated tilt purely for legibility at this scale.
        val inc = if (m.inclinationDeg != 0.0) m.inclinationDeg
                  else if (retro) 130.0 + rnd.nextDouble() * 45.0
                  else 5.0 + rnd.nextDouble() * 30.0
        val ecc = if (m.eccentricity != 0.0) m.eccentricity else 0.01 + rnd.nextDouble() * 0.10
        val node = if (m.nodeDeg != 0.0) m.nodeDeg else rnd.nextDouble() * 360.0
        m.copy(eccentricity = ecc, inclinationDeg = inc, nodeDeg = node)
    }

    /**
     * Jupiter and Saturn's moon counts (97 and 274 as of late 2025) are overwhelmingly tiny, km-scale
     * irregular moons found by deep-sky survey in the last few years — only a fraction have permanent
     * IAU names, and their individual orbits aren't practical to hand-catalogue here. To still show the
     * *real count*, this generates the remainder as a seeded scatter (same spirit as [generateBeltPoints]):
     * placed into the real prograde/retrograde period bands their group occupies (e.g. Jupiter's Ananke/
     * Carme/Pasiphae clusters, Saturn's Norse/Inuit/Gallic clusters), each still a real two-body orbit
     * that turns at its own period — just not a specific catalogued object. Deterministic per [seed], so
     * the same 97th or 274th moon is in the same place every time the app runs.
     */
    private fun proceduralIrregulars(
        planetPrefix: String, count: Int, seed: Long,
        prograde: Boolean, periodRangeDays: ClosedRange<Double>,
        orbitFactorRange: ClosedRange<Double>, colors: List<Long>
    ): List<Moon> {
        val rnd = Random(seed)
        return List(count) { i ->
            val year = 2003 + rnd.nextInt(23)
            val name = "S/$year ${planetPrefix}${i + 1}"
            val period = periodRangeDays.start + rnd.nextDouble() * (periodRangeDays.endInclusive - periodRangeDays.start)
            val orbitF = orbitFactorRange.start + rnd.nextDouble() * (orbitFactorRange.endInclusive - orbitFactorRange.start)
            val color = colors[rnd.nextInt(colors.size)]
            Moon(name, color, 0.025 + rnd.nextDouble() * 0.02, orbitF, if (prograde) period else -period, irregularShape = true)
        }
    }

    /** What kind of procedural shading [Body] gets — see textureBrush() in SolarSystemScreen.kt. */
    enum class Texture { SUN, RED_STAR, ROCK, VENUS, EARTH, MARS, GAS_BANDED, ICE, ICE_DARK, COMET }

    /**
     * What a [Body] *is*, for UI filtering (the `[sim]` screen's dwarf/asteroid/comet/probe toggles)
     * and for [describeBody] in SolarSystemScreen.kt. Doesn't affect the physics — a DWARF_PLANET and
     * an ASTEROID are propagated by the exact same Kepler solver as a PLANET; this only says which
     * on-screen switch hides it and which sentence describes it.
     */
    enum class Kind { PLANET, DWARF_PLANET, ASTEROID, COMET, PROBE }

    /** JPL Table-1 style Keplerian elements: value at J2000 and rate per Julian century. Angles in degrees. */
    data class Elements(
        val a0: Double, val aD: Double, val e0: Double, val eD: Double,
        val i0: Double, val iD: Double, val l0: Double, val lD: Double,
        val w0: Double, val wD: Double, val o0: Double, val oD: Double
    )

    /**
     * A comet / interstellar visitor: fixed orbit shape plus the real dates of its perihelion passages.
     * Between two known passages the mean anomaly is interpolated (so Halley's real 76-year period
     * wobble from Jupiter is respected); past the last one it repeats the final interval.
     * e >= 1 is a hyperbolic flyby (uses only the first perihelion date).
     */
    data class CometOrbit(
        val a: Double,            // semi-major axis, AU (negative for a hyperbola)
        val e: Double,
        val incDeg: Double, val argPeriDeg: Double, val nodeDeg: Double,
        val periJd: List<Double>
    )

    /** A body orbiting [Body.parent] (null = the star itself, sits at the system origin). */
    data class Body(
        val name: String,
        val color: Long,          // 0xAARRGGBB
        val radiusUnits: Double,  // relative visual size only — NOT to scale with orbit distance
        val orbitAu: Double,      // semi-major axis, astronomical units (0 for the star)
        val periodDays: Double,   // orbital period (0 for the star)
        val inclinationDeg: Double = 0.0, // tilt of the orbital plane vs the system's reference plane
        val startAngleDeg: Double = 0.0,
        val isStar: Boolean = false,
        val texture: Texture = Texture.ROCK,
        val rings: Boolean = false,
        // Real moon orbits are far too small to draw to true AU scale next to a whole solar system —
        // these are screen-space decorations (orbitFactor is relative to the drawn planet, not AU),
        // but each still turns at its own real orbital period, so the motion means something.
        val moons: List<Moon> = emptyList(),
        val el: Elements? = null,
        val comet: CometOrbit? = null,
        // A human-observed spacecraft (Voyager 1/2): same hyperbolic-orbit math and [CometOrbit] shape
        // as a comet, but never coma/tail-drawn and never hidden past 45 AU (see isProbe below) — a
        // probe that's actually 160+ AU out should still show up when the user zooms out far enough.
        val probe: CometOrbit? = null,
        val kind: Kind = Kind.PLANET
    ) {
        val isComet: Boolean get() = comet != null
        val isProbe: Boolean get() = probe != null
    }

    const val J2000_JD = 2451545.0
    private const val GAUSS_K = 0.01720209895 // Gaussian gravitational constant, rad/day for a = 1 AU

    private fun normRad(x: Double): Double {
        var v = x % (2 * Math.PI)
        if (v > Math.PI) v -= 2 * Math.PI
        if (v < -Math.PI) v += 2 * Math.PI
        return v
    }

    /** Rotates a point in the orbital plane (xv toward perihelion) into the reference frame. */
    private fun rotateOrbit(xv: Double, yv: Double, iDeg: Double, omegaDeg: Double, nodeDeg: Double): Vec3 {
        val i = Math.toRadians(iDeg); val w = Math.toRadians(omegaDeg); val n = Math.toRadians(nodeDeg)
        val cw = cos(w); val sw = sin(w); val cn = cos(n); val sn = sin(n); val ci = cos(i); val si = sin(i)
        val x = (cw * cn - sw * sn * ci) * xv + (-sw * cn - cw * sn * ci) * yv
        val y = (cw * sn + sw * cn * ci) * xv + (-sw * sn + cw * cn * ci) * yv
        val z = (sw * si) * xv + (cw * si) * yv
        return Vec3(x, y, z)
    }

    private fun ellipseFromE(a: Double, e: Double, iDeg: Double, omegaDeg: Double, nodeDeg: Double, eccAnom: Double): Vec3 {
        val xv = a * (cos(eccAnom) - e)
        val yv = a * sqrt(1 - e * e) * sin(eccAnom)
        return rotateOrbit(xv, yv, iDeg, omegaDeg, nodeDeg)
    }

    /** Public wrapper so decorative screen-space orbits (moons) can share the same real Kepler solve. */
    fun keplerEccentricAnomaly(meanAnomRad: Double, e: Double): Double = solveKepler(meanAnomRad, e)

    private fun solveKepler(mRad: Double, e: Double): Double {
        val m = normRad(mRad)
        var ea = if (e > 0.8) Math.PI * (if (m >= 0) 1.0 else -1.0) else m
        repeat(40) {
            val f = ea - e * sin(ea) - m
            val fp = 1 - e * cos(ea)
            val d = f / fp
            ea -= d
            if (abs(d) < 1e-12) return ea
        }
        return ea
    }

    private fun hyperbolicPoint(c: CometOrbit, hAnom: Double): Vec3 {
        val e = c.e
        val xv = c.a * (cosh(hAnom) - e)
        val yv = -c.a * sqrt(e * e - 1) * sinh(hAnom)
        return rotateOrbit(xv, yv, c.incDeg, c.argPeriDeg, c.nodeDeg)
    }

    private fun planetPos(el: Elements, tDays: Double, circular: Boolean): Vec3 {
        val t = tDays / 36525.0
        val a = el.a0 + el.aD * t
        val e = if (circular) 0.0 else el.e0 + el.eD * t
        val inc = el.i0 + el.iD * t
        val l = el.l0 + el.lD * t
        val w = el.w0 + el.wD * t      // longitude of perihelion
        val o = el.o0 + el.oD * t      // longitude of ascending node
        val m = Math.toRadians(l - w)
        val ea = if (e == 0.0) normRad(m) else solveKepler(m, e)
        return ellipseFromE(a, e, inc, w - o, o, ea)
    }

    private fun cometPos(c: CometOrbit, tDays: Double, circular: Boolean): Vec3 {
        val jd = J2000_JD + tDays
        if (c.e >= 1.0) {
            val n = GAUSS_K / Math.pow(abs(c.a), 1.5)
            val m = n * (jd - c.periJd[0])
            var h = (if (m >= 0) 1.0 else -1.0) * ln(2 * abs(m) / c.e + 1.8)
            repeat(60) {
                val f = c.e * sinh(h) - h - m
                val fp = c.e * cosh(h) - 1
                val d = f / fp
                h -= d
                if (abs(d) < 1e-10) return hyperbolicPoint(c, h)
            }
            return hyperbolicPoint(c, h)
        }
        val p = c.periJd
        var idx = 0
        for (i in p.indices) if (p[i] <= jd) idx = i
        if (idx >= p.size - 1) idx = p.size - 2
        val span = p[idx + 1] - p[idx]
        val m = 2 * Math.PI * (jd - p[idx]) / span
        val e = if (circular) 0.0 else c.e
        val ea = if (e == 0.0) normRad(m) else solveKepler(m, e)
        return ellipseFromE(c.a, e, c.incDeg, c.argPeriDeg, c.nodeDeg, ea)
    }

    /**
     * Position of [body] at [tDays], in AU, in the system's reference frame. For the Solar System,
     * [tDays] is days since J2000.0. [circular] = true forces every eccentricity to zero.
     */
    fun position(body: Body, tDays: Double, circular: Boolean = false): Vec3 {
        if (body.isStar || body.orbitAu == 0.0) return Vec3(0.0, 0.0, 0.0)
        body.el?.let { return planetPos(it, tDays, circular) }
        body.comet?.let { return cometPos(it, tDays, circular) }
        body.probe?.let { return cometPos(it, tDays, circular) }
        val angle = Math.toRadians(body.startAngleDeg) + (2 * Math.PI) * (tDays / body.periodDays)
        val xOrb = body.orbitAu * cos(angle)
        val yOrb = body.orbitAu * sin(angle)
        val inc = Math.toRadians(body.inclinationDeg)
        // rotate the orbital plane about the x-axis by its inclination
        val y = yOrb * cos(inc)
        val z = yOrb * sin(inc)
        return Vec3(xOrb, y, z)
    }

    /** Points tracing [body]'s whole orbit (or, for a hyperbola, the part inside ~15 AU), for drawing the path. */
    fun orbitPoints(body: Body, circular: Boolean = false, steps: Int = 120): List<Vec3> {
        body.el?.let { el ->
            val e = if (circular) 0.0 else el.e0
            return (0..steps).map { i ->
                ellipseFromE(el.a0, e, el.i0, el.w0 - el.o0, el.o0, 2 * Math.PI * i / steps)
            }
        }
        body.comet?.let { c ->
            if (c.e >= 1.0) {
                val hMax = ln(((15.0 / abs(c.a) + 1) / c.e) + sqrt(Math.pow((15.0 / abs(c.a) + 1) / c.e, 2.0) - 1))
                return (0..steps).map { i -> hyperbolicPoint(c, -hMax + 2 * hMax * i / steps) }
            }
            val e = if (circular) 0.0 else c.e
            return (0..steps).map { i -> ellipseFromE(c.a, e, c.incDeg, c.argPeriDeg, c.nodeDeg, 2 * Math.PI * i / steps) }
        }
        body.probe?.let { p ->
            // A probe's "orbit" is the outbound leg of its hyperbola only — same hMax windowing as a
            // hyperbolic comet, just walked one direction (departure to +hMax) since it never returns.
            val hMax = ln(((160.0 / abs(p.a) + 1) / p.e) + sqrt(Math.pow((160.0 / abs(p.a) + 1) / p.e, 2.0) - 1))
            return (0..steps).map { i -> hyperbolicPoint(p, -hMax * 0.15 + hMax * 1.15 * i / steps) }
        }
        val fake = body.copy(startAngleDeg = 0.0, periodDays = 1.0)
        return (0..steps).map { i -> position(fake, i.toDouble() / steps) }
    }

    // ---------------------------------------------------------------- calendar helpers (days since J2000.0)

    /** Days since J2000.0 (noon 2000-01-01) at noon of [date]. */
    fun daysFromDate(date: java.time.LocalDate): Double = (date.toEpochDay() - 10957L).toDouble()

    fun dateFromDays(tDays: Double): java.time.LocalDate =
        java.time.LocalDate.ofEpochDay(Math.floor(tDays + 10957.5).toLong())

    fun todayDays(): Double = System.currentTimeMillis() / 86_400_000.0 - 10957.5 // fractional UTC days since J2000.0

    /** Range the date scrubber covers. */
    val MIN_DAYS = daysFromDate(java.time.LocalDate.of(1900, 1, 1))
    val MAX_DAYS = daysFromDate(java.time.LocalDate.of(2100, 12, 31))

    /** Distance from the star (AU) — used for comet tails. */
    fun distFromStar(p: Vec3): Double = sqrt(p.x * p.x + p.y * p.y + p.z * p.z)

    /**
     * Orbit camera: yaw/pitch rotate the view for the 3D tilt; zoom is driven purely by [viewRadiusAu]
     * (how many AU are visible across ~half the frame), never by depth. An earlier version divided a
     * pixel-scale focal length by an AU-scale depth (`focal / camZ`) — a unit mismatch that made
     * on-screen size swing wildly with camera angle and could even grow when zooming out, at the mercy
     * of whatever clamp caught it. `project()` now returns depth only for draw-order sorting.
     */
    class Camera(var yaw: Double, var pitch: Double, var viewRadiusAu: Double) {
        /** @return (screenX, screenY, depth) — depth is post-rotation z, for back-to-front sorting only. */
        fun project(p: Vec3, screenW: Float, screenH: Float): Triple<Float, Float, Double> {
            // Rotate world point by -yaw around Y, then -pitch around X, so the camera "orbits" the origin.
            val cy = cos(yaw); val sy = sin(yaw)
            val x1 = p.x * cy - p.z * sy
            val z1 = p.x * sy + p.z * cy
            val cp = cos(pitch); val sp = sin(pitch)
            val y2 = p.y * cp - z1 * sp
            val z2 = p.y * sp + z1 * cp

            val pxPerAu = min(screenW, screenH) * 0.48 / viewRadiusAu
            val sx = screenW / 2 + (x1 * pxPerAu).toFloat()
            val sy2 = screenH / 2 - (y2 * pxPerAu).toFloat()
            return Triple(sx, sy2, z2)
        }

        fun pxPerAu(screenW: Float, screenH: Float): Double = min(screenW, screenH) * 0.48 / viewRadiusAu
    }

    /** Halley's Comet: real perihelion passages 1835, 1910, 1986 and the predicted July 2061 one. */
    val HALLEY = CometOrbit(
        a = 17.834, e = 0.96714, incDeg = 162.26, argPeriDeg = 111.33, nodeDeg = 58.42,
        periJd = listOf(2391598.5, 2418781.5, 2446470.96, 2474033.5)
    )

    /** 1I/'Oumuamua, the first confirmed interstellar visitor: a hyperbola, perihelion 9 Sep 2017. */
    val OUMUAMUA = CometOrbit(
        a = -1.2723, e = 1.1996, incDeg = 122.74, argPeriDeg = 241.81, nodeDeg = 24.60,
        periJd = listOf(2458005.59)
    )

    /** 2P/Encke: the shortest known period of any comet (3.3 yr) — perihelion passages recur fast. */
    val ENCKE = CometOrbit(
        a = 2.215, e = 0.8482, incDeg = 11.78, argPeriDeg = 186.55, nodeDeg = 334.57,
        periJd = listOf(2457822.5, 2459025.5, 2460239.5, 2461440.5) // 2017-03-10, 2020-06-25, 2023-10-22, 2027-02-04
    )

    /** C/1995 O1 (Hale-Bopp): the "Great Comet" of 1997, visible to the naked eye for a record 18 months. */
    val HALE_BOPP = CometOrbit(
        a = 186.0, e = 0.9951, incDeg = 89.43, argPeriDeg = 130.59, nodeDeg = 282.47,
        periJd = listOf(2450539.5) // perihelion 1997-04-01; ~2500-year period, so only the one passage matters here
    )

    // ---------------------------------------------------------------- spacecraft (hyperbolic solar-escape trajectories)

    /**
     * Voyager 1 & 2: launched 1977, both now on unbound (e > 1) solar escape trajectories, far past
     * every planet. [a] here is derived from each probe's real current heliocentric speed (Voyager 1
     * ≈17.0 km/s, Voyager 2 ≈15.4 km/s — both essentially at their asymptotic v∞ already, this far out)
     * via the vis-viva relation a = -GM/v∞²; [e] then follows from assuming a ~1 AU periapsis, since
     * both launched from Earth orbit before their planetary gravity assists boosted them hyperbolic.
     * Inclination is the real, well-known fact that Voyager 1 heads out ~35° *above* the ecliptic
     * (toward Ophiuchus) while Voyager 2 heads ~48° *below* it (toward Sagittarius/Telescopium) — the
     * two probes were deliberately sent opposite ways so between them they'd sample both directions out
     * of the solar system. [argPeriDeg]/[nodeDeg] are not from a real JPL Horizons fit (that needs live
     * tracking data this offline app doesn't have) — they just orient each hyperbola so the tilt reads
     * correctly on screen. periJd is each probe's real launch date, standing in for its periapsis time.
     */
    val VOYAGER1_ORBIT = CometOrbit(
        a = -3.07, e = 1.326, incDeg = 35.0, argPeriDeg = 0.0, nodeDeg = 100.0,
        periJd = listOf(2443391.5) // launched 1977-09-05
    )
    val VOYAGER2_ORBIT = CometOrbit(
        a = -3.74, e = 1.267, incDeg = 48.0, argPeriDeg = 180.0, nodeDeg = 280.0,
        periJd = listOf(2443375.5) // launched 1977-08-20
    )

    /** The 8 planets (+ Sun), Halley and 'Oumuamua. Distances in AU, periods in Earth days. */
    val SOLAR_SYSTEM: List<Body> = listOf(
        Body("Sun", 0xFFFFD84A, 6.0, 0.0, 0.0, isStar = true, texture = Texture.SUN),
        Body(
            "Mercury", 0xFF9E9E9E, 0.9, 0.39, 88.0, 7.0, 20.0, texture = Texture.ROCK,
            el = Elements(0.38709927, 0.00000037, 0.20563593, 0.00001906, 7.00497902, -0.00594749, 252.25032350, 149472.67411175, 77.45779628, 0.16047689, 48.33076593, -0.12534081)
        ),
        Body(
            "Venus", 0xFFE0C46E, 1.4, 0.72, 224.7, 3.4, 80.0, texture = Texture.VENUS,
            el = Elements(0.72333566, 0.00000390, 0.00677672, -0.00004107, 3.39467605, -0.00078890, 181.97909950, 58517.81538729, 131.60246718, 0.00268329, 76.67984255, -0.27769418)
        ),
        Body(
            "Earth", 0xFF4FA8FF, 1.5, 1.00, 365.25, 0.0, 160.0, texture = Texture.EARTH,
            moons = tiltedMoons(listOf(Moon("Moon", 0xFFC9C9C9, 0.27, 2.4, 27.3, eccentricity = 0.0549, inclinationDeg = 18.3))),
            el = Elements(1.00000261, 0.00000562, 0.01671123, -0.00004392, -0.00001531, -0.01294668, 100.46457166, 35999.37244981, 102.93768193, 0.32327364, 0.0, 0.0)
        ),
        Body(
            "Mars", 0xFFFF6A4F, 1.1, 1.52, 687.0, 1.85, 260.0, texture = Texture.MARS,
            moons = tiltedMoons(listOf(
                Moon("Phobos", 0xFF8A7D6E, 0.16, 1.9, 0.32, eccentricity = 0.0151, irregularShape = true),
                Moon("Deimos", 0xFF8A7D6E, 0.13, 2.6, 1.26, eccentricity = 0.0003, irregularShape = true)
            )),
            el = Elements(1.52371034, 0.00001847, 0.09339410, 0.00007882, 1.84969142, -0.00813131, -4.55343205, 19140.30268499, -23.94362959, 0.44441088, 49.55953891, -0.29257343)
        ),
        Body(
            "Jupiter", 0xFFE0B27A, 3.4, 5.20, 4331.0, 1.3, 30.0, texture = Texture.GAS_BANDED,
            // 97 moons total (the real count as of late 2025): the 20 IAU-named ones below with
            // well-established orbits, plus 77 more generated into the real prograde/retrograde
            // period bands of Jupiter's irregular-moon families — see [proceduralIrregulars].
            moons = tiltedMoons(listOf(
                Moon("Metis", 0xFF9C9284, 0.10, 1.25, 0.295, irregularShape = true),
                Moon("Adrastea", 0xFF8A7D6E, 0.08, 1.30, 0.298, irregularShape = true),
                Moon("Amalthea", 0xFFB0654F, 0.16, 1.40, 0.498, irregularShape = true),
                Moon("Thebe", 0xFF9C6E52, 0.14, 1.55, 0.675, irregularShape = true),
                Moon("Io", 0xFFE8D08A, 0.30, 1.75, 1.77, eccentricity = 0.0041),
                Moon("Europa", 0xFFCFCABF, 0.28, 2.10, 3.55, eccentricity = 0.0090),
                Moon("Ganymede", 0xFF9C9284, 0.35, 2.60, 7.15, eccentricity = 0.0013),
                Moon("Callisto", 0xFF6E655A, 0.33, 3.10, 16.69, eccentricity = 0.0074),
                Moon("Themisto", 0xFF8A8478, 0.07, 3.40, 130.0),
                Moon("Leda", 0xFF8A8478, 0.06, 3.55, 241.0),
                Moon("Himalia", 0xFFA69C86, 0.12, 3.70, 250.6),
                Moon("Lysithea", 0xFF8A8478, 0.07, 3.85, 259.0),
                Moon("Elara", 0xFF9C9284, 0.09, 4.00, 259.6),
                Moon("Carpo", 0xFF7A7468, 0.06, 4.20, 456.0),
                Moon("Valetudo", 0xFF7A7468, 0.05, 4.35, 533.0),
                Moon("Euporie", 0xFF6E655A, 0.05, 4.50, 550.0),
                Moon("Ananke", 0xFF6E655A, 0.07, 4.70, 630.0),
                Moon("Carme", 0xFF625A50, 0.08, 4.90, 702.0),
                Moon("Pasiphae", 0xFF625A50, 0.09, 5.10, 708.0),
                Moon("Sinope", 0xFF564F46, 0.07, 5.30, 725.0)
            ) + proceduralIrregulars("J", 9, 900_01L, true, 130.0..300.0, 3.4..4.4, listOf(0xFF8A8478, 0xFF9C9284, 0xFF7A7468)) +
                proceduralIrregulars("J", 68, 900_02L, false, 500.0..980.0, 4.4..6.2, listOf(0xFF6E655A, 0xFF625A50, 0xFF564F46, 0xFF7A7468))),
            el = Elements(5.20288700, -0.00011607, 0.04838624, -0.00013253, 1.30439695, -0.00183714, 34.39644051, 3034.74612775, 14.72847983, 0.21252668, 100.47390909, 0.20469106)
        ),
        Body(
            "Saturn", 0xFFE8D6A0, 3.0, 9.58, 10747.0, 2.5, 300.0, texture = Texture.GAS_BANDED, rings = true,
            // 274 moons total (the real count as of late 2025, most from the 2023 deep-imaging survey):
            // the 20 named moons below with well-established orbits, plus 254 more generated into the
            // real period bands of Saturn's irregular-moon families — see [proceduralIrregulars].
            moons = tiltedMoons(listOf(
                Moon("Pan", 0xFFB0AA9C, 0.06, 1.20, 0.575, irregularShape = true),
                Moon("Daphnis", 0xFFB0AA9C, 0.05, 1.25, 0.594, irregularShape = true),
                Moon("Atlas", 0xFFB0AA9C, 0.06, 1.30, 0.602, irregularShape = true),
                Moon("Prometheus", 0xFFC4BCA8, 0.08, 1.40, 0.613, irregularShape = true),
                Moon("Pandora", 0xFFC4BCA8, 0.08, 1.45, 0.629, irregularShape = true),
                Moon("Epimetheus", 0xFFC4BCA8, 0.08, 1.55, 0.694, irregularShape = true),
                Moon("Janus", 0xFFC4BCA8, 0.09, 1.60, 0.695, irregularShape = true),
                Moon("Mimas", 0xFFCFCABF, 0.14, 1.75, 0.942, eccentricity = 0.0196, inclinationDeg = 1.53),
                Moon("Enceladus", 0xFFEAF2F8, 0.16, 1.95, 1.370, eccentricity = 0.0047),
                Moon("Tethys", 0xFFD6D2C8, 0.20, 2.15, 1.888, eccentricity = 0.0001),
                Moon("Telesto", 0xFFB0AA9C, 0.06, 2.20, 1.888, irregularShape = true),
                Moon("Calypso", 0xFFB0AA9C, 0.06, 2.25, 1.888, irregularShape = true),
                Moon("Dione", 0xFFCFCABF, 0.21, 2.45, 2.737, eccentricity = 0.0022),
                Moon("Helene", 0xFFB0AA9C, 0.06, 2.50, 2.737, irregularShape = true),
                Moon("Polydeuces", 0xFF9C9284, 0.05, 2.55, 2.737, irregularShape = true),
                Moon("Rhea", 0xFFD6D2C8, 0.24, 2.80, 4.518, eccentricity = 0.0013),
                Moon("Titan", 0xFFD8B26A, 0.32, 3.40, 15.945, eccentricity = 0.0288),
                Moon("Hyperion", 0xFFA69C86, 0.10, 3.70, 21.28, eccentricity = 0.1230, irregularShape = true),
                Moon("Iapetus", 0xFF8A8478, 0.22, 4.20, 79.32, eccentricity = 0.0286, inclinationDeg = 15.47),
                Moon("Phoebe", 0xFF625A50, 0.10, 4.80, -550.4, eccentricity = 0.156, inclinationDeg = 175.2, irregularShape = true)
            ) + proceduralIrregulars("S", 36, 900_03L, true, 700.0..1150.0, 4.9..6.0, listOf(0xFFA69C86, 0xFF8A8478, 0xFF9C9284)) +
                proceduralIrregulars("S", 218, 900_04L, false, 550.0..1650.0, 4.9..7.4, listOf(0xFF625A50, 0xFF564F46, 0xFF6E655A, 0xFF7A7468))),
            el = Elements(9.53667594, -0.00125060, 0.05386179, -0.00050991, 2.48599187, 0.00193609, 49.95424423, 1222.49362201, 92.59887831, -0.41897216, 113.66242448, -0.28867794)
        ),
        Body(
            "Uranus", 0xFF8FDDE8, 2.2, 19.20, 30589.0, 0.77, 120.0, texture = Texture.ICE,
            // All 29 known moons of Uranus (the real count as of 2025): 13 inner ring-moons — including
            // S/2025 U1, found by JWST between Ophelia and Bianca, not yet named — the 5 major moons
            // (Shakespeare's heroines/heroes), then the 10 outer irregulars, ending with S/2023 U1
            // (found 2023, the first new Uranian moon in 20 years, also not yet named).
            moons = tiltedMoons(listOf(
                Moon("Cordelia", 0xFFB9B9B9, 0.05, 1.20, 0.335, irregularShape = true),
                Moon("Ophelia", 0xFFB9B9B9, 0.05, 1.25, 0.376, irregularShape = true),
                Moon("S/2025 U1", 0xFFA0A0A0, 0.03, 1.27, 0.40, irregularShape = true),
                Moon("Bianca", 0xFFB9B9B9, 0.05, 1.30, 0.435, irregularShape = true),
                Moon("Cressida", 0xFFB9B9B9, 0.05, 1.35, 0.464, irregularShape = true),
                Moon("Desdemona", 0xFFB9B9B9, 0.05, 1.40, 0.474, irregularShape = true),
                Moon("Juliet", 0xFFB9B9B9, 0.06, 1.45, 0.493, irregularShape = true),
                Moon("Portia", 0xFFB9B9B9, 0.06, 1.50, 0.513, irregularShape = true),
                Moon("Rosalind", 0xFFB9B9B9, 0.05, 1.55, 0.558, irregularShape = true),
                Moon("Cupid", 0xFFA0A0A0, 0.04, 1.60, 0.618, irregularShape = true),
                Moon("Belinda", 0xFFB9B9B9, 0.06, 1.65, 0.624, irregularShape = true),
                Moon("Perdita", 0xFFA0A0A0, 0.04, 1.70, 0.638, irregularShape = true),
                Moon("Puck", 0xFFB9B9B9, 0.08, 1.80, 0.762, irregularShape = true),
                Moon("Mab", 0xFFA0A0A0, 0.05, 1.90, 0.923, irregularShape = true),
                Moon("Miranda", 0xFFCFCFCF, 0.16, 2.10, 1.413, eccentricity = 0.0013, inclinationDeg = 4.34),
                Moon("Ariel", 0xFFD6D6D6, 0.20, 2.40, 2.520, eccentricity = 0.0012),
                Moon("Umbriel", 0xFF8F8F8F, 0.19, 2.70, 4.144, eccentricity = 0.0039),
                Moon("Titania", 0xFFB9B9B9, 0.23, 3.00, 8.706, eccentricity = 0.0011),
                Moon("Oberon", 0xFFA69C9C, 0.22, 3.30, 13.46, eccentricity = 0.0014),
                // The outer irregular moons are real captured objects — all retrograde except Margaret,
                // the one known prograde outlier among them.
                Moon("Francisco", 0xFF7A7A7A, 0.05, 3.60, -267.0, irregularShape = true),
                Moon("Caliban", 0xFF7A7A7A, 0.09, 3.80, -580.0, irregularShape = true),
                Moon("Stephano", 0xFF6E6E6E, 0.05, 4.00, -677.0, irregularShape = true),
                Moon("S/2023 U1", 0xFF6E6E6E, 0.03, 4.05, -681.0, irregularShape = true),
                Moon("Trinculo", 0xFF6E6E6E, 0.04, 4.20, -749.0, irregularShape = true),
                Moon("Sycorax", 0xFF8A7060, 0.11, 4.50, -1288.0, irregularShape = true),
                Moon("Margaret", 0xFF6E6E6E, 0.05, 4.70, 1687.0, irregularShape = true),
                Moon("Prospero", 0xFF625A50, 0.07, 4.90, -1978.0, irregularShape = true),
                Moon("Setebos", 0xFF625A50, 0.08, 5.10, -2225.0, irregularShape = true),
                Moon("Ferdinand", 0xFF564F46, 0.05, 5.30, -2823.0, irregularShape = true)
            )),
            el = Elements(19.18916464, -0.00196176, 0.04725744, -0.00004397, 0.77263783, -0.00242939, 313.23810451, 428.48202785, 170.95427630, 0.40805281, 74.01692503, 0.04240589)
        ),
        Body(
            "Neptune", 0xFF5C7CFF, 2.1, 30.05, 59800.0, 1.77, 200.0, texture = Texture.ICE_DARK,
            // All 16 known moons of Neptune (the real count as of 2025): the 6 inner ring-moons +
            // Hippocamp, Proteus, retrograde Triton, then Nereid and the far outer irregulars, including
            // S/2002 N5 and S/2021 N1 (both found 2021-23, not yet named) — real distance order.
            moons = tiltedMoons(listOf(
                Moon("Naiad", 0xFF9FB8D8, 0.05, 1.20, 0.294, irregularShape = true),
                Moon("Thalassa", 0xFF9FB8D8, 0.05, 1.25, 0.311, irregularShape = true),
                Moon("Despina", 0xFF9FB8D8, 0.06, 1.30, 0.335, irregularShape = true),
                Moon("Galatea", 0xFF9FB8D8, 0.07, 1.40, 0.429, irregularShape = true),
                Moon("Larissa", 0xFFAFC4DE, 0.08, 1.50, 0.555, irregularShape = true),
                Moon("Hippocamp", 0xFF7E97B8, 0.03, 1.60, 0.951, irregularShape = true),
                Moon("Proteus", 0xFFAFC4DE, 0.14, 1.75, 1.122, eccentricity = 0.0005, irregularShape = true),
                // Triton is famously retrograde and near-perfectly circular — captured, not formed in place.
                Moon("Triton", 0xFFD9CBB0, 0.24, 2.10, -5.877, eccentricity = 0.00002, inclinationDeg = 156.9),
                Moon("Nereid", 0xFF9FB8D8, 0.10, 2.60, 360.13, eccentricity = 0.7512),
                // Outer irregulars: Sao and Laomedeia are the two known prograde ones, the rest retrograde.
                Moon("Halimede", 0xFF7E97B8, 0.05, 2.90, -1879.0, irregularShape = true),
                Moon("Sao", 0xFF7E97B8, 0.04, 3.10, 2914.0, irregularShape = true),
                Moon("Laomedeia", 0xFF7E97B8, 0.04, 3.30, 3171.0, irregularShape = true),
                Moon("S/2002 N5", 0xFF6E85A0, 0.04, 3.45, -3287.0, irregularShape = true),
                Moon("Psamathe", 0xFF6E85A0, 0.04, 3.60, -9074.0, irregularShape = true),
                Moon("Neso", 0xFF6E85A0, 0.05, 3.90, -9374.0, irregularShape = true),
                Moon("S/2021 N1", 0xFF6E85A0, 0.03, 4.05, -9861.0, irregularShape = true)
            )),
            el = Elements(30.06992276, 0.00026291, 0.00859048, 0.00005105, 1.77004347, 0.00035372, -55.12002969, 218.45945325, 44.96476227, -0.32241464, 131.78422574, -0.00508664)
        ),
        Body(
            // Dwarf planet #1, and by far the biggest object in the main asteroid belt — 1/3 of the
            // belt's total mass on its own. Real Kepler ellipse just like the 8 planets above; only
            // its mean anomaly at J2000 is a placeholder pick (see the [Kind.DWARF_PLANET]/[Kind.ASTEROID]
            // group's shared note below the Neptune block) rather than a fitted rate table.
            "Ceres", 0xFFB0A090, 0.55, 2.7658, 1680.05, 10.59, texture = Texture.ROCK, kind = Kind.DWARF_PLANET,
            el = Elements(2.7658, 0.0, 0.0760, 0.0, 10.593, 0.0, 193.902, 7826.57, 153.902, 0.0, 80.305, 0.0)
        ),
        Body(
            "Vesta", 0xFFC9BFA8, 0.30, 2.3615, 1325.48, 7.14, texture = Texture.ROCK, kind = Kind.ASTEROID,
            el = Elements(2.3615, 0.0, 0.0887, 0.0, 7.140, 0.0, 25.049, 9920.20, 255.049, 0.0, 103.851, 0.0)
        ),
        Body(
            // The most inclined of the big four — 2 Pallas sits ~35° out of the ecliptic, a real
            // consequence of a colossal ancient collision, not a visualiser exaggeration.
            "Pallas", 0xFFAFA898, 0.26, 2.7721, 1685.79, 34.93, texture = Texture.ROCK, kind = Kind.ASTEROID,
            el = Elements(2.7721, 0.0, 0.2302, 0.0, 34.93, 0.0, 343.8, 7799.90, 123.8, 0.0, 172.9, 0.0)
        ),
        Body(
            "Hygiea", 0xFF9C9284, 0.27, 3.1415, 2033.74, 3.83, texture = Texture.ROCK, kind = Kind.ASTEROID,
            el = Elements(3.1415, 0.0, 0.1146, 0.0, 3.83, 0.0, 185.52, 6465.42, 235.52, 0.0, 283.20, 0.0)
        ),
        Body(
            "Juno", 0xFFB89C7A, 0.22, 2.6699, 1593.43, 12.98, texture = Texture.ROCK, kind = Kind.ASTEROID,
            el = Elements(2.6699, 0.0, 0.2562, 0.0, 12.98, 0.0, 67.91, 8252.02, 57.91, 0.0, 169.85, 0.0)
        ),
        Body(
            // The one dwarf planet with a real fitted rate table (Standish, same source and 1800-2050
            // validity as the 8 planets above) rather than the fixed-ellipse approximation the newer
            // dwarf planets below use — Pluto's motion has been tracked precisely since 1930.
            "Pluto", 0xFFD8C4A0, 0.42, 39.482, 90613.07, 17.14, texture = Texture.ICE, kind = Kind.DWARF_PLANET,
            moons = tiltedMoons(listOf(
                Moon("Charon", 0xFFA69C90, 0.50, 3.0, 6.387, eccentricity = 0.0002, inclinationDeg = 0.0),
                Moon("Styx", 0xFF8A8478, 0.06, 4.2, 20.16, irregularShape = true),
                Moon("Nix", 0xFF9C9284, 0.10, 4.6, 24.85, irregularShape = true),
                Moon("Kerberos", 0xFF7A7468, 0.06, 5.3, 32.17, irregularShape = true),
                Moon("Hydra", 0xFF9C9284, 0.10, 5.8, 38.20, irregularShape = true)
            )),
            el = Elements(
                39.48211675, -0.00031596, 0.24882730, 0.00005170, 17.14001206, 0.00004818,
                238.92903833, 145.20780515, 224.06891629, -0.04062942, 110.30393684, -0.01183482
            )
        ),
        Body(
            // Beyond Pluto, the newer dwarf planets get fixed (non-precessing) ellipses — real
            // semi-major axis/eccentricity/inclination/node/perihelion, Kepler's-3rd-law-consistent
            // period, but each one's mean anomaly at J2000 is only a spread-out placeholder pick (like
            // TRAPPIST-1's start angles above) rather than a fitted position, since none has anywhere
            // near Pluto's century of tracking to fit a rate table from.
            "Eris", 0xFFE8E2D8, 0.40, 67.78, 203818.02, 44.04, texture = Texture.ICE, kind = Kind.DWARF_PLANET,
            moons = tiltedMoons(listOf(Moon("Dysnomia", 0xFF8A8478, 0.09, 3.0, 15.79, irregularShape = true))),
            el = Elements(67.78, 0.0, 0.4407, 0.0, 44.04, 0.0, 27.23, 64.51, 187.23, 0.0, 35.95, 0.0)
        ),
        Body(
            "Haumea", 0xFFD0CCC0, 0.32, 43.13, 103456.89, 28.19, texture = Texture.ICE, kind = Kind.DWARF_PLANET,
            moons = tiltedMoons(listOf(
                Moon("Hi'iaka", 0xFF9C9284, 0.08, 3.1, 49.12, irregularShape = true),
                Moon("Namaka", 0xFF8A8478, 0.05, 2.5, 18.28, irregularShape = true)
            )),
            el = Elements(43.13, 0.0, 0.1961, 0.0, 28.19, 0.0, 61.1, 127.10, 1.1, 0.0, 121.9, 0.0)
        ),
        Body(
            "Makemake", 0xFFC9A888, 0.31, 45.43, 111841.85, 29.01, texture = Texture.ICE, kind = Kind.DWARF_PLANET,
            moons = tiltedMoons(listOf(Moon("MK 2", 0xFF625A50, 0.05, 2.8, 12.4, irregularShape = true))),
            el = Elements(45.43, 0.0, 0.1559, 0.0, 29.01, 0.0, 166.26, 117.57, 16.26, 0.0, 79.36, 0.0)
        ),
        Body(
            // The most distant known dwarf-planet candidate — 90377 Sedna's orbit is so extreme (out to
            // ~936 AU at aphelion, ~11,400-year period) that it's currently only ~84 AU out, near the
            // one small stretch of its whole lap that passes anywhere close to the rest of the system.
            "Sedna", 0xFFC97A6A, 0.24, 506.0, 4157344.36, 11.93, texture = Texture.ICE, kind = Kind.DWARF_PLANET,
            el = Elements(506.0, 0.0, 0.8496, 0.0, 11.93, 0.0, 15.3, 3.16, 95.3, 0.0, 144.3, 0.0)
        ),
        Body("Halley", 0xFFBFE8FF, 0.5, 17.834, 27_563.0, texture = Texture.COMET, kind = Kind.COMET, comet = HALLEY),
        Body("'Oumuamua", 0xFFC08A6A, 0.35, 1.27, 0.0, texture = Texture.COMET, kind = Kind.COMET, comet = OUMUAMUA),
        Body("Encke", 0xFFBFE8FF, 0.4, 2.215, 1204.0, texture = Texture.COMET, kind = Kind.COMET, comet = ENCKE),
        Body("Hale-Bopp", 0xFFFFE2C0, 0.55, 186.0, 926_644.0, texture = Texture.COMET, kind = Kind.COMET, comet = HALE_BOPP),
        // Voyager 1 & 2: real launch dates/speeds/escape directions, simplified hyperbola shape — see
        // the full caveat on [VOYAGER1_ORBIT]/[VOYAGER2_ORBIT] above. orbitAu is only a rough "how far
        // out is it right now" for the UI's zoom range; it's excluded from outerAuOf (see there) so it
        // doesn't blow up the default framing of everything else.
        Body("Voyager 1", 0xFFE8E8E8, 0.18, 165.0, 0.0, kind = Kind.PROBE, probe = VOYAGER1_ORBIT),
        Body("Voyager 2", 0xFFC8D8E8, 0.18, 137.0, 0.0, kind = Kind.PROBE, probe = VOYAGER2_ORBIT)
    )

    /**
     * Proxima Centauri system: the star plus its confirmed/candidate planets. Distances and periods
     * are the published estimates (Proxima b: Anglada-Escudé et al. 2016; Proxima c and the disputed
     * inner candidate d: later radial-velocity work) — real numbers, not placeholders, though c and d
     * are far less certain than b.
     */
    val PROXIMA_SYSTEM: List<Body> = listOf(
        Body("Proxima Centauri", 0xFFFF5C3D, 2.0, 0.0, 0.0, isStar = true, texture = Texture.RED_STAR),
        Body("Proxima d", 0xFFB0B0B0, 0.5, 0.029, 5.15, 20.0, 0.0, texture = Texture.ROCK),
        Body("Proxima b", 0xFF4FD1A5, 1.0, 0.0485, 11.19, 10.0, 140.0, texture = Texture.EARTH),
        Body("Proxima c", 0xFF9E7BFF, 0.9, 1.49, 1928.0, 40.0, 260.0, texture = Texture.ICE)
    )

    /**
     * TRAPPIST-1: an ultra-cool red dwarf with seven roughly Earth-sized planets packed into an orbit
     * tighter than Mercury's, several in its habitable zone. Distances and periods are the refined
     * transit-timing values (Grimm et al. 2018) — real published numbers, same spirit as the two
     * systems above, not a compressed cartoon. Inclinations are near-zero (the whole system transits
     * nearly edge-on from Earth) so they're left at 0 here; distinct start angles just keep the seven
     * from visually overlapping at t=0.
     */
    val TRAPPIST1_SYSTEM: List<Body> = listOf(
        Body("TRAPPIST-1", 0xFFB0392A, 1.1, 0.0, 0.0, isStar = true, texture = Texture.RED_STAR),
        Body("TRAPPIST-1b", 0xFFC98A6B, 0.5, 0.01154, 1.51, 0.0, 0.0, texture = Texture.ROCK),
        Body("TRAPPIST-1c", 0xFFDCC08A, 0.55, 0.01580, 2.42, 0.0, 55.0, texture = Texture.VENUS),
        Body("TRAPPIST-1d", 0xFF6FA8E8, 0.4, 0.02227, 4.05, 0.0, 110.0, texture = Texture.EARTH),
        Body("TRAPPIST-1e", 0xFF4FD1A5, 0.48, 0.02925, 6.10, 0.0, 165.0, texture = Texture.EARTH),
        Body("TRAPPIST-1f", 0xFF9FB8D8, 0.52, 0.03849, 9.21, 0.0, 220.0, texture = Texture.ICE),
        Body("TRAPPIST-1g", 0xFF6E8FBF, 0.57, 0.04683, 12.35, 0.0, 275.0, texture = Texture.ICE),
        Body("TRAPPIST-1h", 0xFFB0B0B0, 0.35, 0.06189, 18.77, 0.0, 330.0, texture = Texture.ROCK)
    )

    /** One entry in the `[sim]` screen's system-cycle button (see [SYSTEMS], defined below the belts). */
    data class SystemDef(val label: String, val key: String, val bodies: List<Body>, val belts: List<Belt>)

    /**
     * A ring of small bodies drawn as a static scatter of dots rather than individually-tracked
     * orbits — the main asteroid belt (between Mars and Jupiter) and the Kuiper belt (beyond
     * Neptune). Real ones hold millions of objects on their own independent orbits; here [count]
     * points are seeded once (see [generateBeltPoints]) at true-to-scale distances so the *shape*
     * and *extent* of the belt reads correctly at a glance, same spirit as the rest of this
     * visualiser (real distances, not a compressed cartoon), without actually simulating each one.
     */
    data class Belt(
        val name: String,
        val innerAu: Double,
        val outerAu: Double,
        val color: Long,      // 0xAARRGGBB, base tint (per-dot alpha/size is jittered)
        val count: Int,
        val thicknessAu: Double, // scatter above/below the plane, roughly the belt's real vertical spread
        val seed: Long
    )

    /** One static dot in a [Belt]'s scatter, already in AU in the system's reference frame. */
    data class BeltPoint(val x: Double, val y: Double, val z: Double, val jitter: Float)

    val ASTEROID_BELT = Belt(
        name = "Asteroid Belt", innerAu = 2.1, outerAu = 3.3,
        color = 0xFFBBAA88, count = 900, thicknessAu = 0.15, seed = 770_01L
    )
    val KUIPER_BELT = Belt(
        name = "Kuiper Belt", innerAu = 30.0, outerAu = 50.0,
        color = 0xFF9FB8D8, count = 1400, thicknessAu = 0.6, seed = 770_02L
    )

    /** Both belts of the real Solar System. The Proxima and TRAPPIST-1 systems have none modelled. */
    val SOLAR_SYSTEM_BELTS: List<Belt> = listOf(ASTEROID_BELT, KUIPER_BELT)

    /** The systems offered on the `[sim]` screen's system-cycle button, in cycle order. */
    val SYSTEMS: List<SystemDef> = listOf(
        SystemDef("solar", "[solar]", SOLAR_SYSTEM, SOLAR_SYSTEM_BELTS),
        SystemDef("proxima", "[proxima]", PROXIMA_SYSTEM, emptyList()),
        SystemDef("trappist-1", "[trappist-1]", TRAPPIST1_SYSTEM, emptyList())
    )

    /** Seeded once per [belt] (same seed every time) so the scatter doesn't reshuffle every recompose. */
    fun generateBeltPoints(belt: Belt): List<BeltPoint> {
        val rnd = Random(belt.seed)
        return List(belt.count) {
            // area-uniform radius (not linear) so density doesn't artificially bunch near the inner edge
            val r = sqrt(rnd.nextDouble(belt.innerAu * belt.innerAu, belt.outerAu * belt.outerAu))
            val theta = rnd.nextDouble(0.0, 2 * Math.PI)
            val z = (rnd.nextDouble() - 0.5) * belt.thicknessAu
            BeltPoint(r * cos(theta), r * sin(theta), z, rnd.nextFloat())
        }
    }

    /** Like [outerAuOf], but also accounts for any belts so the default framing shows them fully. */
    fun outerAuOfWithBelts(bodies: List<Body>, belts: List<Belt>): Double =
        maxOf(outerAuOf(bodies), belts.maxOfOrNull { it.outerAu } ?: 0.0)

    fun angleFromCenter(x: Float, y: Float, cx: Float, cy: Float) = atan2((y - cy).toDouble(), (x - cx).toDouble())

    fun dist(x1: Float, y1: Float, x2: Float, y2: Float): Float {
        val dx = x1 - x2; val dy = y1 - y2
        return sqrt((dx * dx + dy * dy).toDouble()).toFloat()
    }

    // Comets and probes carry an orbitAu that's either meaningless (hyperbolic) or way out past Pluto
    // (Voyager) — including them here would blow up the default framing for every other body, the
    // exact reason 'Oumuamua/Halley were already excluded before probes existed.
    fun outerAuOf(bodies: List<Body>): Double = bodies.filter { !it.isComet && !it.isProbe }.maxOfOrNull { it.orbitAu }?.coerceAtLeast(1.0) ?: 1.0

    // Body pixel size is directly proportional to pxPerAu — the exact same rate the orbit distances
    // themselves scale at. That's what makes zoom strictly monotonic: zoom out -> pxPerAu drops ->
    // every body shrinks by the same factor as the orbits around it, full stop, no separate curve that
    // could ever push it the other way. (An earlier version compared against a fixed "default zoom"
    // baseline with a sqrt curve — that decoupled body size from true zoom level and let the sun's
    // fixed pixel size swallow the inner planets at the default overview.) At true AU scale, a
    // visible-sized sun will still overlap Mercury/Venus/Earth at the full-system view — that's not a
    // bug, it's the real ratio of the sun's size to their orbits; that's also exactly what the
    // reference screenshot shows (a small tight cluster near the star). Zoom in / tap a planet to
    // separate them.
    const val PLANET_SCALE = 0.09

    /** Screen radius for a body, directly proportional to the current AU-to-pixel ratio. */
    fun bodyPixelRadius(b: Body, pxPerAu: Double, minScreenDim: Float): Float {
        val sizeMult = if (b.isStar) 3.2 else 2.1
        val floor = if (b.isStar) 4f else 2f
        val raw = (b.radiusUnits * sizeMult * PLANET_SCALE * pxPerAu).toFloat()
        return raw.coerceIn(floor, minScreenDim * 0.42f)
    }

    /** viewRadiusAu that frames [b] as a [desiredPx]-ish close-up, given the current screen size. */
    fun focusViewRadiusFor(b: Body, minScreenDim: Float, desiredPx: Double): Double {
        val sizeMult = if (b.isStar) 3.2 else 2.1
        return ((b.radiusUnits * sizeMult * PLANET_SCALE * minScreenDim * 0.48) / desiredPx).coerceAtLeast(0.0005)
    }

    // ---------------------------------------------------------------- spacecraft trajectories (Hohmann transfer)

    /** GM of the Sun, km^3/s^2 (standard gravitational parameter) — used for real delta-v/time numbers. */
    private const val MU_SUN_KM3S2 = 1.32712440018e11
    private const val AU_KM = 1.495978707e8
    private const val SECONDS_PER_DAY = 86400.0

    /** Everything worth telling the user about a two-burn Hohmann transfer between two circular orbits. */
    data class HohmannResult(
        val transferDays: Double,   // one-way coast time, departure burn to arrival burn
        val deltaV1Kms: Double,     // burn at departure (raises or lowers the orbit onto the transfer ellipse)
        val deltaV2Kms: Double,     // burn at arrival (circularizes onto the target orbit)
        val eccentricity: Double,
        val semiMajorAxisAu: Double
    )

    /**
     * Classic two-impulse Hohmann transfer between two circular, coplanar orbits of radii [r1Au] and
     * [r2Au] (order doesn't matter — it works the same climbing out or dropping in). Real vis-viva
     * equation, real solar GM, not a placeholder formula — this is exactly what a mission planner would
     * compute for a first-pass estimate (ignores the planets' own gravity wells / Oberth effect, which
     * is the standard simplification at this level of fidelity).
     */
    fun hohmannTransfer(r1Au: Double, r2Au: Double): HohmannResult {
        val r1 = r1Au * AU_KM
        val r2 = r2Au * AU_KM
        val at = (r1 + r2) / 2.0
        val mu = MU_SUN_KM3S2
        val v1 = sqrt(mu / r1)
        val v2 = sqrt(mu / r2)
        val vTransferAt1 = sqrt(mu * (2.0 / r1 - 1.0 / at))
        val vTransferAt2 = sqrt(mu * (2.0 / r2 - 1.0 / at))
        val dv1 = Math.abs(vTransferAt1 - v1)
        val dv2 = Math.abs(v2 - vTransferAt2)
        val periodSeconds = 2 * Math.PI * sqrt((at * at * at) / mu)
        val transferDays = (periodSeconds / 2.0) / SECONDS_PER_DAY // half the transfer ellipse's period
        val ecc = Math.abs(r2 - r1) / (r1 + r2)
        return HohmannResult(transferDays, dv1, dv2, ecc, at / AU_KM)
    }

    /**
     * Points along the coasting arc of a Hohmann transfer from [r1Au] to [r2Au], for drawing the dashed
     * transfer ellipse on the `[sim]` screen. The ellipse's periapsis is placed at [startAngleDeg] (the
     * departure body's angle at burn time) so the arc visibly starts there; z is always 0 (transfer
     * plane assumed coplanar with the reference plane — a real transfer would also plane-change, but
     * that's a second, separate burn most mission designs avoid when they can help it).
     */
    fun transferEllipsePoints(r1Au: Double, r2Au: Double, startAngleDeg: Double, steps: Int = 72): List<Vec3> {
        val a = (r1Au + r2Au) / 2.0
        val e = Math.abs(r2Au - r1Au) / (r1Au + r2Au)
        val goingOut = r2Au >= r1Au
        val startRad = Math.toRadians(startAngleDeg)
        return (0..steps).map { i ->
            val theta = Math.PI * i / steps // 0 (periapsis) .. pi (apoapsis) — half the ellipse
            val r = a * (1 - e * e) / (1 + e * cos(theta))
            // if departing outward, periapsis (theta=0) is the start body's current position; if
            // dropping inward, the start body sits at apoapsis instead, so the arc is walked the other way
            val ang = startRad + (if (goingOut) theta else Math.PI - theta) * signOfTravel(startAngleDeg)
            Vec3(r * cos(ang), r * sin(ang), 0.0)
        }
    }

    // Kept as a hook in case a future version wants retrograde transfers; every orbit here is prograde.
    private fun signOfTravel(@Suppress("UNUSED_PARAMETER") startAngleDeg: Double): Double = 1.0

    // ---------------------------------------------------------------- conjunction / alignment finder

    /** Heliocentric ecliptic-longitude angle of [body] at time [tDays], 0..360 (circular-orbit approximation). */
    fun angleDeg(body: Body, tDays: Double): Double {
        if (body.el != null) {
            val p = position(body, tDays)
            return ((Math.toDegrees(atan2(p.y, p.x)) % 360.0) + 360.0) % 360.0
        }
        if (body.periodDays <= 0.0) return body.startAngleDeg
        val a = body.startAngleDeg + 360.0 * (tDays / body.periodDays)
        return ((a % 360.0) + 360.0) % 360.0
    }

    /** Signed angular separation between [a] and [b], wrapped to (-180, 180]. 0 = perfectly aligned with the star. */
    fun angleSeparation(a: Body, b: Body, tDays: Double): Double {
        var d = angleDeg(a, tDays) - angleDeg(b, tDays)
        d = ((d + 180.0) % 360.0 + 360.0) % 360.0 - 180.0
        return d
    }

    /**
     * Next time after [fromTDays] that [a] and [b] share the same heliocentric longitude — i.e. the star,
     * and both bodies, line up (conjunction as seen from the star; the everyday "when do Earth and Mars
     * align" question). Coarse-steps forward looking for the separation crossing zero, then bisects down
     * to sub-hour precision. Returns null if neither has a real period, or nothing is found within
     * [searchDays] (shouldn't happen for any pair with finite periods — the search window defaults to
     * comfortably more than either body's synodic period would ever need).
     */
    fun nextConjunction(a: Body, b: Body, fromTDays: Double, searchDays: Double = 200_000.0): Double? {
        if (a.periodDays <= 0.0 || b.periodDays <= 0.0 || a == b) return null
        // step size: a fraction of the faster body's period, fine enough not to skip past a crossing
        val step = min(a.periodDays, b.periodDays) / 60.0
        var t = fromTDays
        var prev = angleSeparation(a, b, t)
        val end = fromTDays + searchDays
        while (t < end) {
            val next = t + step
            val cur = angleSeparation(a, b, next)
            if (prev == 0.0) return t
            if ((prev > 0) != (cur > 0)) {
                // bisect between t and next for a precise crossing
                var lo = t; var hi = next; var loVal = prev
                repeat(40) {
                    val mid = (lo + hi) / 2.0
                    val midVal = angleSeparation(a, b, mid)
                    if ((midVal > 0) == (loVal > 0)) { lo = mid; loVal = midVal } else hi = mid
                }
                return (lo + hi) / 2.0
            }
            prev = cur
            t = next
        }
        return null
    }
}
