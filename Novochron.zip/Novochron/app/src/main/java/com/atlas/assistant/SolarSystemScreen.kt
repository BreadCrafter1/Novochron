package com.atlas.assistant

import android.content.Context
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.random.Random

/**
 * The lab: `[sim] [sky] [plan] [nbody] [graph]`. This is the host for the first four tabs; `[graph]` is
 * its own screen (GraphScreen.kt) that shows the same tab row, so tapping it swaps screens.
 *
 *  - `[sim]`   the orbit viewer below (real eccentric orbits, date scrubber, Halley, textures)
 *  - `[sky]`   SkyScreen.kt   — what's overhead, driven by the phone's rotation sensor
 *  - `[plan]`  PlanScreen.kt  — Hohmann transfer planner with a tiltable 3D arc
 *  - `[nbody]` NBodyScreen.kt — tap to drop a body and watch real gravity
 */
@Composable
fun SolarSystemScreen(onClose: () -> Unit) {
    var tab by remember {
        mutableStateOf(AssistantState.labTab.value.let { if (it in LabTabNames && it != "graph") it else "sim" })
    }
    Box(Modifier.fillMaxSize().background(Color.Black)) {
        Column(Modifier.fillMaxSize().padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                TermTextKey("[back]", onClick = onClose)
                Spacer(Modifier.weight(1f))
                Text(tab, color = Accent, fontFamily = TermFont, fontSize = 18.sp)
                Spacer(Modifier.weight(1f))
                Spacer(Modifier.width(56.dp))
            }
            LabTabs(active = tab) { t ->
                if (t == "graph") openLabTab("graph")
                else { tab = t; AssistantState.labTab.value = t }
            }
            Spacer(Modifier.height(4.dp))
            Box(Modifier.weight(1f).fillMaxWidth()) {
                when (tab) {
                    "sky" -> SkyTab()
                    "plan" -> PlanTab()
                    "nbody" -> NBodyTab()
                    else -> SimTab()
                }
            }
        }
    }
}

// ============================================================================================ [sim] tab

@Composable
private fun SimTab() {
    val ctx = LocalContext.current
    var systemIndex by remember { mutableStateOf(0) }
    val systemDef = OrbitMath.SYSTEMS[systemIndex]
    val bodies = remember(systemIndex) { systemDef.bodies }
    // Static scatter for the asteroid + Kuiper belts (only the real Solar System has any).
    val belts = remember(systemIndex) { systemDef.belts }
    val beltPoints = remember(systemIndex) { belts.map { it to OrbitMath.generateBeltPoints(it) } }
    val isSolar = systemIndex == 0

    // Solar System time is days since J2000.0 and starts at today; the other systems just count from 0.
    var tDays by remember(systemIndex) {
        mutableFloatStateOf(if (systemIndex == 0) (LabState.simT ?: OrbitMath.todayDays().toFloat()) else 0f)
    }
    var playing by remember { mutableStateOf(true) }
    var speed by remember { mutableFloatStateOf(1f) } // simulated days per real second, before the exponential scale below
    var direction by remember { mutableStateOf(1f) }
    var circular by remember { mutableStateOf(LabState.circular) }
    var camTick by remember { mutableIntStateOf(0) } // bumped whenever the camera moves, so a paused sim still redraws

    DisposableEffect(Unit) {
        onDispose {
            if (systemIndex == 0) LabState.simT = tDays
            LabState.circular = circular
        }
    }

    var texReady by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        withContext(Dispatchers.Default) { Textures.preload(ctx) }
        texReady = true
    }
    val milky = if (texReady) Textures.image(ctx, "milkyway") else null

    val camera = remember(systemIndex) {
        OrbitMath.Camera(yaw = 0.5, pitch = 0.55, viewRadiusAu = OrbitMath.outerAuOfWithBelts(bodies, belts) * 1.12)
    }
    var selected by remember(systemIndex) { mutableStateOf<OrbitMath.Body?>(null) }
    var focusBody by remember(systemIndex) { mutableStateOf<OrbitMath.Body?>(null) }
    val stars = remember { generateStarfield() }

    var transferFrom by remember(systemIndex) { mutableStateOf<OrbitMath.Body?>(null) }
    var transferTo by remember(systemIndex) { mutableStateOf<OrbitMath.Body?>(null) }
    var conjunctionNote by remember(systemIndex) { mutableStateOf("") }
    val github = remember { GitHub(Store.get(ctx)) }
    val scope = rememberCoroutineScope()
    var shareBusy by remember { mutableStateOf(false) }
    var shareNote by remember { mutableStateOf("") }
    var dateText by remember { mutableStateOf("") }
    var dateNote by remember { mutableStateOf("") }

    val daysPerSecond = Math.pow(10.0, (speed - 1.0) / 1.3).toFloat() * direction

    LaunchedEffect(playing, daysPerSecond, systemIndex) {
        if (!playing) return@LaunchedEffect
        while (true) {
            delay(32)
            tDays += daysPerSecond * 0.032f
        }
    }

    val tDaysState = androidx.compose.runtime.rememberUpdatedState(tDays)
    val circularState = androidx.compose.runtime.rememberUpdatedState(circular)
    val transferResult = remember(transferFrom, transferTo) {
        val a = transferFrom; val b = transferTo
        if (a != null && b != null && a != b && a.orbitAu > 0 && b.orbitAu > 0) OrbitMath.hohmannTransfer(a.orbitAu, b.orbitAu) else null
    }

    fun overviewRadius(): Double = OrbitMath.outerAuOfWithBelts(bodies, belts) * 1.12
    fun setView(inner: Boolean) {
        focusBody = null; selected = null
        val outer = OrbitMath.outerAuOf(bodies)
        camera.viewRadiusAu = if (inner) (if (isSolar) 1.85 else outer * 0.5) else (if (isSolar) 38.0 else outer * 1.12)
        camTick++
    }
    fun jumpToJd(jd: Double) {
        tDays = (jd - OrbitMath.J2000_JD).toFloat()
        dateNote = ""
        setView(inner = true)
        camera.viewRadiusAu = 2.2
        camTick++
    }

    val screenH = LocalConfiguration.current.screenHeightDp
    val canvasH = (screenH * 0.46f).coerceIn(230f, 430f).dp

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                if (isSolar) OrbitMath.dateFromDays(tDays.toDouble()).toString() else "t + ${(tDays / 365f).toInt()} y",
                color = Dim, fontFamily = TermFont, fontSize = 12.sp
            )
            Spacer(Modifier.weight(1f))
            TermTextKey(
                systemDef.label,
                tone = Accent,
                onClick = {
                    systemIndex = (systemIndex + 1) % OrbitMath.SYSTEMS.size
                    val next = OrbitMath.SYSTEMS[systemIndex]
                    selected = null; focusBody = null
                    transferFrom = null; transferTo = null; conjunctionNote = ""
                    camera.viewRadiusAu = OrbitMath.outerAuOfWithBelts(next.bodies, next.belts) * 1.12
                    camera.yaw = 0.5; camera.pitch = 0.55
                    camTick++
                }
            )
        }

        Box(
            Modifier
                .fillMaxWidth()
                .height(canvasH)
                .border(1.dp, Line)
                .pointerInput(systemIndex) {
                    detectTransformGestures { _, pan, zoom, _ ->
                        camera.yaw -= pan.x * 0.006
                        camera.pitch = (camera.pitch - pan.y * 0.006).coerceIn(-1.4, 1.4)
                        val outerAu = OrbitMath.outerAuOf(bodies)
                        camera.viewRadiusAu = (camera.viewRadiusAu / zoom).coerceIn(0.003, outerAu * 4.0)
                        camTick++
                    }
                }
                .pointerInput(bodies, systemIndex) {
                    detectTapGestures { tap ->
                        val w = size.width.toFloat(); val h = size.height.toFloat()
                        val t = tDaysState.value.toDouble()
                        val circ = circularState.value
                        val outerAu = OrbitMath.outerAuOf(bodies)
                        val focusPos = focusBody?.let { OrbitMath.position(it, t, circ) }
                            ?: OrbitMath.Vec3(0.0, 0.0, 0.0)
                        var best: OrbitMath.Body? = null
                        var bestDist = Float.MAX_VALUE
                        bodies.forEach { b ->
                            val p = OrbitMath.position(b, t, circ)
                            if ((b.comet?.e ?: 0.0) >= 1.0 && OrbitMath.distFromStar(p) > 45.0) return@forEach
                            val rel = OrbitMath.Vec3(p.x - focusPos.x, p.y - focusPos.y, p.z - focusPos.z)
                            val (sx, sy, _) = camera.project(rel, w, h)
                            val rr = OrbitMath.bodyPixelRadius(b, camera.pxPerAu(w, h), min(w, h))
                            val d = OrbitMath.dist(tap.x, tap.y, sx, sy)
                            val tol = max(rr + 8f, 30f)
                            if (d < tol && d < bestDist) { bestDist = d; best = b }
                        }
                        val tapped = best
                        if (tapped != null) {
                            selected = tapped
                            if (!tapped.isStar && tapped != focusBody) {
                                focusBody = tapped
                                camera.viewRadiusAu = OrbitMath.focusViewRadiusFor(tapped, min(w, h), 130.0)
                            } else if (tapped.isStar && focusBody != null) {
                                focusBody = null
                                camera.viewRadiusAu = outerAu * 1.12
                            }
                        } else if (focusBody != null) {
                            focusBody = null; selected = null; camera.viewRadiusAu = outerAu * 1.12
                        }
                        camTick++
                    }
                }
        ) {
            OrbitCanvas(
                ctx, bodies, beltPoints, tDays, circular, camera, stars, milky, texReady,
                selected, focusBody, transferFrom, transferTo, isSolar, camTick
            )
        }

        selected?.let { b ->
            Spacer(Modifier.height(6.dp))
            Text(describeBody(b, tDays.toDouble(), circular), color = Ink, fontFamily = TermFont, fontSize = 12.sp)
        }

        // ---- view / orbit shape
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("view", color = Dim, fontFamily = TermFont, fontSize = 11.sp)
            TermTextKey("Inner", onClick = { setView(true) })
            TermTextKey("Full", onClick = { setView(false) })
            TermTextKey("[overview]", onClick = {
                focusBody = null; selected = null
                camera.viewRadiusAu = overviewRadius()
                camera.yaw = 0.5; camera.pitch = 0.55
                camTick++
            })
        }
        if (isSolar) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("orbits", color = Dim, fontFamily = TermFont, fontSize = 11.sp)
                TermTextKey("Eccentric", tone = if (!circular) Accent else Ink, bold = !circular, onClick = { circular = false })
                TermTextKey("Circular", tone = if (circular) Accent else Ink, bold = circular, onClick = { circular = true })
            }
        }

        // ---- time
        Row(verticalAlignment = Alignment.CenterVertically) {
            TermTextKey(if (direction < 0f) "[<<]" else "[>>]", tone = if (direction < 0f) Warn else Ink, onClick = { direction = -direction })
            TermTextKey(if (playing) "Pause" else "Play", onClick = { playing = !playing })
            Spacer(Modifier.width(6.dp))
            Text("speed", color = Dim, fontFamily = TermFont, fontSize = 11.sp)
            Slider(
                value = speed,
                onValueChange = { speed = it },
                valueRange = 0f..8f,
                colors = SliderDefaults.colors(thumbColor = Accent, activeTrackColor = Accent, inactiveTrackColor = Line),
                modifier = Modifier.weight(1f).padding(horizontal = 8.dp)
            )
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("rate", color = Dim, fontFamily = TermFont, fontSize = 11.sp)
            TermTextKey("10 d/s", onClick = { speed = 2.3f; direction = 1f })
            TermTextKey("100 d/s", onClick = { speed = 3.6f; direction = 1f })
            TermTextKey("1 y/s", onClick = { speed = 4.33f; direction = 1f })
        }

        if (isSolar) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("date", color = Dim, fontFamily = TermFont, fontSize = 11.sp)
                Slider(
                    value = tDays.coerceIn(OrbitMath.MIN_DAYS.toFloat(), OrbitMath.MAX_DAYS.toFloat()),
                    onValueChange = { tDays = it; dateNote = "" },
                    valueRange = OrbitMath.MIN_DAYS.toFloat()..OrbitMath.MAX_DAYS.toFloat(),
                    colors = SliderDefaults.colors(thumbColor = Accent, activeTrackColor = Accent, inactiveTrackColor = Line),
                    modifier = Modifier.weight(1f).padding(horizontal = 8.dp)
                )
                Text(OrbitMath.dateFromDays(tDays.toDouble()).toString(), color = Ink, fontFamily = TermFont, fontSize = 11.sp)
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                TermTextKey("Today", onClick = { tDays = OrbitMath.todayDays().toFloat(); dateNote = ""; camTick++ })
                TermTextKey("Halley 1986", onClick = { jumpToJd(2446470.96) })
                TermTextKey("Halley 2061", onClick = { jumpToJd(2474033.5) })
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                TermTextKey("'Oumuamua 2017", onClick = { jumpToJd(2458005.59) })
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("go to", color = Dim, fontFamily = TermFont, fontSize = 11.sp)
                Spacer(Modifier.width(6.dp))
                OutlinedTextField(
                    value = dateText,
                    onValueChange = { dateText = it },
                    singleLine = true,
                    placeholder = { Text("yyyy-mm-dd or dd/mm/yyyy", color = Dim, fontFamily = TermFont, fontSize = 12.sp) },
                    textStyle = TextStyle(fontFamily = TermFont, fontSize = 14.sp, color = Ink),
                    colors = fieldColors(),
                    modifier = Modifier.weight(1f)
                )
                TermTextKey("[go]", tone = Accent, onClick = {
                    val d = parseDate(dateText)
                    if (d == null) dateNote = "Couldn't read that date."
                    else {
                        val t = OrbitMath.daysFromDate(d)
                        if (t < OrbitMath.MIN_DAYS || t > OrbitMath.MAX_DAYS) dateNote = "Dates run from 1900 to 2100."
                        else { tDays = t.toFloat(); dateNote = ""; camTick++ }
                    }
                })
            }
            if (dateNote.isNotBlank()) Text(dateNote, color = Warn, fontFamily = TermFont, fontSize = 11.sp)
        } else {
            Row { TermTextKey("[reset t]", onClick = { tDays = 0f; camTick++ }) }
        }

        // ---- share
        Row(verticalAlignment = Alignment.CenterVertically) {
            TermTextKey(
                "[export]",
                onClick = {
                    val bmp = Sharing.renderOrbitSnapshot(bodies, tDays.toDouble(), camera, focusBody, 1000, 1400, circular)
                    Sharing.shareBitmap(ctx, bmp, "orbit-${systemDef.key}")
                }
            )
            TermTextKey(
                if (shareBusy) "[linking…]" else "[link]",
                tone = if (shareBusy) Dim else Ink,
                onClick = {
                    if (!shareBusy) {
                        shareBusy = true; shareNote = ""
                        scope.launch {
                            try {
                                val bmp = Sharing.renderOrbitSnapshot(bodies, tDays.toDouble(), camera, focusBody, 1000, 1400, circular)
                                shareNote = Sharing.uploadAndLink(github, bmp, "orbit-${systemDef.key}")
                            } catch (e: Exception) {
                                shareNote = "Couldn't upload — check the vault is set up in [vault]."
                            } finally {
                                shareBusy = false
                            }
                        }
                    }
                }
            )
        }
        if (shareNote.isNotBlank()) Text(shareNote, color = Accent, fontFamily = TermFont, fontSize = 11.sp)

        // ---- transfer / alignment (the full planner is the [plan] tab)
        Spacer(Modifier.height(6.dp))
        Text("spacecraft transfer & alignment", color = Dim, fontFamily = TermFont, fontSize = 11.sp)
        Row(verticalAlignment = Alignment.CenterVertically) {
            TermTextKey(
                "[start:${transferFrom?.name ?: "—"}]",
                onClick = { selected?.let { if (!it.isStar && !it.isComet) transferFrom = it } }
            )
            TermTextKey(
                "[target:${transferTo?.name ?: "—"}]",
                onClick = { selected?.let { if (!it.isStar && !it.isComet) transferTo = it } }
            )
            TermTextKey("[clear]", onClick = { transferFrom = null; transferTo = null; conjunctionNote = "" })
        }
        Text("tap a planet above to select it, then tap [start]/[target] to assign it", color = Dim, fontFamily = TermFont, fontSize = 10.sp)
        transferResult?.let { r ->
            Text(
                "Transfer ${transferFrom?.name} → ${transferTo?.name}: ${fmt(r.transferDays)} days coast, " +
                    "Δv ≈ ${fmt(r.deltaV1Kms)} km/s + ${fmt(r.deltaV2Kms)} km/s",
                color = Ink, fontFamily = TermFont, fontSize = 12.sp
            )
            TermTextKey(
                "[find next align]",
                onClick = {
                    val a = transferFrom; val b = transferTo
                    if (a != null && b != null) {
                        val next = OrbitMath.nextConjunction(a, b, tDays.toDouble())
                        conjunctionNote = if (next != null) {
                            val daysAway = next - tDays
                            tDays = next.toFloat(); playing = false; camTick++
                            "${a.name} and ${b.name} align with the star in ~${fmt(daysAway)} days from where you were — jumped there and paused."
                        } else "Couldn't find an alignment in the searched window."
                    }
                }
            )
        }
        if (conjunctionNote.isNotBlank()) Text(conjunctionNote, color = Accent, fontFamily = TermFont, fontSize = 11.sp)

        Text(
            "Drag to orbit · pinch to zoom · tap a body to zoom into it, tap empty space to back out",
            color = Dim, fontFamily = TermFont, fontSize = 11.sp
        )
        Spacer(Modifier.height(24.dp))
    }
}

private fun parseDate(raw: String): java.time.LocalDate? {
    val t = raw.trim()
    if (t.isEmpty()) return null
    for (pattern in listOf("yyyy-MM-dd", "d/M/yyyy", "d.M.yyyy")) {
        try {
            return java.time.LocalDate.parse(t, java.time.format.DateTimeFormatter.ofPattern(pattern))
        } catch (e: Exception) {
            // try the next pattern
        }
    }
    return null
}

private fun describeBody(b: OrbitMath.Body, tDays: Double, circular: Boolean): String {
    if (b.isStar) return "${b.name} — the system's star"
    val c = b.comet
    if (c != null) {
        val d = OrbitMath.distFromStar(OrbitMath.position(b, tDays, circular))
        if (c.e >= 1.0) {
            return "${b.name} — interstellar visitor on a hyperbolic path (e ${fmt(c.e)}), perihelion " +
                "${OrbitMath.dateFromDays(c.periJd[0] - OrbitMath.J2000_JD)}. Now ${fmt(d)} AU from the Sun."
        }
        val jd = OrbitMath.J2000_JD + tDays
        val next = c.periJd.firstOrNull { it > jd }
        return "${b.name} — ${fmt(c.a)} AU semi-major axis, e ${fmt(c.e)}, about 76 years per lap. Now ${fmt(d)} AU from the Sun" +
            (if (next != null) "; next perihelion ${OrbitMath.dateFromDays(next - OrbitMath.J2000_JD)}." else ".")
    }
    val base = "${b.name} — ${fmt(b.orbitAu)} AU out, orbits every ${fmt(b.periodDays)} days" +
        (if (b.periodDays > 700) " (${fmt(b.periodDays / 365.25)} years)" else "")
    if (b.el != null) {
        val d = OrbitMath.distFromStar(OrbitMath.position(b, tDays, circular))
        return base + ". Now ${fmt(d)} AU from the Sun" + (if (!circular) " (eccentricity ${fmt(b.el.e0)})." else ".")
    }
    return base
}

private fun fmt(v: Double): String {
    val r = Math.round(v * 100.0) / 100.0
    return if (r == r.toLong().toDouble()) r.toLong().toString() else r.toString()
}

// ---------------------------------------------------------------------------------------- drawing

/** A star's position as size-independent fractions, plus its look — used only if the Milky Way texture is missing. */
private class Star(val fx: Float, val fy: Float, val radius: Float, val alpha: Float, val tint: Color)

private fun generateStarfield(): List<Star> {
    val rnd = Random(20240609)
    return List(500) {
        val bright = rnd.nextFloat()
        val r = if (bright > 0.985f) 1.6f else if (bright > 0.9f) 1.1f else 0.6f
        val tintRoll = rnd.nextFloat()
        val tint = when {
            tintRoll > 0.85f -> Color(0xFFB4C8FF)
            tintRoll > 0.7f -> Color(0xFFFFDCB4)
            else -> Color.White
        }
        Star(rnd.nextFloat(), rnd.nextFloat(), r, 0.35f + bright * 0.6f, tint)
    }
}

private fun DrawScope.drawFallbackStarfield(stars: List<Star>) {
    val w = size.width; val h = size.height
    rotate(degrees = -20f, pivot = Offset(w * 0.5f, h * 0.55f)) {
        drawRect(
            brush = Brush.verticalGradient(
                colors = listOf(Color(0x00282C3C), Color(0x1A78788C), Color(0x29BEB9C8), Color(0x1A78788C), Color(0x00282C3C)),
                startY = h * 0.05f, endY = h
            ),
            topLeft = Offset(-w * 0.5f, -h * 0.5f),
            size = Size(w * 2f, h * 2f)
        )
    }
    stars.forEach { s ->
        drawCircle(color = s.tint.copy(alpha = s.alpha), radius = s.radius, center = Offset(s.fx * w, s.fy * h))
    }
}

private val labelPaint = android.graphics.Paint().apply { isAntiAlias = true; textSize = 24f }

internal fun DrawScope.drawLabel(text: String, x: Float, y: Float, argb: Int) {
    labelPaint.color = argb
    drawContext.canvas.nativeCanvas.drawText(text, x, y, labelPaint)
}

private class Drawn(val b: OrbitMath.Body, val pos: Offset, val depth: Double, val au: Double)

@Composable
private fun OrbitCanvas(
    ctx: Context,
    bodies: List<OrbitMath.Body>,
    beltPoints: List<Pair<OrbitMath.Belt, List<OrbitMath.BeltPoint>>>,
    tDays: Float,
    circular: Boolean,
    camera: OrbitMath.Camera,
    stars: List<Star>,
    milky: ImageBitmap?,
    texReady: Boolean,
    selected: OrbitMath.Body?,
    focusBody: OrbitMath.Body?,
    transferFrom: OrbitMath.Body?,
    transferTo: OrbitMath.Body?,
    isSolar: Boolean,
    camTick: Int
) {
    Canvas(Modifier.fillMaxSize()) {
        @Suppress("UNUSED_VARIABLE") val tick = camTick // read so a camera move invalidates this draw
        val w = size.width; val h = size.height
        val t = tDays.toDouble()

        if (milky != null) drawMilkyWay(milky, camera.yaw, camera.pitch, 0.95f) else drawFallbackStarfield(stars)

        val outerAu = OrbitMath.outerAuOf(bodies)
        val focusPos = focusBody?.let { OrbitMath.position(it, t, circular) } ?: OrbitMath.Vec3(0.0, 0.0, 0.0)
        fun relative(p: OrbitMath.Vec3) = OrbitMath.Vec3(p.x - focusPos.x, p.y - focusPos.y, p.z - focusPos.z)

        // faint AU distance rings around the star
        if (focusBody == null) {
            val ringSteps = 4
            for (i in 1..ringSteps) {
                val au = (outerAu / ringSteps) * i
                var prev: Offset? = null
                for (j in 0..72) {
                    val ang = (j / 72.0) * 2 * Math.PI
                    val (sx, sy, _) = camera.project(OrbitMath.Vec3(au * cos(ang), au * sin(ang), 0.0), w, h)
                    val cur = Offset(sx, sy)
                    if (prev != null) drawLine(color = Color(0x28C8C8C8), start = prev, end = cur, strokeWidth = 1f)
                    prev = cur
                }
            }
        }

        // asteroid + Kuiper belts
        if (focusBody == null && beltPoints.isNotEmpty()) {
            beltPoints.forEach { (belt, points) ->
                val base = Color(belt.color)
                points.forEach { p ->
                    val (sx, sy, _) = camera.project(OrbitMath.Vec3(p.x, p.y, p.z), w, h)
                    drawCircle(color = base.copy(alpha = 0.18f + p.jitter * 0.35f), radius = 1.0f + p.jitter * 0.9f, center = Offset(sx, sy))
                }
            }
        }

        // orbit paths — real ellipses (or circles when the Circular toggle is on)
        bodies.forEach { b ->
            if (b.isStar || b.orbitAu <= 0.0) return@forEach
            val pathColor = if (b.isComet) Color(0x66BFE8FF) else Color(0x59DCC88C)
            val pts = OrbitMath.orbitPoints(b, circular, if (b.isComet) 200 else 120)
            var prev: Offset? = null
            pts.forEach { p3 ->
                val (sx, sy, _) = camera.project(relative(p3), w, h)
                val cur = Offset(sx, sy)
                if (prev != null) drawLine(color = pathColor, start = prev!!, end = cur, strokeWidth = 1f)
                prev = cur
            }
        }

        // spacecraft transfer arc
        if (transferFrom != null && transferTo != null && transferFrom != transferTo &&
            transferFrom.orbitAu > 0 && transferTo.orbitAu > 0
        ) {
            val startAngle = OrbitMath.angleDeg(transferFrom, t)
            val pts = OrbitMath.transferEllipsePoints(transferFrom.orbitAu, transferTo.orbitAu, startAngle)
            var prev: Offset? = null
            pts.forEachIndexed { i, p3 ->
                val (sx, sy, _) = camera.project(relative(p3), w, h)
                val cur = Offset(sx, sy)
                if (prev != null && i % 2 == 0) drawLine(color = Color(0xFFFFD24C), start = prev!!, end = cur, strokeWidth = 2f)
                prev = cur
            }
        }

        val starScreen = camera.project(relative(OrbitMath.Vec3(0.0, 0.0, 0.0)), w, h).let { Offset(it.first, it.second) }
        val pxPerAu = camera.pxPerAu(w, h)
        val minDim = min(w, h)
        val showLabels = camera.viewRadiusAu < 12.0

        val drawn = bodies.mapNotNull { b ->
            val p3 = OrbitMath.position(b, t, circular)
            val au = OrbitMath.distFromStar(p3)
            if ((b.comet?.e ?: 0.0) >= 1.0 && au > 45.0) return@mapNotNull null // 'Oumuamua is only "here" near its flyby
            val (sx, sy, depth) = camera.project(relative(p3), w, h)
            Drawn(b, Offset(sx, sy), depth, au)
        }.sortedBy { it.depth }

        drawn.forEach { d ->
            val b = d.b
            val pos = d.pos
            val r = OrbitMath.bodyPixelRadius(b, pxPerAu, minDim)

            if (b.isComet) {
                drawComet(b, pos, r, starScreen, d.au)
                if (showLabels || b == selected) drawLabel(b.name, pos.x + r + 8f, pos.y - 8f, 0xCCBFE8FF.toInt())
                if (b == selected) drawCircle(color = Accent, radius = r + 8f, center = pos, style = Stroke(width = 1.5f))
                return@forEach
            }

            if (b.isStar) {
                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(Color(b.color).copy(alpha = 0.35f), Color(b.color).copy(alpha = 0f)),
                        center = pos, radius = r * 3f
                    ),
                    radius = r * 3f, center = pos
                )
            }

            if (b.rings) drawRingHalf(ctx, pos, r, back = true)
            drawTexturedBody(ctx, b, pos, r, if (b.isStar) null else starScreen)
            if (b.rings) drawRingHalf(ctx, pos, r, back = false)
            if (b.moons.isNotEmpty()) drawMoons(b, pos, r, tDays)

            if (showLabels || b == selected || b == focusBody) {
                drawLabel(b.name, pos.x + r + 6f, pos.y - r - 4f, 0xCCE8E8E8.toInt())
            }
            if (b == selected) drawCircle(color = Accent, radius = r + 6f, center = pos, style = Stroke(width = 1.5f))
        }

        // HUD, bottom-left
        val halley = drawn.firstOrNull { it.b.name == "Halley" }
        val hud = if (isSolar) {
            OrbitMath.dateFromDays(t).toString() + (if (halley != null) "   Halley ${fmt(halley.au)} AU" else "") +
                (focusBody?.let { "   focused: ${it.name}" } ?: "")
        } else {
            val totalDays = tDays.toLong()
            "t + ${totalDays / 365} y ${totalDays % 365} d" + (focusBody?.let { "   focused: ${it.name}" } ?: "")
        }
        drawLabel(hud, 12f, h - 14f, 0xD9E8E8E8.toInt())
    }
}

/** Comet: a glowing coma + a tail pointing away from the star that grows as it nears the Sun. */
private fun DrawScope.drawComet(b: OrbitMath.Body, pos: Offset, r: Float, starScreen: Offset, distAu: Double) {
    val dx = pos.x - starScreen.x
    val dy = pos.y - starScreen.y
    val len = sqrt(dx * dx + dy * dy)
    val ux = if (len > 0.5f) dx / len else 1f
    val uy = if (len > 0.5f) dy / len else 0f
    val hasTail = (b.comet?.e ?: 0.0) < 1.0
    val d = distAu.toFloat()
    val tailLen = if (hasTail) ((60f * (4f - d).coerceAtLeast(0f) / (d + 0.5f)).coerceAtMost(220f)) else 0f
    val core = max(2.2f, min(r, 6f))
    if (tailLen > 4f) {
        val px = -uy; val py = ux
        val half = core + 2f
        val end = Offset(pos.x + ux * tailLen, pos.y + uy * tailLen)
        // ion tail: straight, blue-white
        val ion = Path().apply {
            moveTo(pos.x + px * half, pos.y + py * half)
            lineTo(end.x, end.y)
            lineTo(pos.x - px * half, pos.y - py * half)
            close()
        }
        drawPath(ion, brush = Brush.linearGradient(listOf(Color(0xAAD8F2FF), Color(0x00D8F2FF)), start = pos, end = end))
        // dust tail: shorter, curved slightly, warmer
        val curve = Offset(pos.x + ux * tailLen * 0.55f + px * tailLen * 0.14f, pos.y + uy * tailLen * 0.55f + py * tailLen * 0.14f)
        val dustEnd = Offset(pos.x + ux * tailLen * 0.8f + px * tailLen * 0.30f, pos.y + uy * tailLen * 0.8f + py * tailLen * 0.30f)
        val dust = Path().apply {
            moveTo(pos.x, pos.y)
            quadraticBezierTo(curve.x, curve.y, dustEnd.x, dustEnd.y)
        }
        drawPath(dust, color = Color(0x55FFE2B8), style = Stroke(width = half * 1.6f))
    }
    if (d < 3.5f || !hasTail) drawGlow(pos, core * 4f, Color(0xFFBFE8FF), 0.8f)
    drawCircle(color = Color(0xFFF4FBFF), radius = core * 0.6f, center = pos)
}

/** Draws the near or far half of the rings, banded from rings.png, squashed into an ellipse. */
private fun DrawScope.drawRingHalf(ctx: Context, center: Offset, r: Float, back: Boolean) {
    val rxOut = r * 2.3f
    val ryOut = r * 0.75f
    val stops = Textures.ringGradientStops(ctx, 1.35f / 2.3f)
    val halfClip = Path().apply {
        val top = center.y - ryOut - 4f
        val bottom = center.y + ryOut + 4f
        if (back) addRect(Rect(center.x - rxOut - 4f, top, center.x + rxOut + 4f, center.y))
        else addRect(Rect(center.x - rxOut - 4f, center.y, center.x + rxOut + 4f, bottom))
    }
    clipPath(halfClip) {
        withTransform({ scale(1f, ryOut / rxOut, center) }) {
            drawCircle(
                brush = Brush.radialGradient(*stops.toTypedArray(), center = center, radius = rxOut),
                radius = rxOut, center = center
            )
        }
    }
}

private fun DrawScope.drawMoons(b: OrbitMath.Body, center: Offset, r: Float, tDays: Float) {
    b.moons.forEach { m ->
        val orbitR = r * m.orbitFactor.toFloat()
        val ang = (if (m.periodDays > 0) ((tDays % m.periodDays.toFloat()) / m.periodDays.toFloat()) else 0f) * 2 * Math.PI.toFloat()
        val mx = center.x + cos(ang) * orbitR
        val my = center.y + sin(ang) * orbitR * 0.55f
        val mr = max(1.2f, r * m.radiusUnits.toFloat() * 0.5f)
        drawOval(
            color = Color.White.copy(alpha = 0.10f),
            topLeft = Offset(center.x - orbitR, center.y - orbitR * 0.55f),
            size = Size(orbitR * 2f, orbitR * 1.1f),
            style = Stroke(width = 1f)
        )
        drawCircle(color = Color(m.color), radius = mr, center = Offset(mx, my))
    }
}

/**
 * A textured, lit sphere. Uses the wrapped texture from [Textures] when the file is there (spinning slowly,
 * lit from the direction of the star at [starScreen]); otherwise falls back to the old procedural shading.
 */
internal fun DrawScope.drawTexturedBody(ctx: Context, b: OrbitMath.Body, center: Offset, r: Float, starScreen: Offset?) {
    val name = Textures.nameFor(b)
    val texSize = if (r > 40f) 192 else 96
    val img = if (name != null && r >= 3f) Textures.sphere(ctx, name, Textures.spinStep(name), texSize) else null
    if (img != null) {
        val d = (2f * r).toInt().coerceAtLeast(2)
        drawImage(
            image = img,
            srcOffset = IntOffset.Zero,
            srcSize = IntSize(img.width, img.height),
            dstOffset = IntOffset((center.x - r).toInt(), (center.y - r).toInt()),
            dstSize = IntSize(d, d),
            filterQuality = FilterQuality.Medium
        )
        val circle = Path().apply { addOval(Rect(center.x - r, center.y - r, center.x + r, center.y + r)) }
        clipPath(circle) {
            if (starScreen != null) {
                // light comes from the star: the far side of the planet falls into shadow
                var lx = starScreen.x - center.x
                var ly = starScreen.y - center.y
                val ll = sqrt(lx * lx + ly * ly)
                if (ll > 0.5f) { lx /= ll; ly /= ll } else { lx = -0.5f; ly = -0.5f }
                val lightCenter = Offset(center.x + lx * r * 0.55f, center.y + ly * r * 0.55f)
                drawCircle(
                    brush = Brush.radialGradient(
                        0f to Color.Transparent,
                        0.55f to Color.Black.copy(alpha = 0.10f),
                        1f to Color.Black.copy(alpha = 0.88f),
                        center = lightCenter, radius = r * 1.75f
                    ),
                    radius = r, center = center
                )
            } else {
                // a star glows: brighten the middle instead of shading the edge
                drawCircle(
                    brush = Brush.radialGradient(
                        0f to Color.White.copy(alpha = 0.18f),
                        1f to Color.Transparent,
                        center = center, radius = r
                    ),
                    radius = r, center = center
                )
            }
        }
        return
    }
    drawProceduralBody(b, center, r)
}

/** The original gradient-and-blobs shading, kept as the fallback when a texture file is missing. */
private fun DrawScope.drawProceduralBody(b: OrbitMath.Body, center: Offset, r: Float) {
    val base = Color(b.color)
    val circle = Path().apply { addOval(Rect(center.x - r, center.y - r, center.x + r, center.y + r)) }
    clipPath(circle) {
        val lightCenter = Offset(center.x - r * 0.35f, center.y - r * 0.35f)
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(base.copy(alpha = 1f), base.copy(alpha = 0.55f)),
                center = lightCenter, radius = r * 1.6f
            ),
            radius = r, center = center
        )
        when (b.texture) {
            OrbitMath.Texture.GAS_BANDED -> {
                val bandColors = listOf(
                    base.copy(alpha = 0.35f), Color.White.copy(alpha = 0.12f),
                    base.copy(alpha = 0.30f), Color.Black.copy(alpha = 0.10f), base.copy(alpha = 0.25f)
                )
                bandColors.forEachIndexed { i, c ->
                    val bandY = center.y - r + (2 * r / bandColors.size) * i
                    drawRect(color = c, topLeft = Offset(center.x - r, bandY), size = Size(r * 2f, 2 * r / bandColors.size + 1f))
                }
            }
            OrbitMath.Texture.EARTH -> {
                val rnd = Random(b.name.hashCode())
                repeat(6) {
                    val bx = center.x + (rnd.nextFloat() - 0.5f) * r * 1.6f
                    val by = center.y + (rnd.nextFloat() - 0.5f) * r * 1.6f
                    drawCircle(color = Color(0xFF3C9646).copy(alpha = 0.8f), radius = r * (0.18f + rnd.nextFloat() * 0.2f), center = Offset(bx, by))
                }
            }
            OrbitMath.Texture.MARS -> {
                val rnd = Random(b.name.hashCode())
                repeat(5) {
                    val bx = center.x + (rnd.nextFloat() - 0.5f) * r * 1.5f
                    val by = center.y + (rnd.nextFloat() - 0.5f) * r * 1.5f
                    drawCircle(color = Color(0xFF7A2E14).copy(alpha = 0.35f), radius = r * (0.15f + rnd.nextFloat() * 0.2f), center = Offset(bx, by))
                }
                drawOval(color = Color.White.copy(alpha = 0.75f), topLeft = Offset(center.x - r * 0.5f, center.y - r * 1.0f), size = Size(r, r * 0.4f))
            }
            OrbitMath.Texture.ROCK -> {
                val rnd = Random(b.name.hashCode())
                repeat(18) {
                    val bx = center.x + (rnd.nextFloat() - 0.5f) * r * 1.7f
                    val by = center.y + (rnd.nextFloat() - 0.5f) * r * 1.7f
                    drawCircle(color = Color.Black.copy(alpha = 0.12f), radius = r * 0.06f, center = Offset(bx, by))
                }
            }
            else -> { /* base gradient above is enough */ }
        }
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(Color.Transparent, Color.Black.copy(alpha = 0.08f), Color.Black.copy(alpha = 0.5f)),
                center = lightCenter, radius = r * 1.05f
            ),
            radius = r, center = center
        )
    }
    drawCircle(color = Color.Black.copy(alpha = 0.6f), radius = r, center = center, style = Stroke(width = 1f))
}
