package com.atlas.assistant

import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer

/**
 * Continuous hands-free listening: no press-to-talk. Restarts itself after every phrase and keeps
 * running while Novochron is thinking or speaking, so the user can talk over it (the engine filters out
 * Novochron's own voice). Uses the on-device recognizer when there is no internet.
 *
 * Turn-taking speed: the recognizer's own EXTRA_SPEECH_INPUT_..._MILLIS extras below are a fixed
 * silence-length guess and stay in place as the baseline/fallback. On top of that, when
 * Store.instantResponseEnabled is on, a lightweight endpoint detector watches the recognizer's own
 * onRmsChanged volume readout and force-stops it the instant real silence follows real speech, so
 * replies start right away instead of waiting out the fixed timer.
 *
 * This used to run a second, separate mic tap (a Silero VAD model over its own AudioRecord - see
 * VadEndpointer, no longer wired in here) to do this more precisely. That approach could silently
 * starve the recognizer of audio: Android doesn't error when a second concurrent capture isn't truly
 * supported on a device, it just mutes one of the two sessions, and there's no public API to detect
 * this in advance - so the recognizer could end up hearing nothing at all while Novochron sat on
 * "Listening…" forever. Reading onRmsChanged instead reuses the recognizer's *own* single audio
 * session, so there's nothing for it to compete with - just a coarser signal (an ambient noise floor
 * that adapts per utterance, not real speech/silence classification).
 */
class Listener(
    private val ctx: Context,
    private val onText: (String) -> Unit,
    private val onPartial: (String) -> Unit,
    private val onFatal: (String) -> Unit,
    private val onSpeechEnd: () -> Unit = {}
) : RecognitionListener {

    private val main = Handler(Looper.getMainLooper())
    private val audio = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private val store = Store.get(ctx)
    private var rec: SpeechRecognizer? = null
    private var recOffline = false
    private var active = false
    private var running = false
    private var offlineUntil = 0L

    // ---- RMS-based endpoint detector state (see class doc) ----
    private var rmsFloor = Float.NaN
    private var speechActive = false
    private var silenceSinceMs = 0L

    fun start() {
        if (!SpeechRecognizer.isRecognitionAvailable(ctx)) {
            onFatal("No speech recognition service found. Install or enable the Google app.")
            return
        }
        active = true
        setBeepMuted(true)
        begin()
    }

    fun stop() {
        active = false
        main.removeCallbacksAndMessages(null)
        destroy()
        setBeepMuted(false)
    }

    private fun begin() {
        if (!active || running) return
        rmsFloor = Float.NaN
        speechActive = false
        silenceSinceMs = 0L
        val offline = store.forceOffline || System.currentTimeMillis() < offlineUntil || !Net.isOnline(ctx)
        if (rec == null || recOffline != offline) {
            destroy()
            rec = makeRecognizer(offline)
            recOffline = offline
            rec?.setRecognitionListener(this)
        }
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
            putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, offline)
            putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, ctx.packageName)
            // Snappy turn-taking: Novochron should start answering right after the user stops talking, not
            // after a long pause. A short, natural breath mid-sentence is still shorter than this, so it
            // doesn't cut people off, but the assistant no longer sits there waiting once they're done.
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 450L)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 300L)
        }
        running = true
        try {
            rec?.startListening(i)
        } catch (e: Exception) {
            running = false
            retry(1000)
        }
    }

    private fun makeRecognizer(offline: Boolean): SpeechRecognizer =
        if (offline && Build.VERSION.SDK_INT >= 31 && SpeechRecognizer.isOnDeviceRecognitionAvailable(ctx)) {
            SpeechRecognizer.createOnDeviceSpeechRecognizer(ctx)
        } else {
            SpeechRecognizer.createSpeechRecognizer(ctx)
        }

    private fun retry(ms: Long) {
        main.removeCallbacksAndMessages(null)
        main.postDelayed({ begin() }, ms)
    }

    private fun destroy() {
        try { rec?.destroy() } catch (e: Exception) { }
        rec = null
        running = false
    }

    private fun setBeepMuted(mute: Boolean) {
        val dir = if (mute) AudioManager.ADJUST_MUTE else AudioManager.ADJUST_UNMUTE
        for (s in intArrayOf(AudioManager.STREAM_NOTIFICATION, AudioManager.STREAM_SYSTEM)) {
            try { audio.adjustStreamVolume(s, dir, 0) } catch (e: Exception) { }
        }
    }

    // ---- RecognitionListener ----
    override fun onReadyForSpeech(params: Bundle?) {}
    override fun onBeginningOfSpeech() {}
    override fun onRmsChanged(rmsdB: Float) {
        if (!store.instantResponseEnabled || !active || !running) return
        if (rmsdB.isNaN() || rmsdB <= -100f) return // some devices report a bogus reading right at session start

        val now = System.currentTimeMillis()
        if (rmsFloor.isNaN()) rmsFloor = rmsdB
        if (!speechActive) {
            // Ambient noise floor for this utterance, adapted slowly - frozen once real speech starts so
            // the speaker's own voice doesn't drag the floor upward.
            rmsFloor = rmsFloor * 0.9f + rmsdB * 0.1f
        }
        val speechThreshold = rmsFloor + SPEECH_MARGIN_DB
        val silenceThreshold = rmsFloor + SILENCE_MARGIN_DB // hysteresis band, see VadEndpointer's original

        if (rmsdB >= speechThreshold) {
            speechActive = true
            silenceSinceMs = 0L
        } else if (speechActive) {
            if (rmsdB <= silenceThreshold) {
                if (silenceSinceMs == 0L) {
                    silenceSinceMs = now
                } else if (now - silenceSinceMs >= SILENCE_HANGOVER_MS) {
                    speechActive = false
                    silenceSinceMs = 0L
                    DebugTelemetry.recordVadEndpoint()
                    try { rec?.stopListening() } catch (e: Exception) { }
                    onSpeechEnd()
                }
            } else {
                silenceSinceMs = 0L // back above the silence band - still mid-speech
            }
        }
    }
    override fun onBufferReceived(buffer: ByteArray?) {}
    override fun onEndOfSpeech() { onSpeechEnd() }
    override fun onEvent(eventType: Int, params: Bundle?) {}

    override fun onPartialResults(partialResults: Bundle?) {
        val t = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
        if (!t.isNullOrBlank()) onPartial(t)
    }

    override fun onResults(results: Bundle?) {
        running = false
        val t = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
        if (!t.isNullOrBlank()) onText(t)
        // always go straight back to listening; the user may keep talking
        if (active) retry(10)
    }

    override fun onError(error: Int) {
        running = false
        if (!active) return
        when (error) {
            SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS ->
                onFatal("Microphone permission is off. Enable it in app settings.")
            12, 13 -> // language not supported / unavailable
                onFatal("Speech language pack missing. In the Google app: Settings > Voice > Offline speech recognition, download English.")
            SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> { destroy(); retry(600) }
            SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> retry(50)
            SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT, SpeechRecognizer.ERROR_SERVER -> {
                offlineUntil = System.currentTimeMillis() + 60_000
                destroy(); retry(500)
            }
            else -> { destroy(); retry(1000) }
        }
    }

    companion object {
        // Hysteresis band so one borderline reading doesn't flip speech/silence back and forth.
        private const val SPEECH_MARGIN_DB = 6f
        private const val SILENCE_MARGIN_DB = 3f
        // A short natural breath mid-sentence is shorter than this, so it doesn't cut people off - but
        // Novochron no longer sits there waiting once they're actually done, unlike the fixed timer alone.
        private const val SILENCE_HANGOVER_MS = 260L
    }
}
