package com.atlas.assistant

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.os.SystemClock
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.security.MessageDigest

/**
 * Continuous multi-device backup of everything Novochron keeps on this phone - chat history and the
 * artifacts library (both live inside novochron.db), learned places, learned knowledge, saved photos
 * and adaptive preferences - to one fixed GitHub repo (see [Store.cloudSyncRepo], defaults to
 * "BreadCrafter1/vault"). Sign in once with the same GitHub account on a second phone pointed at the
 * same repo and it picks up everything the first phone has, and vice versa.
 *
 * This is a plain file mirror, not a database merge: every file under [NovochronStorage.root] except
 * [NovochronStorage.modelsDir] (left out on purpose - it's just the optional offline model, easily a
 * couple of GB and not something two phones need to duplicate) gets mirrored 1:1 to "Sync/<relative
 * path>" in the repo. Because the SQLite database itself lives under that root, chats and the artifact
 * library ride along for free - no separate export format to keep in sync with [Store]'s schema.
 *
 * Change detection uses each file's git blob sha (the exact hash Git itself would give the file), computed
 * locally with no extra API calls, against a small local manifest of "what we last agreed with the repo"
 * (see [Store.cloudSyncManifest]). That tells a real edit apart from "nothing changed" and, when both
 * sides have moved since the last sync, which one changed - see [syncOnce] for exactly how.
 *
 * Trigger: [notifyDirty] is called from [Engine.refresh], which runs after essentially every change (a
 * new message, a new chat, a new artifact, a learned note, a saved place...). Bursts of changes are
 * debounced into one sync a few seconds later; if the network isn't there right now, [Store.cloudSyncPending]
 * just stays set and a [ConnectivityManager.NetworkCallback] (started once from [Engine]'s init) fires the
 * sync the moment a connection comes back - even if the app was closed and reopened in between. On top of
 * that, [ensurePeriodicSync] (also armed from [Engine]'s init, via [ensureNetworkWatcher]) re-checks every
 * hour regardless of whether anything changed here, so a phone that just sits online still eventually picks
 * up whatever the other device pushed - see that section below for why.
 */
object CloudSync {
    private const val REMOTE_PREFIX = "Sync"
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var debounceJob: Job? = null
    private var watcherStarted = false
    @Volatile private var syncing = false

    // ---- hourly heartbeat sync, on top of the change-triggered one above ----
    //
    // notifyDirty() only fires a sync when something local actually changed, and the reconnect callback
    // only fires when the network was down and comes back. Neither covers "phone sat idle and online for
    // a while" - the other device may have pushed changes in that time with nothing here to notice until
    // the app is next opened. This alarm-driven heartbeat guarantees a sync attempt at least once an hour
    // regardless, the same way MsgWatchService's "saver" mode re-arms itself (see that class) rather than
    // needing a foreground service or WorkManager just to wait an hour.
    private const val PERIODIC_SYNC_MS = 60 * 60_000L // 1 hour
    private const val ACTION_PERIODIC = "com.atlas.assistant.CLOUD_SYNC_PERIODIC"
    private var periodicRegistered = false

    private val periodicReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            val app = context.applicationContext
            kick(app, immediate = true)
            schedulePeriodic(app) // re-arm for the next hour
        }
    }

    /** Starts listening for "the network just came back" so a queued sync fires without anyone opening
     *  the app. Cheap to call more than once - only the first call does anything. */
    fun ensureNetworkWatcher(ctx: Context) {
        if (watcherStarted) return
        watcherStarted = true
        val app = ctx.applicationContext
        try {
            val cm = app.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            cm.registerNetworkCallback(
                NetworkRequest.Builder().addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET).build(),
                object : ConnectivityManager.NetworkCallback() {
                    override fun onAvailable(network: Network) {
                        if (Store.get(app).cloudSyncPending) kick(app, immediate = true)
                    }
                }
            )
        } catch (e: Exception) {
            // No connectivity service to watch - the next notifyDirty() (or opening the app) still retries.
        }
        ensurePeriodicSync(app)
    }

    /** Makes sure the hourly heartbeat alarm is registered and armed. Safe to call repeatedly - only the
     *  first call registers the receiver; every call (re)schedules the next tick, so it's harmless to
     *  call again whenever the app comes to the foreground too. Fires regardless of whether sync is
     *  currently enabled - runSync() itself is a no-op when [Store.cloudSyncEnabled] is off. */
    fun ensurePeriodicSync(ctx: Context) {
        val app = ctx.applicationContext
        if (!periodicRegistered) {
            periodicRegistered = true
            try {
                ContextCompat.registerReceiver(app, periodicReceiver, IntentFilter(ACTION_PERIODIC), ContextCompat.RECEIVER_NOT_EXPORTED)
            } catch (e: Exception) { }
        }
        schedulePeriodic(app)
    }

    private fun periodicIntent(app: Context): PendingIntent = PendingIntent.getBroadcast(
        app, 9, Intent(ACTION_PERIODIC).setPackage(app.packageName), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
    )

    private fun schedulePeriodic(app: Context) {
        try {
            app.getSystemService(AlarmManager::class.java).setAndAllowWhileIdle(
                AlarmManager.ELAPSED_REALTIME_WAKEUP, SystemClock.elapsedRealtime() + PERIODIC_SYNC_MS, periodicIntent(app)
            )
        } catch (e: Exception) { }
    }

    /** Something local changed. Marks a sync as owed (survives being offline or the app closing) and
     *  schedules an attempt a few seconds out, so a burst of changes becomes one sync, not several. */
    fun notifyDirty(ctx: Context) {
        val app = ctx.applicationContext
        val store = Store.get(app)
        if (!store.cloudSyncEnabled) return
        store.cloudSyncPending = true
        kick(app, immediate = false)
    }

    /** Runs a sync pass right now if one isn't already in flight - used by the "Sync now" button. */
    fun syncNow(ctx: Context) = kick(ctx.applicationContext, immediate = true)

    private fun kick(app: Context, immediate: Boolean) {
        debounceJob?.cancel()
        debounceJob = scope.launch {
            if (!immediate) delay(4000L)
            runSync(app)
        }
    }

    fun isOnline(ctx: Context): Boolean = try {
        val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val caps = cm.getNetworkCapabilities(cm.activeNetwork)
        caps != null &&
            caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
            caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
    } catch (e: Exception) {
        false
    }

    private suspend fun runSync(app: Context) {
        if (syncing) return
        val store = Store.get(app)
        if (!store.cloudSyncEnabled) return
        val github = GitHub(store)
        if (!github.isLinked) {
            // Shouldn't normally happen - a Personal Access Token is baked into this build (see
            // Store.githubToken), so linking is automatic. This only fires if that token is blank
            // or someone explicitly ran "gh logout".
            store.cloudSyncStatus = "No GitHub token — check the baked-in token, or log in again in the terminal"
            return // stays pending; nothing to retry until a token is available again
        }
        val repo = RepoRef.parse(store.cloudSyncRepo.ifBlank { "BreadCrafter1/vault" })
        if (repo == null) {
            store.cloudSyncStatus = "Bad sync repo: ${store.cloudSyncRepo}"
            return
        }
        if (!isOnline(app)) {
            store.cloudSyncStatus = "Offline — queued, will sync when back online"
            return // stays pending
        }

        syncing = true
        store.cloudSyncStatus = "Syncing…"
        try {
            val (pushed, pulled) = withContext(Dispatchers.IO) { syncOnce(store, github, repo) }
            store.cloudSyncPending = false
            store.cloudSyncLastTs = System.currentTimeMillis()
            store.cloudSyncStatus = if (pushed == 0 && pulled == 0) "Synced — up to date" else "Synced ($pushed up, $pulled down)"
        } catch (e: Exception) {
            // cloudSyncPending is left true on purpose: next notifyDirty(), reconnect, or app open retries.
            store.cloudSyncStatus = "Sync error: ${e.message?.take(70) ?: e.javaClass.simpleName}"
        } finally {
            syncing = false
        }
    }

    /**
     * One push+pull pass. Returns (pushed, pulled) file counts.
     *
     * For each local file: no remote copy at all -> push it. Remote already matches -> nothing to do.
     * Remote differs but matches what we last synced -> only the local side changed -> push. Remote
     * differs from what we last synced but local matches it -> only the remote side changed -> pull.
     * Both differ from last-synced -> genuine conflict (both devices changed the same file since the
     * last sync); the local copy wins and overwrites the remote one, since this is meant for one person
     * using one phone at a time, not simultaneous editors.
     *
     * Remote-only files (something the *other* phone made that this one has never seen) are pulled down,
     * unless the manifest shows this phone used to have that path and it's simply gone now - i.e. it was
     * deleted here on purpose, so it isn't resurrected from the repo.
     */
    private suspend fun syncOnce(store: Store, github: GitHub, repo: RepoRef): Pair<Int, Int> {
        val root = NovochronStorage.root()
        if (!root.exists()) return 0 to 0
        val modelsPath = NovochronStorage.modelsDir().canonicalPath

        val manifest = loadManifest(store)
        val newManifest = HashMap(manifest)
        val remoteTree = github.listTree(REMOTE_PREFIX, repo)

        val localFiles = LinkedHashMap<String, File>()
        root.walkTopDown()
            .onEnter { it.canonicalPath != modelsPath }
            .filter { it.isFile }
            .forEach { f ->
                val rel = f.relativeTo(root).path.replace(File.separatorChar, '/')
                if (!rel.endsWith("-journal") && !rel.endsWith("-wal") && !rel.endsWith("-shm")) localFiles[rel] = f
            }

        var pushed = 0
        var pulled = 0
        val device = try { android.os.Build.MODEL ?: "phone" } catch (e: Exception) { "phone" }

        for ((rel, file) in localFiles) {
            val bytes = try { file.readBytes() } catch (e: Exception) { continue }
            val localSha = gitBlobSha(bytes)
            val remote = remoteTree[rel]
            val lastSynced = manifest[rel]
            when {
                remote == null || lastSynced == remote.sha -> {
                    if (remote == null || remote.sha != localSha) {
                        github.commitBytes("$REMOTE_PREFIX/$rel", bytes, "Sync: $rel from $device", repo)
                        pushed++
                    }
                    newManifest[rel] = localSha
                }
                remote.sha == localSha -> newManifest[rel] = localSha // already in sync
                lastSynced == localSha -> {
                    val remoteBytes = github.readFileBytes("$REMOTE_PREFIX/$rel", repo)
                    if (remoteBytes != null) {
                        file.parentFile?.mkdirs()
                        file.writeBytes(remoteBytes)
                        newManifest[rel] = remote.sha
                        pulled++
                    }
                }
                else -> { // both sides changed since the last sync - local wins
                    github.commitBytes("$REMOTE_PREFIX/$rel", bytes, "Sync: $rel from $device (conflict, local kept)", repo)
                    newManifest[rel] = localSha
                    pushed++
                }
            }
        }

        for ((rel, entry) in remoteTree) {
            if (localFiles.containsKey(rel) || manifest.containsKey(rel)) continue
            val bytes = github.readFileBytes("$REMOTE_PREFIX/$rel", repo) ?: continue
            val target = File(root, rel)
            target.parentFile?.mkdirs()
            target.writeBytes(bytes)
            newManifest[rel] = entry.sha
            pulled++
        }

        saveManifest(store, newManifest)
        return pushed to pulled
    }

    /** The sha `git hash-object` would give this exact content, computed with no network call. */
    private fun gitBlobSha(bytes: ByteArray): String {
        val header = "blob ${bytes.size}\u0000".toByteArray(Charsets.UTF_8)
        val md = MessageDigest.getInstance("SHA-1")
        md.update(header)
        md.update(bytes)
        return md.digest().joinToString("") { "%02x".format(it) }
    }

    private fun loadManifest(store: Store): Map<String, String> = try {
        val o = JSONObject(store.cloudSyncManifest.ifBlank { "{}" })
        val out = HashMap<String, String>()
        o.keys().forEach { k -> out[k] = o.getString(k) }
        out
    } catch (e: Exception) {
        emptyMap()
    }

    private fun saveManifest(store: Store, map: Map<String, String>) {
        val o = JSONObject()
        map.forEach { (k, v) -> o.put(k, v) }
        store.cloudSyncManifest = o.toString()
    }
}
