package com.atlas.assistant

import android.Manifest
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaPlayer
import android.media.MediaRecorder
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.UUID

/** Everything for "msg" lives under this folder in whichever repo the two people both point at. */
private const val MSG_DIR = "Msg"
private const val MSG_MEDIA_DIR = "Msg/media"
private const val POLL_MS = 1000L              // cheap: unchanged polls come back as empty 304s
private const val FETCH_PARALLELISM = 6         // new message files fetched this many at a time
/** GitHub's Contents API tops out at 100 MB per file - that's the real ceiling for photos/videos/voice. */
private const val MAX_MEDIA_BYTES = 100L * 1024 * 1024

private enum class MsgType { TEXT, PHOTO, VIDEO, VOICE }

private data class ChatMsg(
    val path: String,
    val sender: String,
    val ts: Long,
    val type: MsgType,
    val text: String = "",
    val mediaPath: String = "",
    val durationMs: Long = 0L,
    val pending: Boolean = false
)

/**
 * "msg": a tiny chat that uses a GitHub repo as the mailbox instead of a server. Both people paste
 * the same "owner/repo" into the box at the top (each logged into their own GitHub account via the
 * same device-code login the terminal's `gh login` sets up - see GitHub.kt), pick a name, and from
 * then on sending a message is one commit to Msg/ in that repo; receiving is just polling the same
 * folder for commits the other person made. Photos, videos and voice messages are committed as their own file under
 * Msg/media/ and referenced from the text message that announces them.
 */
@Composable
fun MsgScreen(engine: Engine, onClose: () -> Unit) {
    val ctx = LocalContext.current
    // GitHub (shared with vault/terminal) is only used here for login state + pasting a token.
    val github = remember { GitHub(engine.store) }
    // All msg traffic goes through MsgClient, which reads the same token/branch live on every request.
    val msgClient = remember { MsgClient(tokenProvider = { engine.store.githubToken }, branchProvider = { engine.store.githubBranch }) }
    val scope = rememberCoroutineScope()

    var linked by remember { mutableStateOf(github.isLinked) }
    var repoText by remember { mutableStateOf(engine.store.msgRepo) }
    var nameText by remember { mutableStateOf(engine.store.msgUserName.ifBlank { "me" }) }
    var editingSetup by remember { mutableStateOf(engine.store.msgRepo.isBlank()) }
    var tokenText by remember { mutableStateOf("") }
    var tokenBusy by remember { mutableStateOf(false) }
    var tokenStatus by remember { mutableStateOf("") }

    var messages by remember { mutableStateOf(listOf<ChatMsg>()) }
    val knownPaths = remember { mutableSetOf<String>() }
    var input by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }          // a photo/video/voice upload is in progress
    var status by remember { mutableStateOf("") }
    var viewing by remember { mutableStateOf<Pair<File, String>?>(null) }   // photo open full-screen: (file, mediaPath)
    var cacheReady by remember { mutableStateOf(false) }
    val sendLock = remember { Mutex() }                     // commits to one branch go out one at a time
    val listState = rememberLazyListState()

    fun repoRef(): RepoRef? = RepoRef.parse(engine.store.msgRepo)

    // ---- calling: [call] / [video call], same shared-repo signaling as msg itself (see Calling.kt) ----
    val callManager = remember(msgClient, engine.store.msgRepo) { CallManager(ctx.applicationContext, scope, msgClient, repoRef(), engine.store) }
    // Mirrors the call's phase/video-ness into AssistantState so MainActivity knows, from outside
    // this composable, whether "on a call" PiP should trigger when the person leaves the app -
    // see MainActivity.onUserLeaveHint(). RINGING_IN/RINGING_OUT are deliberately excluded: those
    // still need [accept]/[decline] on a full-size screen, not a tiny PiP window.
    LaunchedEffect(callManager.ui) {
        val st = callManager.ui
        AssistantState.callActive.value = st?.phase == CallPhase.CONNECTING || st?.phase == CallPhase.CONNECTED
        AssistantState.callHasVideo.value = st?.video == true
    }
    DisposableEffect(callManager) {
        onDispose {
            callManager.dispose()
            AssistantState.callActive.value = false
            AssistantState.callHasVideo.value = false
        }
    }
    LaunchedEffect(callManager) { while (true) { callManager.poll(); delay(CALL_POLL_MS) } }
    // Opening msg (e.g. from the "X is calling you" notification) means any pending call alert is stale now.
    LaunchedEffect(Unit) { CallNotifier.clear(ctx) }

    var pendingCallAction by remember { mutableStateOf<(() -> Unit)?>(null) }
    val callPermLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { result ->
        val micOk = result[Manifest.permission.RECORD_AUDIO]
            ?: (ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED)
        if (micOk) pendingCallAction?.invoke() else status = "Microphone permission is needed to call."
        pendingCallAction = null
    }
    fun requestCallPermsThen(video: Boolean, action: () -> Unit) {
        val need = mutableListOf<String>()
        if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) need += Manifest.permission.RECORD_AUDIO
        if (video && ContextCompat.checkSelfPermission(ctx, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) need += Manifest.permission.CAMERA
        if (need.isEmpty()) action() else { pendingCallAction = action; callPermLauncher.launch(need.toTypedArray()) }
    }
    val cacheFile = remember(engine.store.msgRepo) { msgCacheFile(ctx, engine.store.msgRepo, engine.store.githubBranch) }

    var clearingChat by remember { mutableStateOf(false) }

    /**
     * Wipes every message (and any attached photo/video/voice under Msg/media) directly on the
     * shared repo - not just this phone's local copy. Since Msg/ is the mailbox both people read,
     * this clears the chat for both of you; there's no undo once the commit lands.
     * [ClearChatKey]'s own tap-to-arm-then-confirm gesture is the confirmation step.
     *
     * Clears almost instantly: the screen and local cache are wiped right away rather than waiting
     * on the network, and the repo side goes out as ONE commit via [GitHub.deleteTree] (Git Data
     * API) instead of one commit per message - the earlier per-file loop could take as long as
     * there were messages to delete one by one. [GitHub.deleteFile] per file is kept as a fallback
     * for the rare case deleteTree itself fails (e.g. a very old token without the Git Data scopes).
     */
    fun clearChatOnRepo() {
        val repo = repoRef()
        if (repo == null) { status = "Not configured."; return }
        if (!github.isLinked) { status = "Not linked to GitHub."; return }

        // Instant: clear the screen and local cache right now, don't wait on the network.
        messages = emptyList(); knownPaths.clear()
        scope.launch(Dispatchers.IO) { msgSaveCache(cacheFile, emptyList()) }
        status = "Cleared. Wiping the shared repo…"
        clearingChat = true

        scope.launch {
            try {
                withContext(Dispatchers.IO) {
                    try {
                        github.deleteTree(MSG_DIR, "novochron: clear chat history", repo)
                    } catch (e: Exception) {
                        // Slow fallback: one commit per file, walking Msg/ and Msg/media.
                        for (dir in listOf(MSG_DIR, MSG_MEDIA_DIR)) {
                            val files = try { msgClient.listFiles(dir, repo) } catch (e: Exception) { emptyList() }
                            for (f in files) {
                                if (f.isDir) continue
                                try { github.deleteFile(f.path, "novochron: clear chat history", repo) } catch (e: Exception) { /* keep going */ }
                            }
                        }
                    }
                }
                status = "Chat cleared for both of you."
            } catch (e: Exception) {
                status = "Cleared here, but the shared repo may still have old messages: ${e.message ?: "unknown error"}"
            } finally {
                clearingChat = false
            }
        }
    }

    suspend fun poll() {
        val repo = repoRef() ?: return
        if (!github.isLinked) return
        if (clearingChat) return   // don't let a poll mid-clear repopulate messages the wipe hasn't reached yet
        val files = try {
            msgClient.listFiles(MSG_DIR, repo)
        } catch (e: GitHubApiException) {
            status = "Couldn't check for messages: ${e.body.take(80)}"; return
        } catch (e: Exception) {
            status = "Couldn't check for messages: ${e.message ?: "unknown error"}"; return
        }
        val jsonFiles = files.filter { !it.isDir && it.path.endsWith(".json") }

        // Drop messages that were deleted remotely.
        val listed = jsonFiles.mapTo(HashSet()) { it.path }
        val recent = System.currentTimeMillis() - 30_000
        val gone = messages.filter { !it.pending && it.path !in listed && it.ts < recent }.mapTo(HashSet()) { it.path }
        if (gone.isNotEmpty()) { messages = messages.filter { it.path !in gone }; knownPaths.removeAll(gone) }

        val newOnes = jsonFiles.filter { it.path !in knownPaths }
        if (newOnes.isEmpty()) return

        // Fetch all new message files at once (a few at a time) instead of one after another.
        val gate = Semaphore(FETCH_PARALLELISM)
        val parsed = coroutineScope {
            newOnes.sortedBy { it.path }.map { f -> async { gate.withPermit { msgFetchMessage(msgClient, repo, f.path, knownPaths) } } }.awaitAll()
        }.filterNotNull()
        for (m in parsed) knownPaths += m.path
        if (parsed.isNotEmpty()) { messages = (messages + parsed).sortedBy { it.ts }; status = "" }
    }

    // First load (from the on-disk copy, so it's instant), then keep polling for what the other person sends.
    LaunchedEffect(engine.store.msgRepo) {
        messages = emptyList()
        knownPaths.clear()
        cacheReady = false
        val cached = withContext(Dispatchers.IO) { msgLoadCache(cacheFile) }
        messages = cached; knownPaths.addAll(cached.map { it.path }); cacheReady = true
        if (repoRef() != null) {
            while (true) {
                poll()
                delay(POLL_MS)
            }
        }
    }
    LaunchedEffect(messages, cacheReady) {
        if (!cacheReady) return@LaunchedEffect
        delay(400)
        val snapshot = messages
        withContext(Dispatchers.IO) { msgSaveCache(cacheFile, snapshot) }
    }

    fun markSent(path: String) { messages = messages.map { if (it.path == path) it.copy(pending = false) else it } }
    fun dropFailed(path: String) { knownPaths -= path; messages = messages.filter { it.path != path } }

    // Text goes on screen instantly; the commit happens in the background.
    fun sendText(text: String) {
        val repo = repoRef() ?: return
        val trimmed = text.trim()
        if (trimmed.isEmpty()) return
        input = ""
        val me = engine.store.msgUserName.ifBlank { "me" }
        val ts = System.currentTimeMillis()
        val path = "$MSG_DIR/$ts-${UUID.randomUUID().toString().take(6)}.json"
        knownPaths += path
        messages = messages + ChatMsg(path, me, ts, MsgType.TEXT, text = trimmed, pending = true)
        scope.launch {
            try {
                val body = JSONObject().apply { put("from", me); put("ts", ts); put("type", "TEXT"); put("text", trimmed) }
                sendLock.withLock { msgClient.commitFile(path, body.toString(), "msg: text", repo) }
                markSent(path)
            } catch (e: Exception) {
                dropFailed(path)
                if (input.isBlank()) input = trimmed
                status = "Failed to send: ${msgErrText(e)}"
            }
        }
    }

    /** [local] is already in the media cache, so the bubble shows it right away while it uploads. */
    suspend fun sendMediaFile(local: File, mediaPath: String, type: MsgType, ts: Long, durationMs: Long = 0L) {
        val repo = repoRef()
        if (repo == null) { local.delete(); busy = false; return }
        val me = engine.store.msgUserName.ifBlank { "me" }
        val label = type.name.lowercase()
        val jsonPath = "$MSG_DIR/$ts-${UUID.randomUUID().toString().take(6)}.json"
        busy = true
        status = "Uploading $label…"
        knownPaths += jsonPath
        messages = messages + ChatMsg(jsonPath, me, ts, type, mediaPath = mediaPath, durationMs = durationMs, pending = true)
        try {
            sendLock.withLock {
                msgClient.commitFileStream(mediaPath, local, "msg: $label", repo) { pct -> status = "Uploading $label… $pct%" }
                val body = JSONObject().apply {
                    put("from", me); put("ts", ts); put("type", type.name); put("media", mediaPath)
                    if (durationMs > 0) put("duration", durationMs)
                }
                msgClient.commitFile(jsonPath, body.toString(), "msg: $label", repo)
            }
            markSent(jsonPath)
            status = ""
        } catch (e: Exception) {
            dropFailed(jsonPath); local.delete()
            status = "Failed to send: ${msgErrText(e)}"
        }
        busy = false
    }

    fun sendMedia(uri: Uri, type: MsgType) {
        if (repoRef() == null) return
        scope.launch {
            busy = true
            status = "Preparing ${type.name.lowercase()}…"
            val ts = System.currentTimeMillis()
            val ext = if (type == MsgType.PHOTO) msgPhotoExt(ctx.contentResolver.getType(uri).orEmpty()) else "mp4"
            val mediaPath = "$MSG_MEDIA_DIR/$ts.$ext"
            val local = msgMediaCacheFile(ctx, mediaPath)
            val copied = withContext(Dispatchers.IO) {
                try {
                    val stream = ctx.contentResolver.openInputStream(uri) ?: return@withContext false
                    local.parentFile?.mkdirs()
                    stream.use { i -> local.outputStream().use { o -> i.copyTo(o, 64 * 1024) } }
                    true
                } catch (e: Exception) { false }
            }
            if (!copied) { local.delete(); status = "Couldn't read that file."; busy = false; return@launch }
            if (local.length() > MAX_MEDIA_BYTES) {
                val size = local.length(); local.delete()
                status = "That's ${humanMsgBytes(size)} - the max is ${humanMsgBytes(MAX_MEDIA_BYTES)}."
                busy = false; return@launch
            }
            sendMediaFile(local, mediaPath, type, ts)
        }
    }

    val photoLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) sendMedia(uri, MsgType.PHOTO)
    }
    val videoLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) sendMedia(uri, MsgType.VIDEO)
    }

    // ---- voice messages ----
    var hasMicPermission by remember {
        mutableStateOf(ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED)
    }
    var recorder by remember { mutableStateOf<MediaRecorder?>(null) }
    var recordingFile by remember { mutableStateOf<File?>(null) }
    var recordStartMs by remember { mutableStateOf(0L) }
    var isRecording by remember { mutableStateOf(false) }
    var recordedSec by remember { mutableStateOf(0) }

    fun startRecording() {
        if (busy || isRecording || repoRef() == null) return
        val dir = File(ctx.cacheDir, "msg").apply { mkdirs() }
        val file = File(dir, "rec-${System.currentTimeMillis()}.m4a")
        @Suppress("DEPRECATION")
        val rec = if (Build.VERSION.SDK_INT >= 31) MediaRecorder(ctx) else MediaRecorder()
        try {
            rec.apply {
                setAudioSource(MediaRecorder.AudioSource.MIC)
                setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
                setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
                setOutputFile(file.absolutePath)
            }
            rec.prepare(); rec.start()
            recorder = rec; recordingFile = file; recordStartMs = System.currentTimeMillis()
            isRecording = true; recordedSec = 0; status = ""
        } catch (e: Exception) {
            status = "Couldn't start recording: ${e.message ?: "unknown error"}"
            try { rec.release() } catch (_: Exception) {}
            file.delete()
        }
    }

    fun stopRecording(send: Boolean) {
        val rec = recorder ?: return
        val file = recordingFile
        val durationMs = System.currentTimeMillis() - recordStartMs
        isRecording = false; recorder = null; recordingFile = null
        try { rec.stop() } catch (_: Exception) {}
        rec.release()
        if (send && file != null && durationMs >= 500) {
            val ts = System.currentTimeMillis()
            val mediaPath = "$MSG_MEDIA_DIR/$ts.m4a"
            val dest = msgMediaCacheFile(ctx, mediaPath)
            dest.parentFile?.mkdirs()
            if (!file.renameTo(dest)) { file.copyTo(dest, overwrite = true); file.delete() }
            scope.launch { sendMediaFile(dest, mediaPath, MsgType.VOICE, ts, durationMs) }
        } else {
            file?.delete()
            if (send) status = "Recording was too short."
        }
    }

    val micPermissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        hasMicPermission = granted
        if (granted) startRecording() else status = "Microphone permission is needed to record a voice message."
    }
    LaunchedEffect(isRecording) {
        while (isRecording) { delay(1000); recordedSec += 1 }
    }
    DisposableEffect(Unit) {
        onDispose { recorder?.let { try { it.stop() } catch (_: Exception) {}; it.release() } }
    }

    // ---- background alerts (see MsgWatchService.kt) ----
    var alertsOn by remember { mutableStateOf(engine.store.msgNotify) }
    var alertMode by remember { mutableStateOf(engine.store.msgNotifyMode) }
    var speakOn by remember { mutableStateOf(engine.store.msgSpeak) }
    /** Alerts and read-aloud share one background watcher; a fresh start re-baselines so old messages aren't announced. */
    fun setWatch(alerts: Boolean, speak: Boolean) {
        val wasWatching = engine.store.msgNotify || engine.store.msgSpeak
        if (!wasWatching && (alerts || speak)) MsgWatcher.resetBaseline(ctx, engine.store)
        engine.store.msgNotify = alerts
        engine.store.msgSpeak = speak
        alertsOn = alerts; speakOn = speak
        MsgWatchService.refresh(ctx)
    }
    fun setAlerts(on: Boolean) = setWatch(on, speakOn)
    val notifPermissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) setAlerts(true) else status = "Notifications are blocked for this app - allow them in Android settings to get message alerts."
    }
    fun toggleAlerts() {
        if (alertsOn) { setAlerts(false); return }
        val needsPermission = Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        if (needsPermission) notifPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS) else setAlerts(true)
    }
    // Opening msg means you're reading: drop any alert that's still sitting in the shade.
    LaunchedEffect(Unit) { MsgNotifier.clear(ctx) }

    LaunchedEffect(messages.size) {
        if (messages.isNotEmpty()) listState.animateScrollToItem(messages.size - 1)
    }


    // A Box, not just the Column below, so the call UI (see callManager.ui?.let { CallOverlay(...) }
    // right at the bottom of this function) can sit on top as a real full-screen layer *inside this
    // same window* rather than a separate Dialog window - that's what lets it participate in
    // Picture-in-Picture when MainActivity shrinks the window (a Dialog's own window would not shrink
    // with it). See MainActivity.onUserLeaveHint()/onPictureInPictureModeChanged().
    Box(Modifier.fillMaxSize()) {
    Column(
        Modifier
            .fillMaxSize()
            .background(Color.Black)
            .padding(horizontal = 12.dp, vertical = 10.dp)
    ) {
        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("[ msg ]", color = Accent, fontFamily = TermFont, fontWeight = FontWeight.Bold, fontSize = 18.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                if (!editingSetup && repoRef() != null) {
                    TextButton(onClick = { editingSetup = true }) { Text("[repo]", color = Accent, fontFamily = TermFont, fontSize = 13.sp) }
                }
                TextButton(onClick = onClose) { Text("[close]", color = Ink, fontFamily = TermFont, fontSize = 13.sp) }
            }
        }
        Spacer(Modifier.height(8.dp))

        if (!linked) {
            Text(
                "Not logged into GitHub yet - msg needs that to reach the shared repo. Paste a Personal " +
                    "Access Token below (create one at github.com/settings/tokens - a fine-grained token " +
                    "with Contents read/write on the repo, or a classic token with the \"repo\" scope), " +
                    "or open [term] and run \"gh login\" instead.",
                color = Dim, fontFamily = TermFont, fontSize = 13.sp
            )
            Spacer(Modifier.height(8.dp))
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                TextField(
                    value = tokenText,
                    onValueChange = { tokenText = it; tokenStatus = "" },
                    placeholder = { Text("ghp_… or github_pat_…", color = Dim, fontFamily = TermFont) },
                    singleLine = true,
                    enabled = !tokenBusy,
                    textStyle = androidx.compose.ui.text.TextStyle(color = Ink, fontFamily = TermFont, fontSize = 13.sp),
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                    keyboardActions = androidx.compose.foundation.text.KeyboardActions(onDone = {
                        if (tokenText.isNotBlank() && !tokenBusy) {
                            scope.launch {
                                tokenBusy = true
                                tokenStatus = "Verifying…"
                                github.loginWithToken(tokenText).onSuccess {
                                    tokenStatus = ""; tokenText = ""; linked = true
                                }.onFailure { tokenStatus = it.message ?: "Couldn't verify that token." }
                                tokenBusy = false
                            }
                        }
                    }),
                    colors = TextFieldDefaults.colors(
                        focusedContainerColor = Raised, unfocusedContainerColor = Raised,
                        focusedIndicatorColor = Accent, unfocusedIndicatorColor = Line,
                        cursorColor = Accent
                    ),
                    modifier = Modifier.weight(1f)
                )
                TextButton(
                    onClick = {
                        scope.launch {
                            tokenBusy = true
                            tokenStatus = "Verifying…"
                            github.loginWithToken(tokenText).onSuccess {
                                tokenStatus = ""; tokenText = ""; linked = true
                            }.onFailure { tokenStatus = it.message ?: "Couldn't verify that token." }
                            tokenBusy = false
                        }
                    },
                    enabled = !tokenBusy && tokenText.isNotBlank()
                ) { Text(if (tokenBusy) "[…]" else "[link]", color = Accent, fontFamily = TermFont, fontSize = 13.sp) }
            }
            if (tokenStatus.isNotEmpty()) {
                Spacer(Modifier.height(6.dp))
                Text(tokenStatus, color = Warn, fontFamily = TermFont, fontSize = 12.sp)
            }
            LaunchedEffect(Unit) {
                while (!linked) { delay(1000); linked = github.isLinked }
            }
            return@Column
        }

        if (editingSetup) {
            Text("Shared repo (owner/name) - both people paste the same one:", color = Dim, fontFamily = TermFont, fontSize = 12.sp)
            Spacer(Modifier.height(4.dp))
            TextField(
                value = repoText,
                onValueChange = { repoText = it },
                singleLine = true,
                textStyle = androidx.compose.ui.text.TextStyle(color = Ink, fontFamily = TermFont, fontSize = 14.sp),
                colors = TextFieldDefaults.colors(
                    focusedContainerColor = Raised, unfocusedContainerColor = Raised,
                    focusedIndicatorColor = Accent, unfocusedIndicatorColor = Line,
                    cursorColor = Accent
                ),
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(8.dp))
            Text("Your name (shown on your messages):", color = Dim, fontFamily = TermFont, fontSize = 12.sp)
            Spacer(Modifier.height(4.dp))
            TextField(
                value = nameText,
                onValueChange = { nameText = it },
                singleLine = true,
                textStyle = androidx.compose.ui.text.TextStyle(color = Ink, fontFamily = TermFont, fontSize = 14.sp),
                colors = TextFieldDefaults.colors(
                    focusedContainerColor = Raised, unfocusedContainerColor = Raised,
                    focusedIndicatorColor = Accent, unfocusedIndicatorColor = Line,
                    cursorColor = Accent
                ),
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                TextButton(onClick = {
                    val ok = RepoRef.parse(repoText) != null
                    if (!ok) { status = "That doesn't look like \"owner/repo\"."; return@TextButton }
                    engine.store.msgRepo = repoText
                    engine.store.msgUserName = nameText.ifBlank { "me" }
                    editingSetup = false
                    status = ""
                }) { Text("[save]", color = Accent, fontFamily = TermFont, fontSize = 14.sp) }
                if (repoRef() != null) {
                    TextButton(onClick = { editingSetup = false }) { Text("[cancel]", color = Ink, fontFamily = TermFont, fontSize = 14.sp) }
                }
            }
            if (status.isNotEmpty()) {
                Spacer(Modifier.height(8.dp))
                Text(status, color = Warn, fontFamily = TermFont, fontSize = 12.sp)
            }
            return@Column
        }

        Text(
            "${engine.store.msgRepo} @ ${engine.store.githubBranch} · as \"${engine.store.msgUserName.ifBlank { "me" }}\"",
            color = Dim, fontFamily = TermFont, fontSize = 11.sp
        )
        Spacer(Modifier.height(6.dp))

        // Scrolls horizontally instead of clipping off-screen: on narrower/lower-density phones a
        // fixed-width row here can run wider than the screen and silently cut a button off with no
        // visual sign anything is missing - wrapping it in horizontalScroll avoids that regardless
        // of how many buttons end up in this row.
        Row(
            Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            TextButton(onClick = { requestCallPermsThen(false) { callManager.startCall(false) } }, enabled = callManager.ui == null) {
                Text("[call]", color = Accent, fontFamily = TermFont, fontSize = 12.sp)
            }
            TextButton(onClick = { requestCallPermsThen(true) { callManager.startCall(true) } }, enabled = callManager.ui == null) {
                Text("[video call]", color = Accent, fontFamily = TermFont, fontSize = 12.sp)
            }
        }
        Spacer(Modifier.height(6.dp))

        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            ClearChatKey(onClear = { clearChatOnRepo() }, busy = clearingChat)
        }
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            TextButton(onClick = { toggleAlerts() }) {
                Text(
                    if (alertsOn) "[alerts: on]" else "[alerts: off]",
                    color = if (alertsOn) Accent else Dim, fontFamily = TermFont, fontSize = 12.sp
                )
            }
            TextButton(onClick = { setWatch(alertsOn, !speakOn) }) {
                Text(
                    if (speakOn) "[read aloud: on]" else "[read aloud: off]",
                    color = if (speakOn) Accent else Dim, fontFamily = TermFont, fontSize = 12.sp
                )
            }
            if (alertsOn || speakOn) {
                TextButton(onClick = {
                    alertMode = if (alertMode == "saver") "instant" else "saver"
                    engine.store.msgNotifyMode = alertMode
                    MsgWatchService.refresh(ctx)        // restarts the watcher in the new mode
                }) {
                    Text("[mode: $alertMode]", color = Ink, fontFamily = TermFont, fontSize = 12.sp)
                }
            }
        }
        if (alertsOn || speakOn) {
            Text(
                if (alertMode == "saver") "Checks about every 5 minutes in the background. Light on battery."
                else "Checks every few seconds in the background so alerts are near-instant. Uses more battery - see [stats].",
                color = Dim, fontFamily = TermFont, fontSize = 10.sp
            )
        }

        viewing?.let { (file, mediaPath) ->
            MsgPhotoViewer(file, mediaPath, onClose = { viewing = null })
        }

        Box(Modifier.weight(1f).fillMaxWidth()) {
            if (messages.isEmpty()) {
                Text(
                    if (status.isNotEmpty()) status else "No messages yet. Say hi below - it'll show up for the other person next time they check.",
                    color = Dim, fontFamily = TermFont, fontSize = 13.sp
                )
            } else {
                LazyColumn(state = listState, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(messages, key = { it.path }) { m ->
                        MsgBubble(
                            m, mine = m.sender == engine.store.msgUserName.ifBlank { "me" },
                            msgClient = msgClient, repo = repoRef(),
                            onOpenPhoto = { f -> viewing = f to m.mediaPath }
                        )
                    }
                }
            }
        }

        if (status.isNotEmpty() && messages.isNotEmpty()) {
            Text(status, color = Warn, fontFamily = TermFont, fontSize = 11.sp)
            Spacer(Modifier.height(4.dp))
        }

        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            TextButton(onClick = { photoLauncher.launch(arrayOf("image/*")) }, enabled = !busy && !isRecording) {
                Text("[photo]", color = Accent, fontFamily = TermFont, fontSize = 13.sp)
            }
            TextButton(onClick = { videoLauncher.launch(arrayOf("video/*")) }, enabled = !busy && !isRecording) {
                Text("[video]", color = Accent, fontFamily = TermFont, fontSize = 13.sp)
            }
            TextButton(
                onClick = {
                    if (isRecording) stopRecording(send = true)
                    else if (hasMicPermission) startRecording()
                    else micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                },
                enabled = !busy || isRecording
            ) {
                Text(
                    if (isRecording) "[● %d:%02d - stop]".format(recordedSec / 60, recordedSec % 60) else "[mic]",
                    color = if (isRecording) Warn else Accent, fontFamily = TermFont, fontSize = 13.sp
                )
            }
            if (isRecording) {
                TextButton(onClick = { stopRecording(send = false) }) {
                    Text("[cancel]", color = Dim, fontFamily = TermFont, fontSize = 13.sp)
                }
            }
            TextField(
                value = input,
                onValueChange = { input = it },
                placeholder = { Text("message…", color = Dim, fontFamily = TermFont) },
                textStyle = androidx.compose.ui.text.TextStyle(color = Ink, fontFamily = TermFont, fontSize = 14.sp),
                singleLine = true,
                enabled = !isRecording,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                keyboardActions = androidx.compose.foundation.text.KeyboardActions(onSend = { sendText(input) }),
                colors = TextFieldDefaults.colors(
                    focusedContainerColor = Raised, unfocusedContainerColor = Raised,
                    focusedIndicatorColor = Accent, unfocusedIndicatorColor = Line,
                    cursorColor = Accent
                ),
                modifier = Modifier.weight(1f)
            )
            TextButton(onClick = { sendText(input) }, enabled = input.isNotBlank()) {
                Text("[send]", color = Accent, fontFamily = TermFont, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            }
        }
    }

    // Drawn last so it sits on top of the Column above, full-screen, as a real layer of this same
    // window (see the Box comment near the top of this function for why that matters for PiP).
    callManager.ui?.let { st ->
        CallOverlay(
            state = st, localVideo = callManager.localVideo, remoteVideo = callManager.remoteVideo,
            eglBaseContext = callManager.eglBaseContext,
            onAccept = { requestCallPermsThen(st.video) { callManager.accept() } },
            onDecline = callManager::decline, onHangup = callManager::hangup,
            onToggleMute = callManager::toggleMute, onSwitchCamera = callManager::switchCamera,
            onToggleSpeaker = callManager::toggleSpeaker,
            // Only read while shrunk into PiP (see CallOverlay's split layout) - a few lines of
            // "sender: text" so a glance at the corner window shows what's being said, not just
            // who you're on the phone with. Media messages get a bracketed placeholder since
            // there's no room to open/preview the actual photo/video/voice note that small. Each
            // line is tagged with whether it's yours - same mine == m.sender check the normal
            // MsgBubble list uses - so CallOverlay can color your own messages green.
            pipMessages = messages.takeLast(6).map { m ->
                val body = when (m.type) {
                    MsgType.TEXT -> m.text
                    MsgType.PHOTO -> "[photo]"
                    MsgType.VIDEO -> "[video]"
                    MsgType.VOICE -> "[voice]"
                }
                "${m.sender}: $body" to (m.sender == engine.store.msgUserName.ifBlank { "me" })
            },
        )
    }
    }
}

@Composable
private fun MsgBubble(m: ChatMsg, mine: Boolean, msgClient: MsgClient, repo: RepoRef?, onOpenPhoto: (File) -> Unit) {
    val bg = if (mine) Color(0xFF0E2A12) else Raised
    val align = if (mine) Alignment.End else Alignment.Start

    Column(Modifier.fillMaxWidth(), horizontalAlignment = align) {
        Text(
            "${m.sender} · ${if (m.pending) "sending…" else timeLabel(m.ts)}",
            color = Dim, fontFamily = TermFont, fontSize = 10.sp
        )
        Box(
            Modifier
                .widthIn(max = 260.dp)
                .clip(RoundedCornerShape(6.dp))
                .background(bg)
                .padding(10.dp)
        ) {
            when (m.type) {
                MsgType.TEXT -> Text(m.text, color = Ink, fontFamily = TermFont, fontSize = 14.sp)
                else -> MediaBubble(m, msgClient, repo, type = m.type, onOpenPhoto = onOpenPhoto)
            }
        }
    }
    Spacer(Modifier.height(2.dp))
}

@Composable
private fun MediaBubble(m: ChatMsg, msgClient: MsgClient, repo: RepoRef?, type: MsgType, onOpenPhoto: (File) -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var file by remember(m.path) { mutableStateOf<File?>(null) }
    var error by remember(m.path) { mutableStateOf("") }
    var loading by remember(m.path) { mutableStateOf(false) }

    /** Gets the media onto disk (instant if it's already cached or we sent it ourselves). */
    fun load(onDone: (File?) -> Unit) {
        file?.let { onDone(it); return }
        val r = repo ?: return
        loading = true; error = ""
        scope.launch {
            val result = try {
                withContext(Dispatchers.IO) {
                    val dest = msgMediaCacheFile(ctx, m.mediaPath)
                    if (dest.exists() && dest.length() > 0) dest
                    else if (msgClient.downloadFile(m.mediaPath, r, dest)) dest else null
                }
            } catch (e: Exception) { error = e.message ?: "couldn't load"; null }
            if (result == null && error.isEmpty()) error = "not found"
            loading = false; file = result; onDone(result)
        }
    }

    when (type) {
        MsgType.PHOTO -> {
            LaunchedEffect(m.path) { if (file == null && error.isEmpty()) load {} }
            val f = file
            var thumb by remember(f) { mutableStateOf<Bitmap?>(null) }
            var decodeFailed by remember(f) { mutableStateOf(false) }
            LaunchedEffect(f) {
                if (f != null) {
                    val b = withContext(Dispatchers.IO) { msgDecodeSampled(f, 720) }
                    if (b == null) decodeFailed = true else thumb = b
                }
            }
            val bmp = thumb
            when {
                bmp != null && f != null -> Image(
                    bmp.asImageBitmap(), contentDescription = "photo (tap to view or save)",
                    modifier = Modifier.widthIn(max = 240.dp).clickable { onOpenPhoto(f) }
                )
                decodeFailed -> Text("[photo couldn't be decoded]", color = Warn, fontFamily = TermFont, fontSize = 12.sp)
                error.isNotEmpty() -> Text("[photo failed: $error]", color = Warn, fontFamily = TermFont, fontSize = 12.sp)
                loading || f != null -> Text("[loading photo…]", color = Dim, fontFamily = TermFont, fontSize = 12.sp)
                else -> Text("[photo]", color = Dim, fontFamily = TermFont, fontSize = 12.sp)
            }
        }
        MsgType.VIDEO -> {
            Column {
                Text("[ video ]", color = Ink, fontFamily = TermFont, fontSize = 13.sp)
                Spacer(Modifier.height(4.dp))
                TextButton(onClick = { load { f -> f?.let { openVideo(ctx, it) } } }, enabled = !loading) {
                    Text(if (loading) "[loading…]" else "[play]", color = Accent, fontFamily = TermFont, fontSize = 13.sp)
                }
                if (error.isNotEmpty()) Text("[video failed: $error]", color = Warn, fontFamily = TermFont, fontSize = 11.sp)
            }
        }
        MsgType.VOICE -> {
            var player by remember(m.path) { mutableStateOf<MediaPlayer?>(null) }
            var playing by remember(m.path) { mutableStateOf(false) }
            DisposableEffect(m.path) { onDispose { player?.release() } }

            fun playFile(f: File) {
                val mp = MediaPlayer().apply {
                    setDataSource(f.absolutePath)
                    setOnCompletionListener { playing = false }
                    prepare()
                    start()
                }
                player = mp; playing = true
            }

            val labelLen = if (m.durationMs > 0) {
                val s = (m.durationMs / 1000).toInt()
                " · %d:%02d".format(s / 60, s % 60)
            } else ""
            Column {
                Text("[ voice$labelLen ]", color = Ink, fontFamily = TermFont, fontSize = 13.sp)
                Spacer(Modifier.height(4.dp))
                TextButton(
                    onClick = {
                        if (playing) {
                            player?.stop(); player?.release(); player = null; playing = false
                        } else {
                            load { f -> f?.let { playFile(it) } }
                        }
                    },
                    enabled = !loading
                ) {
                    Text(
                        if (loading) "[loading…]" else if (playing) "[■ stop]" else "[▶ play]",
                        color = Accent, fontFamily = TermFont, fontSize = 13.sp
                    )
                }
                if (error.isNotEmpty()) Text("[voice failed: $error]", color = Warn, fontFamily = TermFont, fontSize = 11.sp)
            }
        }
        MsgType.TEXT -> {}
    }
}

/** Full-screen photo with a [save] button that puts the original file in Pictures/Novochron. */
@Composable
private fun MsgPhotoViewer(file: File, mediaPath: String, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var bmp by remember(file) { mutableStateOf<Bitmap?>(null) }
    LaunchedEffect(file) { bmp = withContext(Dispatchers.IO) { msgDecodeSampled(file, 2048) } }

    val name = "Novochron-" + mediaPath.substringAfterLast('/')
    val mime = msgMimeForExt(name.substringAfterLast('.', "jpg"))

    fun save() {
        scope.launch {
            val ok = withContext(Dispatchers.IO) { msgSaveImageToGallery(ctx, file, name, mime) }
            Toast.makeText(ctx, if (ok) "Saved to Pictures/Novochron" else "Couldn't save photo", Toast.LENGTH_SHORT).show()
        }
    }
    // Android 9 and older need a storage permission to write to Pictures; 10+ doesn't.
    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) save() else Toast.makeText(ctx, "Storage permission is needed to save photos on this Android version", Toast.LENGTH_LONG).show()
    }
    fun onSaveClick() {
        val needsPermission = Build.VERSION.SDK_INT < 29 &&
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED
        if (needsPermission) permLauncher.launch(Manifest.permission.WRITE_EXTERNAL_STORAGE) else save()
    }

    Dialog(onDismissRequest = onClose, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Box(Modifier.fillMaxSize().background(Color.Black)) {
            val b = bmp
            if (b != null) {
                Image(b.asImageBitmap(), contentDescription = "photo", modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Fit)
            } else {
                Text("[loading…]", color = Dim, fontFamily = TermFont, fontSize = 13.sp, modifier = Modifier.align(Alignment.Center))
            }
            Row(
                Modifier.align(Alignment.TopEnd).statusBarsPadding().padding(8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                TextButton(onClick = { onSaveClick() }, enabled = b != null) {
                    Text("[save]", color = Accent, fontFamily = TermFont, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                }
                TextButton(onClick = onClose) { Text("[close]", color = Ink, fontFamily = TermFont, fontSize = 15.sp) }
            }
        }
    }
}

private fun openVideo(ctx: Context, file: File) {
    val uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.fileprovider", file)
    val intent = Intent(Intent.ACTION_VIEW).apply {
        setDataAndType(uri, "video/mp4")
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
    ctx.startActivity(intent)
}

private fun timeLabel(ts: Long): String {
    if (ts <= 0L) return ""
    val fmt = java.text.SimpleDateFormat("MMM d, HH:mm", java.util.Locale.getDefault())
    return fmt.format(java.util.Date(ts))
}

private fun humanMsgBytes(n: Long): String = when {
    n >= 1_000_000 -> "%.1f MB".format(n / 1_000_000.0)
    n >= 1_000 -> "%.0f KB".format(n / 1_000.0)
    else -> "$n B"
}

// ---------------- helpers ----------------

private fun msgErrText(e: Exception): String = if (e is GitHubApiException) e.body.take(80) else e.message ?: "unknown error"

/** Where a media file lives on this phone once downloaded (or before upload, for our own). Under cache/msg/, which the FileProvider already exposes. */
private fun msgMediaCacheFile(ctx: Context, mediaPath: String): File =
    File(ctx.cacheDir, "msg/media/" + mediaPath.replace('/', '_'))

private fun msgPhotoExt(mime: String): String = when (mime.lowercase()) {
    "image/png" -> "png"
    "image/webp" -> "webp"
    "image/gif" -> "gif"
    "image/heic" -> "heic"
    "image/heif" -> "heif"
    else -> "jpg"
}

private fun msgMimeForExt(ext: String): String = when (ext.lowercase()) {
    "png" -> "image/png"
    "webp" -> "image/webp"
    "gif" -> "image/gif"
    "heic" -> "image/heic"
    "heif" -> "image/heif"
    else -> "image/jpeg"
}

/** Decodes at reduced size so a 50 MB photo doesn't blow up memory. Result is at least [maxDim] px where possible. */
private fun msgDecodeSampled(file: File, maxDim: Int): Bitmap? {
    val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    BitmapFactory.decodeFile(file.absolutePath, bounds)
    if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
    var sample = 1
    while (bounds.outWidth / (sample * 2) >= maxDim && bounds.outHeight / (sample * 2) >= maxDim) sample *= 2
    return BitmapFactory.decodeFile(file.absolutePath, BitmapFactory.Options().apply { inSampleSize = sample })
}

/** Copies the original, full-quality file into the gallery (Pictures/Novochron). */
private fun msgSaveImageToGallery(ctx: Context, src: File, displayName: String, mime: String): Boolean = try {
    if (Build.VERSION.SDK_INT >= 29) {
        val resolver = ctx.contentResolver
        val values = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, displayName)
            put(MediaStore.Images.Media.MIME_TYPE, mime)
            put(MediaStore.Images.Media.RELATIVE_PATH, "${Environment.DIRECTORY_PICTURES}/Novochron")
            put(MediaStore.Images.Media.IS_PENDING, 1)
        }
        val uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
        if (uri == null) false else {
            val out = resolver.openOutputStream(uri)
            if (out == null) false else {
                out.use { o -> src.inputStream().use { it.copyTo(o, 64 * 1024) } }
                values.clear(); values.put(MediaStore.Images.Media.IS_PENDING, 0)
                resolver.update(uri, values, null, null)
                true
            }
        }
    } else {
        @Suppress("DEPRECATION")
        val dir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES), "Novochron").apply { mkdirs() }
        val dest = File(dir, displayName)
        src.copyTo(dest, overwrite = true)
        MediaScannerConnection.scanFile(ctx, arrayOf(dest.absolutePath), arrayOf(mime), null)
        true
    }
} catch (e: Exception) { false }

// ---- message parsing + on-disk copy of the chat (so it appears instantly when msg opens) ----

private fun msgParse(path: String, o: JSONObject) = ChatMsg(
    path = path,
    sender = o.optString("from", "them"),
    ts = o.optLong("ts", 0L),
    type = MsgType.valueOf(o.optString("type", "TEXT").uppercase()),
    text = o.optString("text", ""),
    mediaPath = o.optString("media", ""),
    durationMs = o.optLong("duration", 0L)
)

/** null = couldn't fetch right now (retried on the next poll). Malformed files are marked known and skipped for good. */
private suspend fun msgFetchMessage(c: MsgClient, r: RepoRef, path: String, known: MutableSet<String>): ChatMsg? {
    val body = try { c.readFile(path, r) } catch (e: Exception) { null } ?: return null
    return try { msgParse(path, JSONObject(body)) } catch (e: Exception) { known += path; null }
}

private fun msgCacheFile(ctx: Context, repo: String, branch: String) =
    File(ctx.filesDir, "msg_chat_${"$repo@$branch".hashCode()}.json")

private fun msgSaveCache(f: File, list: List<ChatMsg>) {
    try {
        val arr = JSONArray()
        for (m in list) if (!m.pending) arr.put(JSONObject().apply {
            put("path", m.path); put("from", m.sender); put("ts", m.ts); put("type", m.type.name)
            put("text", m.text); put("media", m.mediaPath); put("duration", m.durationMs)
        })
        f.writeText(arr.toString())
    } catch (_: Exception) {}
}

private fun msgLoadCache(f: File): List<ChatMsg> = try {
    if (!f.exists()) emptyList() else {
        val arr = JSONArray(f.readText())
        (0 until arr.length()).map { val o = arr.getJSONObject(it); msgParse(o.getString("path"), o) }.sortedBy { it.ts }
    }
} catch (e: Exception) { emptyList() }
