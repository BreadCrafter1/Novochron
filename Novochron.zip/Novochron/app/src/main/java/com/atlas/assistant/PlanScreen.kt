package com.atlas.assistant

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * `[plan]`: pick a target and see a real Hohmann transfer from Earth — coast time, delta-v, the launch
 * phase angle — drawn as a curving arc you can tilt. The `flight` slider (or `[fly]`) moves the
 * spacecraft along it in TIME (solved from Kepler's equation, so it really does dawdle near the far end),
 * and `[next window]` finds the next real launch date from the planets' actual positions.
 */
@Composable
internal fun PlanTab() {
    val ctx = LocalContext.current
    val targets = remember { listOf("Venus", "Mars", "Jupiter", "Saturn") }
    var targetName by remember { mutableStateOf("Jupiter") }
    var flight by remember { mutableFloatStateOf(0.62f) }
    var tiltDeg by remember { mutableFloatStateOf(45f) }
    var yaw by remember { mutableFloatStateOf(0.35f) }
    var zoomK by remember { mutableFloatStateOf(1f) }
    var flying by remember { mutableStateOf(false) }
    var windowNote by remember { mutableStateOf("") }
    var texReady by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { withContext(Dispatchers.Default) { Textures.preload(ctx) }; texReady = true }

    val earth = remember { OrbitMath.SOLAR_SYSTEM.first { it.name == "Earth" } }
    val sun = remember { OrbitMath.SOLAR_SYSTEM.first { it.isStar } }
    val target = remember(targetName) { OrbitMath.SOLAR_SYSTEM.first { it.name == targetName } }
    val r1 = 1.0
    val r2 = target.orbitAu
    val hoh = remember(targetName) { OrbitMath.hohmannTransfer(r1, r2) }
    // The target must be this many degrees ahead of Earth at launch (negative = behind it).
    val lead = 180.0 - 360.0 * hoh.transferDays / target.periodDays
    val leadWrapped = ((lead + 180.0) % 360.0 + 360.0) % 360.0 - 180.0

    LaunchedEffect(flying) {
        while (flying) {
            delay(32)
            flight += 0.032f / 9f
            if (flight >= 1f) { flight = 1f; flying = false }
        }
    }

    val space = if (texReady) Textures.image(ctx, "space") else null
    val screenH = LocalConfiguration.current.screenHeightDp
    val canvasH = (screenH * 0.46f).coerceIn(230f, 430f).dp

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        Box(
            Modifier
                .fillMaxWidth()
                .height(canvasH)
                .border(1.dp, Line)
                .pointerInput(Unit) {
                    detectTransformGestures { _, pan, zoom, _ ->
                        yaw += pan.x * 0.008f
                        tiltDeg = (tiltDeg - pan.y * 0.2f).coerceIn(0f, 80f)
                        zoomK = (zoomK * zoom).coerceIn(0.5f, 4f)
                    }
                }
        ) {
            PlanCanvas(ctx, space, sun, earth, target, hoh, leadWrapped, flight, tiltDeg, yaw, zoomK, texReady)
        }

        Row(Modifier.horizontalScroll(rememberScrollState()), verticalAlignment = Alignment.CenterVertically) {
            Text("to", color = Dim, fontFamily = TermFont, fontSize = 11.sp)
            targets.forEach { n ->
                TermTextKey(n, tone = if (n == targetName) Accent else Ink, bold = n == targetName, onClick = { targetName = n; windowNote = "" })
            }
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("flight", color = Dim, fontFamily = TermFont, fontSize = 11.sp)
            Slider(
                value = flight, onValueChange = { flight = it; flying = false }, valueRange = 0f..1f,
                colors = SliderDefaults.colors(thumbColor = Accent, activeTrackColor = Accent, inactiveTrackColor = Line),
                modifier = Modifier.weight(1f).padding(horizontal = 8.dp)
            )
            Text("${(flight * 100).toInt()}%", color = Ink, fontFamily = TermFont, fontSize = 11.sp)
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("tilt", color = Dim, fontFamily = TermFont, fontSize = 11.sp)
            Spacer(Modifier.width(14.dp))
            Slider(
                value = tiltDeg, onValueChange = { tiltDeg = it }, valueRange = 0f..80f,
                colors = SliderDefaults.colors(thumbColor = Accent, activeTrackColor = Accent, inactiveTrackColor = Line),
                modifier = Modifier.weight(1f).padding(horizontal = 8.dp)
            )
            Text("${tiltDeg.toInt()}°", color = Ink, fontFamily = TermFont, fontSize = 11.sp)
        }
        Text(
            "${hoh.transferDays.toInt()} days · dv ${fmtP(hoh.deltaV1Kms + hoh.deltaV2Kms)} km/s · target " +
                (if (leadWrapped >= 0) "leads by ${abs(leadWrapped).toInt()}°" else "trails by ${abs(leadWrapped).toInt()}°"),
            color = Ink, fontFamily = TermFont, fontSize = 12.sp
        )
        Text(
            "burn 1 ${fmtP(hoh.deltaV1Kms)} km/s at Earth, burn 2 ${fmtP(hoh.deltaV2Kms)} km/s at ${target.name}  ·  " +
                "day ${(hoh.transferDays * flight).toInt()} of ${hoh.transferDays.toInt()}  ·  e ${fmtP(hoh.eccentricity)}",
            color = Dim, fontFamily = TermFont, fontSize = 11.sp
        )
        Row(verticalAlignment = Alignment.CenterVertically) {
            TermTextKey(if (flying) "[stop]" else "[fly]", tone = Accent, onClick = {
                if (flying) flying = false else { if (flight >= 1f) flight = 0f; flying = true }
            })
            TermTextKey("[next window]", onClick = {
                val now = OrbitMath.todayDays()
                val w = nextLaunchWindow(target, leadWrapped, now)
                windowNote = if (w == null) "Couldn't find a launch window in the next few years."
                else "Next Earth→${target.name} window: ${OrbitMath.dateFromDays(w)} (in ${(w - now).toInt()} days), " +
                    "arriving about ${OrbitMath.dateFromDays(w + hoh.transferDays)}."
            })
            TermTextKey("[set sim date]", onClick = {
                val now = OrbitMath.todayDays()
                val w = nextLaunchWindow(target, leadWrapped, now)
                if (w != null) { LabState.simT = w.toFloat(); windowNote = "Sim date set to ${OrbitMath.dateFromDays(w)} — open [sim] to watch the alignment." }
            })
        }
        if (windowNote.isNotBlank()) Text(windowNote, color = Accent, fontFamily = TermFont, fontSize = 11.sp)
        Text(
            "Two-burn Hohmann transfer between circular, coplanar orbits (real vis-viva numbers, Sun's gravity only). " +
                "Drag to spin and tilt, pinch to zoom.",
            color = Dim, fontFamily = TermFont, fontSize = 10.sp
        )
        Spacer(Modifier.height(24.dp))
    }
}

private fun fmtP(v: Double): String = ((Math.round(v * 10.0)) / 10.0).toString()

/**
 * The next date on/after [fromT] when [target] is [lead] degrees ahead of Earth (in heliocentric
 * longitude) — the moment to fire the first burn. Uses the real Keplerian positions day by day.
 */
private fun nextLaunchWindow(target: OrbitMath.Body, lead: Double, fromT: Double): Double? {
    val earth = OrbitMath.SOLAR_SYSTEM.first { it.name == "Earth" }
    fun diff(t: Double): Double {
        var d = OrbitMath.angleDeg(target, t) - OrbitMath.angleDeg(earth, t) - lead
        d = ((d + 180.0) % 360.0 + 360.0) % 360.0 - 180.0
        return d
    }
    var t = fromT
    var prev = diff(t)
    val end = fromT + 1500.0
    while (t < end) {
        val next = t + 1.0
        val cur = diff(next)
        if ((prev > 0) != (cur > 0) && abs(prev) < 90.0 && abs(cur) < 90.0) {
            val f = abs(prev) / (abs(prev) + abs(cur))
            return t + f
        }
        prev = cur
        t = next
    }
    return null
}

private fun solveE(m: Double, e: Double): Double {
    var ea = if (e > 0.8) PI else m
    repeat(40) {
        val d = (ea - e * sin(ea) - m) / (1 - e * cos(ea))
        ea -= d
        if (abs(d) < 1e-12) return ea
    }
    return ea
}

@Composable
private fun PlanCanvas(
    ctx: android.content.Context,
    space: androidx.compose.ui.graphics.ImageBitmap?,
    sun: OrbitMath.Body,
    earth: OrbitMath.Body,
    target: OrbitMath.Body,
    hoh: OrbitMath.HohmannResult,
    leadDeg: Double,
    flight: Float,
    tiltDeg: Float,
    yaw: Float,
    zoomK: Float,
    texReady: Boolean
) {
    Canvas(Modifier.fillMaxSize()) {
        @Suppress("UNUSED_VARIABLE") val ready = texReady
        val w = size.width; val h = size.height
        if (space != null) drawSpaceBackdrop(space, 0.9f)

        val r1 = 1.0
        val r2 = target.orbitAu
        val outer = maxOf(r1, r2)
        val scale = (min(w, h) * 0.44f / outer.toFloat()) * zoomK
        val tilt = Math.toRadians(tiltDeg.toDouble())
        val yw = yaw.toDouble()
        val cx = w / 2f; val cy = h / 2f
        fun pt(x: Double, y: Double, z: Double): Offset {
            val xr = x * cos(yw) - y * sin(yw)
            val yr = x * sin(yw) + y * cos(yw)
            return Offset((cx + xr * scale).toFloat(), (cy - (yr * cos(tilt) + z * sin(tilt)) * scale).toFloat())
        }

        // orbits
        fun ring(radius: Double, color: Color) {
            var prev: Offset? = null
            for (i in 0..96) {
                val a = 2 * PI * i / 96
                val p = pt(radius * cos(a), radius * sin(a), 0.0)
                if (prev != null) drawLine(color, prev!!, p, strokeWidth = 1.2f)
                prev = p
            }
        }
        ring(r1, Color(0x884FA8FF))
        ring(r2, Color(0x88DCC88C))

        // transfer arc, launch from angle 0; the arc lifts out of the plane a little so the tilt shows it curving
        val a = (r1 + r2) / 2.0
        val e = abs(r2 - r1) / (r1 + r2)
        val p = a * (1 - e * e)
        val outward = r2 >= r1
        val lift = 0.16 * outer
        fun arc(f: Double): Offset {
            val th = (if (outward) 0.0 else PI) + PI * f
            val r = p / (1 + e * cos(th))
            val ang = PI * f
            return pt(r * cos(ang), r * sin(ang), lift * sin(PI * f))
        }
        var prevA: Offset? = null
        val steps = 90
        val dash = PathEffect.dashPathEffect(floatArrayOf(10f, 8f))
        for (i in 0..steps) {
            val f = i / steps.toDouble()
            val pa = arc(f)
            if (prevA != null) {
                if (f <= flight) drawLine(Color(0xFFFFD24C), prevA!!, pa, strokeWidth = 3f)
                else if (i % 2 == 0) drawLine(Color(0x88FFD24C), prevA!!, pa, strokeWidth = 2f)
            }
            prevA = pa
        }
        // (dash effect kept for a possible stroked-path variant)
        @Suppress("UNUSED_VARIABLE") val unused = dash

        // Sun
        val sunPos = pt(0.0, 0.0, 0.0)
        drawGlow(sunPos, 34f, Color(0xFFFFD84A), 0.9f)
        drawTexturedBody(ctx, sun, sunPos, 9f, null)

        // spacecraft position by TIME along the ellipse (Kepler), not by angle
        val mAnom = (if (outward) 0.0 else PI) + PI * flight
        val ecc = solveE(mAnom, e)
        val th = 2 * atan2(sqrt(1 + e) * sin(ecc / 2), sqrt(1 - e) * cos(ecc / 2))
        val thn = ((th % (2 * PI)) + 2 * PI) % (2 * PI)
        val rSc = p / (1 + e * cos(thn))
        val angSc = if (outward) thn else thn - PI
        val fApprox = (if (outward) thn else thn - PI) / PI
        val scPos = pt(rSc * cos(angSc), rSc * sin(angSc), lift * sin(PI * fApprox.coerceIn(0.0, 1.0)))

        // planets: Earth leaves from angle 0; the target sits at (launch lead) and ends at angle 180 on arrival
        val tCoast = hoh.transferDays * flight
        val earthAng = 2 * PI * tCoast / earth.periodDays
        val targetAng = Math.toRadians(leadDeg) + 2 * PI * tCoast / target.periodDays
        val ePos = pt(r1 * cos(earthAng), r1 * sin(earthAng), 0.0)
        val tPos = pt(r2 * cos(targetAng), r2 * sin(targetAng), 0.0)
        drawTexturedBody(ctx, earth, ePos, 8f, sunPos)
        drawTexturedBody(ctx, target, tPos, if (target.name == "Jupiter" || target.name == "Saturn") 11f else 7f, sunPos)
        drawLabel("Earth", ePos.x + 12f, ePos.y + 22f, 0xFF7FB8FF.toInt())
        drawLabel(target.name, tPos.x + 12f, tPos.y - 10f, 0xFFF0D8A8.toInt())

        // launch / arrival markers and the craft
        val launch = arc(0.0)
        val arrive = arc(1.0)
        drawCircle(Color(0xFF3DFF5C), radius = 4f, center = launch, style = Stroke(width = 1.5f))
        drawCircle(Color(0xFFFF9A3D), radius = 4f, center = arrive, style = Stroke(width = 1.5f))
        drawGlow(scPos, 14f, Color.White, 0.8f)
        drawCircle(Color.White, radius = 3.2f, center = scPos)

        drawLabel("day ${tCoast.toInt()}", 12f, h - 14f, 0xD9E8E8E8.toInt())
    }
}
