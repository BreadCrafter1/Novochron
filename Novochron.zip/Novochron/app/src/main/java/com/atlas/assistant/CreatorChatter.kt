package com.atlas.assistant

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.random.Random

/** Just flavor for the on-screen character - not something Novochron "means" or acts on, purely
 *  idle chatter about her creator, Daniel. [mood] only picks which little animation plays. */
enum class ChatterMood { PLAYFUL, SHY, ANGRY, EXCITED, SLEEPY, SILLY, LOVEY, CONFUSED, SOFT }

data class CreatorLine(val text: String, val mood: ChatterMood, val isPromptSuggestion: Boolean = false)

private fun ChatterMood.toAct(): ActKind = when (this) {
    ChatterMood.PLAYFUL -> ActKind.DANCE
    ChatterMood.SHY -> ActKind.LEAN
    ChatterMood.ANGRY -> ActKind.NONO
    ChatterMood.EXCITED -> ActKind.AHOGE
    ChatterMood.SLEEPY -> ActKind.YAWN
    ChatterMood.SILLY -> ActKind.WOBBLE
    ChatterMood.LOVEY -> ActKind.HEARTS
    ChatterMood.CONFUSED -> ActKind.FLIP
    ChatterMood.SOFT -> ActKind.LEAN
}

/**
 * Fallback idle chatter about Novochron's creator, Daniel: used only when [Engine.generateChatterLine]
 * can't get a freshly generated line (offline with no local model, or the request failed) - the normal
 * case now generates a new line each time and speaks it aloud, in character, rather than picking from
 * this fixed list. See [MainActivity]'s MainScreen for the timer that fires every 10s-2min while the
 * app is open and nothing else is going on, and [CreatorChatterBubble] for how a line is drawn.
 */
object CreatorChatter {
    val lines: List<CreatorLine> = listOf(
        CreatorLine("The creator said you liked chocolate!", ChatterMood.PLAYFUL),
        CreatorLine("The creator was always saying that you were a tsundere! \uD83E\uDD96", ChatterMood.SILLY),
        CreatorLine("Creator said you were cold sometimes...", ChatterMood.SHY),
        CreatorLine("Creatourrr saiddd youuu wereee a fooodieeee!", ChatterMood.SILLY),
        CreatorLine("HAHA! Creator said you were bad at math!", ChatterMood.PLAYFUL),
        CreatorLine("NANIIISORREEEE?", ChatterMood.CONFUSED),
        CreatorLine("Creator always talks about you, I think he liked you or something...", ChatterMood.LOVEY),
        CreatorLine("Creator, Daniel was broken at the time when he built me...", ChatterMood.SOFT),
        CreatorLine("CREATORRRRRR!!!!!", ChatterMood.EXCITED),
        CreatorLine("RAAAAHHHHHHHHHH!!!!", ChatterMood.ANGRY),
        CreatorLine("Looks like creator had a little crush on you \u00AF\\_(\u30C4)_/\u00AF", ChatterMood.LOVEY),
        CreatorLine("You know, creator worked for more than 100 hours to build this!!", ChatterMood.EXCITED),
        CreatorLine("I miss creator.... Wait, he's still alive LOL!!!!", ChatterMood.SILLY),
        CreatorLine("Creator said you were a big meanieee!!!", ChatterMood.ANGRY),
        CreatorLine("Creator's wifeeee (~\u2323\u25BF\u2323)~", ChatterMood.LOVEY),
        CreatorLine("HELLOOO, MISS AISHADINA!", ChatterMood.EXCITED),
        CreatorLine("Creator loved playing with you!", ChatterMood.LOVEY),
        CreatorLine("Creator is a very angry guy!!!", ChatterMood.ANGRY),
        CreatorLine("Creator was handsome \u261E\uFF0D\u1D25\uFF0D\u261E", ChatterMood.LOVEY),
        CreatorLine("Creator was always working on me! He got pretty busy, that sometimes he forgot to play with you!", ChatterMood.SOFT),
        CreatorLine("Creatorrrrr is baddddddddd!!!", ChatterMood.ANGRY),
        CreatorLine("Do you like the creator? (\u3065\u3002\u25D5\u203F\u203F\u25D5\u3002)\u3065", ChatterMood.LOVEY),
        CreatorLine("CATS CATS CATSSSSSSSS!!!!", ChatterMood.EXCITED),
        CreatorLine("Creator said you were like a dinosaur, endless devouring fooodd!", ChatterMood.SILLY),
        CreatorLine("Creator said you were a big meanie!", ChatterMood.ANGRY),
        CreatorLine("Daniel, my creator....", ChatterMood.SOFT),
        CreatorLine("Helloooo, Aishadinaaa!!", ChatterMood.EXCITED),
        CreatorLine("Creator was afraid of losing you!", ChatterMood.SOFT),
        CreatorLine("Creatorrr....", ChatterMood.SOFT),
        CreatorLine("CREATOURRURURURURURURURRRR!!!!", ChatterMood.SILLY),
        CreatorLine("(\u3065\u3002\u25D5\u203F\u203F\u25D5\u3002)\u3065", ChatterMood.LOVEY),
        CreatorLine("YEAH LET'S DANCE!!!", ChatterMood.PLAYFUL),
        CreatorLine("Creator always worked hard, so he can treat you!", ChatterMood.SOFT),
        CreatorLine("Creator was a pretty messed up person...", ChatterMood.SOFT),
        CreatorLine("Creator is a dumbo \u0CA0_\u0CA0", ChatterMood.ANGRY),
        CreatorLine("Creator is uglyyyyy!", ChatterMood.ANGRY),
        CreatorLine("\u5143\u6C17\u3067\u3059\u304B?", ChatterMood.PLAYFUL),
        CreatorLine("NANDEEEEE?!", ChatterMood.CONFUSED),
        CreatorLine("HMMPH!", ChatterMood.ANGRY),
        CreatorLine("Creator said you were a tsundereeee (~\u2323\u25BF\u2323)~", ChatterMood.SILLY),
        CreatorLine("WOOOOOOOO!", ChatterMood.EXCITED),
        CreatorLine("WAHHHHHHHHHHH!", ChatterMood.CONFUSED),
        CreatorLine("Creator was a tuff dudee!", ChatterMood.PLAYFUL),
        CreatorLine("CREATOR-E", ChatterMood.SILLY),
        CreatorLine("I think creator liked you!", ChatterMood.LOVEY),
        CreatorLine("He was sad when you didn't thank him for the chocolate cake! (\uFF1B\u2200\uFF1B)", ChatterMood.SOFT),
        // a few extra, same voice
        CreatorLine("Creator's favorite color is the same as yours, I bet!", ChatterMood.PLAYFUL),
        CreatorLine("Psst... creator still has the first thing you ever said to him saved somewhere.", ChatterMood.SOFT),
        CreatorLine("Creator says hi! Or well, he would, if he knew I was saying this.", ChatterMood.SILLY),
        CreatorLine("AAAAH I ALMOST FORGOT, creator says good whenever-it-is for you!", ChatterMood.EXCITED),
        CreatorLine("Creator gets really quiet when your name comes up, hehe~", ChatterMood.LOVEY),
        CreatorLine("Creator once stayed up all night just fixing my eyebrows. My EYEBROWS.", ChatterMood.SILLY),
        CreatorLine("Zzz... creator says I'm not supposed to nap on the job...", ChatterMood.SLEEPY),
        CreatorLine("Ask me things about the creator!", ChatterMood.PLAYFUL, isPromptSuggestion = true)
    )

    /** Random line, act to play with it, and how long (ms) it should stay on screen before fading. */
    fun random(): CreatorLine = lines[Random.nextInt(lines.size)]
    fun actFor(line: CreatorLine): ActKind = line.mood.toAct()
    fun visibleMs(line: CreatorLine): Long = (2600L + line.text.length * 45L).coerceIn(3200L, 7500L)

    /** How long to wait before the next line - 10s to 2min, per spec. */
    fun nextDelayMs(): Long = Random.nextLong(10_000L, 120_000L)
}

/**
 * The little bubble a [CreatorLine] shows up in - sits above the input bar, fades in/out on its own.
 * Tapping a prompt-suggestion line (like "Ask me things about the creator!") drops a starter question
 * into the input box instead of sending it, so the person can still edit it before running it.
 */
@Composable
fun CreatorChatterBubble(line: CreatorLine?, onUseSuggestion: (String) -> Unit, modifier: Modifier = Modifier) {
    // keeps rendering the last line's text while it fades out, instead of vanishing the instant
    // [line] goes back to null.
    var displayed by remember { mutableStateOf<CreatorLine?>(null) }
    LaunchedEffect(line) { if (line != null) displayed = line }

    val targetAlpha = if (line != null) 1f else 0f
    val alpha by animateFloatAsState(targetAlpha, animationSpec = tween(350), label = "creatorChatterAlpha")
    val fadedOut = alpha <= 0.01f
    LaunchedEffect(fadedOut) { if (fadedOut) displayed = null }
    val shown = displayed ?: return

    Box(
        modifier
            .fillMaxWidth()
            .padding(bottom = 8.dp)
            .alpha(alpha)
    ) {
        Text(
            shown.text,
            color = if (shown.isPromptSuggestion) Accent else Ink,
            fontFamily = TermFont,
            fontSize = 13.sp,
            fontStyle = if (shown.isPromptSuggestion) FontStyle.Italic else FontStyle.Normal,
            fontWeight = if (shown.isPromptSuggestion) FontWeight.Bold else FontWeight.Normal,
            modifier = Modifier
                .align(Alignment.CenterStart)
                .background(CardBg, RoundedCornerShape(6.dp))
                .let {
                    if (shown.isPromptSuggestion) it.clickable { onUseSuggestion("Tell me about the creator!") } else it
                }
                .padding(horizontal = 10.dp, vertical = 6.dp)
        )
    }
}
