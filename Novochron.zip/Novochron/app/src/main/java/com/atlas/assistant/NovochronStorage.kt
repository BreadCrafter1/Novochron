package com.atlas.assistant

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.Settings
import java.io.File

/**
 * Gives Novochron its own visible folder on shared storage, at /storage/emulated/0/Novochron, instead of
 * hiding everything inside Android's private app sandbox. Chat history, memory and learned places
 * live there once access is granted, so the user can see, back up or copy the folder like any other
 * folder on the phone (file manager, USB, etc.).
 *
 * Layout:
 *   /storage/emulated/0/Novochron/novochron.db     - chat history, memory, artifacts (SQLite)
 *   /storage/emulated/0/Novochron/Maps/        - learned places (places.json) for offline distance answers
 *   /storage/emulated/0/Novochron/Models/      - optional offline model: model.task (offline LLM)
 *   /storage/emulated/0/Novochron/Knowledge/   - plain-text notes from "learn <topic>", one .txt per topic
 *   /storage/emulated/0/Novochron/Photos/      - pictures from the camera, the gallery picker and screencast frames
 *                                              (Settings > "Clear photos in directory" empties it)
 *   /storage/emulated/0/Novochron/Plugins/     - drop-in .js command plugins (see PluginManager.kt)
 *   /storage/emulated/0/Novochron/Adaptive/    - locally-learned preferences and usage stats (see Adaptive.kt);
 *                                              purely on-device, never uploaded anywhere on its own
 *   /storage/emulated/0/Novochron/Library/     - apps/games/puzzles Novochron builds, mirrored out of the
 *                                              database as plain .html files, one per artifact (see LibraryStore.kt)
 */
object NovochronStorage {

    fun root(): File = File(Environment.getExternalStorageDirectory(), "Novochron")
    fun mapsDir(): File = File(root(), "Maps")
    fun modelsDir(): File = File(root(), "Models")
    fun photosDir(): File = File(root(), "Photos")
    fun knowledgeDir(): File = File(root(), "Knowledge")
    fun pluginsDir(): File = File(root(), "Plugins")
    fun adaptiveDir(): File = File(root(), "Adaptive")
    /** Apps/games/puzzles Novochron builds, mirrored out of the `artifacts` table as plain .html files - see LibraryStore.kt. */
    fun libraryDir(): File = File(root(), "Library")
    fun dbFile(): File = File(root(), "novochron.db")
    /** Marker written once first-run setup finishes (see [Store.setupComplete]). Lives in the visible
     *  folder, not just SharedPreferences, so it survives an uninstall/reinstall or "clear data" the
     *  same way the rest of Novochron/ does - not just a plain app update, which keeps prefs anyway. */
    fun setupMarkerFile(): File = File(root(), ".setup_complete")
    fun placesFile(): File = File(mapsDir(), "places.json")

    /** Where photos go when "All files access" hasn't been granted yet (see [Vision.save]). */
    fun privatePhotosDir(ctx: Context): File = File(ctx.filesDir, "photos")

    private val PHOTO_EXTENSIONS = setOf("jpg", "jpeg", "png", "webp", "gif", "bmp", "heic", "heif")

    /** Every image file in Novochron/Photos and the app-private fallback folder (subfolders included). */
    private fun photoFiles(ctx: Context): List<File> = try {
        listOf(photosDir(), privatePhotosDir(ctx))
            .filter { it.isDirectory }
            .flatMap { dir ->
                dir.walkTopDown().filter { it.isFile && it.extension.lowercase() in PHOTO_EXTENSIONS }.toList()
            }
    } catch (e: Exception) {
        emptyList()
    }

    /** How many photos are saved right now, and how many bytes they take. */
    fun photoStats(ctx: Context): Pair<Int, Long> {
        val files = photoFiles(ctx)
        return files.size to files.fold(0L) { total, f -> total + f.length() }
    }

    /**
     * Deletes every photo in Novochron/Photos (and the app-private fallback folder) and returns how many
     * were removed. Only image files are touched, and the folders themselves are kept, so anything
     * else you've dropped in there by hand is left alone.
     */
    fun clearPhotos(ctx: Context): Int {
        var deleted = 0
        photoFiles(ctx).forEach { f ->
            try { if (f.delete()) deleted++ } catch (e: Exception) { /* locked or read-only: skip it */ }
        }
        return deleted
    }

    /** True once Novochron is allowed to read and write its own folder on shared storage. */
    fun hasAccess(): Boolean = when {
        Build.VERSION.SDK_INT >= 30 -> Environment.isExternalStorageManager()
        else -> true // WRITE_EXTERNAL_STORAGE is requested as a normal runtime permission below API 30
    }

    fun hasLegacyPermission(ctx: Context): Boolean =
        Build.VERSION.SDK_INT >= 30 ||
            ctx.checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED

    /** Creates the folder (and subfolders) if they don't exist yet. Safe to call repeatedly. */
    fun ensureDirs(): Boolean = try {
        root().mkdirs()
        mapsDir().mkdirs()
        modelsDir().mkdirs()
        photosDir().mkdirs()
        knowledgeDir().mkdirs()
        pluginsDir().mkdirs()
        adaptiveDir().mkdirs()
        libraryDir().mkdirs()
        root().exists()
    } catch (e: Exception) {
        false
    }

    /** Opens system settings so the user can grant Novochron "All files access" (Android 11+). */
    fun requestAccessIntent(ctx: Context): Intent = try {
        Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:${ctx.packageName}"))
    } catch (e: Exception) {
        Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION)
    }
}
