package com.atlas.assistant

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.Locale

/**
 * Two small, fully-offline, no-telemetry learning features that sit on top of the normal command flow:
 *
 *  - [CorrectionTracker]: notices when the user corrects the same kind of answer more than once
 *    ("no, always X" / "actually, X" / "instead, X") and, once it's seen the *same* correction twice,
 *    asks "should I always do it that way?" — if confirmed, the correction is saved as a standing
 *    preference note (via [KnowledgeStore]) that feeds Brain's system prompt from then on.
 *  - [UsageStats]: a rolling, purely-local log of what's been asked, so the `[stats]` screen can answer
 *    "what have I asked you about most this week" - nothing here ever leaves the phone on its own.
 *
 * Both persist as plain JSON files in Novochron/Adaptive/ (or the private fallback folder, same pattern as
 * KnowledgeStore/Maps), so they're easy to inspect, back up, or wipe by hand.
 */
object CorrectionTracker {

    private const val THRESHOLD = 2 // ask once the same correction has been seen this many times

    // "no, always mute at night", "actually always do X", "instead, X", "I meant X", "don't do that, do X"
    private val CORRECTION_REGEX = Regex(
        "^(?:no|nope|wait)?[,.\\s]*(?:actually|instead|i meant|you should|from now on|always)[,\\s]+(.{4,})$",
        RegexOption.IGNORE_CASE
    )
    private val AFFIRM = Regex("^(yes|yeah|yep|sure|always|do that|please do|go ahead)\\b", RegexOption.IGNORE_CASE)
    private val DECLINE = Regex("^(no|nope|don't|never mind|nevermind|just this once)\\b", RegexOption.IGNORE_CASE)

    private fun file(ctx: Context): File {
        val d = if (NovochronStorage.hasAccess() && NovochronStorage.ensureDirs()) NovochronStorage.adaptiveDir()
        else File(ctx.filesDir, "Adaptive")
        try { d.mkdirs() } catch (e: Exception) { }
        return File(d, "corrections.json")
    }

    private fun load(ctx: Context): JSONObject = try {
        val f = file(ctx)
        if (f.exists()) JSONObject(f.readText()) else JSONObject()
    } catch (e: Exception) { JSONObject() }

    private fun save(ctx: Context, o: JSONObject) {
        try { file(ctx).writeText(o.toString(2)) } catch (e: Exception) { }
    }

    /** Rough bucket for "the same kind of correction" — the first couple of significant words of the note. */
    private fun category(note: String): String =
        note.lowercase(Locale.US).split(Regex("\\s+")).filter { it.length > 2 }.take(3).joinToString(" ")

    /**
     * Call with every user utterance before normal command handling. Returns a spoken reply if this
     * intercepts the turn (either "should I always do it that way?" or acknowledging yes/no to a
     * pending one); returns null to let the turn continue normally.
     */
    fun intercept(ctx: Context, store: Store, text: String): String? {
        val t = text.trim()
        val pending = store.pendingPreferenceNote
        if (pending.isNotBlank()) {
            store.pendingPreferenceNote = ""
            if (AFFIRM.containsMatchIn(t)) {
                KnowledgeStore.save(ctx, "preference: ${category(pending)}", pending)
                return "Got it — I'll always do that from now on."
            }
            if (DECLINE.containsMatchIn(t)) return "Okay, I won't assume that."
            // wasn't actually an answer to the question — fall through and let it re-trigger detection below
        }

        val m = CORRECTION_REGEX.find(t) ?: return null
        val note = m.groupValues[1].trim().trimEnd('.', '!').ifBlank { return null }
        val cat = category(note)
        val o = load(ctx)
        val key = "$cat|${note.lowercase(Locale.US)}"
        val count = o.optInt(key, 0) + 1
        o.put(key, count)
        save(ctx, o)
        if (count >= THRESHOLD) {
            store.pendingPreferenceNote = note
            return "I've noticed you correct me the same way here. Should I always $note from now on?"
        }
        return null // noted quietly; not yet asking
    }
}

/** One thing the user asked/said, logged for the `[stats]` screen. Category is a coarse bucket, not raw text. */
private data class UsageEvent(val category: String, val ts: Long)

object UsageStats {
    private const val MAX_EVENTS = 2000

    private fun file(ctx: Context): File {
        val d = if (NovochronStorage.hasAccess() && NovochronStorage.ensureDirs()) NovochronStorage.adaptiveDir()
        else File(ctx.filesDir, "Adaptive")
        try { d.mkdirs() } catch (e: Exception) { }
        return File(d, "usage.json")
    }

    /** Coarse category for a raw utterance — enough to say "you've asked about X most", not the literal text. */
    private fun categorize(text: String): String {
        val t = text.trim().lowercase(Locale.US)
        if (t.isBlank()) return "other"
        val firstWords = t.split(Regex("\\s+")).filter { it.length > 2 }.take(2)
        return if (firstWords.isEmpty()) "other" else firstWords.joinToString(" ")
    }

    @Synchronized
    fun log(ctx: Context, text: String) {
        if (text.isBlank()) return
        val f = file(ctx)
        val arr = try { if (f.exists()) JSONArray(f.readText()) else JSONArray() } catch (e: Exception) { JSONArray() }
        arr.put(JSONObject().put("cat", categorize(text)).put("ts", System.currentTimeMillis()))
        // keep only the most recent MAX_EVENTS entries
        val trimmed = if (arr.length() > MAX_EVENTS) {
            val out = JSONArray()
            for (i in (arr.length() - MAX_EVENTS) until arr.length()) out.put(arr.getJSONObject(i))
            out
        } else arr
        try { f.writeText(trimmed.toString()) } catch (e: Exception) { }
    }

    private fun events(ctx: Context): List<UsageEvent> {
        val f = file(ctx)
        if (!f.exists()) return emptyList()
        return try {
            val arr = JSONArray(f.readText())
            (0 until arr.length()).mapNotNull { i ->
                val o = arr.optJSONObject(i) ?: return@mapNotNull null
                UsageEvent(o.optString("cat", "other"), o.optLong("ts", 0))
            }
        } catch (e: Exception) { emptyList() }
    }

    /** Top categories within [days] days, most-asked first, each with its count. */
    fun topCategories(ctx: Context, days: Int = 7, limit: Int = 8): List<Pair<String, Int>> {
        val since = System.currentTimeMillis() - days * 86_400_000L
        return events(ctx).filter { it.ts >= since }
            .groupingBy { it.category }.eachCount()
            .entries.sortedByDescending { it.value }
            .take(limit)
            .map { it.key to it.value }
    }

    fun totalCount(ctx: Context, days: Int = 7): Int {
        val since = System.currentTimeMillis() - days * 86_400_000L
        return events(ctx).count { it.ts >= since }
    }

    fun allTimeCount(ctx: Context): Int = events(ctx).size

    @Synchronized
    fun clear(ctx: Context) {
        try { file(ctx).delete() } catch (e: Exception) { }
    }
}
