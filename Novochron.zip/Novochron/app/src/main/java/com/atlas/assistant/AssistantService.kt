package com.atlas.assistant

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import androidx.core.app.NotificationCompat

/**
 * Keeps the microphone open (always-on listening) as a foreground service, so Novochron keeps working
 * with the screen off or while you are in another app.
 *
 * Wake-word gating (when on) reuses this same continuous recognizer (Listener) to gate what it reacts
 * to — see WakeWord.kt / Engine.onHeard — rather than a separate dedicated low-power engine. Listener
 * itself can end each turn the instant real speech stops, instead of waiting on a fixed silence timer -
 * see Listener.kt's class doc for how.
 */
class AssistantService : Service() {

    private lateinit var engine: Engine
    private lateinit var listener: Listener
    private lateinit var maps: Maps
    private val main = Handler(Looper.getMainLooper())
    private var wake: PowerManager.WakeLock? = null
    private var listening = false

    // Logs a battery reading every couple of minutes while voice is on, for the [stats] battery section.
    private val batterySampler = object : Runnable {
        override fun run() {
            BatteryTracker.sample(this@AssistantService)
            main.postDelayed(this, 2 * 60_000L)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        engine = Engine.get(this)
        maps = Maps.get(this)
        engine.onDedicatedWakeRearm = { main.post { rearmGate() } }
        listener = Listener(
            ctx = this,
            onText = { engine.onHeard(it, true) },
            onPartial = { engine.onHeard(it, false) },
            // Fires the instant the recognizer detects the user has stopped talking, before the final
            // text is even ready, so the UI reacts right away instead of appearing to wait.
            onSpeechEnd = {
                if (AssistantState.status.value == "Listening…") AssistantState.status.value = "Thinking…"
            },
            onFatal = { msg ->
                stopVoice()
                AssistantState.status.value = msg
            }
        )
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopVoice()
            return START_NOT_STICKY
        }
        val n = buildNotification()
        try {
            if (Build.VERSION.SDK_INT >= 30) {
                startForeground(
                    NOTIF_ID, n,
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE or ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION
                )
            } else {
                startForeground(NOTIF_ID, n)
            }
        } catch (e: Exception) {
            // Android refuses to (re)start a microphone service from the background. Fail quietly.
            AssistantState.voiceOn.value = false
            AssistantState.status.value = "Voice stopped. Tap VOICE to turn it back on."
            stopSelf()
            return START_NOT_STICKY
        }
        if (!listening) {
            listening = true
            acquireWake()
            AssistantState.voiceOn.value = true
            rearmGate()
            maps.start() // keep a cached location fresh in the background, offline, for "how far" questions
            BatteryTracker.setActive(this, BatteryTracker.TAG_VOICE, true)
            main.removeCallbacks(batterySampler)
            main.postDelayed(batterySampler, 2 * 60_000L)
        }
        // if Android kills the service to free memory, ask it to bring listening back
        return START_STICKY
    }

    /** Puts the microphone back into "waiting for the wake word" (or plain listening) state. */
    private fun rearmGate() {
        if (!listening) return
        val store = Store.get(this)
        listener.start()
        AssistantState.status.value = if (store.wakeWordEnabled) "Say “${store.wakeWordPhrase}”…" else "Listening…"
    }

    private fun stopVoice() {
        listening = false
        listener.stop()
        maps.stop()
        engine.stopSpeaking()
        main.removeCallbacks(batterySampler)
        BatteryTracker.setActive(this, BatteryTracker.TAG_VOICE, false)
        releaseWake()
        AssistantState.voiceOn.value = false
        AssistantState.status.value = "Voice off"
        AssistantState.heard.value = ""
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        listener.stop()
        maps.stop()
        main.removeCallbacks(batterySampler)
        BatteryTracker.setActive(this, BatteryTracker.TAG_VOICE, false)
        releaseWake()
        AssistantState.voiceOn.value = false
        super.onDestroy()
    }

    private fun acquireWake() {
        if (wake?.isHeld == true) return
        val pm = getSystemService(PowerManager::class.java)
        wake = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "novochron:voice").apply {
            setReferenceCounted(false)
            acquire(12 * 60 * 60 * 1000L)
        }
    }

    private fun releaseWake() {
        try { if (wake?.isHeld == true) wake?.release() } catch (e: Exception) { }
        wake = null
    }

    private fun buildNotification(): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH, "Novochron voice", NotificationManager.IMPORTANCE_LOW))
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val stop = PendingIntent.getService(
            this, 1, Intent(this, AssistantService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CH)
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle("Novochron is listening")
            .setContentText("Say “stop listening” or tap Turn off")
            .setContentIntent(open)
            .addAction(0, "Turn off", stop)
            .setOngoing(true)
            .build()
    }

    companion object {
        const val ACTION_STOP = "com.novochron.assistant.STOP"
        private const val CH = "novochron_voice"
        private const val NOTIF_ID = 42
    }
}
