package com.atlas.assistant

import android.content.Context
import java.io.File

/**
 * Mirrors the artifacts library (the `artifacts` table in novochron.db - see [Store.addArtifact]) out
 * to plain .html files under Novochron/Library/, one per artifact. Same idea as Knowledge/Maps (see
 * KnowledgeStore.kt): visible in any file manager, easy to open, share or back up on its own, and -
 * since [CloudSync] already mirrors everything under [NovochronStorage.root] - it rides along with
 * chats, memory, photos and the rest to whatever repo the phone is synced to, no separate sync path
 * needed.
 *
 * This is a write-through mirror, not a second source of truth: the database stays the one place the
 * app actually reads ids/titles/html from. Every save/delete here just keeps the on-disk copy in step;
 * a failure to write is never allowed to block the database save.
 */
object LibraryStore {

    private fun dir(ctx: Context): File {
        val d = if (NovochronStorage.hasAccess() && NovochronStorage.ensureDirs()) NovochronStorage.libraryDir()
        else File(ctx.filesDir, "Library")
        try { d.mkdirs() } catch (e: Exception) { }
        return d
    }

    private fun slug(title: String): String {
        val cleaned = title.trim().lowercase().replace(Regex("[^a-z0-9]+"), "-").trim('-')
        return cleaned.ifBlank { "artifact" }.take(60)
    }

    /** id comes first in the filename so [forget] can find a saved artifact's file even after its title changes. */
    private fun fileFor(ctx: Context, id: Long, title: String): File = File(dir(ctx), "$id-${slug(title)}.html")

    /** Writes (or overwrites) the on-disk copy of one artifact. */
    @Synchronized
    fun save(ctx: Context, id: Long, title: String, html: String) {
        try {
            forget(ctx, id)   // drop any older file for this id first, in case the title differs now
            fileFor(ctx, id, title).writeText(html)
        } catch (e: Exception) { }
    }

    /** Removes the on-disk copy for [id], whatever title it was last saved under. */
    @Synchronized
    fun forget(ctx: Context, id: Long) {
        val prefix = "$id-"
        try {
            dir(ctx).listFiles { f -> f.isFile && f.name.startsWith(prefix) && f.name.endsWith(".html") }
                ?.forEach { try { it.delete() } catch (e: Exception) { } }
        } catch (e: Exception) { }
    }

    /** Removes every on-disk copy except for [keepIds] - keeps Library/ in step with Store's own 100-item cap. */
    @Synchronized
    fun pruneTo(ctx: Context, keepIds: Set<Long>) {
        try {
            dir(ctx).listFiles { f -> f.isFile && f.name.endsWith(".html") }?.forEach { f ->
                val id = f.name.substringBefore('-').toLongOrNull()
                if (id == null || id !in keepIds) try { f.delete() } catch (e: Exception) { }
            }
        } catch (e: Exception) { }
    }
}
