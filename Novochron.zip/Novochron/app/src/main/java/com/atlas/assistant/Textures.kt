package com.atlas.assistant

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import kotlin.math.PI
import kotlin.math.asin
import kotlin.math.atan2
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/**
 * Planet textures, the Milky Way and the deep-space backdrop, all loaded from `assets/textures/`.
 *
 * The images that ship in the app are procedurally generated (no downloads, no licences to track).
 * To use real photographic maps instead, drop files with the SAME names into `assets/textures/`
 * (equirectangular, 2:1, jpg/png/webp): earth, mars, mercury, moon, venus, jupiter, saturn, uranus,
 * neptune, sun, reddwarf, ice, milkyway, space, plus rings.png (a left-to-right strip of the ring
 * profile). Nothing in the code needs to change.
 *
 * A texture is mapped onto a sphere once per (texture, size, spin step) and cached, so a frame only
 * ever draws a ready-made bitmap. If a file is missing, callers fall back to the old gradient shading.
 */
object Textures {

    private val bitmaps = HashMap<String, Bitmap>()
    private val texPixels = HashMap<String, IntArray>()
    private val missing = HashSet<String>()
    private val sphereCache = HashMap<String, ImageBitmap>()
    private val imageCache = HashMap<String, ImageBitmap>()
    private var ringStops: List<Pair<Float, Color>>? = null

    const val SPIN_STEPS = 24

    @Synchronized
    fun bitmap(ctx: Context, name: String): Bitmap? {
        bitmaps[name]?.let { return it }
        if (name in missing) return null
        for (ext in arrayOf("jpg", "png", "webp")) {
            try {
                ctx.applicationContext.assets.open("textures/$name.$ext").use { stream ->
                    val bmp = BitmapFactory.decodeStream(stream)
                    if (bmp != null) {
                        bitmaps[name] = bmp
                        return bmp
                    }
                }
            } catch (e: Exception) {
                // try the next extension
            }
        }
        missing.add(name)
        return null
    }

    /** Whole-image version for backgrounds (Milky Way, space). Null if the file isn't there. */
    @Synchronized
    fun image(ctx: Context, name: String): ImageBitmap? {
        imageCache[name]?.let { return it }
        val bmp = bitmap(ctx, name) ?: return null
        val img = bmp.asImageBitmap()
        imageCache[name] = img
        return img
    }

    /** Loads everything up front (call off the main thread) so the first frames don't hitch. */
    fun preload(ctx: Context) {
        val names = listOf(
            "milkyway", "space", "sun", "mercury", "venus", "earth", "mars", "jupiter", "saturn",
            "uranus", "neptune", "reddwarf", "ice", "rings"
        )
        names.forEach { bitmap(ctx, it) }
    }

    /** Which texture file a body uses, or null for none (comets, unknown). */
    fun nameFor(b: OrbitMath.Body): String? {
        if (b.isComet) return null
        when (b.name) {
            "Sun" -> return "sun"
            "Mercury" -> return "mercury"
            "Venus" -> return "venus"
            "Earth" -> return "earth"
            "Mars" -> return "mars"
            "Jupiter" -> return "jupiter"
            "Saturn" -> return "saturn"
            "Uranus" -> return "uranus"
            "Neptune" -> return "neptune"
        }
        return when (b.texture) {
            OrbitMath.Texture.SUN -> "sun"
            OrbitMath.Texture.RED_STAR -> "reddwarf"
            OrbitMath.Texture.ROCK -> "mercury"
            OrbitMath.Texture.VENUS -> "venus"
            OrbitMath.Texture.EARTH -> "earth"
            OrbitMath.Texture.MARS -> "mars"
            OrbitMath.Texture.GAS_BANDED -> "jupiter"
            OrbitMath.Texture.ICE -> "ice"
            OrbitMath.Texture.ICE_DARK -> "neptune"
            OrbitMath.Texture.COMET -> null
        }
    }

    /** Seconds per visual revolution — purely cosmetic (kept slow so nothing strobes at any sim speed). */
    private fun spinSeconds(name: String): Double = when (name) {
        "jupiter" -> 18.0
        "saturn" -> 20.0
        "sun" -> 60.0
        "venus" -> 90.0
        else -> 36.0
    }

    /** Current spin frame for [name], from the wall clock. */
    fun spinStep(name: String): Int {
        val secs = System.currentTimeMillis() / 1000.0
        val frac = (secs / spinSeconds(name)) % 1.0
        return (frac * SPIN_STEPS).toInt().coerceIn(0, SPIN_STEPS - 1)
    }

    /** The texture [name] wrapped onto a sphere of [size] x [size] pixels, turned by [step]. Null if the file is missing. */
    @Synchronized
    fun sphere(ctx: Context, name: String, step: Int, size: Int): ImageBitmap? {
        val key = "$name#$size#$step"
        sphereCache[key]?.let { return it }
        val src = bitmap(ctx, name) ?: return null
        val tw = src.width
        val th = src.height
        val px = texPixels.getOrPut(name) {
            IntArray(tw * th).also { src.getPixels(it, 0, tw, 0, 0, tw, th) }
        }
        val out = IntArray(size * size)
        val rot = 2.0 * PI * step / SPIN_STEPS
        val rr = (size - 1) / 2.0
        for (j in 0 until size) {
            val ny = (j - rr) / rr
            for (i in 0 until size) {
                val nx = (i - rr) / rr
                val d2 = nx * nx + ny * ny
                if (d2 > 1.0) continue
                val nz = sqrt(1.0 - d2)
                val lon = atan2(nx, nz) + rot
                val lat = asin(-ny)
                var u = lon / (2.0 * PI)
                u -= floor(u)
                val v = 0.5 - lat / PI
                val tx = min(tw - 1, (u * tw).toInt())
                val ty = min(th - 1, max(0, (v * th).toInt()))
                val c = px[ty * tw + tx]
                val a = if (d2 > 0.95) (((1.0 - d2) / 0.05) * 255).toInt().coerceIn(0, 255) else 255
                out[j * size + i] = (a shl 24) or (c and 0xFFFFFF)
            }
        }
        val bmp = Bitmap.createBitmap(out, size, size, Bitmap.Config.ARGB_8888)
        val img = bmp.asImageBitmap()
        sphereCache[key] = img
        return img
    }

    /** Colour stops for the ring gradient, sampled from rings.png (falls back to a plain tan). */
    @Synchronized
    fun ringGradientStops(ctx: Context, innerFrac: Float): List<Pair<Float, Color>> {
        ringStops?.let { return it }
        val list = ArrayList<Pair<Float, Color>>()
        list.add(0f to Color.Transparent)
        list.add((innerFrac - 0.002f) to Color.Transparent)
        val bmp = bitmap(ctx, "rings")
        val n = 24
        for (i in 0..n) {
            val f = i / n.toFloat()
            val stop = innerFrac + (1f - innerFrac) * f
            val c = if (bmp != null) {
                val x = min(bmp.width - 1, (f * bmp.width).toInt())
                val argb = bmp.getPixel(x, bmp.height / 2)
                Color(argb)
            } else Color(0xFFD2BE96).copy(alpha = 0.55f)
            list.add(min(stop, 0.9999f) to c)
        }
        list.add(1f to Color.Transparent)
        ringStops = list
        return list
    }
}

/** Milky Way panorama behind the scene. Orbiting the camera ([yaw], [pitch]) slides it, so it feels like a real backdrop. */
fun DrawScope.drawMilkyWay(img: ImageBitmap, yaw: Double, pitch: Double, alpha: Float = 1f) {
    val w = size.width
    val h = size.height
    val dh = h * 1.7f
    val dw = dh * 2f
    val frac = ((yaw / (2 * PI)) % 1.0 + 1.0) % 1.0
    val ox = (-frac * dw).toFloat()
    val oy = (h - dh) / 2f + (pitch * dh * 0.22).toFloat()
    rotate(degrees = -18f, pivot = Offset(w / 2f, h / 2f)) {
        var x = ox
        while (x < w * 1.6f) {
            if (x + dw > -w * 0.6f) {
                drawImage(
                    image = img,
                    srcOffset = IntOffset.Zero,
                    srcSize = IntSize(img.width, img.height),
                    dstOffset = IntOffset(x.toInt(), oy.toInt()),
                    dstSize = IntSize(dw.toInt(), dh.toInt()),
                    alpha = alpha,
                    filterQuality = FilterQuality.Low
                )
            }
            x += dw
        }
        x = ox - dw
        while (x + dw > -w * 0.6f) {
            drawImage(
                image = img,
                srcOffset = IntOffset.Zero,
                srcSize = IntSize(img.width, img.height),
                dstOffset = IntOffset(x.toInt(), oy.toInt()),
                dstSize = IntSize(dw.toInt(), dh.toInt()),
                alpha = alpha,
                filterQuality = FilterQuality.Low
            )
            x -= dw
        }
    }
}

/** Static deep-space backdrop (dark nebula tint + stars), stretched to cover the canvas. */
fun DrawScope.drawSpaceBackdrop(img: ImageBitmap, alpha: Float = 1f) {
    drawImage(
        image = img,
        srcOffset = IntOffset.Zero,
        srcSize = IntSize(img.width, img.height),
        dstOffset = IntOffset.Zero,
        dstSize = IntSize(size.width.toInt().coerceAtLeast(1), size.height.toInt().coerceAtLeast(1)),
        alpha = alpha,
        filterQuality = FilterQuality.Low
    )
}

/** A soft glowing dot — used for stars, planets in the sky view, and the Sun's halo. */
fun DrawScope.drawGlow(center: Offset, radius: Float, color: Color, alpha: Float = 1f) {
    drawCircle(
        brush = Brush.radialGradient(
            colors = listOf(color.copy(alpha = 0.9f * alpha), color.copy(alpha = 0.25f * alpha), Color.Transparent),
            center = center, radius = radius
        ),
        radius = radius, center = center
    )
}

@Suppress("unused")
private val unusedSize = Size.Zero
