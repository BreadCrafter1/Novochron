package com.atlas.assistant

import android.content.Context
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import kotlin.math.asin
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin

/**
 * `[sat]` — a live ground-track map: the real ISS position (polled from wheretheiss.at) and the
 * current Starlink shell (propagated from real Celestrak TLE elements with a simplified circular-orbit
 * Kepler model — same "real numbers, simplified physics" spirit as [OrbitMath.hohmannTransfer]: it
 * ignores J2 nodal precession and drag, which is fine for a snapshot of a near-circular LEO shell but
 * would drift over days).
 */
private object SatNet {
    private fun get(url: String): String {
        val conn = URL(url).openConnection() as HttpURLConnection
        return try {
            conn.requestMethod = "GET"
            conn.connectTimeout = 12000
            conn.readTimeout = 15000
            conn.setRequestProperty("Accept", "application/json")
            conn.setRequestProperty("User-Agent", "Novochron/1.0")
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            stream?.bufferedReader()?.use { it.readText() } ?: ""
        } finally {
            conn.disconnect()
        }
    }

    /** Real-time ISS lat/lon/alt from wheretheiss.at (NORAD 25544). */
    fun fetchIss(): SatPoint? = try {
        val j = JSONObject(get("https://api.wheretheiss.at/v1/satellites/25544"))
        SatPoint(
            "ISS", j.getDouble("latitude"), j.getDouble("longitude"),
            j.getDouble("altitude"), j.getDouble("velocity")
        )
    } catch (e: Exception) { null }

    /** Current active Starlink GP (general-perturbations) elements from Celestrak, JSON format. */
    fun fetchStarlinkElements(): List<Tle> = try {
        val arr = JSONArray(get("https://celestrak.org/NORAD/elements/gp.php?GROUP=starlink&FORMAT=json"))
        (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            Tle(
                name = o.optString("OBJECT_NAME", "Starlink"),
                epochIso = o.getString("EPOCH"),
                incDeg = o.getDouble("INCLINATION"),
                raanDeg = o.getDouble("RA_OF_ASC_NODE"),
                eccentricity = o.getDouble("ECCENTRICITY"),
                argPerigeeDeg = o.getDouble("ARG_OF_PERICENTER"),
                meanAnomalyDeg = o.getDouble("MEAN_ANOMALY"),
                meanMotionRevPerDay = o.getDouble("MEAN_MOTION")
            )
        }
    } catch (e: Exception) { emptyList() }
}

private data class SatPoint(val name: String, val latDeg: Double, val lonDeg: Double, val altKm: Double, val speedKms: Double)

/** Minimal orbital elements pulled from a Celestrak GP/JSON record — enough for a circular-orbit ground track. */
private data class Tle(
    val name: String, val epochIso: String, val incDeg: Double, val raanDeg: Double,
    val eccentricity: Double, val argPerigeeDeg: Double, val meanAnomalyDeg: Double, val meanMotionRevPerDay: Double
)

/** Days since J2000.0 for an ISO-8601 UTC timestamp like "2024-05-20T12:34:56.789696". */
private fun isoToJ2000Days(iso: String): Double {
    val t = java.time.Instant.parse(if (iso.endsWith("Z")) iso else "${iso}Z")
    return (t.toEpochMilli() / 86_400_000.0) - 10957.5
}

/**
 * Propagates a near-circular [Tle] to [tDays] (days since J2000) and returns its geographic lat/lon.
 * u = argument of latitude (perigee + mean anomaly, valid since e is tiny for Starlink); the orbital
 * plane (inclination + RAAN) is rotated to Earth-Centred-Inertial, then Earth's own rotation (GMST) is
 * subtracted to turn ECI longitude into ground-track longitude.
 */
private fun propagate(tle: Tle, tDays: Double): Pair<Double, Double> {
    val epochDays = isoToJ2000Days(tle.epochIso)
    val dtDays = tDays - epochDays
    val u = Math.toRadians((tle.argPerigeeDeg + tle.meanAnomalyDeg + 360.0 * tle.meanMotionRevPerDay * dtDays) % 360.0)
    val inc = Math.toRadians(tle.incDeg)
    val raan = Math.toRadians(tle.raanDeg)
    val x = cos(raan) * cos(u) - sin(raan) * sin(u) * cos(inc)
    val y = sin(raan) * cos(u) + cos(raan) * sin(u) * cos(inc)
    val z = sin(u) * sin(inc)
    val lat = Math.toDegrees(asin(z.coerceIn(-1.0, 1.0)))
    val raDeg = (Math.toDegrees(atan2(y, x)) + 360.0) % 360.0
    // GMST at tDays (days since J2000.0), degrees — Earth's rotation, so ECI longitude -> ground longitude.
    val gmst = (280.46061837 + 360.98564736629 * tDays) % 360.0
    var lon = raDeg - gmst
    lon = ((lon + 180.0) % 360.0 + 360.0) % 360.0 - 180.0
    return lat to lon
}

private const val STARLINK_SAMPLE = 220 // plotted subset of the ~7000+ active satellites, for a readable map

@Composable
internal fun SatTab() {
    val ctx = LocalContext.current
    var iss by remember { mutableStateOf<SatPoint?>(null) }
    var issTrail by remember { mutableStateOf(listOf<Pair<Double, Double>>()) }
    var elements by remember { mutableStateOf(listOf<Tle>()) }
    var starlinkPts by remember { mutableStateOf(listOf<Pair<Double, Double>>()) }
    var status by remember { mutableStateOf("connecting…") }
    var selected by remember { mutableStateOf<String?>(null) }
    var showStarlink by remember { mutableStateOf(true) }

    // ISS: poll the real live position every 5s and keep a short ground-track trail.
    LaunchedEffect(Unit) {
        while (true) {
            val p = withContext(Dispatchers.IO) { SatNet.fetchIss() }
            if (p != null) {
                iss = p
                issTrail = (issTrail + (p.latDeg to p.lonDeg)).takeLast(120)
                status = "live"
            } else if (iss == null) {
                status = "couldn't reach wheretheiss.at — check network settings"
            }
            delay(5000)
        }
    }

    // Starlink: fetch the real TLE set once, then re-propagate the plotted sample every 5s (cheap — no refetch).
    LaunchedEffect(Unit) {
        val all = withContext(Dispatchers.IO) { SatNet.fetchStarlinkElements() }
        if (all.isNotEmpty()) {
            val step = max(1, all.size / STARLINK_SAMPLE)
            elements = all.filterIndexed { i, _ -> i % step == 0 }
        }
        while (true) {
            if (elements.isNotEmpty()) {
                val tDays = OrbitMath.todayDays()
                starlinkPts = elements.map { propagate(it, tDays) }
            }
            delay(5000)
        }
    }

    Column(Modifier.fillMaxSize().padding(top = 4.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("[sat]", color = Accent, fontFamily = TermFont, fontSize = 13.sp)
            Spacer(Modifier.width(10.dp))
            Text(
                if (iss != null) "ISS ${"%.1f".format(iss!!.latDeg)}°, ${"%.1f".format(iss!!.lonDeg)}° · ${iss!!.altKm.toInt()} km · ${"%.2f".format(iss!!.speedKms)} km/s"
                else status,
                color = Dim, fontFamily = TermFont, fontSize = 11.sp
            )
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            TermTextKey(
                if (showStarlink) "[starlink: on]" else "[starlink: off]",
                tone = if (showStarlink) Accent else Dim,
                onClick = { showStarlink = !showStarlink }
            )
            Spacer(Modifier.width(10.dp))
            Text(
                if (elements.isEmpty()) "loading Starlink elements…" else "plotting ${starlinkPts.size} of ${elements.size}+ active Starlink sats",
                color = Dim, fontFamily = TermFont, fontSize = 10.sp
            )
        }
        Box(
            Modifier
                .fillMaxWidth()
                .weight(1f)
                .padding(top = 6.dp)
                .border(1.dp, Line)
        ) {
            WorldMap(
                ctx = ctx,
                iss = iss,
                issTrail = issTrail,
                starlink = if (showStarlink) starlinkPts else emptyList(),
                onTapIss = { selected = if (selected == "ISS") null else "ISS" }
            )
            selected?.let { name ->
                if (name == "ISS" && iss != null) {
                    Text(
                        "ISS — ${iss!!.altKm.toInt()} km altitude, ${(iss!!.speedKms * 3600).toInt()} km/h",
                        color = Ink, fontFamily = TermFont, fontSize = 11.sp,
                        modifier = Modifier.align(Alignment.BottomStart).padding(8.dp)
                    )
                }
            }
        }
        Text(
            "ISS position is live (polled every 5s). Starlink is propagated from real Celestrak orbital elements " +
                "with a simplified circular-orbit model — a snapshot of the shell, not a precise per-satellite prediction.",
            color = Dim, fontFamily = TermFont, fontSize = 10.sp, modifier = Modifier.padding(top = 4.dp)
        )
    }
}

private fun max(a: Int, b: Int) = if (a > b) a else b

@Composable
private fun WorldMap(
    ctx: Context,
    iss: SatPoint?,
    issTrail: List<Pair<Double, Double>>,
    starlink: List<Pair<Double, Double>>,
    onTapIss: () -> Unit
) {
    val earth = remember { Textures.image(ctx, "earth") }
    Canvas(
        Modifier
            .fillMaxSize()
            .pointerInput(iss) {
                detectTapGestures { onTapIss() }
            }
    ) {
        val w = size.width; val h = size.height
        fun toXY(latDeg: Double, lonDeg: Double): Offset {
            val x = ((lonDeg + 180.0) / 360.0) * w
            val y = ((90.0 - latDeg) / 180.0) * h
            return Offset(x.toFloat(), y.toFloat())
        }

        drawRect(Color(0xFF02030A))
        if (earth != null) {
            drawImage(
                image = earth,
                srcOffset = androidx.compose.ui.unit.IntOffset.Zero,
                srcSize = androidx.compose.ui.unit.IntSize(earth.width, earth.height),
                dstOffset = androidx.compose.ui.unit.IntOffset.Zero,
                dstSize = androidx.compose.ui.unit.IntSize(w.toInt().coerceAtLeast(1), h.toInt().coerceAtLeast(1)),
                alpha = 0.55f
            )
        }
        // lat/lon grid
        for (i in 1..7) {
            val x = w * i / 8f
            drawLine(Color(0x22FFFFFF), Offset(x, 0f), Offset(x, h), strokeWidth = 1f)
        }
        for (i in 1..3) {
            val y = h * i / 4f
            drawLine(Color(0x22FFFFFF), Offset(0f, y), Offset(w, y), strokeWidth = 1f)
        }
        drawLine(Color(0x553DFF5C), Offset(0f, h / 2f), Offset(w, h / 2f), strokeWidth = 1.2f) // equator

        // Starlink scatter
        starlink.forEach { (lat, lon) ->
            drawCircle(Color(0xFF5C7CFF).copy(alpha = 0.7f), radius = 1.6f, center = toXY(lat, lon))
        }

        // ISS ground-track trail
        var prev: Offset? = null
        issTrail.forEach { (lat, lon) ->
            val p = toXY(lat, lon)
            if (prev != null && kotlin.math.abs(p.x - prev!!.x) < w * 0.6f) {
                drawLine(Color(0xAAFFD84A), prev!!, p, strokeWidth = 1.6f)
            }
            prev = p
        }

        // ISS marker
        iss?.let {
            val p = toXY(it.latDeg, it.lonDeg)
            drawCircle(Color(0x66FFD84A), radius = 12f, center = p)
            drawCircle(Color(0xFFFFD84A), radius = 5f, center = p, style = Stroke(width = 2f))
            drawCircle(Color(0xFFFFD84A), radius = 3f, center = p)
            drawContext.canvas.nativeCanvas.drawText(
                "ISS", p.x + 10f, p.y - 8f,
                android.graphics.Paint().apply {
                    color = android.graphics.Color.argb(230, 255, 216, 74)
                    textSize = 26f
                    isAntiAlias = true
                }
            )
        }
    }
}
